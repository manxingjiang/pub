官方版本基础上做了如下修改

# 模板js,css,img路径替换
ThinkPHP3.2.2/Library/Think/Template.class.php

# 改成gbk编码
ThinkPHP3.2.2/Tpl/think_exception.tpl

# 新增了一些常量定义
ThinkPHP3.2.2/ThinkPHP.php

# 为配合ShareTest做了一些调整
ThinkPHP3.2.2/Library/Think/Think.class.php




#Thrift 分词  原框架第三方插件
/opt/webroot/findlaw.cn/Common/FrameWork/ThinkPHP3.2.2/Library/Vendor/Thrift/
