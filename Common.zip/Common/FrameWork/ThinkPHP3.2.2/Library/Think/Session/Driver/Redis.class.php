<?php

/**
 *  +----------------------------------------------------------------------
 *  | ThinkPHP [ WE CAN DO IT JUST THINK IT ]
 *  +----------------------------------------------------------------------
 *  | Copyright (c) 2006-2013 http://thinkphp.cn All rights reserved.
 *  +----------------------------------------------------------------------
 *  | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
 *  +----------------------------------------------------------------------
 *  | @author YateSun <sunyate@wanglv.com>
 *  +----------------------------------------------------------------------
 *  | @datetime 2017-04-20 14:35:00
 *  +---------------------------------------------------------------------- 
 */

namespace Think\Session\Driver;

/**
 * Redis Session驱动 
 * 要求安装phpredis扩展：https://github.com/nicolasff/phpredis
 * @category   Think
 * @package  Session
 * @subpackage  Driver
 * @author YateSun <sunyate@wanglv.com>
 * @version   TP3.2~TP3.2.1
  +------------------------------------------------------------------------------
 */
class Redis {
    
    /**
     * Redis句柄
     */
    private $handler;
    private $get_result;

    public function __construct(){
        if ( !extension_loaded('redis') ) {
            return false;
            //E(L('_NOT_SUPPERT_').':redis');
        }
        if(empty($options)) {
            $options = array (
                'host'          => C('SESSION_REDIS_HOST') ? C('SESSION_REDIS_HOST') : array('127.0.0.1'),
                'port'          => C('SESSION_REDIS_PORT') ? C('SESSION_REDIS_PORT') : 6522,
                'timeout'       => C('SESSION_CACHE_TIME') ? C('SESSION_CACHE_TIME') : false,
                'persistent'    => C('SESSION_PERSISTENT') ? C('SESSION_PERSISTENT') : false,
                'auth'          => C('SESSION_REDIS_AUTH') ? C('SESSION_REDIS_AUTH') : false,
            );
        }

        $this->options =  $options;
        $expire = C('SESSION_EXPIRE');
        $this->options['expire'] =  isset($expire) ? (int)$expire : (int)ini_get('session.gc_maxlifetime');;
        $this->options['prefix'] =  isset($options['prefix']) ?  $options['prefix']  :   C('SESSION_PREFIX');
        $this->handler  = new \Redis;
    }

    /**
     * 连接Redis服务端
     * @access public
     * @param  string $session_id : session分片依据
     */
    public function connect($session_id) {
        $count = count($this->options['host']);
        if ($count) {
            $i = crc32($session_id)%$count;
        } else {
            return false;
        }
        $func = $this->options['persistent'] ? 'pconnect' : 'connect';
        try {
            if ($this->options['timeout'] === false) {
                $result = $this->handler->$func($this->options['host'][$i], $this->options['port']);
                if (!$result)
                    return false;
                    //throw new \Think\Exception('Redis Error', 100);
            } else {
                $result = $this->handler->$func($this->options['host'][$i], $this->options['port'], $this->options['timeout']);
                if (!$result)
                    return false;
                    //throw new \Think\Exception('Redis Error', 101);
            }
            if ($this->options['auth'][$i]) {
                $result = $this->handler->auth($this->options['auth'][$i]);
                if (!$result) {
                    return false;
                    //throw new \Think\Exception('Redis Error', 102);
                }
            }
        } catch ( \Exception $e ) {
            return false;
            //exit('Error Message:'.$e->getMessage().'<br>Error Code:'.$e->getCode().'');
        }
    }
    
    /**
      +----------------------------------------------------------
     * 打开Session 
      +----------------------------------------------------------
     * @access public 
      +----------------------------------------------------------
     * @param string $savePath 
     * @param mixed $sessName  
      +----------------------------------------------------------
     */
    public function open($savePath, $sessName) {
        return true;
    }
    
    /**
      +----------------------------------------------------------
     * 关闭Session 
      +----------------------------------------------------------
     * @access public 
      +----------------------------------------------------------
     */
    public function close() {
        if ($this->options['persistent'] == 'pconnect') {
            $this->handler->close();
        }
        return true;
    }

    /**
      +----------------------------------------------------------
     * 读取Session 
      +----------------------------------------------------------
     * @access public 
      +----------------------------------------------------------
     * @param string $sessID 
      +----------------------------------------------------------
     */
    public function read($sessID) {
        if ($this->connect($this->options['prefix'].$sessID) === false) {
            return false;
        }
        try {
            $this->get_result = false;
            $this->get_result = $this->handler->get($this->options['prefix'].$sessID);
            $expire  =  $this->options['expire'];
            if($this->get_result && is_int($expire) && $expire > 0) {
                $this->handler->expire($this->options['prefix'].$sessID, $expire);
            }
        } finally {
            return $this->get_result;
        }
    }

    /**
      +----------------------------------------------------------
     * 写入Session 
      +----------------------------------------------------------
     * @access public 
      +----------------------------------------------------------
     * @param string $sessID 
     * @param String $sessData  
      +----------------------------------------------------------
     */
    public function write($sessID, $sessData) {
        if (!$sessData || $sessData == $this->get_result) {
            return true;
        }
        if($this->connect($this->options['prefix'].$sessID) === false) {
            return false;
        }
        try {
            $result = false;
            $expire  =  $this->options['expire'];
            $sessID   =   $this->options['prefix'].$sessID;
            if(is_int($expire) && $expire > 0) {
                $result = $this->handler->setex($sessID, $expire, $sessData);
                $result = $result ? 'true' : 'false';
            }else{
                 $result = $this->handler->set($sessID, $sessData);
                 $result = $result ? 'true' : 'false';
            }
        } finally {
            return $result;
        }
    }

    /**
      +----------------------------------------------------------
     * 删除Session 
      +----------------------------------------------------------
     * @access public 
      +----------------------------------------------------------
     * @param string $sessID 
      +----------------------------------------------------------
     */
    public function destroy($sessID) {
        $this->connect($this->options['prefix'].$sessID);
        return $this->handler->delete($this->options['prefix'].$sessID);
    }

    /**
      +----------------------------------------------------------
     * Session 垃圾回收
      +----------------------------------------------------------
     * @access public 
      +----------------------------------------------------------
     * @param string $sessMaxLifeTime 
      +----------------------------------------------------------
     */
    public function gc($sessMaxLifeTime) {
        return true;
    }

    /**
      +----------------------------------------------------------
     * 打开Session 
      +----------------------------------------------------------
     * @access public 
      +----------------------------------------------------------
     * @param string $savePath 
     * @param mixed $sessName  
      +----------------------------------------------------------
     */
    public function execute() {
        session_set_save_handler(
                array(&$this, "open"),
                array(&$this, "close"),
                array(&$this, "read"),
                array(&$this, "write"),
                array(&$this, "destroy"),
                array(&$this, "gc")
        );
    }
    
    public function __destruct() {
        if ($this->options['persistent'] == 'pconnect') {
            $this->handler->close();
        }
        session_write_close();
    }

}

