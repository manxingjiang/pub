<?php
/**
 *  ����������
 *
 *  @author zsg <xx@qq.com>
 */
/**
 *  ������
 *
 *  @author zsg <xx@qq.com>
 */
class Share
{
    public static $objarr = array();
    protected $projectname = '';
    protected $modulename = '';
    protected $currentproject = false;
    protected $moduleobj = null;
    
    /**
     *  ��ȡ����ģ��
     *
     *  @return null
     */
    public static function module($projectmodule='')
    {
        if ($projectmodule == '') {
            die('error 01');
        }
        $arr = explode('.', $projectmodule);
        $arrlen = count($arr);
        if ($arrlen != 1 && $arrlen !=2) {
            die('error 02');
        }
        if ($arrlen == 1) {
            if (!defined('APP_NAME')) {
                die('you must define APP_NAME!');
            }
            $projectname = APP_NAME;
            $modulename = $arr[0];
            return self::ins($projectname, $modulename, true);
        } else {
            $projectname = $arr[0];
            $modulename = $arr[1];
            return self::ins($projectname, $modulename, false);
        }
    }
    
    /**
     *  ��ȡ����ʵ��
     *
     *  @return null
     */
    public static function ins($projectname, $modulename, $currentproject)
    {
        $key = $projectname.'.'.$modulename;
        if (!isset(self::$objarr[$key])) {
            self::$objarr[$key] = new Share($projectname, $modulename, $currentproject);
            if ($currentproject) {
                $sharepath = APP_PATH . 'Share/'. $projectname;
            } else {
                $sharepath = COMMON_PATH . 'Share/'. $projectname;
            }
            require_once($sharepath . '/'.$modulename.'Share.class.php');
        }
        return self::$objarr[$key];
    }
    
    /**
     *  init
     *
     *  @return null
     */
    public function __construct($projectname, $modulename, $currentproject)
    {
        $this->projectname = $projectname;
        $this->modulename = $modulename;
        $this->currentproject = $currentproject;
    }
    
    /**
     *  ���÷���
     *
     *  @return null
     */
    public function __call($func, $args)
    {
        if ($this->moduleobj == null) {
            $classname = sprintf('\Share\%s\%sShare', $this->projectname, $this->modulename);
            $this->moduleobj = new $classname();
        }
        $timestart = microtime(true);
        $result = call_user_func_array(array($this->moduleobj, $func), $args);
        $timeend = microtime(true);
        $spendtime = number_format(($timeend - $timestart)*1000, 4, '.', ''); //'����'
        
        ShareUnit::unitTestPrint($this->projectname.'.'.$this->modulename, $func, $args, $spendtime, $result);
        return $result;
    }
}

class ShareUnit
{
    /**
     *  �Ƿ�Ԫ����
     *
     *  @return null
     */
    public static function isUnitTest()
    {
        return defined("APP_UNIT_TEST");
    }
    
    /**
     *  �����Ԫ��������
     *
     *  @return null
     */
    public static function unitTestPrint($callmodule, $func, $args, $spendtime, $result)
    {
        if (!self::isUnitTest()) {
            return;
        }
        echo "\n".'<br><font style="background-color:#eee">' . sprintf('Test mothod: %s.%s', $callmodule, $func) . '</font>';
        echo "\n".'<br> args: ' . var_export($args, true);
        echo "\n".'<br> spentime: ' . $spendtime . ' msec';
        echo "\n".'<br> result: ' . var_export($result, true) . '';
        echo "\n\n".'<br><br>';  
        /*     
        echo "\n".sprintf('Test mothod: %s.%s', $callmodule, $func);
        if (defined("APP_UNIT_TEST_ARGS")) echo "\n".' args: ' . var_export($args, true);
        echo "\n".' spentime: ' . $spendtime . ' msec';
        if (defined("APP_UNIT_TEST_RESULTS")) echo "\n".' result: ' . var_export($result, true) . '';
        echo "\n\n".'';*/
    }
}
