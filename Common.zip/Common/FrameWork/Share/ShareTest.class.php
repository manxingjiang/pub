<?php
/**
 *  ���������
 *
 *  @author zsg <xx@qq.com>
 */

/**
 *  ���������
 *
 *  @author zsg <xx@qq.com>
 */
class ShareTest
{
    public static function init($class)
    {
        //��������ִ��
        if (isset($_SERVER['SERVER_ADDR']) && $_SERVER['SERVER_ADDR'] != '127.0.0.1') {
            $arr = explode('.', $_SERVER['SERVER_ADDR']);
            if ($arr[0].'.'.$arr[1] != '192.168') {
                die('403 error');
            }
        } 
        if (!isset($_SERVER['SERVER_ADDR'])) {
            $_SERVER['SERVER_ADDR'] = '127.0.0.1';
        }
        
        require_once(APP_PATH . 'ShareTest/'.$class.'.class.php');
    }

    public static function run($class)
    {
        self::init($class);
        if (class_exists($class)) {
            $reflector = new ReflectionClass($class);
            $ref_instance = $reflector->newInstance();
            $methods = $reflector->getMethods();
            //$methodlist = array();
            foreach ($methods as $method) {
                //ȥ��˽�з���
                if ($method->isPrivate()) {
                    continue;
                }
                //ȥ�����෽��
                if ($method->getDeclaringClass()->getName() != $reflector->getName()) {
                    continue;
                }
                $methodName = $method->getName();

                echo '============' . $methodName . " ========== start<br>\n";
                echo sprintf("%s : %s<br/>\n", $methodName, $method->invoke($ref_instance));
                echo '============' . $methodName . " ========== end<br><br>\n";
            }
        } else {
            die('class '.$class.' not found');
        }
    }
    
    public function assertTrue($a)
    {
        return $a ? $this->success() : $this->failed();
    }
    public function assertFalse($a)
    {
        return $a ? $this->failed() : $this->success();
    }
    public function success()
    {
        return '<font color="green">success</font>';
    }
    public function failed()
    {
        return '<font color="red">failed</font>';
    }
}
