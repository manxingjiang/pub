<?php
/**
 *  �ҷ����������ļ�
 *  �������� ����ʱҪ���� �����������(* ���� ������Ϊ���� *)
 *  
 *  @author wrd <xx@qq.com>
 */
return array(
        //cms��
        'cms_config_db33506' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.111',
                'username' => 'phpcmsfl',
                'password' => 'Md8mdr5Lj6rT23',
                'hostport' => '33506',
                'database' => 'fl_system',
                'names'       => 'gbk',
                'cachetime'=> 86400
        ),
        'hb_config_db3307' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.115',
                'username' => 'gTqcweber3wqYne3',
                'password' => '3Tbdswer8Gwe23',
                'hostport' => '33579',
                'names'    => 'gbk',
                'database' => 'findlaw_db',
        ),
        //user_cloud_db ��
        'hb_config_db57789' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.115',
                'username' => 'ucWanYoutech',
                'password' => 'Yiplk987*Lopu&98Hm<',
                'hostport' => '57789',
                'names'    => 'gbk',
                'database' => 'user_cloud_db',
        ),
        //δ֪
        'hb_config_db3320' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.131',
                'username' => 'memiperaeiye',
                'password' => 'sasretoac0616',
                'hostport' => '3320',
                'names'    => 'gbk',
                'database' => 'tempsearch',
        ),
        //֪ʶר��� �ÿ� 2013���ֹͣ�����ˣ��в�ѯ
        'hb_config_db53318' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.111', //'192.168.1.104',
                'username' => 'gTqcweber3wqYne3',
                'password' => '3Tbdswer8Gwe23',
                'hostport' => '53318',
                'names'    => 'gbk',
                'database' => 'dede_news',
        ),
        //֪ʶר��� �ÿ� 2013���ֹͣ�����ˣ��в�ѯ
        'hb_config_db53319' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.111', //'192.168.1.104',
                'username' => 'gTqcweber3wqYne3',
                'password' => '3Tbdswer8Gwe23',
                'hostport' => '53319',
                'names'    => 'gbk',
                'database' => 'dede_news',
        ),
        'hb_config_dbSecondary' => array(
                'dbms'     => 'mysql',
                'hostname' =>  '192.168.1.114',  //'192.168.1.104', 81,109
                'hostname0' => '192.168.1.114',  //'192.168.1.104'
                'hostname1' => '192.168.1.114',  //'192.168.1.104', 118,12 142
                'hostname2' => '192.168.1.114',  //'192.168.1.104'
                'hostname3' => '192.168.1.114',  //'192.168.1.104', 12 142
                'username' => 'gTqcweber3wqYne3',
                'password' => '3Tbdswer8Gwe23',
                'hostport' => '33579',
                'names'    => 'gbk',
                'database' => 'findlaw_db',
        ),
        //δ֪
        'hb_config_db13306' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.20',
                'username' => 'phpcmsfl',
                'password' => 'Md8mdr5Lj6rT23',
                'hostport' => '31506',
                'names'    => 'gbk',
                'database' => 'fl_system',
        ),
        /*�Ҳ����ô�
        'sphinx_setting' => array(
                'hostname' => '',
                'hostport' => '',
        ),
        */
        //��ѯ����
        'hb_config_33603' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.115', //'192.168.1.119',
                'username' => 'asklvhai',
                'password' => 'LiweRweeQ4',
                'hostport' => '33879',
                'database' => 'fl_ask',
                'names'=>'gbk',
                'cachetime'=>86400,
        ),
        //��ѯ�ӿ�
        'db_fl_ask_slave' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.118',
                'username' => 'asklvhai',
                'password' => 'LiweRweeQ4',
                'hostport' => '33879',
                'database' => 'fl_ask',
                'names'=>'gbk',
                'cachetime'=>86400,
        ),
        //δ֪
        'hb_config_33601' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.140', //109
                'username' => 'flvitstat2012',
                'password' => 'u8po90908Gwe23',
                'hostport' => '43434',
                'database' => 'fl_visitstat',
                'names'=>'gbk',
                'cachetime'=>86400,
        ),
        //δ֪
        'hb_config_33599' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.140', //109
                'username' => 'flextend2012',
                'password' => '7yuIop908Gwe23',
                'hostport' => '43434',
                'database' => 'fl_extend',
                'names'=>'gbk',
                'cachetime'=>86400,
        ),
        //fcgi-cache
        'fcgi_cache_db_33666' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.115',
                'username' => 'MdeRMpd67Pwq9543',
                'password' => 'MjdRNmdr45Te23',
                'hostport' => '33666',
                'names'    => 'gbk',
                'database' => 'mcache',
                'names'       => 'gbk',
                'cachetime'=> 86400
        ),
        
        
        'product_config_db33605' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.114',
                'username' => 'wy_product',
                'password' => 'Fid2RfdLaw67HNb4',
                'hostport' => '33605',
                'database' => 'wy_product',
        ),        
        'product_config_db_tongji_diaodu' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.104',
                'username' => 'wyproductzsi',
                'password' => 'dEfkeddssed<lfK',
                'hostport' => '33606',
                'names'    => 'gbk',
                'database' => 'wy_product_zhanshi',
        ),
       'hb_config_ip33177' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.111',
                'username' => 'ipGis',
                'password' => 'Gis88HM3edcUH95@W',
                'hostport' => '33177',
                'names'    => 'gbk',
                'database' => 'ip_gis'
        ),
        //������
        'hb_config_33666' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.115',
                'username' => 'lsurl_cn',
                'password' => 'LS(56)UHGRFVG368gr',
                'hostport' => '33666',
                'database' => 'yun_ask',
                'names'=>'gbk',
                'cachetime'=>86400,
        ),
        
        //RPC
        'RPC_list_host' => array(
                '192.168.1.178:8080',
                //'192.168.1.178:8082',
        ),
        
        //PRC���
        'click_rpc_host' => array(
                '192.168.1.178:8090',
                //'192.168.1.178:8092',
        ),
        
        //������RPC
        'shortlink_rpc_host' => array('192.168.1.178:16080'),
        
        //�û�����
        'uc_rpc_host' => array(
                '192.168.1.178:18080',
        ),
        
        //����ʦ�ңУ�
        'hls_rpc_host'=> array('192.168.1.178:12080'),        

        //IP ��
        'IpSerMysqlHost' => '192.168.1.131:3320',
        
        //memcached
        'memcachecfginfo' => array(
                array('192.168.1.97', '61110')
        ),
        'redis_config' => array('192.168.1.87:6533', '192.168.1.101:6533', '192.168.1.104:6533', '192.168.1.108:6533'
        ),
        //session���� ����
        'SESSION_TYPE'          =>  'Redis',
        //�Ƿ�����
        'SESSION_PERSISTENT'    =>  0,
        //���ӳ�ʱʱ��(��)
        'SESSION_CACHE_TIME'    =>  1,
         //session��Ч��(��λ:��) 0��ʾ���û���
        'SESSION_EXPIRE'        =>  7200,
        //sessionǰ׺
        'SESSION_PREFIX'        =>  'Fl:Session:',
        //�ֲ�ʽRedis
        'SESSION_REDIS_HOST'    =>  array('192.168.1.108', '192.168.1.111'
        ),
        //Redis�˿�
        'SESSION_REDIS_PORT'    =>  '6522',
        //����//fl_findlaw_search���ݿ�����
        'hb_search_config' => array(
                'hb_search_host'=> '192.168.1.121',
                'hb_search_port'=>'6667',
                'DB_SESSION_CONFIG'=>array(
                        'host' => '192.168.1.115:33579',
                        'user' => 'gTqcweber3wqYne3',
                        'pwd'  => '3Tbdswer8Gwe23',
                        'db'   => 'fl_findlaw_search'
                )
        ),
        
       //CURLͼƬ�ϴ�ָ��������
        'curlconfig' => array(
                array('180.186.38.85',80)
        ),
        
        //�ִ�
        'dicthttpSever' => 'http://192.168.1.121:7779',        
        //thrift
        'thrift_host' => '192.168.1.121',
        'thrift_port' => 9090,        
        // Python�ӿ����ã���Ҫ���ڷֳ��ؼ���
        'RPC_THRIFT' => array(
            'SERVER' => array(
                array('192.168.1.121', 9090),
            ),
            'DEBUG'    => 1,
            'TOKEN'    => 'R4mm4O.me',
            'CLIENTID' => 1,
        ),
        //΢������ host
        'weixin_push_host' => 'http://china.findlaw.cn/'
);
