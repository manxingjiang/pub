<?php
/**
 *  �ҷ����������ļ�
 *  �������� ����ʱҪ���� �����������(* ���� ������Ϊ���� *)
 *  
 *  @author wrd <xx@qq.com>
 */
return array(
        'product_config_db33605' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.3.235',
                'username' => 'wypads',
                'password' => 'adslj89wYou',
                'hostport' => '33605',
                'database' => 'wy_product',
        ),
        
        'hb_config_ip33177' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.3.237',
                'username' => 'wypads',
                'password' => 'adslj89wYou',
                'hostport' => '33605',
                'names'    => 'gbk',
                'database' => 'ip_gis',
        ),
        
        'product_config_db_tongji_diaodu' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.3.235',
                'username' => 'wypads',
                'password' => 'adslj89wYou',
                'hostport' => '33605',
                'names'    => 'gbk',
                'database' => 'wy_product_zhanshi',
        ),
        //user_cloud_db ��
        'hb_config_db57789' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.216',
                'username' => 'user_cloud',
                'password' => 'YgFD762EWSXijh65',
                'hostport' => '57789',
                'names'    => 'gbk',
                'database' => 'user_cloud_db',
        ),
        'hb_config_db3307' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.216',
                'username' => 'gTqcweber3wqYne3',
                'password' => '3Tbdswer8Gwe23',
                'hostport' => '33579',
                'database' => 'findlaw_db',
        ),
        'hb_config_db3320' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.216',
                'username' => 'gTqcweber3wqYne3',
                'password' => '3Tbdswer8Gwe23',
                'hostport' => '33579',
                'database' => 'tempsearch',
        ),
        //ԭ 192.168.1.218:53319
        'hb_config_db53318' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.216',
                'username' => 'gTqcweber3wqYne3',
                'password' => '3Tbdswer8Gwe23',
                'hostport' => '53319',
                'database' => 'dede_news',
        ),
        'hb_config_db53319'  => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.218',
                'username' => 'gTqcweber3wqYne3',
                'password' => '3Tbdswer8Gwe23',
                'hostport' =>'53319',
                'database' => 'dede_news',
        ),
        'hb_config_db3323' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.219',
                'username' => 'findlaw_search',
                'password' => 'Ga8e3',
                'hostport' => '3323',
                'database' => 'findlaw_search',
        ),
        'sphinx_setting' => array(
                'hostname' => '192.168.1.218',
                'hostport' => '3316',
        ),
        //ԭ 192.168.1.218:33606
        'hb_config_db13306' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.216',
                'username' => 'phpcmsfl',
                'password' => 'Md8mdr5Lj6rT23',
                'hostport' => '33506',
                'database' => 'findlaw_search',
        ),
        'hb_config_dbSecondary' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.216',
                'hostname0' => '192.168.1.216',
                'hostname1' => '192.168.1.216',
                'hostname2' => '192.168.1.216',
                'hostname3' => '192.168.1.216',
                'username' => 'gTqcweber3wqYne3',
                'password' => '3Tbdswer8Gwe23',
                'hostport' => '33579',
                'database' => 'findlaw_db',
        ),
        'hb_config_219_cms33579' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.219',
                'username' => 'phpcmscha',
                'password' => 'Y219Li8B',
                'hostport' => '33579',
                'database' => 'findlaw_db',
        ),
        'cms_config_db33506' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.216',
                'username' => 'cms_web_33506',
                'password' => 'Co216MnTrU777VC',
                'hostport' => '33506',
                'database' => 'fl_system',
                'names'        => 'gbk',
                'cachetime'=>86400,
        ),
        //��ѯ����
        'hb_config_33603' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.216',
                'username' => 'dep_33879',
                'password' => 'iSrPqZt8Yt%8J',
                'hostport' => '33879',
                'database' => 'fl_ask',
                'names'=>'gbk',
                'cachetime'=>86400,
        ),
        //��ѯ�ӿ� ��������û�дӿ⣬�����������ú�����һ��
        'db_fl_ask_slave' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.216',
                'username' => 'dep_33879',
                'password' => 'iSrPqZt8Yt%8J',
                'hostport' => '33879',
                'database' => 'fl_ask',
                'names'=>'gbk',
                'cachetime'=>86400,
        ),
        //ԭ 192.168.1.218:33601
        'hb_config_33601' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.216',
                'username' => 'chensanxin',
                'password' => 'T8u9p2GH',
                'hostport' => '43434',
                'database' => 'fl_visitstat',
                'names'=>'gbk',
                'cachetime'=>86400,
        ),
        //ԭ 192.168.1.218:33599
        'hb_config_33599' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.216',
                'username' => 'chensanxin',
                'password' => 'T8u9p2GH',
                'hostport' => '43434',
                'database' => 'fl_extend',
                'names'=>'gbk',
                'cachetime'=>86400,
        ),
        'hb_config_27018' => array(
                'dbms'     => 'mongo',
                'hostname' => '192.168.1.151',
                'username' => 'CoMdbleirjer',
                'password' => 'fewjerker2345435',
                'hostport' => '27018',
                'database' => 'findlaw',
                'names'=>'utf8',
                'cachetime'=>86400,
        ),
        //������
        'hb_config_33666' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.216',
                'username' => 'lsurl',
                'password' => 'iSurPqZt216(393)',
                'hostport' => '33666',
                'database' => 'yun_ask',
                'names'=>'gbk',
                'cachetime'=>86400,
        ),
        //�����������Կ�
        'dong_db_config' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.4.72',
                'username' => 'wrd',
                'password' => '123456',
                'hostport' => '3307',
                'database' => 'fl_ask',
                'names'=>'gbk',
                'cachetime'=>86400,
        ),
        
        'memcachecfginfo' => array(
                array('192.168.1.217',  '61111'),
        ),
        'redis_config' => array('192.168.1.120:6577'
        ),
        //���ؿ���������ֹʹ�û���
        'nocache' => 1,

        //����PRC������
        'RPC_list_host' => array('192.168.3.235:8080'),
        //'RPC_list_host' => array('192.168.4.91:8080'), //����
        'click_rpc_host' => array('192.168.3.235:8080'),
        'shortlink_rpc_host' => array('192.168.3.235:16080'),
        'uc_rpc_host' => array('192.168.3.235:18080'),
        //'uc_rpc_host' => array('192.168.4.91:18080'),//����
        //����ʦ�ңУ�
        'hls_rpc_host' => array('192.168.3.235:12080'),
        //CURLͼƬ�ϴ�ָ��������
        'curlconfig' => array(
                array('192.168.1.217',80),
                //array('192.168.4.52',80)
        ),
        //����  //fl_findlaw_search���ݿ�����
        'hb_search_config' => array(
                'hb_search_host'=>'192.168.1.150',
                'hb_search_port'=>'6667',
                'DB_SESSION_CONFIG'=>array(
                        'host' => '192.168.1.216:33579',
                        'user' => 'gTqcweber3wqYne3',
                        'pwd'  => '3Tbdswer8Gwe23',
                        'db'   => 'fl_findlaw_search'
                )
        ),
        
        //thrift
        'thrift_host' => '192.168.3.234',
        'thrift_port' => 9099,
        
        //IP��
        'IpSerMysqlHost' => '192.168.1.216:33579',
        //���ķִ�
        'dicthttpSever' => 'http://192.168.1.149:7779',        
        'zhisouip' => '14.17.121.114',
        //����΢������ip
        'weixin_push_host' => 'http://183.233.131.155/',
        // Python�ӿ����ã���Ҫ���ڷֳ��ؼ���
        'RPC_THRIFT' => array(
            'SERVER' => array(
                array('192.168.1.150', 9090),
            ),
            'DEBUG'    => 1,
            'TOKEN'    => 'R4mm4O.me',
            'CLIENTID' => 1,
        ),
);
