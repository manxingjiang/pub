<?php
/**
 *  ���� ȫ�ֱ���  $_SERVER['SERVER_NODE'] --���������ڵ�)
 *  
 *  @author wrd <xx@qq.com>
 */


if (empty($_SERVER['SERVER_NODE'])) {
    $serverIP = isset($_SERVER['SERVER_ADDR'])?$_SERVER['SERVER_ADDR']:(isset($serverIP)?$serverIP:'14.17.121.112');
    //IPǰ����
    $iparr          = explode('.', $serverIP);
    $serverIP_3     = $iparr[0].'.'.$iparr[1].'.'.$iparr[2];
    $serverIP_2     = $iparr[0].'.'.$iparr[1];
    $serverIP_end   = $iparr[3];
    //hostname
    $hostname  = gethostname();
    $hostnameInfo = explode('-', $hostname);
    if (empty($hostnameInfo[0]) && $hostnameInfo[0] == "co") {
        $_SERVER['SERVER_NODE'] = 'local';
    } else {
        
        $_SERVER['SERVER_NODE'] = $hostnameInfo[0];
    }

    //ͨ�� hostname ���� ȫ�ֱ��� ���������ڵ�)
    $_SERVER['SERVER_NODE'] = '';
    switch ($hostnameInfo[0]) {
    case 'gz':
        if ($hostnameInfo[2] == 99) {
            $_SERVER['SERVER_NODE'] = 'test';    //���ݻ������Ի���
        } else {
            $_SERVER['SERVER_NODE'] = 'gz';      //���ݻ�����ʽ����
        }
        break;
    case 'bj':
        $_SERVER['SERVER_NODE'] = 'bj';
        break;
    case 'co':
        $_SERVER['SERVER_NODE'] = 'local';
        break;
    default:
        $_SERVER['SERVER_NODE'] = 'gz';
    }

}
?>
