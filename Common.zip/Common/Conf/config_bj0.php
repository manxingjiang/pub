<?php
/**
 *  �ҷ����������ļ�
 *  �������� ����ʱҪ���� �����������(* ���� ������Ϊ���� *)
 *  
 *  @author wrd <xx@qq.com>
 */
return array(
        //cms��
        'cms_config_db33506' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.89',
                'username' => 'phpcmsfl',
                'password' => 'Md8mdr5Lj6rT23',
                'hostport' => '33506',
                'database' => 'fl_system',
                'names'    => 'gbk',
                'cachetime'=> 86400
        ),
        //findlaw_db ��
        'hb_config_db3307' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.76',
                'username' => 'gTqcweber3wqYne3',
                'password' => '3Tbdswer8Gwe23',
                'hostport' => '33579',
                'names'    => 'gbk',
                'database' => 'findlaw_db',
        ),
        //user_cloud_db ��
        'hb_config_db57789' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.76',
                'username' => 'ucWanYoutech',
                'password' => 'Yiplk987*Lopu&98Hm<',
                'hostport' => '57789',
                'names'    => 'gbk',
                'database' => 'user_cloud_db',
        ),
        //δ֪
        'hb_config_db3320' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.76',
                'username' => 'memiperaeiye',
                'password' => 'sasretoac0616',
                'hostport' => '3320',
                'names'    => 'gbk',
                'database' => 'tempsearch',
        ),
        //֪ʶר��� �ÿ� 2013���ֹͣ�����ˣ��в�ѯ
        'hb_config_db53318' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.88',
                'username' => 'gTqcweber3wqYne3',
                'password' => '3Tbdswer8Gwe23',
                'hostport' => '53318',
                'names'    => 'gbk',
                'database' => 'dede_news',
        ),
        //֪ʶר��� �ÿ� 2013���ֹͣ�����ˣ��в�ѯ
        'hb_config_db53319' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.88',
                'username' => 'gTqcweber3wqYne3',
                'password' => '3Tbdswer8Gwe23',
                'hostport' => '53319',
                'names'    => 'gbk',
                'database' => 'dede_news',
        ),
        //findlaw_db ��
        'hb_config_dbSecondary' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.77',
                'hostname0' => '192.168.1.91',
                'username' => 'gTqcweber3wqYne3',
                'password' => '3Tbdswer8Gwe23',
                'hostport' => '33579',
                'names'    => 'gbk',
                'database' => 'findlaw_db',
        ),
        //δ֪
        'hb_config_db13306' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.89',
                'username' => 'phpcmsfl',
                'password' => 'Md8mdr5Lj6rT23',
                'hostport' => '33506',
                'names'    => 'gbk',
                'database' => 'findlaw_search',
        ),
        /*�Ҳ����ô�
        'sphinx_setting' => array(
                'hostname' => '',
                'hostport' => '',
        ),
        */
        //fl_ask ��
        'hb_config_33603' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.77',
                'username' => 'asklvhai',
                'password' => 'LiweRweeQ4',
                'hostport' => '33879',
                'database' => 'fl_ask',
                'names'=>'gbk',
                'cachetime'=>86400,
        ),
        //fl_ask ��
        'db_fl_ask_slave' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.91',
                'username' => 'asklvhai',
                'password' => 'LiweRweeQ4',
                'hostport' => '33879',
                'database' => 'fl_ask',
                'names'=>'gbk',
                'cachetime'=>86400,
        ),
        //δ֪
        'hb_config_33601' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.146',
                'username' => 'flvitstat2012',
                'password' => 'u8po90908Gwe23',
                'hostport' => '43434',
                'database' => 'fl_visitstat',
                'names'=>'gbk',
                'cachetime'=>86400,
        ),
        //δ֪
        'hb_config_33599' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.146',
                'username' => 'flextend2012',
                'password' => '7yuIop908Gwe23',
                'hostport' => '43434',
                'database' => 'fl_extend',
                'names'=>'gbk',
                'cachetime'=>86400,
        ),
        //fcgi-cache
        'fcgi_cache_db_33666' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.147',
                'username' => 'MdeRMpd67Pwq9543',
                'password' => 'MjdRNmdr45Te23',
                'hostport' => '33666',
                'names'    => 'gbk',
                'database' => 'mcache',
                'names'       => 'gbk',
                'cachetime'=> 86400
        ),
        
        
        // product ��
        'product_config_db33605' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.89',//201
                'username' => 'wy_product',
                'password' => 'Fid2RfdLaw67HNb4',
                'hostport' => '33605',
                'database' => 'wy_product',
        ),
        
        // product ��
        'product_config_db_tongji_diaodu' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.66',
                'username' => 'wyproductzsi',
                'password' => 'dEfkeddssed<lfK',
                'hostport' => '33606',
                'names'    => 'gbk',
                'database' => 'wy_product_zhanshi',
        ),
        
        // ip ��
        'hb_config_ip33177' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.77',
                'username' => 'ipGisRead',
                'password' => 'Gis66HM8edcUH95@R',
                'hostport' => '33177',
                'names'    => 'gbk',
                'database' => 'ip_gis'
        ),
        //������
        'hb_config_33666' => array(
                'dbms'     => 'mysql',
                'hostname' => '192.168.1.76',
                'username' => 'lsurl_cn',
                'password' => 'LS(56)UHGRFVG368gr',
                'hostport' => '31666',
                'database' => 'yun_ask',
                'names'=>'gbk',
                'cachetime'=>86400,
        ),
        
        //RPC�ҷ�
        'RPC_list_host' => array(
                '192.168.1.178:8080',
                //'192.168.1.178:8082',git 
        ),
        //���
        'click_rpc_host' => array(
                '192.168.1.178:8090',
                //'192.168.1.178:8092',
        ),
        //������RPC
        'shortlink_rpc_host' => array('192.168.1.178:16080'),
        //�û�����
        'uc_rpc_host' => array(
                '192.168.1.178:18080',
        ),
        //����ʦ�ңУ�
        'hls_rpc_host' => array('192.168.1.178:12080'),
        //IP��
        'IpSerMysqlHost' => '192.168.1.76:3320',
        //memcache & beansdb
        'memcachecfginfo' => array(
                array('192.168.1.83',  '61110')
        ),
        //--�Ѿ�ͣ�ã�һ���������
        'beansdbcfginfo' => array(
                array('192.168.1.140', '61112')
        ),
        
        //CURLͼƬ�ϴ�ָ��������
        'curlconfig' => array(
                array('14.17.121.116',80)
        ),
        
        //�ִ�
        'dicthttpSever' => 'http://192.168.1.68:7779',
        
        //thrift
        'thrift_host' => '192.168.1.153',
        'thrift_port' => 9099,
        // Python�ӿ����ã���Ҫ���ڷֳ��ؼ���
        'RPC_THRIFT' => array(
            'SERVER' => array(
                array('192.168.1.68', 9090),
            ),
            'DEBUG'    => 1,
            'TOKEN'    => 'R4mm4O.me',
            'CLIENTID' => 1,
        ),
        //΢������ host
        'weixin_push_host' => 'http://china.findlaw.cn/'
);
