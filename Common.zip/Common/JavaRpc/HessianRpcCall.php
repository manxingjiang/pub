<?php
/**
 * Hessian����
 */
class HessianRpcCall extends RpcCall
{
	private $serverIp;
	private $serverPort;	
	
	// ���캯��
	function __construct($config) {
		$this->serverIp = $config['server_ip'];
		$this->serverPort = $config['server_port'];
	}	
	
	public function doCall($jsonRequest)
	{
		$options = new HessianOptions();
		$options->version = 2;
		$options->detectVersion = false;
		$options->typeMap = array('ParamObjectJava' => 'ParamObject');

		//$url = 'http://127.0.0.1:8080/hessian/rpc';
		$url = 'http://'.$this->serverIp.':'.$this->serverPort.'/hessian/rpc';
		$proxy = new Hessianclient($url,$options);
		$jsonResult = urldecode($proxy->rpcCall($jsonRequest));

		return $jsonResult;
	}

}

?>
