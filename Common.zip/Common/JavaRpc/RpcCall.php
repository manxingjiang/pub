<?php
/**
 * <h3>Զ�̷������ú�����</h3>
 * <li>1 ֧������ϡ�Զ�̽ӿڵ��ù淶��ʵ�ֵķ���˵�ͨ��, ���������޹�</li> 
 * <li>2 ֧��WebService, Hessian, Socket, Socket httpЭ��</li>
 * <li>3 ֧�ּ��ܽ���</li>
 * <li>4 ֧��Gzipѹ��</li>
 * 
 */


/**
 * ��̬����,���ڱ��澲̬����
 */
final class RpcConstant
{
	private function __construct() {
	}

	public static $CONTENT_ENCRYTED = "C-E";
	public static $CONTENT_ENCRYTED_METHOD = "C-E-M";
	
	public static $CONTENT_COMPRESS = "C-C";

	public static $VALUE_CONTENT_ENCRYTED_NONE = "NONE";
	public static $VALUE_CONTENT_ENCRYTED_BOTH = "BOTH";
	public static $VALUE_CONTENT_ENCRYTED_GO = "GO";
	public static $VALUE_CONTENT_ENCRYTED_BACK = "BACK";
	
	public static $VALUE_CONTENT_COMPRESS_GZIP = "GZIP";
	
	public static $VALUE_CONTENT_ENCRYTED_METHOD_BASE64 = "BASE64";
	
}

/**
 * RPC ����
 */
class RpcRequestParam
{
	public $cmd;
	public $header;
	public $data;

	// ���캯��
	function __construct() {
		$args=func_get_args();//��ȡ����

		if(NULL != $args && 3 == count($args))
		{
			$this->cmd = $args[0];
			$this->header = $args[1];
			$this->data = $args[2];
		}
	}

	/**
	 * �����Ƿ����
	 */ 
	public function isEncryptedData()
	{
		if(is_array($this->header) 
				&& isset($this->header[RpcConstant::$CONTENT_ENCRYTED]))
		{
			if(RpcConstant::$VALUE_CONTENT_ENCRYTED_BOTH == $this->header[RpcConstant::$CONTENT_ENCRYTED]
					|| RpcConstant::$VALUE_CONTENT_ENCRYTED_GO == $this->header[RpcConstant::$CONTENT_ENCRYTED])
			{
				return true;
			}
		}

		return false;
	}

	/**
	 * ���ܷ���
	 */
	public function getEncryptedMethod()
	{
		if(isset($this->header[RpcConstant::$CONTENT_ENCRYTED_METHOD]))
		{
			return $this->header[RpcConstant::$CONTENT_ENCRYTED_METHOD];
		}
		
		// Ĭ��BASE64
		return RpcConstant::$VALUE_CONTENT_ENCRYTED_METHOD_BASE64;
// 		return null;
	}
	
	/**
	 * �����Ƿ�ѹ��
	 */
	public function isCompressedData()
	{
		if(is_array($this->header)
				&& isset($this->header[RpcConstant::$CONTENT_COMPRESS]))
		{
			if(RpcConstant::$VALUE_CONTENT_COMPRESS_GZIP == $this->header[RpcConstant::$CONTENT_COMPRESS])
			{
				return true;
			}
		}
		
		return false;
	}
}

/**
 * RPC ��Ӧ
 */
class RpcResponseParam
{
	public $state;
	public $header;
	public $data;

	/**
	 * ��ȡRPC������Ӧ����
	 * @param $isArray �Ƿ�Ϊ����
	 */
	public function getData($isArray=true, $code="GBK")
	{	
		if('200' == $this->state)
		{
			if('UTF-8' != $code)
			{
				return RpcUtils::hb_json_decode($this->data, $code, $isArray);
			}
			else
			{
				return json_decode($this->data, $isArray);
			}
		}
		else
		{
			return false;
		}
	}

	/**
	 * ��ȡ����ԭ��
	 */
	public function getErrorCause()
	{
		if('200' != $this->state
				&& '204' != $this->state)
		{
			return $this->data;
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * ��Ӧ�ɹ�
	 */
	public function isSuccess()
	{
		if('200' == $this->state
				|| '204' == $this->state)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * �����Ƿ����
	 * @return boolean
	 */
	public function isEncryptedData()
	{
		if(is_array($this->header) 
				&& isset($this->header[RpcConstant::$CONTENT_ENCRYTED]))
		{
			if(RpcConstant::$VALUE_CONTENT_ENCRYTED_BOTH == $this->header[RpcConstant::$CONTENT_ENCRYTED]
					|| RpcConstant::$VALUE_CONTENT_ENCRYTED_BACK == $this->header[RpcConstant::$CONTENT_ENCRYTED])
			{
				return true;
			}
		}

		return false;
	}

	/**
	 * ���ܷ���
	 */
	public function getEncryptedMethod()
	{
		if(isset($this->header[RpcConstant::$CONTENT_ENCRYTED_METHOD]))
		{
			return $this->header[RpcConstant::$CONTENT_ENCRYTED_METHOD];
		}
		
		// Ĭ��BASE64
		return RpcConstant::$VALUE_CONTENT_ENCRYTED_METHOD_BASE64;
// 		return null;
	}
	
	/**
	 * �����Ƿ�ѹ��
	 */
	public function isCompressedData()
	{
		if(is_array($this->header)
				&& isset($this->header[RpcConstant::$CONTENT_COMPRESS]))
		{
			if(RpcConstant::$VALUE_CONTENT_COMPRESS_GZIP == $this->header[RpcConstant::$CONTENT_COMPRESS])
			{
				return true;
			}
		}
	
		return false;
	}	
}


/**
 * Զ�̵��û���
 * �������ʵ��Զ�̵��õĹ���
 */
abstract class RpcCall
{
	protected $multiCallData = array(
		//'response'=> array(), // ����˵Ļظ�����
		//'request' => array(), // �ͻ��˵���������
	);
	
	protected $timeout = '';
	
	/**
	 * ������ʵ�־���Ĵ�������
	 * @param RPC���� $rpcRequest
	 */
	abstract protected function doCall($jsonRequest);
	
	/**
	 * ������������
	 */
	abstract protected function doMultiCall();
	 
	/**
	 * socket_write����д��
	 * @param $request ���������
	 */
	abstract protected function socketWrite(Array $request);
	
	/**
	 * socket_read������ȡ
	 * @param $request ���������
	 */
	abstract protected function socketRead(Array $request);
	  
	/**
	 * Զ�̵��÷���
	 * @param RPC���� $rpcRequest ���뱣֤�ò�����ֵΪUTF-8��ʽ
	 * @return ����һ�� JSON�ִ���ʽ��RpcResponseParam����
	 */
	public function call($rpcRequest)
	{
		$rpcResponse =  new RpcResponseParam();
		
		if(empty($rpcRequest->data))
		{
			$rpcRequest->data = array();
		}
		
		// �������
		if (!is_array($rpcRequest->data) || !is_string($rpcRequest->cmd)) {
			$rpcResponse->state = "400";
			$rpcResponse->data = "ERROR��Bad Request";
			return $rpcResponse;
		}	
		$jsonRequest = $this->parseRequest($rpcRequest);		
        // Զ������
        if (isset($_GET['debug'])) {
            $this->exec_start = $this->exec_start();//��ȡ����ʼִ��ʱ��
        }

        $starttime = $this->getMillisecond();
        $jsonResult=$this->doCall($jsonRequest);
        $endtime = $this->getMillisecond();
        $exec_time = $endtime - $starttime;
		$result = json_decode($jsonResult, true); // ע���ַ��������Ϊ UTF-8 , ����Ϊ����
		$rpcResponse = $this->parseResponse($result);
		
		if(!$rpcResponse->isSuccess()) {
            $typeid = 1;
            //$this->curl_write($rpcRequest, $typeid, $exec_time);
            \Tools\Error::postError($rpcRequest->cmd, $exec_time, 'findlaw_log_rpc', $typeid);

			$rpclogdir = '/opt/webroot/findlaw.cn/Runtime/rpcError';
			if(!file_exists($rpclogdir)) {
                @ mkdir($rpclogdir);
            }
            $rpclogfile = $rpclogdir . '/rpcError_' .  date("Y.m.d") . '.txt';
            //��������
            //����̫��,�ļ�̫��,ǰ���Ȳ���¼�������
            $requesdata = '';
            if ($jsonRequest) {
                $jsonRequestArr =  json_decode($jsonRequest, true);
                //$requesdata = $jsonRequestArr['data'];
                $cmdName    = $jsonRequestArr['cmd'];
            }
            //��Ӧ����
            $state = 0;
            if ($jsonResult) {
                $jsonResultArr  =  json_decode($jsonResult, true);
                $state = $jsonResultArr['state'];
            }
            $clienIP = $this->getClientIPforRpc();
            if ($clienIP) {
                $clienIPint = $clienIP ? ip2long($clienIP) : 0;
            }
            $server = $_SERVER['SERVER_ADDR'];
            $serverInt = $server ? ip2long($server) : 0;
            $uri = $_SERVER['REQUEST_URI'];
            $errMsg = "[" . date('H:i') . "]rpcError=>cmd:" . $cmdName . ',state:' . $state. ',clientIP:' . 
            $clienIPint . ',serverip:' . $serverInt . ',uri:' . 
            $uri. ',time:' . time() . ',data:' . $requesdata . ', send:'.$jsonRequest .', return:' .$jsonResult. "\r\n";
			@ file_put_contents($rpclogfile, $errMsg, FILE_APPEND);
            //���Է��������Զ�����
            $localServer = array(
                '192.168.1.218',
                '192.168.1.217',
                '14.17.121.99',
                '120.31.52.218',
                '127.0.0.1'
            );
			if(isset($server) && in_array( $server, $localServer) ) {   
                //$rpclogfile = '/opt/devel/192.168.4.75' . $rpclogfile ;
                //@ file_put_contents($rpclogfile, $errMsg, FILE_APPEND);
				echo '<hr>Error:send=>'.$jsonRequest.' <br>return=>'.$jsonResult.'';	
			}
		} else {
            if ($exec_time >= 1000) {
                $typeid = 0;
                //$this->curl_write($rpcRequest, $typeid, $exec_time);
                \Tools\Error::postError($rpcRequest->cmd, $exec_time, 'findlaw_log_rpc');
            }            
        }			
		//debug=rpcjsonʱ��ʾrpc������Ӧ��Ϣ 
		if( isset($_GET['debug']) )
		{			
            $exec_stop = $this->exec_stop();
			if( $_GET['debug']=='rpcjson' )
			{
                echo '|��Ӧʱ��'.$this->get_exec_end($exec_stop, $this->exec_start)."<br />";
				echo '<hr>send=>'.$jsonRequest.' <br>return=>'.$jsonResult.'';			
			}	 
			elseif( $_GET['debug']=='rpcobj' )
			{
				static $requestnum = 0;
				$requestnum++;
				echo '<pre>';
				echo "
	��{$requestnum}������:
	".var_export($rpcRequest,true)."
	��������:
	".var_export($rpcResponse,true);

				echo '</pre>';
            } elseif ( $_GET['debug'] == 'rpcExecTime' ) {
                echo $rpcRequest->cmd.'|��Ӧʱ��'.$this->get_exec_end($exec_stop, $this->exec_start)."<br />";
                
            }
		}

		return $rpcResponse;
	}
	
    /**
     * �м����ʱ�ϱ� �Ѳ���ʹ��
     * 
     * @param  [type]  $rpcRequest [description]
     * @param  integer $typeid     [description]
     * @param  integer $exec_time  [description]
     * 
     * @return [type]              [description]
     */
    public function curl_write($rpcRequest, $typeid=0, $exec_time=0) {
        \Tools\Error::postError($rpcRequest->cmd, $exec_time, 'findlaw_log_rpc', $typeid);
        return true;
        /*
        $hostname = gethostname();
        if (strpos($hostname, 'gz') !== false || strpos($hostname, 'bj') !== false) {
            //ʹ�þ�̬       
            static $hostinfo;
            if (!isset($hostinfo)) {
                include "/opt/weblogs/php_logs/linux_host.php";
            }
            $data['ip'] = isset($hostinfo['ip'])?$hostinfo['ip']:$_SERVER['SERVER_ADDR']; //������ip
            $data['data_name'] = 'findlaw_log_rpc';
            $data['name'] = $rpcRequest->cmd;; // �ӿ���
            $data['runtime'] = $exec_time; // �ӿ�ִ��ʱ��
            $data['addtime'] = $this->getMillisecond(); // �ϱ�����ʱ��
            $data['errorUrl'] = $_SERVER['REQUEST_URI'];//�����url
            $data['typeid'] = $typeid; // 0����������ʱ 1��������
            $json_data =json_encode($data);
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, C('CUSTOM_REPORT_URL'));
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_NOSIGNAL, true);
            curl_setopt($ch, CURLOPT_TIMEOUT_MS, 200);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
            if($json_data){ //����JSON����
                curl_setopt($ch, CURLOPT_HTTPHEADER,
                array(
                        'Content-Type: application/json; charset=utf-8',
                        'Content-Length:' . strlen($json_data),
                        'org:1002'
                    )
                );
            }        
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            \Tools\Error::curl_exec($ch);
            curl_close($ch);
        }
        */
    }


	/**
	 * �������ݵ�д��,������һ�����
	 * @param $rpcRequest RPC����,���뱣֤�ò�����ֵΪUTF-8��ʽ
	 * @author Ҧ˳Ȼ
	 * 2012��7��3�� 15:15:41
	 */
	public function requestWrite($rpcRequest)
	{
		
		$rpcResponse =  new RpcResponseParam();
		
		if(empty($rpcRequest->data))
		{
			$rpcRequest->data = array();
		}
		// �������
		if(!is_array($rpcRequest->data) || !is_string($rpcRequest->cmd)){
			$rpcResponse->state = "400";
			$rpcResponse->data = "ERROR��Bad Request";
			$this->multiCallData[] = array('request' => $rpcRequest ,'response' => $rpcResponse);
		}else{
			$jsonRequest = $this->parseRequest($rpcRequest);
//			$jsonRequest = json_encode($jsonRequest);
			$rpcResponse->state = "203";
			$rpcResponse->data = "Accepted";
			$this->multiCallData[] = array('request' => $jsonRequest ,'response' => $rpcResponse);
		}
		return 	count($this->multiCallData)-1;
	}
	
	
	/**
	 * Զ�̲�����������ִ��
	 * @param $timeout ��ʱʱ��
	 * @author Ҧ˳Ȼ
	 * 2012��7��3�� 15:10:41
	 */
	public function execMultiCall($timeout = 5){
		$this->timeout = $timeout; 
		$this->doMultiCall();
		foreach($this->multiCallData as $key => $value){
			$response = $value['response'];
			$response = json_decode($response,true);
			$response = $this->parseResponse($response);
			$this->multiCallData[$key]['response'] = $response->getData();
		}
		$result = $this->multiCallData;
		$this->multiCallData = array();
		return $result;
	}
	
	
	/**
	 * �������ת��λJSON�ַ�
	 */
	public function parseRequest($rpcRequest)
	{
		$mdata = $rpcRequest->data;
		
		$mdata = json_encode($mdata);
		
		$len = strlen($mdata);
		if($len >= 500)
		{
			// > 3K���� �Զ�ѹ�� ������ȥ��
			$rpcRequest->header[RpcConstant::$CONTENT_COMPRESS] = RpcConstant::$VALUE_CONTENT_COMPRESS_GZIP;
		}
		
		// ����ѹ������Begin
		// �Ƿ�ѹ������ (��ѹ���ټ���)
		if($rpcRequest->isCompressedData())
		{
			$mdata = RpcUtils::gzipEncode($mdata);
		
			// ת��ΪUTF-8��
			$mdata=RpcUtils::hb_json_convert_encoding($mdata, "ISO-8859-1", "UTF-8");
		}
		
		// ���ݼ��ܣ���ֻ֧��BASE64
		if($rpcRequest->isEncryptedData())
		{
			$mdata = base64_encode($mdata);
		}
		$rpcRequest->data = $mdata;
		// ѹ������End
		
		$jsonRequest = json_encode($rpcRequest); // ע���ַ��������Ϊ UTF-8
		
		return $jsonRequest;
	}
	
	/**
	 * JSON��ʽ��Ӧת��ΪResponse����
	 */
	public function parseResponse($result)
	{
		$rpcResponse =  new RpcResponseParam();
		
		$rpcResponse->state = $result["state"];
		$rpcResponse->header = $result["header"];
		$rpcResponse->data = $result["data"];
		
		// ��Ӧ���ܽ�ѹ Begin
		// �������ݽ��ܣ���ֻ֧��BASE64
		$mdata = $rpcResponse->data;
		
		// ����
		if($rpcResponse->isEncryptedData())
		{
		
			$mdata = base64_decode($mdata);
		}
		
		// ��ѹ
		if($rpcResponse->isCompressedData())
		{
			// ת�� UTF8 -> ISO-8859-1
			$mdata = RpcUtils::hb_json_convert_encoding($mdata, "UTF-8", "ISO-8859-1");
			// ��ѹ
			$mdata = RpcUtils::gzipDecode($mdata);
		}
		
		$rpcResponse->data = $mdata;
		// ��Ӧ���ܽ�ѹ End
		
		return $rpcResponse;
	}
    /**
     *  ��ȡ�ͻ���IP
     *
     *  @return string
     */
    public function getClientIPforRpc()
    {
        $ip=false;
        if (!empty($_SERVER["HTTP_CLIENT_IP"])) {
            $ip = $_SERVER["HTTP_CLIENT_IP"];
        }

        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(", ", $_SERVER['HTTP_X_FORWARDED_FOR']);
            if ($ip) {
                array_unshift($ips, $ip);
                $ip = false;
            }

            for ($i = 0; $i<count($ips); $i++) {
                if (!preg_match("/^(10|172\.16|127\.0|192\.168)\./i", $ips[$i])) {
                    $ip = $ips[$i];
                    break;
                }
            }
        }
        return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
    }    
    
    /**
      * ��ȡ����ʼִʱ��
      *
      * @return array
      * @author mxj  create by  2016-8-11
      */        
    function exec_start()
    {
        $runtime_start = microtime();
        $runtime_start = explode(' ', $runtime_start);
        return  substr($runtime_start[1], -3).substr($runtime_start[0], 1, 7);    
    }

    /**
      * ��ȡ����ִ�н���ʱ��
      *
      * @return array
      * @author mxj  create by  2016-8-11
      */     
    function exec_stop()
    {
        $runtime_stop = microtime();
        $runtime_stop = explode(' ', $runtime_stop);
        return substr($runtime_stop[1], -3).substr($runtime_stop[0], 1, 7);  
    }

     /**
      * ��ȡ����ִ��ʱ��
      *
      * @param string $stop  stop
      * @param string $start start
      *
      * @return array
      * @author mxj  create by  2016-8-11
      */   
    function get_exec_end($stop, $start)
    {
        return bcsub($stop, $start, 6);
    }

    /**
     * ��ȡ������
     * 
     * @return float ��ǰʱ��-���뼶
     */
    public function getMillisecond()
    {
        list($t1, $t2) = explode(' ', microtime());
        return (float)sprintf('%.0f', (floatval($t1)+floatval($t2))*1000);
    }

}

?>
