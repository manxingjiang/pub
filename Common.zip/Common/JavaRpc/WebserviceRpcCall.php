<?php

/**
 * Webservice����
 */
class WebserviceRpcCall extends RpcCall
{
	private $serverIp;
	private $serverPort;
	
	// ���캯��
	function __construct($config) {
		$this->serverIp = $config['server_ip'];
		$this->serverPort = $config['server_port'];
	}
	
	public function doCall($jsonRequest)
	{
		//$wsdl= "http://china.findlaw.cn:8080/cxf/rpcWebService?wsdl";
		$wsdl= "http://".$this->serverIp.":".$this->serverPort."/cxf/rpcWebService?wsdl";
		$client = new soapclient($wsdl);
		$params = array('jsonRequest'=> $jsonRequest);
		$out = $client->rpcCall($params);
		return $out->return;
	}
}

?>