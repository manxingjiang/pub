<?php
function getRandConf($list = array()){
	$host_str = $list[rand(0,(count($list)-1))];
	$info= explode(':',$host_str);
	return $info;
}