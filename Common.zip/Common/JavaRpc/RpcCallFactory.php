<?php
//namespace User\Controller;
include_once 'RpcUtils.php';
include_once 'RpcCall.php';
//include_once 'include/rpc/config.rpc.php';

/**
 * RpcCall ����
 * ���𴴽� RpcCallʵ��
 */
class RpcCallFactory
{
	public static $RPC_WS = 'webservice';
	public static $RPC_HESSIAN = 'hessian';
	public static $RPC_SOCKET = 'socket';
	public static $RPC_SOCKETHTTP = 'sockethttp';
	public static $debugstr = '';
	
	public static $config = '';
	public static $configs = array();
	
	/*public static $conf_name = 'findlaw_main';
	public static $conf_list = array(
								//�û���������
								'findlaw_uc' => 'uc_config.rpc.php',
								//�ҷ���ҵ������
								'findlaw_main' => 'config.rpc.php',
								//�ҷ����������
								'findlaw_click' => 'click_config.rpc.php'
							);
	public static $tproperty = 'test pro';
	*/
	
	public static function debugstr($val = '')
	{
	    if ($val == '') {
    	    return self::$debugstr;
	    } else {
	        self::$debugstr .= $val;
	    }
	}
    
	/**
	 * ��ȡ��������
	 */
	public static function getConfigs()
	{
	    if (empty(self::$configs)) {
	        self::$configs = require 'config.rpc.php';
	    }
	    return self::$configs;
	}
	
	/**
	 * �����ýӿ�
	 */
	/*public static function checkConfig() {
		echo '<hr />RPC_WS:'.self::$RPC_WS;
		echo '<br />RPC_HESSIAN:'.self::$RPC_HESSIAN;
		echo '<br />RPC_SOCKET:'.self::$RPC_SOCKET;
		echo '<br />RPC_SOCKETHTTP:'.self::$RPC_SOCKETHTTP;
		echo '<br />config:'.self::$config;
		echo '<br />conf_name:'.self::$conf_name;
		echo '<br />conf_list:';
		print_r(self::$conf_list);
		echo '<br />tproperty:'.self::$tproperty;
		echo "<hr />";
	}*/

	public static function createPRCCall($config)
	{
		$type = $config['rpc_model'];
		// 		echo $type;
		
		switch($type)
		{
			case self::$RPC_WS:
				include_once 'WebserviceRpcCall.php';
				return new WebserviceRpcCall($config);
				break;
			case self::$RPC_HESSIAN:
				include_once '../hessianphp/hessianclient.php';
				include_once 'HessianRpcCall.php';
				return new HessianRpcCall($config);
				break;
			case self::$RPC_SOCKET:
				include_once 'SocketRpcCall.php';
				return new SocketRpcCall($config);
				break;
			case self::$RPC_SOCKETHTTP:
				include_once 'SocketHttpRpcCall.php';
				return new SocketHttpRpcCall($config);
				break;
			default:
			    die('wrong config type');
				// Nothing
		}
	}
	
	/*
	public static function createPRCCallD()
	{
		// ʹ��Ĭ������
		// global $hb_config_rpc;
		// $config = $hb_config_rpc;
		$configs = require self::$conf_list[self::$conf_name];
		$config = $configs['hb_config_rpc'];
		return self::createPRCCall($config);		
	}*/
	
	/**
	 *  ��ȡRPC��Ӧ (getResponse()�����)
	 */
	public static function reqResponse()
	{
		$argList = func_get_args();
		$data = array();
		foreach ($argList as $k => $v) {
			if ($k > 0) {
				$data[] = $v;
			}
		}
		return self::getResponse($argList[0], null, $data, 'GBK', null);
	}

	/**
	 *  ��ȡRPC��Ӧ
	 *  
	 * @param $cmd ��������
	 * @param $head ����ͷ
	 * @param $data ��������
	 * @param $code �����ַ�����
	 * @param $config RPC������������
	 */
	public static function getResponse($cmd, $head, $data, $encoding='GBK', $config=null)
	{
	    //header���ӵ�ǰurl     add by zsg
	    if (!empty($_SERVER['SERVER_NAME']) && !empty($_SERVER['REQUEST_URI'])) {
	        $r_url .= ',http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
	    } else {
	        $r_url = $_SERVER['SCRIPT_FILENAME'];
	    }
	    if ($r_url) {
    	    if ($head == null) {
    	        $head = array('R-URL'=>$r_url);
    	    } else {
    	        $head['R-URL'] = $r_url;
    	    }
	    }
	    //header���ӵ�ǰurl  end   add by zsg
	    
		$rpcRequest = new RpcRequestParam();
		$rpcRequest->cmd = $cmd;
		$rpcRequest->header = $head;
		$rpcRequest->data = $data;

		$isOutRequestInfo = isset($_GET['rpcRequest']) && $_GET['rpcRequest']=='2015123';

        self::debugstr("request___:\n<br>\n");
		self::debugstr(var_export(array('cmd'=>$rpcRequest->cmd,'data'=>$rpcRequest->data), true)."\n<br>\n");
		
		if('UTF-8' != $encoding)
		{
			// ת��ΪUTF-8��
			$rpcRequest = RpcUtils::hb_json_convert_encoding($rpcRequest, $encoding, "UTF-8"); 
		}
        
		if (null == $config) {
			//self::checkConfig();
			// ʹ��Ĭ������
			$configs = self::getConfigs();
			$config = $configs['hb_config_rpc'];
			//����
			//$config['server_ip'] = '192.168.4.120';
		} elseif (is_string($config)) {
		    $configs = self::getConfigs();
		    if (!isset($configs[$config])) {
		        die($config . ' not found!');
		    }
			$config = $configs[$config];
			//�л�
			//$config['server_ip'] = '192.168.4.51';
		}
		
		// Ĭ�ϼ���ȫ������
		if(isset($config[RpcConstant::$CONTENT_ENCRYTED]))
		{
			$rpcRequest->header[RpcConstant::$CONTENT_ENCRYTED] = $config[RpcConstant::$CONTENT_ENCRYTED];
			
			if(isset($config[RpcConstant::$CONTENT_ENCRYTED_METHOD]))
			{
				$rpcRequest->header[RpcConstant::$CONTENT_ENCRYTED_METHOD] = $config[RpcConstant::$CONTENT_ENCRYTED_METHOD];
			}
		}
		
// 		// �Ƿ��Զ�ѹ��
// 		if(isset($config[RpcConstant::$CONFIG_ZIPSWITCH]))
// 		{
// 			$zipSwitch = $config[RpcConstant::$CONFIG_ZIPSWITCH];
			
// 			$len = strlen("");
// 			$rpcRequest-header(RpcConstant::$CONTENT_COMPRESS) = RpcConstant::$VALUE_CONTENT_COMPRESS_GZIP;
// 		}
		$rpcResponse = self::createPRCCall($config)->call($rpcRequest);
		
		self::debugstr("return___:\n<br>\n");
		if($rpcResponse->isSuccess()){
		    self::debugstr(var_export($rpcResponse->getData(), true));
		}else{
		    self::debugstr($rpcResponse->getErrorCause());
		}
		self::debugstr("\n<br><hr>\n\n");
		
		if($isOutRequestInfo && $_SERVER['SERVER_ADDR'] == '14.17.121.99'){			
		    echo self::debugstr();
		    self::$debugstr = '';
		}

		return $rpcResponse;
	}
	
	/**
	 * ����RPC����,����һ�����,�������ȥȡ������
	 * @autory Ҧ˳Ȼ
	 * @param $cmd ��������
	 * @param $head ����ͷ
	 * @param $data ��������
	 * @param $code �����ַ�����
	 * @param $config RPC������������
	 */
	public static function requestWrite($cmd, $head, $data, $encoding='GBK', $config=null)
	{
		$rpcRequest = new RpcRequestParam();
		$rpcRequest->cmd = $cmd;
		$rpcRequest->header = $head;
		$rpcRequest->data = $data;
		//if('UTF-8' != $encoding)
		//{
			// ת��ΪUTF-8��
		//	$rpcRequest = RpcUtils::hb_json_convert_encoding($rpcRequest, $encoding, "UTF-8"); 
		//}
		array_walk_recursive($rpcRequest,array(self,'iconv'));
		if(null == $config)
		{
			// ʹ��Ĭ������
			$configs = require self::$conf_list[self::$conf_name];
			
			$config = $configs['hb_config_rpc'];
		}
		
		// Ĭ�ϼ���ȫ������
		if(isset($config[RpcConstant::$CONTENT_ENCRYTED]))
		{
			$rpcRequest->header[RpcConstant::$CONTENT_ENCRYTED] = $config[RpcConstant::$CONTENT_ENCRYTED];
			
			if(isset($config[RpcConstant::$CONTENT_ENCRYTED_METHOD]))
			{
				$rpcRequest->header[RpcConstant::$CONTENT_ENCRYTED_METHOD] = $config[RpcConstant::$CONTENT_ENCRYTED_METHOD];
			}
		}
		
		if(empty(self::$config)){
			self::$config = self::createPRCCall($config);
		}
		return self::$config->requestWrite($rpcRequest);
	}
	
	/**
	 * ִ������,������RPC������������
	 * @return Array
	 * @author Ҧ˳Ȼ
	 * 2012��7��3�� 15:08:18
	 */
	public static function execMultiRequest($timeout = 5){
		$result = self::$config->execMultiCall($timeout);
		self::$config = '';
		return $result;
	}
	
	/**
	 * ��ȡRPC����
	 * @param $cmd ��������
	 * @param $head ����ͷ
	 * @param $data ��������
	 * @param $isArray ����Ƿ�Ϊ����
	 * @param $code ������Ӧ�ַ�����
	 * @param $config RPC������������
	 */
	public static function getData($cmd, $head, $data, $isArray=true, $encoding='GBK', $config=null)
	{
        //rpcȡֵ���룬��UTF-8
        $encoding = C('content_encode') ?: $encoding;
        if (!C('nocache')) {
            $get_key = 'rpc-'.$cmd.\Tools\Cache::hash(array($head, $data));
        }
        if (!$_GET['nocache'] && !C('nocache')) {
            if ($encoding == 'GBK') {
                $info = \Tools\Cache::get($get_key);
            } else {
                $info = \Tools\Cache::get($get_key, true);
            }
        } else {
            $info = false;
        }
        if ($info === false) {
            if (C('nocache')) {
                $head['H-N'] = 'YES';
            }
            $info = self::getResponse($cmd, $head, $data, $encoding, $config)->getData($isArray, $encoding);
            if (!C('nocache') && $info !== false) {
                $time = C('cache_time') ?: rand(600, 1200);
                \Tools\Cache::set($get_key, $info, $time);
            }
        } else if ($_GET['debug'] == 'rpcExecTime') {
            echo '<b>��cache��</b>'.$cmd.'|<b>��cache��</b><br />';
        }
        return $info;
		///return self::getResponse($cmd, $head, $data, $encoding, $config)->getData($isArray, $encoding);
	}

	/**
	 * ��ȡRPC���ݣ�getData�����ľ���棩
	 */
	public static function reqData()
	{
		$argList = func_get_args();
		$data = array();
		foreach ($argList as $k => $v) {
			if ($k > 0) {
				$data[] = $v;
			}
		} 
		return self::getData($argList[0], null, $data, true, 'GBK', null);
	}
	
	/**
	 * ����RPC, �����Ƿ���óɹ�
	 * @param $cmd ��������
	 * @param $head ����ͷ
	 * @param $data ��������
	 * @param $isArray ����Ƿ�Ϊ����
	 * @param $code �����ַ�����
	 * @param $config RPC������������
	 */	
	public static function callRPC($cmd, $head, $data, $encoding='GBK', $config=null)
	{
		$response = self::getResponse($cmd, $head, $data, $encoding, $config);
		if($response->isSuccess())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * ��������ص�����ת����
	 * @author Ҧ˳Ȼ
	 * 2012��7��12�� 11:41:51
	 */
	static function iconv(&$value,$key,$expand = array('inChar'=>'gbk','outChar'=>'utf-8')){
		if($value){
			$value = iconv($expand['inChar'],$expand['outChar'],$value);
		}
	}
}
