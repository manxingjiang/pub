<?php
/**
 * �������������
 * 
 * @author kongwenhua <1500610236@qq.com>
 */
include '../config.php';
include_once 'functions.php';
$rpcHost = '192.168.3.235';
$rpcPort = '16080';
if ($shortlink_rpc_host) {
    $host_info= getRandConf($shortlink_rpc_host);
    $rpcHost  = $host_info[0];
    $rpcPort  = $host_info[1];
}

return array(
    'hb_config_rpc' => array(
        // webservice, hessian, socket, sockethttp
        //'rpc_model' => 'socket',
        'rpc_model' => 'sockethttp',
        'server_ip' => $rpcHost, 
        'server_port' => $rpcPort,
        // ����Ϊ��ѡ����
        // �Ƿ����  None Both Go Back
        // �粻��Ҫ���ܰ�Content-Encrytedע�ͼ���
        'C-E' => 'NONE',
        'C-E-M' => 'BASE64'

        //'server_port' => 8080
    )
);
