<?php
/**
 *  ģ����:// Ĭ������
 *
 *  @author whj <weihongjiang@findlaw.cn>
 */
$config = array(
        'hb_config_rpc' => array(
                
                // webservice, hessian, socket, sockethttp
                // 'rpc_model' => 'socket',
                'rpc_model' => 'sockethttp',
                'server_ip' => '192.168.3.235',
                'server_port' => 8080,
                
                // ����Ϊ��ѡ����
                // �Ƿ���� None Both Go Back
                // �粻��Ҫ���ܰ�Content-Encrytedע�ͼ���
                'C-E' => 'NONE',
                'C-E-M' => 'BASE64'
        ),
        
        'click_config_rpc' => array(
                
                // webservice, hessian, socket, sockethttp
                // 'rpc_model' => 'socket',
                'rpc_model' => 'sockethttp',
                'server_ip' => '192.168.3.235',
                'server_port' => 8090,
                
                // ����Ϊ��ѡ����
                // �Ƿ���� None Both Go Back
                // �粻��Ҫ���ܰ�Content-Encrytedע�ͼ���
                'C-E' => 'NONE',
                'C-E-M' => 'BASE64'
        ),
        
        'shortlink_config_rpc' => array(
                
                // webservice, hessian, socket, sockethttp
                // 'rpc_model' => 'socket',
                'rpc_model' => 'sockethttp',
                'server_ip' => '192.168.3.235',
                'server_port' => 16080,
                
                // ����Ϊ��ѡ����
                // �Ƿ���� None Both Go Back
                // �粻��Ҫ���ܰ�Content-Encrytedע�ͼ���
                'C-E' => 'NONE',
                'C-E-M' => 'BASE64'
        ),
        
        'uc_config_rpc' => array(
                
                // webservice, hessian, socket, sockethttp
                // 'rpc_model' => 'socket',
                'rpc_model' => 'sockethttp',
                'server_ip' => '192.168.3.235',
                'server_port' => 18080,
                
                // ����Ϊ��ѡ����
                // �Ƿ���� None Both Go Back
                // �粻��Ҫ���ܰ�Content-Encrytedע�ͼ���
                'C-E' => 'NONE',
                'C-E-M' => 'BASE64'
        ),
        'hls_config_rpc' => array(
                
                // webservice, hessian, socket, sockethttp
                // 'rpc_model' => 'socket',
                'rpc_model' => 'sockethttp',
                'server_ip' => '192.168.3.235',
                'server_port' => 12080,
                
                // ����Ϊ��ѡ����
                // �Ƿ���� None Both Go Back
                // �粻��Ҫ���ܰ�Content-Encrytedע�ͼ���
                'C-E' => 'NONE',
                'C-E-M' => 'BASE64'
        )
);

include 'include/config_findlaw_db.php';
include_once 'functions.php';

// findlaw_db��������
if (! empty($RPC_list_host)) {
    $host_info = getRandConf($RPC_list_host);
    $config['hb_config_rpc']['server_ip'] = $host_info[0];
    $config['hb_config_rpc']['server_port'] = intval($host_info[1]);
}
// ���������
if (! empty($click_rpc_host)) {
    $host_info = getRandConf($click_rpc_host);
    $config['click_config_rpc']['server_ip'] = $host_info[0];
    $config['click_config_rpc']['server_port'] = intval($host_info[1]);
}
// ���������
if (! empty($shortlink_rpc_host)) {
    $host_info = getRandConf($shortlink_rpc_host);
    $config['shortlink_config_rpc']['server_ip'] = $host_info[0];
    $config['shortlink_config_rpc']['server_port'] = intval($host_info[1]);
}
// �û���������
if (! empty($uc_rpc_host)) {
    $host_info = getRandConf($uc_rpc_host);
    $config['uc_config_rpc']['server_ip'] = $host_info[0];
    $config['uc_config_rpc']['server_port'] = intval($host_info[1]);
}
// ����ʦ����
if (! empty($hls_rpc_host)) {
    $host_info = getRandConf($hls_rpc_host);
    $config['hls_config_rpc']['server_ip'] = $host_info[0];
    $config['hls_config_rpc']['server_port'] = intval($host_info[1]);
}

if (isset($_GET['show_rpc_config'])) {
    print_r($config);
}
return $config;