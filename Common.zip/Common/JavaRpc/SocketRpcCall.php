<?php

/**
 * Socket����
 */
class SocketRpcCall extends RpcCall
{
	private $serverIp;
	private $serverPort;
	
	// ���캯��
	function __construct($config) {
		$this->serverIp = $config['server_ip'];
		$this->serverPort = $config['server_port'];
	}	
	
	public function doCall($jsonRequest)
	{
		$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
		$connection = socket_connect($socket, $this->serverIp, $this->serverPort);

		//$context=json_encode($rpcRequest);
		//if(!socket_write($socket, $jsonRequest))
		if(!socket_write($socket, $jsonRequest, strlen($jsonRequest)))
		{
			// ERROR
			// echo("<p>Write failed</p>"); 
		}
		$returnValue="";
		while ($buffer = socket_read($socket, 1024, PHP_BINARY_READ)) {
			$returnValue=$returnValue."".$buffer;
		}
		socket_close($socket);

		return $returnValue;
	}
}

?>
