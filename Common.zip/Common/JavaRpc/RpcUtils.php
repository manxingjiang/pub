<?php

/**
 * ������
 */
class RpcUtils
{
	/**
	 * PHP����ת��ΪJSON��ʽ�ִ�
	 */
	public static function hb_json_encode($value, $code='GBK', $options = 0)
	{
		if('UTF-8' == $code)
		{
			return json_encode($value, $options);
		}
		else
		{
			return json_encode(self::hb_json_convert_encoding($value, $code, "UTF-8"), $options);
		}

	}

	/**
	 * JSON��ʽ�ִ�ת��ΪPHP����
	 */
	public static function hb_json_decode($str, $code='GBK', $assoc = false, $depth = 512)
	{
		if('UTF-8' == $code)
		{
			return json_decode($str, $assoc);
		}
		else
		{
			return self::hb_json_convert_encoding(json_decode($str, $assoc), "UTF-8", $code);
		}

	}

	/**
	 * �ַ�����ת��
	 */
	public static function hb_json_convert_encoding($m, $from, $to)
	{
		switch(gettype($m)) {
			case 'integer':
			case 'boolean':
			case 'float':
			case 'double':
			case 'NULL':
				return $m;

			case 'string':
				return mb_convert_encoding($m, $to, $from);
			case 'object':
				$vars = array_keys(get_object_vars($m));
				foreach($vars as $key) {
					$m->$key = self::hb_json_convert_encoding($m->$key, $from ,$to);
				}
				return $m;
			case 'array':
				foreach($m as $k => $v) {
				    $_k = self::hb_json_convert_encoding($k, $from, $to);
					$m[$_k] = self::hb_json_convert_encoding($v, $from, $to);
					if ($_k != $k) {
					    unset($m[$k]);
					}
				}
				return $m;
			default:
		}
		return $m;
	}

	/**
	 * Transfer-Encoding: chunked
	 * @param String $chunk
	 * @return unknown|Ambigous <NULL, string>
	 */
	public static function http_chunked_decode($chunk) {
		//echo $chunk;
		//echo "<br />*************************";
		$pos = 0;
		$len = strlen($chunk);
		$dechunk = null;
		$last_pos= 0;

		while(($pos < $len)
				&& ($chunkLenHex = substr($chunk,$pos, ($newlineAt = strpos($chunk,"\n",$pos+1))-$pos)))
		{
			if (! self::is_hex($chunkLenHex)) {
				trigger_error('Value is not properly chunk encoded', E_USER_WARNING);
				return $chunk;
			}

			$pos = $newlineAt + 1;
			if($pos == $last_pos){ return $dechunk; }
			
			//echo "<hr />pos={$pos}<br />newlineAt={$newlineAt}<br />size of dechunk=".strlen($dechunk);
			//if(strlen($dechunk)>133170099){ echo '<hr /><hr />'.$chunk; exit;}
			
			$chunkLen = hexdec(rtrim($chunkLenHex,"\r\n"));
			$dechunk .= substr($chunk, $pos, $chunkLen);
			$pos = strpos($chunk, "\n", $pos + $chunkLen) + 1;
			
			$last_pos = $pos;
		}
		return $dechunk;
	}

	/**
	 * determine if a string can represent a number in hexadecimal
	 *
	 * @param string $hex
	 * @return boolean true if the string is a hex, otherwise false
	 */
	public static function is_hex($hex) {
		// regex is for weenies
		$hex = strtolower(trim(ltrim($hex,"0")));
		if (empty($hex)) {
			$hex = 0;
		};
		$dec = hexdec($hex);
		return ($hex == dechex($dec));
	}

	/**
	 * gzip ѹ��<br>
	 * ѹ������Ϊ1-9 ��Ҫ���õĹ���ռCPU<br>
	 * ����������Ϊ3
	 * @param string $content
	 */
	public static function gzipEncode($data) {
		return gzencode($data, 9);
	}

	/**
	 * gzip ��ѹ
	 * @param string $content
	 */
	public static function gzipDecode($data) {
		$flags = ord(substr($data, 3, 1));
		$headerlen = 10;
		$extralen = 0;
		$filenamelen = 0;
		if ($flags & 4) {
			$extralen = unpack('v' ,substr($data, 10, 2));
			$extralen = $extralen[1];
			$headerlen += 2 + $extralen;
		}
		if ($flags & 8) // Filename
			$headerlen = strpos($data, chr(0), $headerlen) + 1;
		if ($flags & 16) // Comment
			$headerlen = strpos($data, chr(0), $headerlen) + 1;
		if ($flags & 2) // CRC at end of file
			$headerlen += 2;
		$unpacked = @gzinflate(substr($data, $headerlen));
		if ($unpacked === FALSE)
			$unpacked = $data;
		return $unpacked;
	}

}

?>