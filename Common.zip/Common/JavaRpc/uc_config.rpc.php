<?php
//�û����Ľӿ�����
//192.168.3.235 18080
$rpcHost = '192.168.3.235';
$rpcPort = 18080;
include '../config.php';
include_once 'functions.php';
//$rpcHost = '192.168.4.65';
//print_r($RPC_list_host);

if(!empty($RPC_list_host)){
	$host_info= getRandConf($RPC_list_host);
	$rpcHost  = $host_info[0];
	$rpcPort  = intval($host_info[1]);
}
//echo $rpcHost . ':';
//echo $rpcPort . '<br>'; 

return array(
    'hb_config_rpc' => array(
        // webservice, hessian, socket, sockethttp
        //'rpc_model' => 'socket',
        'rpc_model' => 'sockethttp',
        'server_ip' => $rpcHost, 
        'server_port' => $rpcPort,
        // ����Ϊ��ѡ����
        // �Ƿ����  None Both Go Back
        // �粻��Ҫ���ܰ�Content-Encrytedע�ͼ���
        'C-E' => 'NONE',
        'C-E-M' => 'BASE64'
        
        //'server_port' => 8080
        )
    );