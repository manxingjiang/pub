<?php

/**
 * RPC��չ, ���ⲿ����
 */
class RpcExtendsFactory
{
	private $cacheExtends;
	
	/**
	 * Memcached������չ
	 */
	public function getCache()
	{
		if(null == $this->memberModule)
		{
			include_once 'MemcachedExtends.class.php';
			$this->cacheExtends = new MemcachedExtends();
		}
	
		return $this->cacheExtends;
	}
	
} // end class

?>