<?php
include_once 'include/rpc/RpcCallFactory.php';

/**
 * Memcached��չ
 */
class MemcachedExtends
{
    /**
     * ��ȡ����
     */
    public function get($key, $timeout=1000)
    {
        return \Tools\Cache::get($key);
        //return RpcCallFactory::getData("Cache.memcached.get", null, array($key, $timeout));		
    }

    /**
     * ���û���, ʱ�䵥λ:��
     */
    public function put($key, $flushTime, $value) 
    {
        return \Tools\Cache::set($key, $value, $flushTime);
        //return RpcCallFactory::callRPC("Cache.memcached.put", null, array($key, $flushTime, $value));
    }

    /**
     * ɾ������
     */
    public function remove($key)
	{
        return \Tools\Cache::rm($key);
        //return RpcCallFactory::callRPC("Cache.memcached.remove", null, array($key));
    }

} // end class

?>

