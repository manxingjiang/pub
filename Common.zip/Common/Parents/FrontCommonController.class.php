<?php
/**
 *  ����ǰ̨��Ŀ�������Ĺ������࣬ ����ֻ�������ǰ̨��Ŀ������һЩ����, ��ʼ���������漰���ݴ�ȡ
 *
 *  @author zsg <xx@qq.com>
 */
namespace Parents;
use Parents;
/**
 *  ����ǰ̨��Ŀ�������Ĺ������࣬ ����ֻ�������ǰ̨��Ŀ������һЩ����, ��ʼ���������漰���ݴ�ȡ
 *
 *  @author zsg <xx@qq.com>
 */
class FrontCommonController extends \Parents\CommonController
{
    /**
     *  ǰ̨��Ŀ��������ĳ�ʼ��
     *    
     *  @return null
     */
    protected function _initialize()
    {
        parent::_initialize();
        $currModule = C("CONTROLLER_NAME");
        if (C("CONTROLLER_NAME") != "Ajax" && !isset($_REQUEST['callback']) && !isset($_REQUEST['requestmode'])) {
            $this->assign('currModule', $currModule);
            self::tophtml();
            //self::tophtml1();
        }
    }
    
    /**
     * ip
     *
     * @return null
     */
    public function ip()
    {
        echo '<br />��ǰʶ�������Ϣ��';
        print_r(\Tools\Iparea::getIpReviseArea());
        echo '<br /><br />��ip����ʵ������Ϣ��';
        $iprs = \Rpc::getShortlinkData('Ip.getAreaByIp', \Tools\Iparea::getClientIp(), 'fl');
        print_r($iprs);
        $serverIPArr = explode(".", $_SERVER['SERVER_ADDR']);
        echo '<br>���ڷ�����ip��' . $serverIPArr[3] . '(' . gethostname() . ')';
    }
    
    /**
     * �����ݼ����У���ȡĳ���ֶεļ���
     * �磺���罫�û����������е�uid��ȡ����
     * 
     * @param array  $data        ���ݼ���
     * @param string $field       �ֶ���
     * @param bool   $unique      �Ƿ�ȥ��
     * @param bool   $removeEmpty �Ƿ�ȥ�գ�����empty,null,0)
     * 
     * @return void
     */
    protected function getFieldInList($data, $field="uid", $unique=true, $removeEmpty=true)
    {
        $rs = array();
        foreach ($data as $k=>$v) {
            $val = $v[$field];
            if ($removeEmpty && !$val) {
                continue;
            }
            $rs[] = $v[$field];
        }
        
        if ($unique) {
            return array_values(array_unique($rs));
        } else {
            return $rs;
        }
    }
    
    /**
     * �����ݼ��ϵļ�ֵ��ɼ����е�ĳ���ֶ�
     * 
     * @param array  $data  ����
     * @param string $field �ֶ�
     * 
     * @return type
     */
    protected function setDataAsKey($data, $field='id')
    {
        $rs = array();
        foreach ($data as $k=>$v) {
            $key = $v[$field];
            $rs[$key] = $v;
        }
        
        return $rs;
    }
    
    /**
     * ����html
     * 
     * @return string
     */
    public function tophtml()
    {        
        $topTplPath = ROOT_PATH . "china.findlaw.cn/index_front/trunk/Home/View/inc/top.tpl";
        $html = $this->fetch($topTplPath);
        $this->assign('headertophtml', $html);
        return $html;
    }
    /**
     * ����html mxj 20160705 xin zeng
     * 
     * @return string
     */
    public function tophtml1()
    {        
        $topTplPath = ROOT_PATH . "china.findlaw.cn/index_front/trunk/Home/View/inc/top1.tpl";
        $html = $this->fetch($topTplPath);
        $this->assign('headertophtml1', $html);
        return $html;
    }
    /**
     * ȡ�ʼ�����ģ��
     * 
     * @param array $config ��������
     * 
     * @return html
     */
    public function getEmailTpl($config)
    {
        if (empty($config['tpl'])) {
            return false;
        }
        $this->assign('config', $config);
        $emailTplPath = ROOT_PATH . "china.findlaw.cn/index_front/trunk/Home/View/emailtpl/{$config['tpl']}.tpl" ;
        
        return  $this->fetch($emailTplPath);
    }
    /**
     * ���Դ�ӡ
     * 
     * @param mixed $data   ��ӡ����
     * @param bool  $isExit �Ƿ��������
     * 
     * @return null
     */
    public function pdebug($data, $isExit = false)
    {
        echo '<div class="debug"><pre>';
        print_r($data);
        echo '</pre><div>';
        if ($isExit) {
            exit;
        }
    }
    
    /**
     * 404.htm
     *
     * @return void;
     */
    public function show404()
    {
        $TplPath = ROOT_PATH . "china.findlaw.cn/index_front/trunk/Home/View/inc/404.tpl";
        $html    = $this->fetch($TplPath);
        header('HTTP/1.1 404 Not Found');
        header("status: 404 Not Found"); 
        echo $html;
        exit;
    }
    
    /**
     * pcվ 400����
     * 
     * @param int $num 40num
     *
     * @return void
     * @see \Parents\FrontCommonController::show404()
     */
    public function show400($num)
    {
        switch ($num) {
        case 0:
            header('HTTP/1.1 400 Bad Request');
            break;
        case 3:
            header('HTTP/1.1 403 Forbidden');
            break;
        case 13:
            header('HTTP/1.1 413 Request Entity Too Large');
            break;
        default:
            header('HTTP/1.1 404 Not Found');
            break;
        }
        $pathFile = ROOT_PATH . "china.findlaw.cn/index_front/trunk/Home/View/inc/404.tpl";
        $html = $this->fetch($pathFile);
        echo $html; 
        exit;
    }       
    /**
     * 301.htm
     *
     * @param string $url url
     *
     * @return void;
     */
    public static function jump301($url)
    {
        header('HTTP/1.1 301 Moved Permanently');
        header("Location:" . $url);
        exit;
    }
    
    /**
     * ������(ר��)վҳ��а���ϵ (�°��)
     *
     * @param int $pageid   �а�ҳ������ID��findlaw_db.chengbao_page��
     * @param int $areacode areacode
     * @param int $profid   ר��ID
     *
     * @return array
     */
    public function queryChengbaoList($pageid, $areacode, $profid)
    {
        if (empty($areacode) || empty($pageid)) {
            return array();
        }
        $params = array(
            'areacode' => intval($areacode),
            'pageid' => intval($pageid)
        );
        if (!empty($profid)) {
            $params['profid'] = intval($profid);
        }
        return $areacontract = \Rpc::getData("Chengbao.queryChengbaoList", $params);
    }
    
    /**
     * �ҷ�ҳ�澲̬����
     * 
     * @param string $key       ��������
     * @param int    $areacode  ��������
     * @param int    $cacheTime ����ʱ�䣨��λ���룩
     * 
     * @return void
     */
    public function getPageHtmlCache($key="findlaw_index", $areacode = 0, $cacheTime=60)
    {
        $htmlCachePath = RUNTIME_PATH."/Html/";
        if ($areacode > 99) {
            $htmlCachePath = $htmlCachePath.substr($areacode, 0, 2)."/";
            $htmlCacheFile = $key.".".$areacode;
        } else {
            $htmlCacheFile = $key;
        }
        
        if (!isset($_GET['nocache']) && is_file($htmlCachePath.$htmlCacheFile)) {
            $cache_time = filemtime($htmlCachePath.$htmlCacheFile);
            if (time() - $cache_time < $cacheTime) {
                echo file_get_contents($htmlCachePath.$htmlCacheFile);
                exit;
            }
        }
    }
    
    /**
     * �ҷ�ҳ�澲̬����
     * 
     * @param string $key      ��������
     * @param int    $areacode ��������
     * @param string $tpl      ģ��
     * 
     * @return void
     */
    public function setPageHtmlCache($key="findlaw_index", $areacode = 0, $tpl="")
    {
        $htmlCachePath = RUNTIME_PATH."/Html/";
        if ($areacode > 99) {
            $htmlCachePath = $htmlCachePath.substr($areacode, 0, 2)."/";
            $htmlCacheFile = $key.".".$areacode;
        } else {
            $htmlCacheFile = $key;
        }
        
        echo $this->buildHtml($htmlCacheFile, $htmlCachePath, $tpl);
    }
    
    
    /**
     * ȡ��ʦ��������
     * 
     * @param array $lawyerlist ��ʦ��Ϣ
     * @param int   $type       Ĭ������ ��������1  ȫ������2�������ȣ�
     * 
     * @return array
     */
    public function getLawyerListFromUc($lawyerlist, $type=2)
    {
        if (!$lawyerlist) {
            return $lawyerlist;
        }
        //ȡ�û�������ʦ����
        \Tools\Lawyer::setUcLawyerKey($lawyerlist, 'userid');
        $uclawyers = \Tools\Lawyer::getUcLawyerInfo($type);
        $retdata = array();
        foreach ($lawyerlist as $key=>$lawyer) {
            if ($uclawyers['userid'][$lawyer['userid']]) {
                $tmpucinfo = $uclawyers['userid'][$lawyer['userid']];
                $tmpyear = $tmpucinfo['lawyerBeginyear'];
                if (isset($tmpyear) && $tmpyear  > 1964 &&  $tmpyear < date('Y', time())) {
                    $yeartype=date('Y', time())-$tmpyear;
                } else if (strlen($tmpucinfo['lawyerCode']) == 17) {
                    $yeartype = substr($tmpucinfo['lawyerCode'], 5, 4);
                    $yeartype= date('Y', time())-$yeartype;
                } else {//��ȷ����ͳһΪרְ��ʦ
                    $yeartype= -1;
                }
                if ($yeartype <= 0) {
                    $yeartype = 1;
                }
                $tmpucinfo['yeartype'] = $yeartype <= 2 ? 'רְ��ʦ' : $yeartype.'�꾭��';
                $tmpucinfo = $this->specialAreaShow($tmpucinfo);
                $retdata[$key] = array_merge($lawyerlist[$key], $tmpucinfo);
            } else {
                $retdata[$key] = $lawyerlist[$key];
            }
        }
        return $retdata;
    }
    
    /**
     * ���������ʦ��Ϣ����
     * 
     * @param array $lawyerinfo ��ʦ��Ϣ�������û���ϵ��
     * 
     * @return array
     */
    public function specialAreaShow($lawyerinfo)
    {
        if (!$lawyerinfo['areacode']) {
            return $lawyerinfo;
        }
        $subcode = substr($lawyerinfo['areacode'], 0, 2);
        if (in_array($subcode, array(11, 12, 13, 14, 43, 44, 45))) {
            $lawyerinfo['province'] = $lawyerinfo['city'];
            $lawyerinfo['city'] = $lawyerinfo['country'];
        }
        return $lawyerinfo;
    }

     /**
     * ȡcache�������� -- �ѷ�װ key -- md5����
     * 
     * @param string $key     key
     * @param int    $timeout ��ʱʱ�� ����
     * 
     * @return data
     */
    public function getCache($key, $timeout = 1000)
    {
        $info_key = \Tools\Cache::hash($key);
        $info = \Tools\Cache::get($info_key);
        return $info;
    }
    
    /**
     * дcache�������� -- �ѷ�װ key -- md5����
     * 
     * @param string $key       key
     * @param mix    $data      ����
     * @param int    $cachetime ����ʱ�� ��
     * 
     * @return re 
     */
    public function putCache($key, $data, $cachetime = 86400)
    {
        $info_key = \Tools\Cache::hash($key);
        \Tools\Cache::set($info_key, $data, $cachetime);
    }
    
}
