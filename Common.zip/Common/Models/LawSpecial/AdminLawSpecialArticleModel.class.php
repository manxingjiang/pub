<?php
/**
 * ����ר���������ģ��(��̨ʹ��)
 *  
 * @author huanggongqiang <huanggongqiang@wanglv.com>
 *
 *  @data 2017-04-24
 */
namespace Models\LawSpecial;

/**
 * ����ר���������ģ��(��̨ʹ��)
 *  
 * @author huanggongqiang <huanggongqiang@wanglv.com>
 */
class AdminLawSpecialArticleModel
{
    /**
     * ��������
     * 
     * @param array $data ����
     *
     * @return array/false
     */
    public function add($data)
    {
        if (!is_array($data)) {
            return false;
        }
        
        $findlaw_db = new \Models\FindlawModel();
        $findlaw_db->table('law_special_article');
        return $findlaw_db->add($data);
    }
    
    /**
     * ��������
     * 
     * @param array $data  ����
     * @param array $where ����
     *
     * @return array/false
     */
    public function save($data, $where)
    {
        if (!is_array($data) || !is_array($where)) {
            return false;
        }
        
        $findlaw_db = new \Models\FindlawModel();
        $findlaw_db->table('law_special_article');
        return $findlaw_db->where($where)->save($data);
    }
    
    /**
     * ɾ������
     * 
     * @param intval $id ����id
     *
     * @return array/false
     */
    public function delete($id)
    {
        if (!$id) {
            return false;
        }
        
        $findlaw_db = new \Models\FindlawModel();
        $findlaw_db->table('law_special_article');
        $where = array(
            'id' => $id
        );
        return $findlaw_db->where($where)->delete();
    }
    
    /**
     * ��ѯ�б�
     * 
     * @param string  $where  ��ѯ����
     * @param array   $fields ��ѯ�ֶ�
     * @param array   $orders �ֶ�����
     *
     * @return array/false
     */
    public function select($where, $fields='*', $orders='id ASC')
    {
        $findlaw_db = new \Models\FindlawModel();
        $findlaw_db->table('law_special_article');
        return $findlaw_db->where($where)->field($fields)->select();
    }
    
    /**
     *  ��ѯ����
     *
     *  @param intval $id    ����ID
     *  @param string $fields ��ѯ����
     *
     *  @return array
     */
    public static function find($id, $fields='*')
    {
        if (empty($id)) {
            return array();
        }
        $findlaw_db = new \Models\FindlawModel();
        $findlaw_db->table('law_special_article');
        
        return $findlaw_db->where('id='. $id)->field($fields)->find();
    }
}