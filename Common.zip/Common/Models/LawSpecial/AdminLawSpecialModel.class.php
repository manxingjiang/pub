<?php
/**
 * ����ר��ģ��(��̨ʹ��)
 *  
 * @author huanggongqiang <huanggongqiang@wanglv.com>
 *
 *  @data 2017-04-24
 */
namespace Models\LawSpecial;

/**
 * ����ר��ģ��(��̨ʹ��)
 *  
 * @author huanggongqiang <huanggongqiang@wanglv.com>
 */
class AdminLawSpecialModel
{
    /**
     * ��������
     * 
     * @param array $data ����
     *
     * @return array/false
     */
    public function add($data)
    {
        if (!is_array($data)) {
            return false;
        }
        
        $findlaw_db = new \Models\FindlawModel();
        $findlaw_db->table('law_special');
        return $findlaw_db->add($data);
    }
    
    /**
     * ��������
     * 
     * @param array $data  ����
     * @param array $where ����
     *
     * @return array/false
     */
    public function save($data, $where)
    {
        if (!is_array($data) || !is_array($where)) {
            return false;
        }
        
        $findlaw_db = new \Models\FindlawModel();
        $findlaw_db->table('law_special');
        return $findlaw_db->where($where)->save($data);
    }
    
    /**
     * ��ѯ�б�
     * 
     * @param integer $currentPage ��ǰҳ
     * @param string  $pageSize    ÿҳ��ʾ��¼��
     * @param string  $where       ��ѯ����
     * @param array   $fields      ��ѯ�ֶ�
     * @param array   $orders      �ֶ�����
     *
     * @return array/false
     */
    public function selectPage($currentPage=1, $pageSize=10, $where, $fields='*', $orders='lid DESC')
    {
        $findlaw_db = new \Models\FindlawModel();
        $findlaw_db->table('law_special');
        $rowFirst = $pageSize*($currentPage-1);
        return $findlaw_db->where($where)->field($fields)->order($orders)->limit($rowFirst, $pageSize)->select();
    }
    
    /**
     * ��ѯͳ����
     *
     * @param string $where ��ѯ����
     *
     * @return intval
     */
    public function count($where)
    {
        $findlaw_db = new \Models\FindlawModel();
        $findlaw_db->table('law_special');
        return $findlaw_db->where($where)->count();
    }
    
    /**
     *  ��ѯ����
     *
     *  @param intval $lid    ����ID
     *  @param string $fields ��ѯ����
     *
     *  @return array
     */
    public static function find($lid, $fields='*')
    {
        if (empty($lid)) {
            return array();
        }
        $findlaw_db = new \Models\FindlawModel();
        $findlaw_db->table('law_special');
        
        return $findlaw_db->where('lid='. $lid)->field($fields)->find();
    }
}
