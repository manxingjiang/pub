<?php
/**
 * ��������Ҫ��˵�����
 *
 * @author lihuanlin <birdy@findlaw.cn>
 */
namespace Models\UcLawyer;

/**
 * ��������Ҫ��˵�����
 *
 * @author lihuanlin <birdy@findlaw.cn>
 */
class UcLawyerNoCheckModel extends UcLawyerModel
{
    /**
     * ��ʼ��
     * 
     * @param string $lawyerInfo ��ʦ����
     * 
     * @return void
     */
    public function __construct($lawyerInfo)
    {
        $this->uid        = $lawyerInfo['uid'];
        $this->lawyer     = $lawyerInfo;
    }
    
    /**
     * ��ʼ��������
     * 
     * @param array $data Ҫ����������
     * 
     * @return void
     */
    public function start($data)
    {
        if (isset($data['base'])) { //������Ϣ
            $this->_dealBaseInfo($data['base']);
        }
        if (isset($data['info'])) { //������Ϣ
            $this->_dealInfoInfo($data['info']);
        }
        if (isset($data['info'])) { //������Ϣ
            $this->_dealOtherInfo($data['other']);
        }
        if (isset($data['edu'])) {  //������Ϣ
            $this->_dealEduInfo($data['edu']);
        }
        if (isset($data['ref_prof'])) { //��ʦר��
            $this->_dealSortInfo($data['ref_prof']);
        }
        if (isset($data['member'])) {
            $member = $data['member'];
            if (isset($member['password'])) {
                $this->_dealPasswordInfo($member['password']);
            }
        }
        return $this->ptInfo;
    }
    
    /**
     * ������������
     * 
     * @param array $data Ҫ����������
     * 
     * @return void
     */
    private function _dealBaseInfo($data)
    {
        $update = array();
        foreach ($data as $k=>$v) {
            $field = $this->field[$k];
            if ($v != $this->lawyer[$k]) {
                if (!$v && $k != 'sex') { //2016-11-3 ��Խӿڲ�����ʹ��nullֵ �޸�
                    $v = ''; 
                }
                $update[$k] = $v;
                if ($field['platform']) {
                    $this->pushPtInfo($field['platform'], $k, $v);
                }
            }
        }
        if ($update) {
            $update['uid'] = $this->uid;
            \Rpc::getUCData('Member.admin.updateUcLawyerByPKSel', $update);
        }
    }
    
    /**
     * �������������
     * 
     * @param array $data Ҫ����������
     * 
     * @return void
     */
    private function _dealInfoInfo($data)
    {
        $update = array();
        foreach ($data as $k=>$v) {
            $field = $this->field[$k];
            if ($v != $this->lawyer[$k]) {
                $update[$k] = $v;
                if ($field['platform']) {
                    $this->pushPtInfo($field['platform'], $k, $v);
                }
            }
        }
        if ($update) {
            $update['uid'] = $this->uid;
            $update['pid'] = 1;
            \Rpc::getUCData('Member.admin.updateUcLawyerInfo', $update);
        }
    }
    
    /**
     * ����Other������
     * 
     * @param array $data Ҫ����������
     * 
     * @return void
     */
    private function _dealOtherInfo($data)
    {
        $update = array();
        foreach ($data as $k=>$v) {
            $field = $this->field[$k];
            if ($v != $this->lawyer[$k]) {
                $update[$k] = $v;
                if ($field['platform']) {
                    $this->pushPtInfo($field['platform'], $k, $v);
                }
            }
        }
        if ($update) {
            $update['uid'] = $this->uid;
            \Rpc::getUCData('Member.admin.updateUcLawyerOther', $update);
        }
    }
    
    /**
     * ������������
     * 
     * @param array $data Ҫ����������
     * 
     * @return void
     */
    private function _dealEduInfo($data)
    {
        //�û���ϵ������Ϣ
        $eduInfo = array();
        $data = $data['edu'];
        //ѧλ
        if ($data['degree'] > 0 && $this->lawyer['ucLawyerEdu']['degree'] != $data['degree']) {
            $eduInfo['degree'] = $data['degree'];
        }
        
        //��ҵѧУ
        if (isset($data['schoolName']) && trim($data['schoolName']) != $this->lawyer['ucLawyerEdu']['schoolName']) {
            $eduInfo['schoolName'] = trim($data['schoolName']);
        }
        
        //ѧ��ȡ�÷�ʽ
        if ($data['degreeType'] > 0 && $data['degreeType'] != $this->lawyer['ucLawyerEdu']['degreeType']) {
            $eduInfo['degreeType'] = intval($data['degreeType']);
        }
        
        //רҵ
        if (trim($data['specialty']) != $this->lawyer['ucLawyerEdu']['specialty']) {
            $eduInfo['specialty']  = trim($data['specialty']);
        }
        
        if ($eduInfo) {
            if (isset($this->field['edu']['platform'])) {
                $this->pushPtInfo($this->field['edu']['platform'], "edu", $eduInfo);
            }
            
            $eduInfo['uid']    = $this->lawyer['uid'];
            $eduInfo['inputtime']  = time();
            \Rpc::getUCData("Member.admin.updateUcLawyerEdu", $eduInfo);
        }
    }
    
    /**
     * ��ʦר��
     * 
     * @param array $data Ҫ����������
     * 
     * @return void
     */
    private function _dealSortInfo($data)
    {
        if (is_array($data)) {
            $data = implode(",", $data);
        }
        
        //�޸����û�ϵͳר��
        $sorts = \Rpc::getData("Lawyer.queryProfessionIdsByNames", $data);
        $sortIds = array();
        foreach ($sorts as $val) {
            //ɾȥһ������֪ʶ��Ȩ
            if ($val['id'] != 15) {
                $sortIds[] = $val['id'];
            }
        }
        
        //��ɾ��ԭ��ר��
        \Rpc::getUCData('Member.admin.deleteLawyerRefProfByUid', $this->uid);
        if ($sortIds) {
            if (isset($this->field['edu']['platform'])) {
                $this->pushPtInfo($this->field['sort']['platform'], "sort", $data);
            }
            \Rpc::getUCData('Member.admin.insertLawyerRefProfSel', $this->uid, $sortIds, 1, 0, time());
        }
    }
    
    /**
     * �޸�����
     * 
     * @param array $data Ҫ����������(array("oldpwd"=>"������", "newpwd"=>"������", "cti"=>false))
     * 
     * @return void
     */
    private function _dealPasswordInfo($data)
    {
        $passIntensity = \Tools\User::getPassIntensity($data['newpwd']);
        
        $old = \Rpc::getUCData('Member.admin.encrypt', $data['oldpwd']);
        $new = $data['newpwd'];//\Rpc::getUCData('Member.admin.encrypt', $data['newpwd']);//�������Ϊ������
        if ($old && $new) {
            $rs = \Rpc::getUCData('Member.admin.updateUcMemberPassword', $this->uid, $old, $new, $passIntensity);
            if ($rs != 1) {
                $this->setError("�����޸�ʧ��");
                return false;
            }
        }
        return true;
    }
}