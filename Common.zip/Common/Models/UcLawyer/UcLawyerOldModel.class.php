<?php
/**
 * ������Ҫͬ���޸ĵ�����
 *
 * @author lihuanlin <birdy@findlaw.cn>
 */
namespace Models\UcLawyer;

/**
 * ������Ҫͬ���޸ĵ�����
 *
 * @author lihuanlin <birdy@findlaw.cn>
 */
class UcLawyerOldModel extends UcLawyerModel
{
    /**
     * ��ʼ��
     * 
     * @param string $lawyerInfo ��ʦ����
     * 
     * @return void
     */
    public function __construct($lawyerInfo)
    {
        $this->uid        = $lawyerInfo['uid'];
        $this->userid     = $lawyerInfo['userid'];
        $this->lawyer     = $lawyerInfo;
    }
    
    /**
     * ��ʼ��������
     * 
     * @param array $data Ҫ����������
     * 
     * @return void
     */
    public function start($data)
    {
        if (isset($data['findlaw'])) { //�ҷ�����ͬ��
            $this->_dealFindlawInfo($data['findlaw']);
        }
        
        if (isset($data['lvxintong'])) {
            $lvt = $data['lvxintong'];
            if (isset($lvt['edu'])) {
                $this->_dealEduInfo($lvt['edu']);
            }
        }
    }
    
    /**
     * �����ҷ�������ͬ������
     * 
     * @param array $data Ҫ����������
     * 
     * @return void
     */
    private function _dealFindlawInfo($data)
    {
        //����
        $info = array();
        if (isset($data['languagekind'])) { 
            $lk    = explode(",", $data['languagekind']);
            $array = array("��ͨ��", "���ط���", 'Ӣ��'); 
            $kind  = array();
            $kind2 = array();
            foreach ($lk as $lk) {
                if ($array[$lk]) {
                    $kind[] = $array[$lk];
                    $kind2[] = $lk;
                }
            }
            $info['languagekind']      = implode("��", $kind);
        }
        
        //ѧ��
        if (isset($data['degree'])) {
            $info["degree"] = intval($data['degree']);
        }
        
        //�Ա�
        if (isset($data['sex'])) {
            $info["sex"] = intval($data['sex']) === 1 ? 1 : 0;
        }
        
        //����
        if (isset($data['birthday'])) {
            $info['birthday'] = date("Y-m-d", $data['birthday']);
        }
        
        //400�绰
        if (trim($data['tel400']) != $this->lawyer['tel400']) {
            $info['tel400']   = trim($data['tel400']);
        }
        
        //�Ƿ����������Ϣ
        if (isset($data['lawyerLinklawroom'])) {
            $info['linkfirm'] = intval($data['lawyerLinklawroom']) === 1 ? 1 : 0;
        }
        
        //��ƪ
        if (isset($data['postcode'])) {
            $info['postcode'] = intval($data['postcode']);
        }
        
        //ר��
        if (isset($data['sort'])) {
            $info['profession'] = trim($data['sort']);
        }
        
        //��������
        if (isset($data['yuming']) && $data['yuming']) {
            $lawyerdetail     = \Rpc::getData('Member.getTblMemberSearchByUserid', $this->lawyer['userid']);
            $mypath         = "http://{$yuming}.findlaw.cn/";
            $arr1 = array(
                "membertype" => 'lawyer', 
                "lawerid"    => $this->lawyer['userid'], 
                "username"   => $this->lawyer['username'], 
                "myurl"      => $yuming, 
                "mypath"     => $mypath, 
                "inputdate"  => time()
            );

            \Rpc::getData('Lawyer.Admin.insertDns', $arr1); //���뵽dns
            $info['yuming'] = $data['yuming'];
        }
        
        if ($info) {
            $info['regdate']   = time();
            $info['userid']    = $this->userid;
            $info['auditdate'] = time();
            //\Rpc::getData("Member.Admin.updateTblMemberSearchByUseridSel", $info);
            //\Rpc::getData("Member.Admin.updateTblmemberInfoByUseridSel", $info);
        }
    }
    
    /**
     * ͬ������ͨ�еĽ�����Ϣ
     * 
     * @param array $data Ҫ����������
     * 
     * @return void
     */
    private function _dealEduInfo($data)
    {
        //�û���ϵ������Ϣ
        $eduInfo = array();
        
        //��ҵѧУ
        if (isset($data['schoolName'])) {
            $eduInfo['graduation'] = trim($data['schoolName']);
        }
        
        //ѧ��ȡ�÷�ʽ
        if (isset($data['degreeType'])) {
            $eduInfo['xueliGettype'] = intval($data['degreeType']);
        }
        
        //רҵ
        if (isset($data['specialty'])) {
            $eduInfo['specialName']  = trim($data['specialty']);
        }
        
        if ($eduInfo) {
            //���������ͨ�û�����������ͨ�û���Ϣ��
            $tmprow = \Rpc::getData("Wlt.getWltMemberInDetail", $this->userid);
            if (!empty($tmprow)) {
                $eduInfo['lawyerUserid'] = $this->userid;
                \Rpc::getData("Wlt.Admin.updateByUseridOrId", $eduInfo);
            }
        }
    }
}