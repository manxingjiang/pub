<?php
/**
 * �����Զ��崦��������
 *
 * @author lihuanlin <birdy@findlaw.cn>
 */
namespace Models\UcLawyer;

/**
 * �����Զ��崦��������
 *
 * @author lihuanlin <birdy@findlaw.cn>
 */
class UcLawyerDiyModel extends UcLawyerModel
{
    /**
     * ��ʼ��
     * 
     * @param string $lawyerInfo ��ʦ����
     * 
     * @return void
     */
    public function __construct($lawyerInfo)
    {
        $this->uid = $lawyerInfo['uid'];
        $this->userid = $lawyerInfo['userid'];
        $this->lawyer = $lawyerInfo;
    }

    /**
     * ��ʼ��������
     * 
     * @param array $data Ҫ����������
     * 
     * @return void
     */
    public function start($data)
    {
        foreach ($data as $k=>$v) {
            $method = "_deal".ucwords($k);
            if (method_exists($this, $method)) {
                $this->$method($v);
            }
        }
        return $this->ptInfo;
    }
    
    /**
     * ��������
     * 
     * @param string $email ����
     * 
     * @return void
     */
    private function _dealEmail($email)
    {
        //��ǰ�ʺ��Ƿ��Ѿ��а���Ϣ��ֱ�Ӹ���
        $bindInfo = \Rpc::getUCData("Member.admin.getEmailMobileByUidTypeid", $this->uid, 2);
        if ($bindInfo) {
            $update = array(
                "mobileEmail" => $email,
                "verifyTime" => time(),
                "status" => 1,
                "uid" => $this->uid,
                "typeid" => 2
            );
            \Rpc::getUCData("Member.admin.updateEmailMobileByUidTypeid", $update);
            \Rpc::getData("Member.Admin.updateEmailByUid", $email, $this->uid);
        } else {
            $update = array(
                "mobileEmail" => $email,
                "inputtime" => time(),
                "verifyTime" => time(),
                "status" => 1,
                "uid" => $this->uid,
                "typeid" => 2
            );
            \Rpc::getUCData("Member.admin.insertUcEmailMobileSel", $update);
            \Rpc::getData("Member.Admin.updateUserAddEmail", $this->uid, $this->userid, 1, $email);

        }

        //ͬʱ���������е�����
        $data = array('userid' => $this->userid, 'email' => $email);
        //\Rpc::getData("Member.Admin.updateTblmemberInfoByUseridSel", $data);
        $data = array('email' => $email);
        \Rpc::getData("PHPBB.Admin.updateCdbMembersSel", $data, $this->userid);

        //ͬʱ���������е�����-�µ��û�ϵͳ
        $ucLawyer = array('uid' => $this->uid, 'email' => $email);
        \Rpc::getUCData('Member.admin.updateUcLawyerByPKSel', $ucLawyer);
        \Rpc::getUCData('Member.admin.updateUcMemberByPKSel', $ucLawyer);
    }
    
    /**
     * �����ֻ���
     * 
     * @param string $phone �ֻ���
     * 
     * @return void
     */
    private function _dealPhone($phone)
    {
        $bindInfo = \Rpc::getUCData("Member.admin.getEmailMobileByUidTypeid", $this->uid, 1);
        if ($bindInfo) {
            $update = array(
                "mobileEmail" => $phone,
                "verifyTime" => time(),
                "status" => 1,
                "uid" => $this->uid,
                "typeid" => 1
            );
            $res_code = \Rpc::getUCData("Member.admin.updateEmailMobileByUidTypeid", $update);
        } else {
            $update = array(
                "mobileEmail" => $phone,
                "inputtime" => time(),
                "verifyTime" => time(),
                "status" => 1,
                "uid" => $this->uid,
                "typeid" => 1
            );
            $res_code = \Rpc::getUCData("Member.admin.insertUcEmailMobileSel", $update);
        }
        if (true) {
            //ͬʱ���������е�����
            $data = array('userid' => $this->userid, 'mobil' => $phone);
            //\Rpc::getData("Member.Admin.updateTblmemberInfoByUseridSel", $data);
            //\Rpc::getData('Member.Admin.updateTblMemberSearchByUseridSel', $data);

            //ͬ���û���ϵ
            $ucLawyer = array('uid' => $this->uid, 'mobile' => $phone);
            \Rpc::getUCData('Member.admin.updateUcLawyerByPKSel', $ucLawyer);
            \Rpc::getUCData('Member.admin.updateUcMemberByPKSel', $ucLawyer);

            //ͬ��PHPBB��
            if ($phone != '') {
                $data = array('mobil' => $phone);
                \Rpc::getData("PHPBB.Admin.updateCdbMembersSel", $data, $this->userid);
            }
        }
    }
}