<?php
/**
 * ��ȡ����֤��/�����/���б��Ե���ʦ����
 *
 * @author lihuanlin <birdy@findlaw.cn>
 */
namespace Models\UcLawyer;

/**
 * ��ȡ����֤��/�����/���б��Ե���ʦ����
 *
 * @author lihuanlin <birdy@findlaw.cn>
 */
class UcLawyerListInfoModel extends UcLawyerModel
{
    /**
     * ��ʼ��
     * 
     * @param int    $uid        UID
     * @param string $lawyerInfo ��ʦ����
     * 
     * @return void
     */
    public function __construct($uid, $lawyerInfo)
    {
        $this->uid    = $uid;
        $this->lawyer = $lawyerInfo;
    }
    
    /**
     * ��ȡ����Ϣ
     * 
     * @param string $table ������baseΪ������(uc_lawyer)
     * @param array  $para  ���Ӳ���
     * 
     * @return array
     */
    public function getByTable($table="base", $para = array())
    {
        $methodName = "_get".ucwords($table)."Info";
        if (method_exists($this, $methodName)) {
            return $this->$methodName($para);
        } else {
            $this->setError("���������ڣ�".$methodName);
            return false;
        }
    }
    
    /**
     * ��ȡ������Ϣ������ uc_lawyer, uc_lawyer_info, uc_lawyer_other
     * 
     * @param array $para ���Ӳ���
     * 
     * @return array
     */
    private function _getBaseInfo($para = array())
    {
        if (isset($para['uncheck']) && $para['uncheck'] === true) { //��ȡδ��˵�����
            $map = array();
            $map['num'] = "002";
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $content = $this->_jsonDecode($rs['content']);
                $content = $content ? $content : unserialize($rs['content']);
                return $content['newData'];
            } else {
                return null;
            }
        } else {
            return $this->lawyer;
        }
    }
    
    /**
     * ��ȡ��ʦͷ��-������˵�
     *
     * @param array $para ���Ӳ���
     *
     * @return array
     */
    private function _getFileInfo($para = array())
    {
        if (isset($para['uncheck']) && $para['uncheck'] === true) { //��ȡδ��˵�����
            $map = array();
            $map['num'] = "010";
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $content = $this->_jsonDecode($rs['content']);
                $content = $content ? $content : unserialize($rs['content']);
                return $content['newData'];
            } else {
                return null;
            }
        } else {
            return null;
        }
    }
    
    /**
     * ��ȡ��ʦ�Ŷ�������Ϣ
     * <added by wujifeng@findlaw.cn>
     * 
     * @param array $para ���Ӳ���
     * 
     * @return array
     */
    private function _getLtInfo($para = array())
    {
        if (isset($para['uncheck']) && $para['uncheck'] === true) { //��ȡδ��˵�����
            $map = array();
            $map['num'] = "007";
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $content = $this->_jsonDecode($rs['content']);
                $content = $content ? $content : unserialize($rs['content']);
                return $content['newData'];
            } else {
                return null;
            }
        }
    }
    
    /**
     * ��ȡ��ʦ�Ŷӷ���Χ
     * <added by wujifeng@findlaw.cn>
     * 
     * @param array $para ���Ӳ���
     * 
     * @return array
     */
    private function _getLtSInfo($para = array())
    {
        if (isset($para['uncheck']) && $para['uncheck'] === true) { //��ȡδ��˵�����
            $map = array();
            $map['num'] = "008";
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $content = $this->_jsonDecode($rs['content']);
                $content = $content ? $content : unserialize($rs['content']);
                return $content['newData'];
            } else {
                return null;
            }
        }
    }
    
    /**
     * ��ȡ��ʦ�Ŷӷ���Χ
     * <added by wujifeng@findlaw.cn>
     * 
     * @param array $para ���Ӳ���
     * 
     * @return array
     */
    private function _getLtCInfo($para = array())
    {
        if (isset($para['uncheck']) && $para['uncheck'] === true) { //��ȡδ��˵�����
            $map = array();
            $map['num'] = "009";
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $content = $this->_jsonDecode($rs['content']);
                $content = $content ? $content : unserialize($rs['content']);
                return $content['newData'];
            } else {
                return null;
            }
        }
    }
    
    /**
     * ��ȡר����Ϣ
     * 
     * @param array $para ���Ӳ���
     * 
     * @return array
     */
    private function _getSortInfo($para = array())
    {
        if (isset($para['pid'])) {
            $pid = intval($para['pid']);
        } else {
            $pid = 1;
        }
        
        $list = \Rpc::getUCData("Member.queryUcLawyerRefProfListByUidPid", $this->uid, $pid);
        return $list;
    }

    /**
     * ��ȡ���˷������Ϣ
     * 
     * @param array $para ���Ӳ���
     * 
     * @return array
     */
    private function _getSceneInfo($para = array())
    {
        C('nocache', 1);
        if (isset($para['uncheck']) && $para['uncheck'] === true) { //��ȡδ��˵�����
            $map = array();
            $map['num'] = "005";
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $content = $this->_jsonDecode($rs['content']);
                $content = $content ? $content : unserialize($rs['content']);
                return $content['scene'];
            } else {
                return null;
            }
        } else {
            $uids = array($this->uid);
            $list = \Rpc::getUCData("Member.queryUcLawyerSceneListByUids", $uids);
            return $list;
        }
    }
    
    /**
     * ��ȡ֤����Ϣ
     * 
     * @param array $para ���Ӳ���
     * 
     * @return array
     */
    private function _getCertInfo($para = array())
    {
        C('nocache', 1);
        if (isset($para['uncheck']) && $para['uncheck'] === true) { //��ȡδ��˵�����
            $map = array();
            $map['num'] = "005";
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $content = $this->_jsonDecode($rs['content']);
                $content = $content ? $content : unserialize($rs['content']);
                return $content['cert'];
            } else {
                return null;
            }
        } else {
            $uids = array($this->uid);
            $list = \Rpc::getUCData("Member.queryUcLawyerCertListByUids", $uids);
            return $list;
        }
    }
    
    /**
     * ��ȡ���ְ����Ϣ
     * 
     * @param array $para ���Ӳ���
     * 
     * @return array
     */
    private function _getSocialpostInfo($para = array())
    {
        if (isset($para['uncheck']) && $para['uncheck'] === true) { //��ȡδ��˵�����
            $map = array();
            $map['num'] = "004";
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $content = $this->_jsonDecode($rs['content']);
                $content = $content ? $content : unserialize($rs['content']);
                return $content;
            } else {
                return null;
            }
        } else {
            $uids = array($this->uid);
            $list = \Rpc::getUCData("Member.queryUcLawyerSocialpostListByUids", $uids);
            return $list;
        }
    }
    
    /**
     * ��ȡ����Χ��Ϣ
     * 
     * @param array $para ���Ӳ���
     * 
     * @return array
     */
    private function _getServiceInfo($para = array())
    {
        if (isset($para['uncheck']) && $para['uncheck'] === true) { //��ȡδ��˵�����
            $map = array();
            $map['num'] = "003";
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $content = $this->_jsonDecode($rs['content']);
                $content = $content ? $content : unserialize($rs['content']);
                return $content;
            } else {
                return null;
            }
        } else {
            $uids = array($this->uid);
            $list = \Rpc::getUCData("Member.queryUcLawyerServiceListByUids", $uids);
            return $list;
        }
    }
    /**
     * ��ȡ����������Ϣ��Ϣ
     *
     * @param array $para ���Ӳ���
     *
     * @return array
     */
    private function _getFriendlinkInfo($para = array())
    {
        if (isset($para['uncheck']) && $para['uncheck'] === true) { //��ȡδ��˵�����
            $map = array();
            $map['num'] = "011";
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $content = $this->_jsonDecode($rs['content']);
                return $content ? $content : unserialize($rs['content']);
            } else {
                return null;
            }
        } else {
            $list = \Rpc::getData("FriendLink.queryFriendLinkByUserid", $this->lawyer['userid']);
            return $list;
        }
    }
    /**
     * ��ȡ��������
     * 
     * @param array $para ���Ӳ���
     * 
     * @return array
     */
    private function _getWorkInfo($para = array())
    {
        if (isset($para['uncheck']) && $para['uncheck'] === true) { //��ȡδ��˵�����
            $map = array();
            $map['num'] = "013";
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $content = $this->_jsonDecode($rs['content']);
                return  $content ? $content : unserialize($rs['content']);
            } else {
                return null;
            }
        } else {
            return $this->lawyer;
        }
    }
    /**
     * ��ȡ��������
     * 
     * @param array $para ���Ӳ���
     * 
     * @return array
     */
    private function _getEduInfo($para = array())
    {
        if (isset($para['uncheck']) && $para['uncheck'] === true) { //��ȡδ��˵�����
            $map = array();
            $map['num'] = "014";
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $content = $this->_jsonDecode($rs['content']);
                $content = $content ? $content : unserialize($rs['content']);
                return array_merge($content['editData'], $content['newData']);
            } else {
                return null;
            }
        } else {
            return $this->lawyer;
        }
    }
}
?>