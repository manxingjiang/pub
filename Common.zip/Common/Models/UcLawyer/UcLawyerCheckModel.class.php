<?php
/**
 * ������Ҫ��˵�����
 *
 * @author lihuanlin <birdy@findlaw.cn>
 */
namespace Models\UcLawyer;

/**
 * ������Ҫ��˵�����
 *
 * @author lihuanlin <birdy@findlaw.cn>
 */
class UcLawyerCheckModel extends UcLawyerModel
{
    //��Ҫ���������ģ�飬��001,002������
    private $checkModel = array();
    
    /**
     * ��ʼ��
     * 
     * @param int   $uid        UID
     * @param array $lawyerInfo ��ʦ����
     * 
     * @return void
     */
    public function __construct($uid, $lawyerInfo)
    {
        $this->uid     = $uid;
        $this->userid  = $lawyerInfo['userid'];
        $this->lawyer  = $lawyerInfo;
    }
    
    /**
     * ��ʼ��������
     * 
     * @param array $data Ҫ����������
     * 
     * @return void
     */
    public function start($data)
    {
        if (isset($data['base']) || isset($data['info']) || isset($data['other'])) {  //������Ϣ���Ͳ�����Ϣ��
            $this->_dealBaseInfo($data['base'], $data['info'], $data['other']);
        }
        if (isset($data['lt_info']) || isset($data['lt_svr']) || isset($data['lt_cert'])) {
            //��ʦ�Ŷ�������Ϣ
            $this->_dealLtInfo($data['lt_info'], $data['lt_svr'], $data['lt_cert']);
        }
        if (isset($data['socialpost'])) { //���ְ��
            $this->_dealSocialpostInfo($data['socialpost']);
        }
        if (isset($data['cert_photo']) || isset($data['scene_photo'])) {  //����֤��ͷ���գ���ᣩ���
            $this->_dealPhotoInfo($data['cert_photo'], $data['scene_photo']);
        }
        if (isset($data['service'])) { //����Χ
            $this->_dealServiceInfo($data['service']);
        }
        if (isset($data['friendlink'])) { //��������
            $this->_dealFriendlinkInfo($data['friendlink']);
        }
        if (isset($data['file'])) { //ͷ��
            $this->_dealPhoto($data['file']);
        }
        if (isset($data['work'])) { //��������
            $this->_dealWorkInfo($data['work']);
        }
        if (isset($data['edu'])) { //��������
            $this->_dealEduInfo($data['edu']);
        }
        if ($this->checkModel) { //��������ܱ�
            $old = \Rpc::getUCData("Audit.admin.getAuAuditMainByUid", $this->uid);
            
            if ($old) {
                $info = explode(",", $old['info']);
                if ($info) {
                    $info = array_unique(array_merge($info, $this->checkModel));
                } else {
                    $info = $this->checkModel;
                }
                $update = array(
                    "uid" => $this->uid,
                    "updatetime" => time(),
                    "ifaudit"  => 0,
                    "info" => implode(",", array_filter($info))
                );
                \Rpc::getUCData("Audit.admin.updateAuAuditMainByUid", $update);
            } else {
                $insert = array(
                    "uid"      => $this->uid,
                    "userid"   => $this->userid,
                    "username" => $this->lawyer['username'],
                    "areacode" => $this->lawyer['areacode'],
                    "updatetime" => time(),
                    "ifaudit"  => 0,
                    "info"     => implode(",", array_filter($this->checkModel))
                );
                \Rpc::getUCData("Audit.admin.insertAuAuditMainSel", $insert);
            }
        }
    }
    
    /**
     * ��������������� json ��֧��gbk
     * 
     * @param array $base  ������Ϣ
     * @param array $info  ������Ϣ
     * @param array $other ������Ϣ
     * 
     * @return void
     */
    private function _dealBaseInfo($base = array(), $info = array(), $other = array())
    {
        $checkInfo = array();
        $oldInfo   = array();
        if ($base) {
            foreach ($base as $k=>$v) {
                $field = $this->field[$k];
                if ($v != $this->lawyer[$k]) {
                    $checkInfo[$k] = $v;
                    $oldInfo[$k] = $this->lawyer[$k];
                }
            }
        }
        if ($info) {
            foreach ($info as $k=>$v) {
                $field = $this->field[$k];
                if ($v != $this->lawyer['ucLawyerInfo'][$k]) {
                    $checkInfo[$k] = $v;
                    $oldInfo[$k] = $this->lawyer['ucLawyerInfo'][$k];
                }
            }
        }
        if ($other) {
            foreach ($other as $k=>$v) {
                $field = $this->field[$k];
                if ($v != $this->lawyer['ucLawyerOther'][$k]) {
                    $checkInfo[$k] = $v;                    
                    $oldInfo[$k] = $this->lawyer['ucLawyerOther'][$k];
                }
            }
        }
        
        if ($checkInfo) {
            $type = "002";
            $this->checkModel[] = $type;
            $map = array();
            $map['num'] = $type;
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $rs['content'] = $this->_jsonDecode($rs['content']);
                
                $content =  $rs['content'] ? $rs['content'] : unserialize($rs['content']);//������ǰ���ݴ���
                $content['newData'] = $content['newData'] ? $content['newData'] : array();
                $content['oldData'] = $content['oldData'] ? $content['oldData'] : array();
                
                $content['newData'] = array_merge($content['newData'], $checkInfo);
                $content['oldData'] = array_merge($content['oldData'], $oldInfo);
                $update = array();
                $update['id']      = $rs['id'];
                $update['inputtime'] = time();
                
                $update['content']  = $this->_dealJsonEncode($content);
                $update['areacode'] = $this->lawyer['areacode'];
                
                \Rpc::getUCData("Audit.admin.updateAuAuditinfoByPKSel", $update, $type);
            } else {
                $content = array();
                $content['newData']  = $checkInfo;
                $content['oldData']  = $oldInfo;
                $content['username'] = $this->lawyer['username'];
                $content['userid']   = $this->lawyer['userid'];
                $insert = array();
                $insert['inputtime'] = time();
                $insert['ifaudit'] = 0;
                $insert['audittime'] = 0;
                $insert['uid'] = $this->uid;
                $insert['areacode'] = $this->lawyer['areacode'];
                $insert['content']  = $this->_dealJsonEncode($content);
                \Rpc::getUCData("Audit.admin.insertAuAuditinfoSel", $insert, $type);
            }
        }
    }
    
    /**
     * ������ʦ�Ŷ��������
     * <added by wujifeng@findlaw.cn>
     * 
     * @param type $info ��ʦ�Ŷӻ�����Ϣ
     * @param type $svr  ��ʦ�Ŷӷ���Χ
     * @param type $cert ��ʦ�Ŷ�����֤��
     * 
     * @return void
     */
    private function _dealLtInfo($info = array(), $svr = array(), $cert = array())
    {  
        $tinfo = \Rpc::getData('Lawyerteam.getLawyerteamInfoByUid', $this->uid);//��ѯ�Ŷ�������Ϣ
        if (!empty($info['ltoprona'])) {
            $checkInfo['ltoprona'] = $info['ltoprona']; //����ltoprona
            unset($info['ltoprona']);
            $oldInfo =array();
            $type = '007';
        }
        if (!empty($info)) {
            $nto = array(
                'ltname'=>'tname',
                'lttel'=>'tel',
                'lttel400' => 't400',
                'ltmobile'=>'mobile',
                'ltareacode'=>'areacode',
                'ltaddr'=>'addr',
                'ltresume'=>'resume',
                'ltnotice'=>'notice',
                'ltvideo'=>'video',
                'ltbanner'=>'banner',
                'ltavatar'=>'photo',
            ); //������Ӧ��ϵ            
            foreach ($info as $k=>$v) {//�������ݱȶ�
                if ($tinfo[$nto[$k]] !== $v) {
                    $checkInfo[$nto[$k]] = $v;  //��Ҫ��˵����� 
                    $oldInfo[$nto[$k]] = $tinfo[$nto[$k]]; //������
                }
            }
            $type = "007";
        } elseif (!empty($svr)) {
            $service = \Rpc::getData('Lawyerteam.queryLawyerteamServiceList', 1, 20, array('tid'=>$tinfo['tid']));
            if (!empty($service)) { //�Ѵ��ڷ���Χ
                foreach ($svr['ltservice'] as $k => $v) {
                    if ($v['id'] != 0) {
                        foreach ($service as $sk => $sv) {
                            if ($v['id'] == $sv['id']) { //������ͬ����
                                if ($v['servername'] != $sv['servername'] || $v['serverdesc'] != $sv['serverdesc']) {
                                    $checkInfo[$v['id']] = array('id' => $v['id'], 'servername' => $v['servername'], 'serverdesc' => $v['serverdesc'],);  //��Ҫ��˵����� 
                                    $oldInfo[$sv['id']] = array('id' => $sv['id'], 'servername' => $sv['servername'], 'serverdesc' => $sv['serverdesc'],);  //������ 
                                }
                            }
                        }
                    } else { // �²�������
                        $checkInfo[0][] = array('servername' => $v['servername'], 'serverdesc' => $v['serverdesc'],);  //��Ҫ��˵�����                            
                    }
                }
            } else {
                foreach ($svr['ltservice'] as $k => $v) {
                    $checkInfo[0][] = array('servername' => $v['servername'], 'serverdesc' => $v['serverdesc']);  //��Ҫ��˵�����
                }
            }
            $type = "008";            
        } elseif (!empty ($cert)) {
            $checkInfo = $cert;
            $oldInfo = array();
            $type = "009";            
        }
        if ($checkInfo) { //������Ҫ��˵�����
            $this->checkModel[] = $type;
            $map = array();
            $map['num'] = $type;
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $rs['content'] = $this->_jsonDecode($rs['content']);
                $content =  $rs['content'] ? $rs['content'] : unserialize($rs['content']);//������ǰ���ݴ���
                if ($type!='008') {
                    if ($type!='007') {
                        //���ݴ������Ŷ�֤�飩
                        $content['newData'] = array('ltphotos'=>array_merge($content['newData']['ltphotos'], $checkInfo['ltphotos']));
                    } else {
                        $content['newData'] = array_merge($content['newData'], $checkInfo);
                    }
                    if (isset($content['newData']['ltoprona']) && $content['newData']['ltoprona']==';') {
                        unset($content['newData']['ltoprona']);
                        if (empty($content['newData'])) {
                            return \Rpc::getUCResponse('Audit.admin.deleteAuAuditinfoByIds', array($rs['id']), $type);
                        }
                    }
                    $content['oldData'] = array_merge($content['oldData'], $oldInfo);
                } else {//���ݴ������Ŷӷ���Χ��
                    $content['newData'] = $checkInfo;
                    $content['oldData'] = $oldInfo;
                }
                $update = array();
                $update['id']      = $rs['id'];
                $update['inputtime'] = time();
                $update['content']  = $this->_dealJsonEncode($content);
                $update['areacode'] = $this->lawyer['areacode'];
                \Rpc::getUCData("Audit.admin.updateAuAuditinfoByPKSel", $update, $type);
            } else {                
                $content = array();
                $content['newData']  = $checkInfo;
                $content['oldData']  = $oldInfo;
                $content['username'] = $this->lawyer['username'];
                $content['userid']   = $this->lawyer['userid'];
                $insert = array();
                $insert['inputtime'] = time();
                $insert['ifaudit'] = 0;
                $insert['audittime'] = 0;
                $insert['uid'] = $this->uid;
                $insert['areacode'] = $this->lawyer['areacode'];
                $insert['content']  = $this->_dealJsonEncode($content);
                \Rpc::getUCData("Audit.admin.insertAuAuditinfoSel", $insert, $type);
            }
        }
    }
    
    /**
     * �������ְ������
     * 
     * @param array $data Ҫ����������
     * 
     * @return void
     */
    private function _dealSocialpostInfo($data)
    {
        $old = \Rpc::getUCData("Member.queryUcLawyerSocialpostListByUids", array($this->uid));
        if ($old) {
            $old  = \Tools\Arr::setDataAsKey($old, 'id');
        }
        
        $checkInfo = array();
        foreach ($data as $data) {
            if ($data['id'] > 0) {
                if (isset($old[$data['id']]) && $data['post'] != $old[$data['id']]['post']) {
                    $checkInfo["edit"][$data['id']] = array(
                        'id'       => $data['id'], 
                        'post'     => $data['post'], 
                        'post_old' => $old[$data['id']]['post']
                    );
                }
            } else {
                if ($data['post'] !='') {
                    $checkInfo["new"][] = $data['post'];
                }
            }
        }
        if ($checkInfo) {
            $type = "004";
            $this->checkModel[] = $type;
            $map = array();
            $map['num'] = $type;
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $rs['content'] = $this->_jsonDecode($rs['content']);
                $content =  $rs['content'] ? $rs['content'] : unserialize($rs['content']);//������ǰ���ݴ���
                $content['newData']  = $checkInfo['new'] ? $checkInfo['new'] : array();
                $content['editData'] = $checkInfo['edit'] ? $checkInfo['edit'] : array();
                $update = array();
                $update['id']      = $rs['id'];
                $update['inputtime'] = time();
                $update['content']  = $this->_dealJsonEncode($content);
                $update['areacode'] = $this->lawyer['areacode'];
                \Rpc::getUCData("Audit.admin.updateAuAuditinfoByPKSel", $update, $type);
            } else {
                $content = array();
                $content['newData']   = $checkInfo['new']  ? $checkInfo['new'] : array();
                $content['editData']  = $checkInfo['edit'] ? $checkInfo['edit'] : array();
                $content['username'] = $this->lawyer['username'];
                $content['userid']   = $this->lawyer['userid'];
                $insert = array();
                $insert['inputtime'] = time();
                $insert['ifaudit'] = 0;
                $insert['audittime'] = 0;
                $insert['uid'] = $this->uid;
                $insert['areacode'] = $this->lawyer['areacode'];
                $insert['content']  = $this->_dealJsonEncode($content);
                \Rpc::getUCData("Audit.admin.insertAuAuditinfoSel", $insert, $type);
            }
        }
    }
    
    /**
     * ����֤��ͷ���գ���ᣩ���
     * 
     * @param array $cert  ֤������
     * @param array $scene ���������
     * 
     * @return void
     */
    private function _dealPhotoInfo($cert=array(), $scene=array())
    {
        $checkInfo = array();
        C('nocache', 1);
        if ($scene || $cert) {
            $type = "005";
            $this->checkModel[] = $type;
            $map = array();
            $map['num'] = $type;
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            $rs = $rs[0];
            $rs['content'] = $this->_jsonDecode($rs['content']);
            $content =  $rs['content'] ? $rs['content'] : unserialize($rs['content']);//������ǰ���ݴ���
            if ($content) {
                $newdata = $content['scene']['new'];
                $editdata = $content['scene']['edit'];
            } 
            //���
            if ($scene['type'] < 2 && $scene['id']>0) {//�޸�δ������ݺ����������
                $update = array();
                if ($scene['type']==0) {//�޸� ���������
                    $old = \Rpc::getUCData('Member.getUcLawyerSceneById', $scene['id']);
                    $update['sceneName_old'] = $old['sceneName'];
                    $update['labels_old'] = $old['labels'];
                    $update['memo_old'] = $old['memo'];
                    $update['sceneImg_old'] = $old['sceneImg'];
                    $update['id'] = $scene['id'];
                    $update['type'] = 1;
                    if ($scene['sceneName'] != $old['sceneName']) {
                        $update['sceneName'] = $scene['sceneName'];
                    }
                    if ($scene['labels'] != $old['labels']) {
                        $update['labels'] = $scene['labels'];
                    }
                    if ($scene['memo'] != $old['memo']) {
                        $update['memo'] = $scene['memo'];
                    }
                    if ($scene['sceneImg'] && $scene['sceneImg'] != $old['sceneImg']) {
                        $update['sceneImg'] = $scene['sceneImg'];
                    } 
                    $update = $editdata ? array_merge($editdata, array($update)) : array($update);
                } else {//�޸��޸��� δ�������
                    foreach ($editdata as $key=>&$val) {
                        if ($val['id'] == $scene['id']) {
                            $scene['sceneImg'] = $scene['sceneImg'] ? $scene['sceneImg'] : $val['sceneImg'];
                            $val = $scene;
                            break;
                        }
                    }
                    unset($val);
                    $update = $editdata;
                }
                $checkInfo['scene']['new'] = $newdata;
                if ($update) {
                    $checkInfo['scene']['edit'] = $update;
                }
                $checkInfo['cert'] =  $content['cert'];
            } else if ($scene) {//�������ݣ�type=2 and id=0�����������ݵı༭(type=2 id>0)
                if ($scene['type'] == 2 && $scene['id']>0) {// ���������ݵı༭(type=2 id>0)
                    foreach ($newdata as $key=>&$val) {
                        if ($val['id'] == $scene['id']) {
                            $scene['sceneImg'] = $scene['sceneImg'] ? $scene['sceneImg'] : $val['sceneImg'];
                            $val = $scene;
                            break;
                        }
                    }
                    unset($val);
                    $newarr = $newdata;
                } else {//�������ݣ�type=2 and id=0��
                    $scene['id'] = empty($newdata) ? 1 : count($newdata) + 1;
                    $scene['type'] = 2;
                    $newarr = $newdata ? array_merge($newdata, array($scene)) : array($scene);
                }
                $checkInfo['scene']['new'] = $newarr;
                $checkInfo['scene']['edit'] = $editdata;
                $checkInfo['cert'] =  $content['cert'];
            }
            //����֤��
            if ($content && $cert) {
                $newdata = $content['cert']['new'];
                $editdata = $content['cert']['edit'];
            } 
            if ($cert['type'] < 2 && $cert['id']>0) {//�޸�δ������ݺ����������
                $update = array();
                if ($cert['type']==0) {//�޸� ���������
                    $oldcert = \Rpc::getUCData("Member.queryUcLawyerCertListByForm", 1, 1, array('id'=>$cert['id']));
                    $old = array();
                    $old = $oldcert[0];
                    $update['certname_old'] = $old['certname'];
                    $update['labels_old'] = $old['labels'];
                    $update['memo_old'] = $old['memo'];
                    $update['certimg_old'] = $old['certimg'];
                    $update['id'] = $cert['id'];
                    $update['type'] = 1;
                    if ($cert['certname'] != $old['certname']) {
                        $update['certname'] = $cert['certname'];
                    }
                    if ($cert['labels'] != $old['labels']) {
                        $update['labels'] = $cert['labels'];
                    }
                    if ($cert['memo'] != $old['memo']) {
                        $update['memo'] = $cert['memo'];
                    }
                    if ($cert['certimg'] && $cert['certimg'] != $old['certimg']) {
                        $update['certimg'] = $cert['certimg'];
                    } 
                    $update = $editdata ? array_merge($editdata, array($update)) : array($update);
                } else {//�޸��޸��� δ�������
                    foreach ($editdata as $key=>&$val) {
                        if ($val['id'] == $cert['id']) {
                            $cert['certimg'] = $cert['certimg'] ? $cert['certimg'] : $val['certimg'];
                            $val = $cert;
                            break;
                        }
                    }
                    unset($val);
                    $update = $editdata;
                }
                $checkInfo['cert']['new'] = $newdata;
                if ($update) {
                    $checkInfo['cert']['edit'] = $update;
                }
                $checkInfo['scene'] = $content['scene'];
            } else if ($cert) {//�������ݣ�type=2 and id=0�����������ݵı༭(type=2 id>0)
                if ($cert['type'] == 2 && $cert['id']>0) {// ���������ݵı༭(type=2 id>0)
                    foreach ($newdata as $key=>&$val) {
                        if ($val['id'] == $cert['id']) {
                            $cert['certimg'] = $cert['certimg'] ? $cert['certimg'] : $val['certimg'];
                            $val = $cert;
                            break;
                        }
                    }
                    unset($val);
                    $newarr = $newdata;
                } else {//�������ݣ�type=2 and id=0��
                    $cert['id'] = empty($newdata) ? 1 : count($newdata) + 1;
                    $cert['type'] = 2;
                    $newarr = $newdata ? array_merge($newdata, array($cert)) : array($cert);
                }
                $checkInfo['cert']['new'] = $newarr;
                $checkInfo['cert']['edit'] = $editdata;
                $checkInfo['scene'] = $content['scene'];
            } 
        }
        if ($checkInfo) {
            if ($rs['content']) {
                $update = array();
                $update['id']      = $rs['id'];
                $update['inputtime'] = time();
                $checkInfo['username'] = $this->lawyer['username'];
                $checkInfo['userid']   = $this->lawyer['userid'];
                $update['content']  = $this->_dealJsonEncode($checkInfo);
                $update['areacode'] = $this->lawyer['areacode'];
                $res = \Rpc::getUCResponse("Audit.admin.updateAuAuditinfoByPKSel", $update, $type);
            } else {
                $content = array();
                $content['cert']   = $checkInfo['cert']  ? $checkInfo['cert'] : array();
                $content['scene']  = $checkInfo['scene'] ? $checkInfo['scene'] : array();
                $content['username'] = $this->lawyer['username'];
                $content['userid']   = $this->lawyer['userid'];
                $insert = array();
                $insert['inputtime'] = time();
                $insert['ifaudit'] = 0;
                $insert['audittime'] = 0;
                $insert['uid'] = $this->uid;
                $insert['areacode'] = $this->lawyer['areacode'];
                $insert['content']  = $this->_dealJsonEncode($content);
                $res = \Rpc::getUCResponse("Audit.admin.insertAuAuditinfoSel", $insert, $type);
            }
        }
    }
    
    /**
     * ��������Χ����
     * 
     * @param array $data Ҫ����������
     * 
     * @return void
     */
    private function _dealServiceInfo($data)
    {
        $old = \Rpc::getUCData("Member.queryUcLawyerServiceListByUids", array($this->uid));
        if ($old) {
            $old  = \Tools\Arr::setDataAsKey($old, 'id');
        }
        
        $checkInfo = array();
        foreach ($data as $data) {
            if ($data['id'] > 0) {
                if (isset($old[$data['id']])) {
                    $update = array();
                    if ($data['servername'] != $old[$data['id']]['servername']) {
                        $update['servername'] = $data['servername'];
                        $update['servername_old'] = $old[$data['id']]['servername'];
                    }
                    if ($data['serverdesc'] != $old[$data['id']]['serverdesc']) {
                        $update['serverdesc'] = $data['serverdesc'];
                        $update['serverdesc_old'] = $old[$data['id']]['serverdesc'];
                    }
                    if ($update) {
                        $update['id'] = $data['id'];
                        $checkInfo["edit"][$data['id']] = $update;
                    }
                }
            } else {
                $checkInfo["new"][] = array($data['servername'], $data["serverdesc"]);
            }
        }
        if ($checkInfo) {
            $type = "003";
            $this->checkModel[] = $type;
            $map = array();
            $map['num'] = $type;
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $rs['content'] = $this->_jsonDecode($rs['content']);
                $content =  $rs['content'] ? $rs['content'] : unserialize($rs['content']);//������ǰ���ݴ���
                $content['newData']  = $checkInfo['new'] ? $checkInfo['new'] : array();
                $content['editData'] = $checkInfo['edit'] ? $checkInfo['edit'] : array();
                $update = array();
                $update['id']      = $rs['id'];
                $update['inputtime'] = time();
                $update['content']  = $this->_dealJsonEncode($content);
                $update['areacode'] = $this->lawyer['areacode'];
                \Rpc::getUCData("Audit.admin.updateAuAuditinfoByPKSel", $update, $type);
            } else {
                $content = array();
                $content['newData']   = $checkInfo['new']  ? $checkInfo['new'] : array();
                $content['editData']  = $checkInfo['edit'] ? $checkInfo['edit'] : array();
                $content['username'] = $this->lawyer['username'];
                $content['userid']   = $this->lawyer['userid'];
                $insert = array();
                $insert['inputtime'] = time();
                $insert['ifaudit'] = 0;
                $insert['audittime'] = 0;
                $insert['uid'] = $this->uid;
                $insert['areacode'] = $this->lawyer['areacode'];
                $insert['content']  = $this->_dealJsonEncode($content);
                \Rpc::getUCData("Audit.admin.insertAuAuditinfoSel", $insert, $type);
            }
        }
    }
    
    
    /**
     * ͷ�����
     * 
     * @param array $data ͷ��
     * 
     * @return void
     */
    private function _dealPhoto($data)
    {
        $checkInfo = array();
        if (isset($this->lawyer['ucLawyerFile'])) {
            $old = $this->lawyer['ucLawyerFile'];
        } else {
            $old = \Rpc::getUCData('Member.admin.getLawyerFileByUidPid', $this->uid, 1);
        }
        if (empty($old['photo'])) {
            $old['photo'] = 'blank.jpg';
        }
        foreach ($data as $k => $v) {
            $checkInfo['new'][$k] = $v;
            $checkInfo['edit'][$k] = $old[$k] === null ? '' : $old[$k];
        }
        if ($checkInfo) {
            $type = "010";
            $this->checkModel[] = $type;
            $map = array();
            $map['num'] = $type;
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $rs['content'] = $this->_jsonDecode($rs['content']);
                $content =  $rs['content'] ? $rs['content'] : unserialize($rs['content']);//������ǰ���ݴ���
                $content['newData'] = $checkInfo['new'] ? $checkInfo['new'] : array();
                $content['editData']   = $checkInfo['edit']  ? $checkInfo['edit'] : array();
                $update = array();
                $update['id']      = $rs['id'];
                $update['inputtime'] = time();
                $update['content']  = $this->_dealJsonEncode($content);
                $update['areacode'] = $this->lawyer['areacode'];
                \Rpc::getUCData("Audit.admin.updateAuAuditinfoByPKSel", $update, $type);
            } else {
                $content = array();
                $content['newData'] = $checkInfo['new'] ? $checkInfo['new'] : array();
                $content['editData']   = $checkInfo['edit']  ? $checkInfo['edit'] : array();
                $content['username'] = $this->lawyer['username'];
                $content['userid']   = $this->lawyer['userid'];
                $insert = array();
                $insert['inputtime'] = time();
                $insert['ifaudit'] = 0;
                $insert['audittime'] = 0;
                $insert['uid'] = $this->uid;
                $insert['areacode'] = $this->lawyer['areacode'];
                $insert['content']  = $this->_dealJsonEncode($content);
                \Rpc::getUCData("Audit.admin.insertAuAuditinfoSel", $insert, $type);
            }
        }
    }
    /**
     * ����������������
     *
     * @param array $data Ҫ����������
     *
     * @return void
     */
    private function _dealFriendlinkInfo($data)
    {
        $old = \Rpc::getData("FriendLink.queryFriendLinkByUserid", $this->lawyer['userid']);
        if ($old) {
            $old  = \Tools\Arr::setDataAsKey($old, 'id');
        }
        $checkInfo = array();
        foreach ($data as $data) {
            if ($data['id'] > 0) {
                if (isset($old[$data['id']])) {
                    $update = array();
                    if ($data['sitename1'] != $old[$data['id']]['sitename1']) {
                        $update['sitename1'] = $data['sitename1'];
                        $update['sitename1_old'] = $old[$data['id']]['sitename1'];
                    }
                    if ($data['homepage1'] != $old[$data['id']]['homepage1']) {
                        $update['homepage1'] = $data['homepage1'];
                        $update['homepge1_old'] = $old[$data['id']]['homepage1'];
                    }
                    if ($update) {
                        $update['id'] = $data['id'];
                        $checkInfo["edit"][$data['id']] = $update;
                    }
                }
            } else {
                $checkInfo["new"][] = array($data['sitename1'], $data["homepage1"]);
            }
        }
        if ($checkInfo) {
            $type = "011";
            $this->checkModel[] = $type;
            $map = array();
            $map['num'] = $type;
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $rs['content'] = $this->_jsonDecode($rs['content']);
                $content =  $rs['content'] ? $rs['content'] : unserialize($rs['content']);//������ǰ���ݴ���
                $content['newData']  = $checkInfo['new'] ? $checkInfo['new'] : array();
                $content['editData'] = $checkInfo['edit'] ? $checkInfo['edit'] : array();
                $update = array();
                $update['id']      = $rs['id'];
                $update['inputtime'] = time();
                $update['content']  = $this->_dealJsonEncode($content);
                $update['areacode'] = $this->lawyer['areacode'];
                \Rpc::getUCData("Audit.admin.updateAuAuditinfoByPKSel", $update, $type);
            } else {
                $content = array();
                $content['newData']   = $checkInfo['new']  ? $checkInfo['new'] : array();
                $content['editData']  = $checkInfo['edit'] ? $checkInfo['edit'] : array();
                $content['username'] = $this->lawyer['username'];
                $content['userid']   = $this->lawyer['userid'];
                $insert = array();
                $insert['inputtime'] = time();
                $insert['ifaudit'] = 0;
                $insert['audittime'] = 0;
                $insert['uid'] = $this->uid;
                $insert['areacode'] = $this->lawyer['areacode'];
                $insert['content']  = $this->_dealJsonEncode($content);
                \Rpc::getUCData("Audit.admin.insertAuAuditinfoSel", $insert, $type);
            }
        }
    }
 
    /**
     * ��������,�������������
     * 
     * @param array $data Ҫ����������
     * 
     * @return void
     */
    private function _dealWorkInfo($data)
    {
        $old = \Rpc::getUCData("Member.admin.getUcLawyerExperByUid", $this->uid);
        if ($old) {
            $old  = \Tools\Arr::setDataAsKey($old, 'id');
        }
        $checkInfo = array();
        foreach ($data as $data) {
            if ($data['id'] > 0) {
                if (isset($old[$data['id']])) {
                    $update = array();
                    if ($data['workPeriodStart'] != $old[$data['id']]['workPeriodStart']) {
                        $update['workPeriodStart'] = $data['workPeriodStart'];
                        $update['workPeriodStart_old'] = $old[$data['id']]['workPeriodStart'];
                    }
                    if ($data['workPeriodEnd'] != $old[$data['id']]['workPeriodEnd']) {
                        $update['workPeriodEnd'] = $data['workPeriodEnd'];
                        $update['workPeriodEnd_old'] = $old[$data['id']]['workPeriodEnd'];
                    }
                    if ($data['lawfirmname'] != $old[$data['id']]['lawfirmname']) {
                        $update['lawfirmname'] = $data['lawfirmname'];
                        $update['lawfirmname_old'] = $old[$data['id']]['lawfirmname'];
                    }
                    if ($update) {
                        $update['id'] = $data['id'];
                        $checkInfo["edit"][$data['id']] = $update;
                    }
                }
            } else {
                $checkInfo["new"][] = $data;
            }
        }
        if ($checkInfo) {
            $type = "013";
            $this->checkModel[] = $type;
            $map = array();
            $map['num'] = $type;
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $rs['content'] = $this->_jsonDecode($rs['content']);
                $content =  $rs['content'] ? $rs['content'] : unserialize($rs['content']);//������ǰ���ݴ���
                $content['newData']  = $checkInfo['new'] ? $checkInfo['new'] : array();
                $content['editData'] = $checkInfo['edit'] ? $checkInfo['edit'] : array();
                $update = array();
                $update['id']      = $rs['id'];
                $update['inputtime'] = time();
                $update['content']  = $this->_dealJsonEncode($content);
                $update['areacode'] = $this->lawyer['areacode'];
                \Rpc::getUCData("Audit.admin.updateAuAuditinfoByPKSel", $update, $type);
            } else {
                $content = array();
                $content['newData']   = $checkInfo['new']  ? $checkInfo['new'] : array();
                $content['editData']  = $checkInfo['edit'] ? $checkInfo['edit'] : array();
                $content['username'] = $this->lawyer['username'];
                $content['userid']   = $this->lawyer['userid'];
                $insert = array();
                $insert['inputtime'] = time();
                $insert['ifaudit'] = 0;
                $insert['audittime'] = 0;
                $insert['uid'] = $this->uid;
                $insert['areacode'] = $this->lawyer['areacode'];
                $insert['content']  = $this->_dealJsonEncode($content);
                \Rpc::getUCData("Audit.admin.insertAuAuditinfoSel", $insert, $type);
            }
        }
    }

    /**
     * �������������
     * 
     * @param array $data Ҫ����������
     * 
     * @return void
     */
    private function _dealEduInfo($data)
    {
        //ѧ������ degreeѧ�� 1Сѧ 2 ���� 3 ���� 4 ��ר 5 ���� 6 ˶ʿ 7 ��ʿ 10���� 11 ����
        $old = \Rpc::getUCData("Member.admin.getUcLawyerEduByUid", (int)($this->uid));
        $deg = array(3=>'a',4=>'b',5=>'c',6=>'d',7=>'e',10=>'f');
        $nold = array();
        foreach ($old as $key=>$val) {
            if ($val['degree'] < 3 || $val['degree'] > 10 ) {
                unset($oedu);
                break;
            }
            $nold[$deg[$val['degree']]] = $val;
        } 
        $checkInfo = array();
        foreach ($data as $key => $data) {
            if ($data['id'] > 0) {
                if (isset($nold[$key])) {
                    $update = array();
                    if ($data['entranceTime'] != $old[$key]['entranceTime']) {
                        $update['entranceTime'] = $data['entranceTime'];
                        $update['entranceTime_old'] = $old[$key]['entranceTime'];
                    }
                    if ($data['graduationTime'] != $old[$key]['graduationTime']) {
                        $update['graduationTime'] = $data['graduationTime'];
                        $update['graduationTime_old'] = $old[$key]['graduationTime'];
                    }
                    if ($data['schoolName'] != $old[$key]['schoolName']) {
                        $update['schoolName'] = $data['schoolName'];
                        $update['schoolName_old'] = $old[$key]['schoolName'];
                    }
                    if ($update) {
                        $update['id'] = $key;
                        $checkInfo["edit"][$key] = $update;
                    }
                }
            } else {
                $checkInfo["new"][$key] = $data;
            }
        }
        if ($checkInfo) {
            $type = "014";
            $this->checkModel[] = $type;
            $map = array();
            $map['num'] = $type;
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $rs['content'] = $this->_jsonDecode($rs['content']);
                $content =  $rs['content'] ? $rs['content'] : unserialize($rs['content']);//������ǰ���ݴ���
                $content['newData']  = $checkInfo['new'] ? $checkInfo['new'] : array();
                $content['editData'] = $checkInfo['edit'] ? $checkInfo['edit'] : array();
                $update = array();
                $update['id']      = $rs['id'];
                $update['inputtime'] = time();
                $update['content']  = $this->_dealJsonEncode($content);
                $update['areacode'] = $this->lawyer['areacode'];
                \Rpc::getUCData("Audit.admin.updateAuAuditinfoByPKSel", $update, $type);
            } else {
                $content = array();
                $content['newData']   = $checkInfo['new']  ? $checkInfo['new'] : array();
                $content['editData']  = $checkInfo['edit'] ? $checkInfo['edit'] : array();
                $content['username'] = $this->lawyer['username'];
                $content['userid']   = $this->lawyer['userid'];
                $insert = array();
                $insert['inputtime'] = time();
                $insert['ifaudit'] = 0;
                $insert['audittime'] = 0;
                $insert['uid'] = $this->uid;
                $insert['areacode'] = $this->lawyer['areacode'];
                $insert['content']  = $this->_dealJsonEncode($content);
                \Rpc::getUCData("Audit.admin.insertAuAuditinfoSel", $insert, $type);
            }
        }
    }

    /**
     * json ��֧��gbk ��Ҫת��utf-8 Ȼ����
     * 
     * @param array $data Ҫ����������
     * 
     * @return array
     */
    private function _dealJsonEncode($data)
    {
        $data = \Tools\Strings::utf8Gbk($data, 'UTF-8');
        return json_encode($data);
    }
}
?>