<?php
/**
 * ɾ�� ����֤��/�����/����Χ/���ְ�� ���б��Ե���ʦ����
 *
 * @author lihuanlin <birdy@findlaw.cn>
 */
namespace Models\UcLawyer;

/**
 * ɾ�� ����֤��/�����/����Χ/���ְ�� ���б��Ե���ʦ����
 *
 * @author lihuanlin <birdy@findlaw.cn>
 */
class UcLawyerDeleteModel extends UcLawyerModel
{
    /**
     * ��ʼ��
     * 
     * @param int   $uid    UID
     * @param array $lawyer ��ʦ����
     * 
     * @return void
     */
    public function __construct($uid, $lawyer)
    {
        $this->uid = $uid;
        $this->lawyer = $lawyer;
    }
    
    /**
     * ɾ����Ϣ
     * 
     * @param string $table ����
     * @param int    $id    ��ϢID�����Ϊ���飬��������ɾ��
     * @param array  $para  ��������
     * 
     * @return void
     */
    public function deleteById($table, $id, $para = array())
    {
        $methodName = "_delete".ucwords($table)."Info";
        if (method_exists($this, $methodName)) {
            return $this->$methodName($id, $para);
        } else {
            $this->setError("���������ڣ�".$methodName);
            return false;
        }
    }
    
    /**
     * ɾ��֤����Ϣ
     * 
     * @param int   $id   ID
     * @param array $para ���Ӳ���
     * 
     * @return array
     */
    private function _deleteCertInfo($id, $para)
    {
        return true;
        return \Rpc::getUCData("Member.admin.deleteUcLawyerCertByIdUid", $id, $this->uid);
    }
    
    /**
     * ɾ�����˷����
     * 
     * @param int   $id   ID
     * @param array $para ���Ӳ���
     * 
     * @return array
     */
    private function _deleteSceneInfo($id, $para)
    {
        return true;
        return \Rpc::getUCData("Member.admin.deleteUcLawyerSceneByIdUid", $id, $this->uid);
    }
    
    /**
     * ɾ�����ְ��
     * 
     * @param int   $id   ID
     * @param array $para ���Ӳ���
     * 
     * @return array
     */
    private function _deleteSocialpostInfo($id, $para)
    {
        if ($id > 0) {
            $rs = \Rpc::getUCData("Member.admin.deleteUcLawyerSocialpostByIdUid", $id, $this->uid);
            if (!$rs) {
                return false;
            } 
        }
        //return true;
        if (isset($para['uncheck']) && $para['uncheck'] > 0) {
            $type = "004";
            $map = array();
            $map['num'] = $type;
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $content = unserialize($rs['content']);
                if ($content['editData'] && isset($content['editData'][$id])) {
                    unset($content['editData'][$id]);
                }
                
                if ($content['editData'] || $content['newData']) {
                    $update = array();
                    $update['id']      = $rs['id'];
                    $update['content']  = serialize($content);
                    \Rpc::getUCData("Audit.admin.updateAuAuditinfoByPKSel", $update, $type);
                } else {
                    \Rpc::getUCData("Audit.admin.deleteAuAuditinfoByIds", array($rs['id']), $type);
                }
            }
        }
        
        return true;
    }
    
    /**
     * ɾ������Χ
     * 
     * @param int   $id   ID
     * @param array $para ���Ӳ���
     * 
     * @return array
     */
    private function _deleteServiceInfo($id, $para)
    {
        if ($id > 0) {
            $rs = \Rpc::getUCData("Member.admin.deleteUcLawyerServiceByIdUid", $id, $this->uid);
            if (!$rs) {
                return false;
            } 
        }
        
        //ͬ����˵�����
        if (isset($para['uncheck']) && $para['uncheck'] > 0) {
            $type = "003";
            $map = array();
            $map['num'] = $type;
            $map['uids'] = array($this->uid);
            $map['ifaudit'] = 0;
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                $rs = $rs[0];
                $content = unserialize($rs['content']);
                if ($content['editData'] && isset($content['editData'][$id])) {
                    unset($content['editData'][$id]);
                }
                if ($content['editData'] || $content['newData']) {
                    $update = array();
                    $update['id']      = $rs['id'];
                    $update['content']  = serialize($content);
                    \Rpc::getUCData("Audit.admin.updateAuAuditinfoByPKSel", $update, $type);
                } else {
                    \Rpc::getUCData("Audit.admin.deleteAuAuditinfoByIds", array($rs['id']), $type);
                }
            }
        }
    }
}