<?php
/**
 * �ҷ�����Դ���ĳ���API
 *  
 * @author wujifeng <wujifeng@findlaw.cn>
 */
namespace Models\Anjian;

/**
 * �ҷ�����Դ���ĳ���API
 *  
 * @author wujifeng <wujifeng@findlaw.cn>
 */
class AnjianModel
{
    /**
    * ���½Ӱ���ʦ
    *
    * @return array ��������
    **/
    public static function last_replay_lawers()
    {
        $lastrelawer = \Rpc::getData('Anyuan.queryAnyuanResList', 0, 4, array('ifaudit'=>1, 'orderBy'=>'id desc'));         
        foreach ($lastrelawer as $val) {
            $useridarr[] = $val['lawerid'];
        }
        if (is_array($useridarr)) { //��ȡ��ʦ��ϸ��Ϣ
            $ret = self::getLawyerInfoByUserids($useridarr);
        } else {
            $ret = '';
        }        
        return $ret;
    }
    
    /**
     * ��ȡ�û�������ʦ��Ϣ
     * 
     * @param array $useridarr ��ʦuserid����
     * 
     * @return array Description
     */
    public static function getLawyerInfoByUserids($useridarr)
    {
        $retemp = \Rpc::getUCData('Member.queryUcLawyerList', array('userids' => $useridarr), 1, 2);
        foreach ($retemp as $k => $v) {
            foreach ($useridarr as $i => $u) {
                if ($u == $v['userid']) {
                    $ret[$i]['uid'] = $v['uid'];
                    $ret[$i]['province'] = $v['province'];
                    $ret[$i]['city'] = $v['city'];
                    $ret[$i]['country'] = $v['country'];
                    $ret[$i]['username'] = $v['username'];
                    $ret[$i]['yuming'] = $v['yuming'];
                    $ret[$i]['tel'] = $v['tel'];
                    $ret[$i]['mobile'] = $v['mobile'];
                    $ret[$i]['photo'] = $v['photo'];
                }
            }
        }
        unset($retemp);
        return $ret;
    }
    
     /**
    * ��Դ�б�
    *
    * @param string $type    ����(all Ϊ���е�  area ���ݵ������б�   codeΪʡ����(��λ���ֻ�ǰ��λ) type��Ū(code 1��ͨ��Դ  2�Ƽ���Դ 3�Ӽ���Դ ) 
    * @param string $code    ��������򰸼����ͱ���
    * @param string $page    �ӵڼ�ҳ��ʼ
    * @param string $pageper ÿҳ��ʾ����
    * @param string $order   ��ʲô����
    * 
    * @return array ��������
    **/  
    public static function anyuanslist($type, $code = '', $page = 0, $pageper = 25, $order = ' a.pubdate desc ')
    {
        $appendcon = array('ifaudit'=>1, 'orderBy'=>$order);
        switch ($type) {
        case 'area':
            if (strlen($code) == 2) {
                $min = intval($code . "0000");
                $max = intval($code . "9999");
            } else {
                $min = intval($code . "00");
                $max = intval($code . "99");
            }
            $appendcon['areacodeMin'] = $min;
            $appendcon['areacodeMax'] = $max;
            break;
        case 'type':
            $appendcon['type'] = $code;
            break;
        default:
            break;
        }
        $result = \Rpc::getData('Anyuan.queryAnyuansAllMap', $page, $pageper, $appendcon);
        return $result;
        
    }
    
    /**
    * ������ذ�Դ������ʦ
    *
    * @param string $page    �ӵڼ�ҳ��ʼ
    * @param string $pageper ÿҳ��ʾ����
    * @param string $order   ��ʲô����
    *
    * @return array ��������
    **/ 
    public function get_last_yday_lawers($page = 1, $pageper = 25, $order = 'id desc ')
    {
        //SELECT * from findlaw_anjian.yday_join where ifaudit=1 ORDER BY id desc LIMIT 0,25 
        $appendcon = array('ifaudit'=>1, 'orderBy'=>$order);
        $res = \Rpc::getData('Anyuan.queryYdayJoinList', $page, $pageper, $appendcon);
        foreach ($res as $val) {
            $useridarr[] = $val['lawerid'];
        }
        $result = self::getLawyerInfoByUserids($useridarr);
        return $result;
    }
    
    /**
    * ��ҳ������ʦ�ظ�ͳ��
    *
    * @param int    $number ����..
    * @param string $order  ��ʲô����
    * @param array  $_where ����
    * 
    * @return array ��������
    **/
    public static function index_ayzx_replay_order($number = 8, $order = ' lawercount desc ', $_where = array())
    {
        //����û���ݷ������ȡһ��
        $timelimit = $_SERVER['SERVER_NODE'] == 'local' ? 86400*365 : 86400;
        //����0��ʱ���
        $dateend = strtotime(date('Ymd'));
        //Ĭ�����յ�ͳ������
        $where = array(
                'orderBy'=>$order,
                'limitCount'=>$number,
                'ifaudit'=>1,
                'groupBy'=>'lawerid',
                'datestart' => $dateend - $timelimit,
                'dateend' => $dateend,
        );
        if (!empty($_where) && is_array($_where)) {
            $where = array_merge($where, $_where);
        }
        $result = \Rpc::getData('Anyuan.queryAnyuanResMapList', $where);
        if (is_array($result)) {
            foreach ($result as $key => $val) {
                if ($val['lawerid']) {
                    $ret = self::getLawyerInfoByUserids(array($val['lawerid']));
                    if (!empty($ret[0]['file8098'])) {
                        $ret[0]['img'] = \Tools\Image::imagesReplace('/my/lawyer_80/' . $ret[0]['file8098']);
                    } else {
                        $ret[0]['img'] = \Tools\Image::imagesReplace('/my/photo/' . $ret[0]['photo']);
                    }
                    $result[$key]['lawerinfo'] = $ret[0];
                    $result[$key]['lawerinfo']['profession'] = \Tools\Prof::getLawProStr($ret[0]['uid']);
                } else {
                    unset($result[$key]);
                }
            }
        }
        return $result;
    }
    
    /**
    * ���а�Դͳ��
    *
    * @param string $type ����(all Ϊ���е�  area ���ݵ������б�(codeΪʡ����(��λ����) ) type��Ū(code  1�Ƽ���Դ 2�Ӽ���Դ  3��ع�����Դ)    
    * @param string $code ��������
    *
    * @return array ��������
    **/ 
    public static function allanyuanscount($type, $code = '')
    {
        //SELECT count(*) as `count` FROM findlaw_anjian.anyuans_main where ifaudit=1 
        $appendcon = array('ifaudit'=>1, );
        switch ($type) {
        case 'area':
            if (strlen($code) == 2) {
                $min = intval($code . "0000");
                $max = intval($code . "9999");
            } else {
                $min = intval($code . "00");
                $max = intval($code . "99");
            }
            $appendcon['areacodeMin'] = $min;
            $appendcon['areacodeMax'] = $max;
            break;
        case 'type':
            $appendcon['type'] = intval($code);
            break;
        default:
            break;
        }
        $result = \Rpc::getData('Anyuan.queryAnyuansAllMapCount', $appendcon);
        return intval($result);
    }
    
    /**
    * �õ�ֻ��ʡ�������ͳ�ƵĽ��
    *
    * @return array ��������
    **/
    public static function get_Area_count_list()
    {
        $ret   = array();
        $plist = self::getprovincelist(1, 100);
        $i = 0;
        foreach ($plist as $val) {
            $code             = intval(substr($val['id'], 0, 2));
            $ret[$i]['code']  = $code;
            $ret[$i]['name']  = $val['province'];
            $ret[$i]['count'] = self::count_by_area($val['id']);
            $i++;
        }
        return $ret;
    }
    
    /**
    * ����ʡ���б�
    *
    * @param string $page    �ӵڼ�ҳ��ʼ
    * @param string $pageper ÿҳ��ʾ����
    *
    * @return array ��������
    **/
    public static function getprovincelist($page = 1, $pageper = 20)
    {
        //SELECT * FROM findlaw_db.fl_area WHERE grade=0 LIMIT 0,100
        $rs = \Rpc::getUCData('Area.queryUcAreaListByForm', array('grade'=>0, 'orderBy'=>' id asc '), 1, 0);
        return $rs;
        
    }
    
    /**
    * �õ���ʡ�ļ�¼����ͳ��
    *
    * @param int $areacode ��������
    *
    * @return array ��������
    **/
    public static function count_by_area($areacode)
    {
         $code = intval(substr($areacode, 0, 2));
        if ($code <= 0) {
            return 0;
        }
        $result = self::allanyuanscount('area', $code);
        if (empty($result)) {
            return 0;
        }
        return $result;
    }
    
    /**
    * ��ذ�Դͳ��
    *
    * @return array ��������
    **/
    public function ydaymaincount()
    {
        //SELECT count(*) as `count` FROM findlaw_anjian.yday_main where ifaudit=1 
        $result = \Rpc::getData('Anyuan.queryYdayMainListCount', array('ifaudit'=>1));
        return $result;
    }    
    
    /**
    * ���ڰ�Դ�ظ������б�
    *
    * @param int    $id      ID
    * @param int    $rid     rid 
    * @param string $page    �ӵڼ�ҳ��ʼ
    * @param string $pageper ÿҳ��ʾ����
    * @param string $order   ��ʲô����
    *
    * @return array ��������
    **/
    public static function ayzx_comm_list($id, $rid, $page = 1, $pageper = 20, $order = "id")
    {
        $id  = intval($id);
        $rid = intval($rid);
        $appendcon = array('ifaudit'=>1, 'orderBy'=>'id desc', 'aid'=>$id, 'rid'=>$rid);
        return \Rpc::getData('Anyuan.queryAnyuansRepCommentList', $page, $pageper, $appendcon);
    }       
    
    /**
    * �����е��б�
    *
    * @param int $typeid  ����ID
    * @param int $typeval ����ֵ
    *
    * @return array ��������
    **/
    public static function getCityCountryList($typeid, $typeval)
    {
        //SELECT * FROM findlaw_db.fl_area WHERE grade=0 LIMIT 0,100
        $typeid = intval($typeid);
        if ($typeid == 1) {
            $prifix = intval(substr($typeval, 0, 2));
            $mix    = intval($prifix . '0000');
            $max    = intval($prifix . '9999');
        } else {
            $prifix = intval(substr($typeval, 0, 4));
            $mix    = intval($prifix . '00');
            $max    = intval($prifix . '99');
        }
        $ucdata = \Rpc::getUCData('Area.queryUcAreaListByForm', array('grade'=>$typeid, 'areacodeBegin'=>$mix, 'areacodeEnd'=>$max), 1, 0);
        return $ucdata;
    }
    
      /**
    * ��������ͨ���� �� ʡ �� ǰX��
    *
    * @param int    $type    ����
    * @param int    $typeid  ����ID 
    * @param string $page    �ӵڼ�ҳ��ʼ
    * @param string $pageper ÿҳ��ʾ����
    * @param string $order   ��ʲô����
    *
    * @return array ��������
    **/
    public static function get_top_jifeng($type = 1, $typeid = 0, $page = 1, $pageper = 5, $order = 'alljifeng desc')
    {
        if ($type == 0) {
            $min = 0;
            $max = 999999;
        } else if ($type == 1) {
            $pri = substr($typeid, 0, 2);
            $min = intval($pri . "0000");
            $max = intval($pri . "9999");
        } else {
            $pri = substr($typeid, 0, 4);
            $min = intval($pri . "00");
            $max = intval($pri . "99");
        }
        $resdata = \Rpc::getData('Lxt.queryLxtMemberList', $page, $pageper, array('ifaudit'=>1, 'areaMax'=>$max, 'areaMin'=>$min, 'orderBy'=>$order));
        return $resdata;
    }
    
    /**
    * ��ذ�Դ�б�
    *
    * @param string $page    �ӵڼ�ҳ��ʼ
    * @param string $pageper ÿҳ��ʾ����
    * @param string $order   ��ʲô����
    *
    * @return array ��������
    **/ 
    public static function ydaypagelist($page, $pageper, $order = ' id desc ')
    {
        //SELECT m.*,s.id as sid,s.yid,s.plname,s.ajprovince,s.ajcity,s.pprovince,s.pcity,s.special,s.demo 
        //FROM findlaw_anjian.yday_main m,findlaw_anjian.yday_sub s WHERE m.id=s.yid and m.ifaudit=1 
        //ORDER BY m.id desc LIMIT 0,25 
        $result = \Rpc::getData('Anyuan.queryYdayMainList', $page, $pageper, array('ifaudit'=>1, 'orderBy'=>$order));
        return $result;
    }
        
     /**
    * ��ѯ��ʦ�Ƿ���������ذ�Դ����
    *
    * @param int $userid �û�ID
    *
    * @return array ��������
    **/
    public static function yday_lawer_query($userid)
    {
        //SELECT * from findlaw_anjian.yday_join where lawerid='�Ż۽���ʦ' LIMIT 0,1 
        if (empty($userid)) {
            return;
        }
        $result = \Rpc::getData(array('Anyuan.queryYdayJoinListCount', array('H-N'=>'YES')), array('lawerid'=>$userid));
        return $result;
    }
    
    /**
    * �û����� ���۷�ҳ(ֻ������)
    *
    * @param string $page    �ӵڼ�ҳ��ʼ
    * @param string $pageper ÿҳ��ʾ����
    * @param string $order   ��ʲô����
    *
    * @return array ��������
    **/
    public static function public_fadeback($page, $pageper, $order = 'id desc ')
    {
        //SELECT * from findlaw_anjian.public_fadeback where ifaudit=1 ORDER BY id desc LIMIT 0,4 
        $appendcon = array('ifaudit'=>1, 'orderBy'=>$order);
        $result = \Rpc::getData('Anyuan.queryPublicFadebackList', $page, $pageper, $appendcon);        
        return $result;
    }
    
    /**
    * �û�����ͳ��
    *
    * @return array ���ط���������
    **/
    public static function public_fadeback_count()
    {
        //SELECT count(*) as `count` from findlaw_anjian.public_fadeback where ifaudit=1 
        $result = \Rpc::getData('Anyuan.queryPublicFadebackListCount', array('ifaudit'=>1));      
        return intval($result);
    }
    
    /**
    * �û��������ݵ������б�
    *
    * @param int    $id      ID
    * @param string $page    �ӵڼ�ҳ��ʼ
    * @param string $pageper ÿҳ��ʾ����
    * @param string $order   ��ʲô����
    *
    * @return array ��������
    **/
    public static function public_comm_list($id, $page = 1, $pageper = 25, $order = ' id desc ')
    {
        //SELECT * from findlaw_anjian.public_comment where pid=2052 and ifaudit=1 ORDER BY id desc LIMIT 0,25 
        $appendcon = array('ifaudit'=>1, 'pid'=>$id, 'orderBy'=>$order);
        $result = \Rpc::getData('Anyuan.queryPublicCommentList', $page, $pageper, $appendcon);
        return $result;
    }
    
    /**
    * �б갸��ͳ�����б�
    *
    *@param int $biddate Description
    *
    * @return array ��������
    **/ 
    public static function haszbcount($biddate = 10000)
    {
        //SELECT count(*) as `count` FROM findlaw_anjian.anyuans_main where ifaudit=1 and biddate>10000 
        $result = \Rpc::getData('Anyuan.queryAnyuansAllListCount', array('ifaudit'=>1, 'biddateStart'=>10000));
        return intval($result);
    }
    
    /**
    * �б갸���б�
    *
    * @param string $page    �ӵڼ�ҳ��ʼ
    * @param string $pageper ÿҳ��ʾ����
    * @param string $order   ��ʲô����
    *
    * @return array ��������
    **/ 
    public static  function haszblist($page = 0, $pageper = 25, $order = 'id desc ')
    {
        //SELECT m.*,s.* FROM findlaw_anjian.anyuans_main m,findlaw_anjian.anyuans_sub s WHERE m.id=s.mid and m.ifaudit=1 and m.biddate>10000 ORDER BY m.id desc LIMIT 0,25 
        $result = \Rpc::getData('Anyuan.queryAnyuansAllMap', $page, $pageper, array('orderBy'=>$order, 'ifaudit'=>1, 'biddateStart'=>10000));
        return $result;
    }
    
    /**
    * ����ί�б���
    *
    * @return array ��������
    **/
    public static function biaowangdate()
    {
        $week = self::weekdate();
        $now  = self::getbiaowang($week['thisweek']['begin'], $week['thisweek']['end']);
        $last = self::getbiaowang($week['lastweek']['begin'], $week['lastweek']['end']);        
        
        $now           = $now[0];
        $last          = $last[0];
        $now['allzb']  = self::lawerzhonbiaocount($now['lawerid']); //��ʦ�б����ͳ��
        $last['allzb'] = self::lawerzhonbiaocount($last['lawerid']);//��ʦ�б����ͳ��

        $temp = self::getLawyerInfoByUserids(array($now['lawerid']));
        $now['info']  = $temp[0];
        $temp = self::getLawyerInfoByUserids(array($last['lawerid']));
        $last['info'] = $temp[0];
        $now['info']['photo'] = \Tools\Image::imagesReplace('/my/photo/' . $now['info']['photo']);
        $last['info']['photo'] = \Tools\Image::imagesReplace('/my/photo/' . $last['info']['photo']);
        $now['info']['profession'] = \Tools\Prof::getLawProStr($now['info']['uid']); 
        $last['info']['profession'] = \Tools\Prof::getLawProStr($last['info']['uid']); 
        ///����Ϊ��ʱ
        if ($now['allzb'] == 0) {
            $now = $last;
        }          
        return array('thisweek' => $now,'lastweek' => $last);
    }
    
     /**
    * ����ԭʼͳ������(����Ϊ��λ.ͳ�ƻظ��������һλ)
    *
    * @param string $begind ��ʼ
    * @param string $endd   ��β
    *
    * @return array ��������
    **/
    public static function getbiaowang($begind, $endd)
    {
        //select lawerid,count(lawerid) as repcount from findlaw_anjian.anyuans_replay where ifaudit=1 and pdate>=1421596800 and pdate<=1422201599 and isbid=1 group by lawerid order by repcount desc limit 1
        $appendcon = array('limitCount'=>1, 'isbid'=>1, 'datestart'=>$begind, 'dateend'=>$endd,  /*'ifaudit'=>1,*/'respFlag'=>'response', 'groupBy'=>'lawerid');
        $result = \Rpc::getData('Anyuan.queryAnyuanResMapList', $appendcon);
        return $result;
    }
    
    /**
    * ��ʦ�б����ͳ��
    *
    * @param int $lawerid ��ʦID
    *
    * @return array ��������
    **/
    public static function lawerzhonbiaocount($lawerid)
    {
        if (empty($lawerid)) {
            return;
        }
        //SELECT count(*) as `count` FROM findlaw_anjian.anyuans_replay where ifaudit=1 and isbid=1 and lawerid='' 
        $result = \Rpc::getData('Anyuan.queryAnyuanResListCount', array('ifaudit'=>1, 'isbid'=>1, 'lawerid'=>$lawerid));
        return $result;
    }
    
    /**
    * ���ܺ���������
    *
    * @return array ��������
    **/
    public static function weekdate()
    {
        $now  = time();
        $now  = mktime(0, 0, 0, date('m', $now), date("d", $now), date("Y", $now));
        $week = $now - (date("w", $now) - 1) * 3600 * 24;        
        $t11 = mktime(0, 0, 0, date("m", $week), date('d', $week), date('Y'));
        $t12 = $t11 + 3600 * 24 * 7 - 1;
        $t21 = $t11 - 3600 * 24 * 7;
        $t22 = $t11 - 1;        
        $arr = array(
            'thisweek' => array('begin' => $t11,"end" => $t12),
            'lastweek' => array('begin' => $t21,"end" => $t22)
        );
        return $arr;
    }
    
    /**
    * ��Դ�����ɻظ������
    *
    * @param array $sdate ������� 
    *
    * @return array ��������
    **/
    public static function ayzxaddreplay($sdate)
    {
        $aid             = intval($sdate['aid']);
        $appendcon['aid']     = $aid;
        $appendcon['demo']    = htmlspecialchars($sdate['demo']);
        $appendcon['lawerid'] = $sdate['lawerid'];
        $appendcon['pubtype'] = $sdate['openyn'];
        $appendcon['pdate']   = time();
        $appendcon['ip'] = \Tools\Iparea::getClientIp();                
        
        $ret = \Rpc::getResponse('Anyuan.Admin.insertAnyuansReplay', $appendcon);              
                
        $findlaw_db = new \Models\FindlawModel();
        $sqla  = "select count(*) as `count` from findlaw_anjian.anyuans_replay where aid={$aid} ";
        $reta  = $findlaw_db->query($sqla);
        $count = intval($reta[0]['count']);
        $sqlb  = "update  findlaw_anjian.anyuans_main  set  repeatcount={$count} where id={$aid} limit 1 ";
        $findlaw_db->query($sqlb);
        return $ret;
    }
    
    /**
     * ���ȡ�������м���vip��ʦ
     * 
     * @param string $areacode �м���������
     * @param int    $num      ��ʦ����
     * 
     * @return array $res       
     */
    public static function getRandomVipLawyerByAreaCode($areacode, $num)
    {
        $amin = $areacode.'00';
        $amax = $areacode.'99';
        $lsum = \Rpc::getData('Ask.queryDayStatListCount', array('vipflag'=>1, 'areacodeBegin'=>$amin, 'areacodeEnd'=>$amax ));
        $pagesnum = floor($lsum/$num);
        $randnum = rand(1, $pagesnum);
        $res = \Rpc::getData('Ask.queryDayStatList', $randnum, $num, array('vipflag' => 1, 'areacodeBegin' => $amin, 'areacodeEnd' => $amax));
        return $res;
    }
}
