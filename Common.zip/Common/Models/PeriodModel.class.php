<?php
/**
 *  fl_ask����ģ��
 *  
 *  @author zsg <xx@qq.com>
 */
namespace Models;
use Models;

/**
 *  fl_ask����ģ��
 *  
 *  @author zsg <xx@qq.com>
 */
class PeriodModel extends \Think\Model
{
    protected  $connection;
    
    /**
     *	init
     *  
     *  @return null
     */
    public function __construct()
    {
            require "include/config_findlaw_db.php";
            $hb_config_db3307 = array(
                'db_type' => $hb_config_db3307['dbms'],                 //���ݿ�����  mysql,
                'db_user'  => $hb_config_db3307['username'],             //�û���,
                'db_pwd'   => $hb_config_db3307['password'],             //����,
                'db_host'  => $hb_config_db3307['hostname'],                 //host,
                'db_port'  => $hb_config_db3307['hostport'],
                'db_name'  => $hb_config_db3307['database'],
                'db_charset' =>    'gbk',
            );
            $this->connection = array_merge($hb_config_db3307, $this->config());
            parent::__construct();  
    }
    
    /**
     *	config
     *  
     *  @return null
     */
    public function config()
    {
        return array(
           'db_name'=>'findlaw_period'
        ) ;
    }
}
