<?php
/**
 *  fl_ask����ģ��
 *  
 *  @author zsg <xx@qq.com>
 */
namespace Models;
use Models;

/**
 *  fl_ask����ģ��
 *  
 *  @author zsg <xx@qq.com>
 */
class FlaskModel extends \Think\Model
{
    protected  $connection;
    
    /**
     *	init
     *  
     *  @return null
     */
    public function __construct($arg = array())
    {
            $db_config = C('hb_config_33603');
            $db_config = array(
                'db_type' => $db_config['dbms'],                 //���ݿ�����  mysql,
                'db_user'  => $db_config['username'],             //�û���,
                'db_pwd'   => $db_config['password'],             //����,
                'db_host'  => $db_config['hostname'],                 //host,
                'db_port'  => $db_config['hostport'],
                'db_name'  => $db_config['database'],
                'db_charset' =>    'gbk',
            );
            if ($arg['tableName']) {
                $this->tableName = $arg['tableName'];
            }
            $this->connection = array_merge($db_config, $this->config());
            parent::__construct();  
    }
    
    /**
     *	config
     *  
     *  @return null
     */
    public function config()
    {
        return array(
           'db_name'=>'fl_ask'
        ) ;
    }
    
}
