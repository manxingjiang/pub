<?php
/**
 *  �ҷ���������ѯ�ٿ�ģ��ǰ̨����API
 *  
 * @author lihuanlin <birdy@findlaw.cn>
 */
namespace Models\Ask;

/**
 * �ҷ���������ѯ�ٿ�ģ��ǰ̨����API
 *  
 * @author lihuanlin <birdy@findlaw.cn>
 */
class BaikeModel
{
    /**
     * �հٿ����а�
     * 
     * @param int $getNum ��ȡ��¼��   
     * @param int $day    ��:��20120805
     * 
     * @return  array
     */
    static public function queryBkDayClickTopList($getNum, $day)
    {
        $list = \Rpc::getData("Bk.queryBkDayClickTopList", 1, $getNum + 10, $day);
        $num = 0;
        $relist = array();
        foreach ($list as $k => $v) {
            if ($v['entryname'] == '') {
                continue;
            }
            $v['url'] = 'http://china.findlaw.cn/ask/baike/' . $v['eid'] . '.html';
            $relist[] = $v;
            $num ++;
            if ($num == $getNum) {
                break;
            }
        }
        return $relist;
    }

    /**
     * �ܰٿ����а�
     * 
     * @param int $getNum ��ȡ��¼��   
     * @param int $week   ��:��201233
     * 
     * @return array
     */
    static public function queryBkWeekClickTopList($getNum, $week)
    {
        $list = \Rpc::getData("Bk.queryBkWeekClickTopList", 1, $getNum + 10, $week);
        $num = 0;
        $relist = array();
        foreach ($list as $k => $v) {
            if ($v['entryname'] == '') {
                continue;
            }
            $v['url'] = 'http://china.findlaw.cn/ask/baike/' . $v['eid'] . '.html';
            $relist[] = $v;
            $num ++;
            if ($num == $getNum) {
                break;
            }
        }
        return $relist;
    }

    /**
     * �°ٿ����а�
     * 
     * @param int $getNum ��ȡ��¼��   
     * @param int $month  ��:��201208
     * 
     * @return array 
     */
    static public function queryBkMonthClickTopList($getNum, $month)
    {
        $list = \Rpc::getData("Bk.queryBkMonthsClickTopList", 1, $getNum + 10, $month);
        $num = 0;
        $relist = array();
        foreach ($list as $k => $v) {
            if ($v['entryname'] == '') {
                continue;
            }
            $v['url'] = 'http://china.findlaw.cn/ask/baike/' . $v['eid'] . '.html';
            $relist[] = $v;
            $num ++;
            if ($num == $getNum) {
                break;
            }
        }
        return $relist;
    }

    /**
     * �ٿ�����������л���
     * 
     * @param int $limit ��ȡ��¼��   
     * @param int $sid1  һ��ר��ID
     * @param int $sid2  ����ר��ID
     * 
     * @return  array 
     */
    static public function queryRandonEntryList($limit = 20, $sid1 = null, $sid2 = null)
    {
        $data = S('Ask.Bk.radomEntry');
        if ($data['radomEntrys'] && $data['limit'] >= $limit) {
            $randKeys = array_rand($data['radomEntrys'], $limit);
            $return = array();
            foreach ($randKeys as $kval) {
                $return[] = $data['radomEntrys'][$kval];
            }
            return $return;
        }
        $data = array();
        $data['radomEntrys'] = \Rpc::getData("Bk.queryRandonEntryList", ($limit < 200 ? 200 : $limit), $sid1, $sid2);
        $data['limit'] = count($data['radomEntrys']);
        S('Ask.Bk.radomEntry', $data, 1800);
        return $data['radomEntrys'];
    }

    /**
     * �ٿ������Ƽ�����
     * 
     * @param int $getNum ��ȡ��¼��
     * 
     * @return array
     */
    static public function getLastRecommendEntry($getNum)
    {
        $k_list = \Rpc::getData("Bk.getLastRecommendEntry", $getNum);
        foreach ($k_list as $k => $v) {
            if ($v['url']) {
                $rs = strpos($v['url'], "http://china.findlaw.cn/ask/index.php?m=baike&a=detail&eid=");
                if ($rs !== false) {
                    $v['url'] = ' http://china.findlaw.cn/ask/baike/' . $v['eid'] . '.html';
                }
            }
            $k_list[$k]['url'] = trim($v['url']) ? $v['url'] : 'http://china.findlaw.cn/ask/baike/' . $v['eid'] . '.html';
        }
        return $k_list;
    }
}
