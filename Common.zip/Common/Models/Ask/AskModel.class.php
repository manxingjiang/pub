<?php
/**
 * �ҷ���������ѯģ��ǰ̨����API
 *  
 * @author wujifeng <wujifeng@findlaw.cn>
 */
namespace Models\Ask;

/**
 * �ҷ���������ѯģ��ǰ̨����API
 *  
 * @author wujifeng <wujifeng@findlaw.cn>
 */
class AskModel
{
    /**
     * ��ѯ�����б�
     *
     * @param type $page      pageҳ��
     * @param type $pageSize  pageSizeÿҳ����
     * @param type $params    params��ѯ����
     * @param type $isGetIden isGetIden�Ƿ���Ҫ��ѯ������Ϣ(expertLawyerFlag,banzhuFlag,lxtFlag),Ĭ��true    
     *
     * @return array (    
     expertLawyerFlag    �Ƿ�ר��
     banzhuFlag            �Ƿ����
     lxtFlag                �Ƿ�����ͨ
     lawyertype6            �Ƿ�vip
     lawname                �������� )
     * @author zhangshengguang
     */
    public static function queryModViewList($page, $pageSize, $params, $isGetIden = true)
    {
        $params['avalableflag'] = 1;
        //$list                   = $this->getAskModule()->queryModViewList($page, $pageSize, $params, $isGetIden);
        $flag = $isGetIden ? 1 : 0;
        $relist                 = array();
        $list                   = \Rpc::getData('Ask.queryModViewList', $page, $pageSize, $params, $flag);
        $uids = \Tools\Arr::getFieldInList($list, 'uid');
        if (empty($uids)) {
            return array();
        }
        $daystatlist = \Rpc::getData('Ask.queryDayStatList', 1, count($uids), array('uids' => $uids));
        $daystatlist = \Tools\Arr::setDataAsKey($daystatlist, 'uid');
        if (!empty($list)) {
            \Tools\Lawyer::setUcLawyerKey($list, 'userid');
            $uclawyers = \Tools\Lawyer::getUcLawyerInfo(2);
            $uclawyers = $uclawyers['userid'];
            foreach ($list as $k => $v) {
                $v['mobile']  = $uclawyers[$v['userid']]['mobile'];
                $v['tel']  = $uclawyers[$v['userid']]['tel'];
                $v['province']  = $uclawyers[$v['userid']]['province'];
                $v['city']  = $uclawyers[$v['userid']]['city'];
                $v['usernamel']  = str_replace('��ʦ', '', $uclawyers[$v['userid']]['username']) . '��ʦ';
                $v['profession'] = \Tools\Prof::getLawProStr($v['uid']);
                $v['profession'] = isset($v['profession']) ? $v['profession'] : '';
                $v['profession'] = preg_replace('/^,/ims', '', $v['profession']);
                $v['resume']     = isset($uclawyers[$v['userid']]['resume']) ? $uclawyers[$v['userid']]['resume'] : '';
                $v['resume']     = strip_tags($v['resume']);
                $v['resume']     = str_replace('&#160;', '', $v['resume']);
                $v['resume']     = str_replace('&nbsp;', '', $v['resume']);
                $v['lawname']    = $uclawyers[$v['userid']]['lawyerLawroom'];
                if ($uclawyers[$v['userid']]['isvip']) { //�û�����ûvip����ʱ�� ȡע��ʱ��
                    $v['vipYear'] = ceil(time() - $uclawyers[$v['userid']]['regtime'] / 3153600); //vip����    
                }
                $v['id']     = isset($v['id']) ? $v['id'] : '';
                $v['yuming'] = isset($uclawyers[$v['userid']]['yuming']) ? $uclawyers[$v['userid']]['yuming'] : '';                //ͳ�� ����
                $v['onlinenum'] = $daystatlist[$v['uid']]['onlinenum'];
                $v['onlinerepnum'] = $daystatlist[$v['uid']]['onlinerepnum'];
                $v['commentnum'] = intval($daystatlist[$v['uid']]['commentnum']);
                $v['ansnum'] = intval($daystatlist[$v['uid']]['ansnum']);
                $v['adoptnum'] = intval($daystatlist[$v['uid']]['adoptnum']);
                $relist[$k]  = $v;
            }
            $relist = \Tools\Lawyer::get_site_url($relist);
            $relist = \Tools\Lawyer::fecth_lawyer_logo($relist);
            $relist = \Tools\Ads::get_ad_file($relist);
        }
        return $relist;
    }
    
    /**
     * desc��ѯר���б�
     *
     * @param type $page      pageҳ��
     * @param type $pageSize  pageSizeÿҳ����
     * @param type $params    params��ѯ����
     * @param type $isGetIden isGetIden�Ƿ���Ҫ��ѯ������Ϣ(expertLawyerFlag,banzhuFlag,lxtFlag),Ĭ��true
     *
     * @return type
     * @author zhangshengguang
     */
    public static function queryExpViewList($page, $pageSize, $params, $isGetIden = true)
    {
        $params['avalableExp'] = 1;
        //$list                  = $this->getAskModule()->queryExpViewList($page, $pageSize, $params, $isGetIden);
        $flag = $isGetIden ? 1 : 0;
        //$list                  = \Rpc::getData('Ask.queryExpViewList', $page, $pageSize, $params, $flag);
        $list                  = \Rpc::getData('Ask.queryExpViewList1', $page, $pageSize, $params, $flag);
        $relist                = array();
        $profList              = self::getExpertLawyerProfList();
        \Tools\Lawyer::setUcLawyerKey($list, 'userid');
        $uclawyers = \Tools\Lawyer::getUcLawyerInfo(2);
        $uclawyers = $uclawyers['userid'];
        foreach ($list as $k => $v) {
            $v['jifeng_ask'] = $v['askjifeng'];
            $v['jifeng_all'] = $v['jifeng'];
            $v['mobile']  = $uclawyers[$v['userid']]['mobile'];
            $v['tel']  = $uclawyers[$v['userid']]['tel'];
            $v['province']  = $uclawyers[$v['userid']]['province'];
            $v['city']  = $uclawyers[$v['userid']]['city']==$uclawyers[$v['userid']]['province'] ? $uclawyers[$v['userid']]['country'] : $uclawyers[$v['userid']]['city'];
            $v['usernamel']  = str_replace('��ʦ', '', $uclawyers[$v['userid']]['username']) . '��ʦ';
            $v['profession'] = \Tools\Prof::getLawProStr($v['uid']);
            if ($uclawyers[$v['userid']]['isvip']) { //�û�����ûvip����ʱ�� ȡע��ʱ��
                $v['vipYear'] = ceil(time() - $uclawyers[$v['userid']]['regtime'] / 3153600); //vip����    
            }
            $v['profession']  = isset($v['profession']) ? $v['profession'] : '';
            $v['profession']  = preg_replace('/^,/ims', '', $v['profession']);
            $v['resume']      = $uclawyers[$v['userid']]['resume'];
            $v['resume']      = strip_tags($v['resume']);
            $v['resume']      = str_replace('&#160;', '', $v['resume']);
            $v['resume']      = str_replace('&nbsp;', '', $v['resume']);
            $v['lawyertype6'] = isset($uclawyers[$v['userid']]['isvip']) ? $uclawyers[$v['userid']]['isvip'] : '';
            $v['lawerroom']    = $uclawyers[$v['userid']]['lawyerLawroom'];
            
            $profNames  = array();
            $profIdsArr = explode(',', $v['profIds']);
            foreach ($profIdsArr as $profId) {
                $profNames[] = str_replace('ר��', '', $profList[$profId]['name']);
            }
            $v['profNames'] = implode(',', $profNames); //ר���ŷ���            
            
            $v['id']     = isset($v['id']) ? $v['id'] : '';
            $v['yuming'] = $uclawyers[$v['userid']]['yuming'] ? $uclawyers[$v['userid']]['yuming'] : '';
            $relist[$k]  = $v;
        }
        $relist = \Tools\Lawyer::get_site_url($relist);
        $relist = \Tools\Lawyer::fecth_lawyer_logo($relist);
        $relist = \Tools\Ads::get_ad_file($relist);
        return $relist;
    }
    
     /**
     * desc�ҷ�ר���Ź̶�12������
     *
     * @return type
     * @author author
     */
    public static function getExpertLawyerProfList()
    {
        $sort     = \Tools\FileDataQuery::import('sort')->getSort();
        $ret      = array();
        foreach ($sort as $id => $_item) {
            $ret[$id] = array(
                'id' => $id,
                'name' => ($_item['sid1'] ? $_item['sort2'] : $_item['sort1'])
            );
        }
        return $ret;
        /*
        return array(
        1101=>array('id'=>1101, 'name'=>'ծ��ծȨר��'),
        1102=>array('id'=>1102, 'name'=>'������ͥר��'),
        1107=>array('id'=>1107, 'name'=>'��ͬ����ר��'),
        1108=>array('id'=>1108, 'name'=>'�Ͷ�����ר��'),
        1109=>array('id'=>1109, 'name'=>'��ͨ�¹�ר��'),
        1110=>array('id'=>1110, 'name'=>'ҽ���¹�ר��'),
        1201=>array('id'=>1201, 'name'=>'��������ר��'),
        1301=>array('id'=>1301, 'name'=>'���±绤ר��'),
        1304=>array('id'=>1304, 'name'=>'���⳥ר��'),
        1501=>array('id'=>1501, 'name'=>'֪ʶ��Ȩר��'),
        1008=>array('id'=>1008, 'name'=>'��˾��ר��'),
        1701=>array('id'=>1701, 'name'=>'�����ۺ�ר��'),
        );
        */
    }
    
    /**
     * desc��ȡ�����Ƽ���ʦ
     *
     * @param type $pageSize pageSizeÿҳ����
     * @param type $params   $params��ϸ����
     *
     * @return type
     * @author author
     */
    public static function queryRecommLawyerVipTblMemberList($pageSize, array $params)
    {
        $params['ifaudit'] = isset($params['ifaudit']) ? $params['ifaudit'] : 1;
        $params['typeid']  = isset($params['typeid']) ? $params['typeid'] : 1;
        //$params['nowtime'] = $params['nowtime'] ? $params['nowtime'] : time();    //ȥ��
        //$list              = $this->getAskModule()->queryRecommLawyerVipTblMemberList($pageSize, $params);
        $list              = \Rpc::getData('Ask.queryRecommLawyerVipTblMemberList', $pageSize, $params);
        if (!$list) {
            return null;
        }
        \Tools\Lawyer::setUcLawyerKey($list, 'uid');
        $uclawyers = \Tools\Lawyer::getUcLawyerInfo(2);
        $uclawyers = $uclawyers['uid'];
        foreach ($list as $k => $v) {
                $list[$k]['username']  = $uclawyers[$v['uid']]['username'];
                $list[$k]['mobil']  = $uclawyers[$v['uid']]['mobile'];
                $list[$k]['tel']  = $uclawyers[$v['uid']]['tel'];
                $list[$k]['yuming']  = $uclawyers[$v['uid']]['yuming'];
            $list[$k]['askRecommLawyerId'] = $list[$k]['id'];
            $list[$k]['id']                = $list[$k]['memberSearchId'];
        }
        $list = \Tools\Lawyer::get_site_url($list);
        foreach ($list as $k => $v) {
            $v['weburl']        = empty($v['weburl']) ? '' : $v['weburl'];
            $list[$k]['weburl'] = trim($v['weburl']) == '' ? $v['siteurl'] : 'http://' . str_replace('http://', '', trim($v['weburl']));
            if (trim($list[$k]['mobil']) == '') {
                $list[$k]['mobil'] = $v['tel'];
            }
        }
        return $list;
    }
    
     /**
     * descר�Ҿ�ѡ����
     *
     * @param type $uid    uid
     * @param type $getNum getNum���ؼ�¼��
     *
     * @return type
     * @author author
     */
    public static function queryExpertLawyerJingXuanQues($uid, $getNum)
    {
        $list   = \Rpc::getData('Ask.queryExpertLawyerJingXuanQues', $uid, $getNum * 2);
        $relist = array();
        $num    = 0;
        foreach ($list as $k => $v) {
            if ($v['title'] == '') {
                continue;
            }
            $relist[] = $v;
            $num++;
            if ($num == $getNum) {
                break;
            }
        }
        return $relist;
    }
    
    /**
     * desc��ѯר��,�������½��
     *
     * @param type $getNum getNum
     * @param type $type   type
     *
     * @return type
     * @author author
     */
    public static function queryNewAnsList($getNum, $type)
    {
        $params = array(
            'num' => $getNum * 2
        );
        $list   = array();
        if ($type == 'exp') {
            $list = \Rpc::getData('Ask.queryExpertNewAns', $params);
        } elseif ($type == 'mod') {
            $list = \Rpc::getData('Ask.queryModeratorNewAns', $params);
        }
        if (empty($list)) {
            return array();
        }
        $userids = array();
        foreach ($list as $k => $v) {
            $userids[] = $v['userid'];
        }
        $lawyerList    = self::getLawyerDetailList($userids, false);
        $lawyerListTmp = array();
        foreach ($lawyerList as $v) {
            $lawyerListTmp[$v["userid"]] = $v;
        }
        $lawyerList = $lawyerListTmp;
        
        $relist = array();
        $num    = 0;
        foreach ($list as $k => $v) {
            if ($v['title'] == '') {
                continue;
            }
            if (isset($lawyerList[$v["userid"]])) {
                $v['url']       = 'http://china.findlaw.cn/ask/question_' . $v['qid'] . '.html';
                $v              = array_merge($v, $lawyerList[$v["userid"]]);
                $v['usernamel'] = str_replace('��ʦ', '', $v['username']) . '��ʦ';
                $relist[]       = $v;
                $num++;
                if ($num == $getNum) {
                    break;
                }
            }
        }
        return $relist;
    }
    
     /**
     * ��ʦ��ϸ�����б�
     *
     * @param type $lawyer   ��ʦID
     * @param type $type     �������ͣ���Ҫ������Ӧ�ɵĲ�������
     * @param type $key_type key_type
     *
     * @return array
     * @author author
     */
    public function getLawyerDetailList($lawyer = array(), $type = true, $key_type = '')
    {
        $list = array();
        if ($type) {
            foreach ($lawyer as $k => $v) {
                $list[] = $v['userid'];
            }
        } else {
            $list = $lawyer;
        }
        
        //$lawyer_list = \Rpc::getData('Ask.queryLawyerInfo1', $list);
        //�ĵ����û���ϵ����
        $lawyer_list = \Rpc::getUCData("Member.queryUcLawyerListByUidsOrUserids", array("userids"=>$list), 1, 2);
        foreach ($lawyer_list as &$v) {
            $v['mobil'] = $v['mobile'];
            $v['profession'] = \Tools\Prof::getLawProStr($v['uid']);
        }
        if ($key_type) {
            foreach ($lawyer_list as $v) {
                $tmp[$v['userid']] = $v;
            }
            return $tmp;
        } else {
            return \Tools\Lawyer::get_site_url($lawyer_list);
        }
    }
    
    /**
     * descר���ţ� ��������ʦ�ظ�����
     *
     * @param type $getNum  getNum
     * @param type $bzOrExp bzOrExp
     *
     * @return type
     * @author author
     */
    public static function lawyerAnsTopList($getNum, $bzOrExp)
    {
        $params = array(
            'orderBy' => 'ansnum desc'
        );
        //����
        if ($bzOrExp == 'banzhu') {
            $params['bzflag'] = 1;
        } elseif ($bzOrExp == 'expert') { //ר��
            $params['expertflag'] = 1;
        }
        $list      = \Rpc::getData('Ask.queryDayStatListB', 1, $getNum, $params);
        $useridArr = array();
        foreach ($list as $v) {
            $useridArr[] = $v['userid'];
        }
        $lawyerList    = self::getLawyerDetailList($useridArr, false);
        $lawyerListTmp = array();
        foreach ($lawyerList as $v) {
            $lawyerListTmp[$v["userid"]] = $v;
        }
        $lawyerList = $lawyerListTmp;
        $relist     = array();
        foreach ($list as $k => $v) {
            if (isset($lawyerList[$v["userid"]])) {
                $v['usernamel'] = str_replace('��ʦ', '', $v['username']) . '��ʦ';
                $relist[]       = array_merge($v, $lawyerList[$v["userid"]]);
            }
        }        
        return $relist;
    }
    
     /**
     * desc��ѯ��������������ͳ��
     *
     * @return type
     * @author author
     */
    public function queryAreaModeratorCountList()
    {
        $params = array(
            'avalableflag' => 1,
            'areacodeBegin' => 100000
        );
        $list   = \Rpc::getData('Ask.queryModeratorAreaBList', $params);
        $relist = array();
        foreach ($list as $k => $v) {
            if (!isset($v['pinyin']) || trim($v['pinyin']) == '') {
                continue;
            }
            $relist[] = $v;
        }
        return $relist;
    }
    
    /**
     * desc��ѯ��ʦ(���֣��ظ�������)��(�죬�ܣ���)���а�
     *
     * @param type $getNum  ��ȡ��¼��
     * @param type $whatTop ʲô����     'jifen':��������, 'ans':�ظ�����, 'adopt':��������  
     * @param type $topType ��������     'day':������, 'week':������, 'month':������  
     *
     * @return array
     * @author zhangshengguang
     */
    public static function queryLawyerTopList($getNum, $whatTop, $topType)
    {
        //�����ֶ�
        switch ($whatTop) {
        case 'jifen':
            $orderby = " count_jifeng desc "; //��������
            break;
        case 'ans':
            $orderby = " count_ans desc "; //�ظ�����
            break;
        case 'adopt':
            $orderby = " count_adopt desc "; //��������
            break;
        default:
            return '�޴�����->' . $whatTop;
            break;
        }        
        if ($topType == 'day') {
            //������
            $list = \Rpc::getData('Ask.queryLawyerDayTopList',  array(  'orderBy' => $orderby, 'num' => $getNum + 10 ));
        } elseif ($topType == 'week') {
            //������
            $list = \Rpc::getData('Ask.queryLawyerWeekTopList', array('orderBy' => $orderby, 'num' => $getNum + 10 ));
        } elseif ($topType == 'month') {
            //������
            $list = \Rpc::getData('Ask.queryLawyerMonthTopList', array( 'orderBy' => $orderby,'num' => $getNum + 10));
        } else {
            return '�޴�����->' . $topType;
        }
        
        \Tools\Lawyer::setUcLawyerKey($list, 'uid');
        $uclawyers = \Tools\Lawyer::getUcLawyerInfo(2);
        $uclawyers = $uclawyers['uid'];
        
        $relist = array();
        $num    = 0;
        foreach ($list as $k => $v) {
            if (empty($v['uid'])) {
                continue;
            }
            $v['lawerroom'] = $uclawyers[$v['uid']]['lawyerLawroom'];
            $v['username'] = $uclawyers[$v['uid']]['username'];
            $v['usernamel'] = str_replace('��ʦ', '', $v['username']) . '��ʦ';
            $v['sortName']  = \Tools\Prof::cutLawyerProfession(\Tools\Prof::getLawProStr($v['uid']), 2);
            $relist[]       = $v;
            $num++;
            if ($num == $getNum) {
                break;
            }
        }        
        return $relist;
    }
    
     /**
     * ����ѯ���а�
     *
     * @param type $getNum ��ȡ��¼��
     * @param type $day    ��:��20120805    
     *
     * @return array
     * @author zhangshengguang
     */
    public static function queryDcountQans($getNum, $day)
    {
        $list   = \Rpc::getData('Ask.queryDcountQans', 1, $getNum + 10, $day);
        $num    = 0;
        $relist = array();
        foreach ($list as $k => $v) {
            if ($v['title'] == '') {
                continue;
            }
            $v['askurl'] = 'http://china.findlaw.cn/ask/question_' . $v['qid'] . '.html';
            $relist[]    = $v;
            $num++;
            if ($num == $getNum) {
                break;
            }
        }
        return $relist;
    }
    
     /**
     * ����ѯ���а�
     *
     * @param type $getNum ��ȡ��¼��
     * @param type $week   ��:��201233  
     *
     * @return array
     * @author zhangshengguang
     */
    public function queryWcountQans($getNum, $week)
    {
        $list   = \Rpc::getData('Ask.queryWcountQans', 1, $getNum + 10, $week);
        $num    = 0;
        $relist = array();
        foreach ($list as $k => $v) {
            if ($v['title'] == '') {
                continue;
            }
            $v['askurl'] = 'http://china.findlaw.cn/ask/question_' . $v['qid'] . '.html';
            $relist[]    = $v;
            $num++;
            if ($num == $getNum) {
                break;
            }
        }
        return $relist;
    }
    
    /**
     * ����ѯ���а�
     *
     * @param type $getNum ��ȡ��¼��
     * @param type $month  ��:��201208    
     *
     * @return array
     * @author zhangshengguang
     */
    public function queryMcountQans($getNum, $month)
    {
        $list   = \Rpc::getData('Ask.queryMcountQans', 1, $getNum + 10, $month);
        $num    = 0;
        $relist = array();
        foreach ($list as $k => $v) {
            if ($v['title'] == '') {
                continue;
            }
            $v['askurl'] = 'http://china.findlaw.cn/ask/question_' . $v['qid'] . '.html';
            $relist[]    = $v;
            $num++;
            if ($num == $getNum) {
                break;
            }
        }
        return $relist;
    }

    /**
     * ��ѯ�Ż� ����΢�� ���� �ʼ�
     *
     * @param array  $question ��ѯ��Ϣ
     * @param string $content  �ظ�����
     * @param array  $lawyer   �ظ���ʦ
     * @param array  $level    ���ͼ���1.���ţ�2.�ʼ���4.΢��
     * @param array  $user     ��ѯ��������Ϣ
     *
     * @return array
     */
    public static function sendMessage($question, $content, $lawyer, $level=7, $user=null)
    {
        $result = array('issendSms'=>0,'issendEmail'=>0,'issendWeixin'=>0);
        if (empty($question) || empty($lawyer) || $content == '') {
            return false;
        }

        //�ɵĻ�ȡ������Ϣ�����ܻ�ȡ�����ֻ�����
        if ($user === null) {
            $user = \Rpc::getUCData('Member.admin.getUcTblleoByPKSel', $question['uid']);
        }



        if (empty($user)) {
            return;
        }
        $uid = $question['uid'];
        $qid = $question['qid'];


        //        $filename=ROOT_PATH."Runtime/Logs/mytest.txt";
        //        file_put_contents($filename, "111---",FILE_APPEND);


        //�����ֻ������Ͷ���
        try {
            //���û����ϵ��ֻ����뷢�Ͷ���
            /*if (($level & 1) && $user['mobile']) {
                $url = "http://m.findlaw.cn/touch_front/index.php?c=askmid&a=index&qid=" . $qid;
                $url = self::createUrl($url, $uid);
                $tpl = $lawyer['username']."��ʦ�ѽ��������ѯ����� " . $url . " �鿴����ϵ��ʦ" . $lawyer['mobile'];
                $sendSmsResult = \Tools\Sms::sendSms($user['mobile'], $tpl, 2);
                if ($sendSmsResult['status'] == 1) {
                    $result['issendSms'] = 1;
                }
            }*/

            //345�ࣨһ��һ�Ӽ���ֱ�ӻ�ȡ�������Ϻ��뷢�Ͷ��ţ�����͸��������ֻ��Ƿ�����жϷ���
            $mobile = 0;
            if (in_array($question['typeid'], array(3, 4, 5))) {
                if ($user['mobile']) {
                    $mobile = $user['mobile'];
                }
            } else {
                //�ж��Ƿ��ֻ�����������⣬�Ǿͷ��Ͷ���
                $bindResult = \Rpc::getData('Ask.Admin.getAskPhoneBind', $qid, 1);
                if (!empty($bindResult) && $bindResult['telephone']) {
                    $mobile = $bindResult['telephone'];
                }
            }

            //�ж��ֻ�����
            if ($mobile) {
                $url = "http://m.findlaw.cn/touch_front/index.php?c=askmid&a=index&qid=" . $qid;
                $url = self::createUrl($url, $uid);
                $tpl = $lawyer['username']."��ʦ�ѽ��������ѯ����� " . $url . " �鿴����ϵ��ʦ" . $lawyer['mobile'];
                $sendSmsResult = \Tools\Sms::sendSms($mobile, $tpl, 2);
                if ($sendSmsResult['status'] == 1) {
                    $result['issendSms'] = 1;
                }
            }
        } catch (\Exception $e) {
            
        }
        
        //�������䣬�����ʼ�
        try {
            if (($level & 2) && $user['email'] && strpos($user['email'], 'auto') !== 0) {
                $userid = $question['userid'];
                $asktime = date('Y��m��d�� Hʱi��', $question['asktime']);
                $supplement = $question['supplement'];
                $lawyername = $lawyer['username'];
                $answer_content = $content;
                $question_url = 'http://china.findlaw.cn/ask/question_' . $qid . '.html';
                $send_time = date('Y��m��d��');
                $mailto = $user['email'];
                $subject = '�ظ���ѯ';

                $body = '';
                $body .= '<!doctype html>';
                $body .= '<html>';
                $body .= '<head>';
                $body .= '<meta charset="utf-8">';
                $body .= '<title>�ظ���ѯ</title>';
                $body .= '</head>';
                $body .= '<body>';
                $body .= '    <div style="width:700px;margin:0 auto;background:#fff; font-family:\'Microsoft Yahei\'"><a href="http://china.findlaw.cn/" target="_blank" style="background:url(http://images.findlaw.cn/img/common/email/yzm-hot-top.jpg);height:88px;width:700px;overflow:hidden;zoom:1;text-indent:-2000px;display:block;" title="�ҷ���">�ҷ���</a>';
                $body .= '        <div style="border:1px solid #ccc;background:#fff;padding:0 40px;border-top:none;">';
                $body .= '        <div style="font:24px/46px \'Microsoft Yahei\';padding-top:20px;font-weight:700;color:#f60;">�𾴵� ' . $userid . '���ã�</div>';
                $body .= '        <div style="text-indent:2em;font-size:14px;color:#666;line-height:24px;">����' . $asktime . ' ���ҷ�����������ѯ���յ���ʦ�ظ��������鿴��ϸ��</div>';
                $body .= '        <div style="background:#ffffe5;padding:30px;margin:10px 0;text-align:center;">';
                $body .= '        <div style="color:#666; text-align:left;"><p style="color:#7ac03b; font-weight:bold;">��ѯ���ݣ�</p>';
                $body .= '        <p style="text-indent:2em;">' . $supplement;
                $body .= '        <br/><br/>';
                $body .= '        <p style="color:#7ac03b; font-weight:bold;">' . $lawyername . '��ʦ�ظ���</p>';
                $body .= '        <p  style="text-indent:2em;">' . $answer_content . '</p><br/><br/></div><a href="' . $question_url . '" style="font:16px/24px arial;color:#39c;font-weight:700;word-break:break-all; " target="_blank"><img src="http://images.findlaw.cn/img/common/email/details-btn.jpg" border="0"></a></div>';
                $body .= '            <div style="font-size:14px;line-height:24px;color:#666;margin-bottom:20px">����û�з�����ѯ���뷢�ʼ�<!--����<a href="mailto:law@findlaw.cn">law@findlaw.cn</a>--><a style="cursor: pointer; color:#F00;" ck="optMail" opt="reply" name="law@findlaw.cn">law@findlaw.cn</a> ���µ磺400-678-6088��</div>';
                $body .= '            <div style="font-size:14px;color:#666;text-align:right;line-height:26px;margin-bottom:20px;">�ҷ��� Findlaw.cn<br>' . $send_time . '</div>';
                $body .= '        </div>';
                $body .= '    </div>'; 
                $body .= '</body>';
                $body .= '</html>';

                $sendEmailResult = \Tools\Email::_send($mailto, $subject, $body);
                if ($sendEmailResult != false) {
                    $result['issendEmail'] = 1;
                }
                
            }
        } catch (\Exception $e) {
            
        }

        //�а�΢�ţ�����΢����Ϣ
        try {
            if (($level & 4)) {
                $url = "http://m.findlaw.cn/touch_front/index.php?c=askmid&a=index&qid=" . $qid . "&t=wx";
                $url = self::createUrl($url, $uid);
                if ($url) {
                    $dataparam = array(
                        'uid' => $uid,
                        'username' => $lawyer['username'],
                        'repcontent' => $content,
                        'mobile' => $lawyer['mobile'],
                        'qtitle' => $question['title'],
                        'qcontent' => $question['supplement'],
                        'url' => $url
                    );
                    $url = WEIXIN_PUSH_HOST . "weixin_front/index.php?m=api&c=findlaw&a=message_template_send";
                    $sendWeixinResult = \Tools\Curl::jsonPost($url, $dataparam);
                    $sendWeixinResult = json_decode($sendWeixinResult[1], 1);
                    if ($sendWeixinResult['errmsg'] == 'ok') {
                        $result['issendWeixin'] = 1;
                    }
                }
            }
        } catch (\Exception $e) {
        }
        return $result;
    }

    /**
     * ��װ�̵�ַ
     * 
     * @param string $url Դ��ַ
     * @param array  $uid �û�����
     * 
     * @return string
     */
    protected static function createUrl($url, $uid)
    {
        $str = $uid . "|2|" . time();
        $token = base64_encode(\Tools\Encrypt::aes_crypt($str, C('TOKEN_LOGIN_KEY'), 'ENCODE'));
        $url = $url . "&token=" . urlencode($token);
        $url = \Tools\ShortUrlSDK::get_short_url($url);
        return $url['url'];
    }
    
}