<?php
/**
 * �°���ʦ��������
 *
 * @author    zhangshengguang <1649353934@qq.com>
 */

namespace Models\LawyerOnline;

/**
 * �°���ʦ��������
 *
 * @author    zhangshengguang <1649353934@qq.com>
 */
class LawyerOnlineModel
{
    public $onlinetime = 1800;
    
    /**
     * ��ʦ������ҳ--��ʦ�����б� 
     *
     * @param int     $page          ��ǰҳ 
     * @param int     $pageSize      ÿҳ��ʾ�� 
     * @param int     $areacodeBegin areacodeBegin 
     * @param int     $areacodeEnd   areacodeEnd      
     * @param string  $orderBy       "jifeng_all desc"---��ʦ�������� 
     *                               "supportcount desc"---����������
     *                               "jifeng_ask desc"---���Ļ�������
     *                               "online_ans desc"---������������
     * @param boolean $getCount      �Ƿ��ȡͳ���� 
     *
     * @return Array
     */
    public function queryOnlineLawyerList($page, $pageSize, $areacodeBegin, $areacodeEnd, $orderBy = 'jifeng_all', $getCount = false)
    {
        $p = array();
        if ($areacodeBegin > 0) {
            $p['areacodeBegin'] = $areacodeBegin;
        } 
        if ($areacodeEnd > 0) {
            $p['areacodeEnd'] = $areacodeEnd;
        } 
        $p['orderBy']    = $orderBy ? $orderBy : 'jifeng_all';
        $p['lastdodate'] = time() - $this->onlinetime;
        $p['lastdodateflag'] = 1;
        $p['lawyertype6'] = 1;
        $list            = $this->queryOnlineLawyer($page, $pageSize, $p);
        $list = \Tools\Ads::get_ad_file($list);
        if ($getCount) {
            unset($p['orderBy']);
            unset($p['lastdodate']);
            unset($p['lastdodateflag']);
            $count = \Rpc::getData('LawyerOnline.queryLawyerOnlineListCount', $p);
            return array(
                'list' => $list,
                'count' => $count
            );
        }
        return $list;
    }
    
    /**
     * ר��,������ʦ�����б� 
     *
     * @param int     $page     ��ǰҳ
     * @param int     $pageSize ÿҳ��ʾ��
     * @param array   $p        ��ѯ����
     * @param string  $orderBy  ����
     * @param boolean $getCount �Ƿ�ͳ��
     *
     * @return array
     */
    public function queryProfOnlineLawyerList($page, $pageSize, $p, $orderBy = 'jifeng_all desc', $getCount = false)
    {
        $p['orderBy'] = $orderBy;
        $p['useridsOrderFlag'] = 0;
        $p['lastdodateflag'] = 1;           //��ֵ=1�ǣ� lastdodateֵ��������
        $p['lastdodate'] = time() - $this->onlinetime; //�ò����������� �ǹ���
        $p['lawyertype6'] = 1;
        $list             = $this->queryOnlineLawyer($page, $pageSize, $p);
        
        $list = \Tools\Ads::get_ad_file($list);
        
        if ($getCount) {
            unset($p['lastdodate']);
            unset($p['orderBy']);
            unset($p['useridsOrderFlag']);
            $count = \Rpc::getData('LawyerOnline.queryLawyerOnlineListCount', $p);
            return array(
                'list' => $list,
                'count' => $count
            );
        } else {
            return $list;
        }
    }
           
    /**
      * city��ҳ��ʦ�б�ר�ýӿ�
      *
      * @param type $page     desc
      * @param type $pageSize desc
      * @param type $p        desc
      * @param type $isCount  desc
      *
      * @return type
      */
    public function onlineCityLawyerList($page, $pageSize, $p, $isCount=true)
    {
        $p['lawyertype6'] = 1;
        $list = $this->queryOnlineLawyer($page, $pageSize, $p);
        if ($isCount) {
            unset($p['lastdodate']);
            unset($p['orderBy']);
            unset($p['lastdodateflag']);
            $count = \Rpc::getData('LawyerOnline.queryLawyerOnlineListCount', $p);
            return array(
                'list' => $list,
                'count' => $count
            );
        }
        return $list;
    }
    
    /**
     * ��ʦר�������б�
     *
     * @param type $page     desc
     * @param type $pageSize desc
     * @param type $p        desc
     *
     * @return array xxx
     */
    public function queryCatOnlineLawyer($page, $pageSize, $p)
    {
        //ר�����ش��� ���������queryOnlineLawyer
        if (empty($p['profession'])) {
            return array();
        }        
        $params = array(
                'lastdodate'=>time() - $this->onlinetime,
                'profession'=>$p['profession'],
                'profname'=>$p['profession'],
                'lawyertype6'=>1,
                'orderBy'=>$p['orderBy']
        );
        $params = array_merge($p, $params);
        $list = \Rpc::getData('LawyerOnline.queryOnlineListMap', $page, $pageSize, $params);
        
        $relist = array();        
        foreach ($list as $k => $v) {
            $LawyerMessage = $v['LawyerMessage'];
            $row           = array();
            
            //ȥ��
            if (!in_array($v['userid'], $tmp_useridarr)) {
                $tmp_useridarr[] = $v['userid'];
            } else {
                continue;
            }
            
            $row['id']           = $v['uid'];
            $row['userid'] = $v['userid'];
            $row['membertype']   = 'lawyer';
            $row['profession']   = $v['profession'];
            $row['jifengAsk']    = $LawyerMessage['jifengAsk'];
            $row['supportcount'] = $v['supportcount']; //������
            $row['goodcommentnum'] = $v['goodcommentnum']; //�°������
            $row['online_ans']   = $v['online_ans']; //��������
            $row['islxt']        = $v['islxt'];
            $row['isonline']     = $v['isonline'] == 1 ? 2 : 1;
            $relist[]            = $row;
        }      
        $parentobj = new \Parents\FrontCommonController();
        $relist = $parentobj->getLawyerListFromUc($relist);
        
        return \Tools\Url::get_site_url($relist);
    }
    
    /**
     * ��ʦ�����б�
     *
     * @param type $page     desc
     * @param type $pageSize desc
     * @param type $p        desc
     *
     * @return array
     */
    protected function queryOnlineLawyer($page, $pageSize, $p)
    {                
        if ($p['profession']!='') {
            return $this->queryCatOnlineLawyer($page, $pageSize, $p);
        }                
        $p['useridsOrderFlag'] = 0;
        if (isset($_GET['db'])) {
            print_r($p);
        }
        $list                  = \Rpc::getData('LawyerOnline.queryOnlineLawyer', $page, $pageSize, $p);
        $relist                = array();
        if (empty($list)) {
            return $list;
        }
        $tmp_useridarr = array();    //����ȥ��
        foreach ($list as $k => $v) {
            $LawyerMessage = $v['LawyerMessage'];
            $row           = array();
            
            //ȥ��
            if (!in_array($v['userid'], $tmp_useridarr)) {
                $tmp_useridarr[] = $v['userid'];
            } else {
                continue;
            }
            
            $row['id']           = $v['uid'];
            $row['userid'] = $v['userid'];
            $row['membertype']   = 'lawyer';
            $row['profession']   = $v['profession'];
            $row['jifengAsk']    = $LawyerMessage['jifengAsk'];
            $row['supportcount'] = $v['supportcount']; //������
            $row['goodcommentnum'] = $v['goodcommentnum']; //�°������
            $row['online_ans']   = $v['onlineAns']; //��������
            $row['islxt']        = $v['islxt'];
            $row['isonline']     = $v['isonline'] == 1 ? 2 : 1;
            $relist[]            = $row;
        }    
        $parentobj = new \Parents\FrontCommonController();
        $relist = $parentobj->getLawyerListFromUc($relist);
        
        return \Tools\Url::get_site_url($relist);
    }
    
    /**
     * ��ʦ������ѯ���ų���( 24Сʱ�� ��ʦ���� ����12�����  )
     *
     * @return array
     */
    public function onlineHotCity()
    {
        /**
        �ɹ���
        SELECT userid,areacode,count(areacode) as lc FROM findlaw_db.session_mem WHERE usertype=1 and lastdodate>'1355673600' and areacode<>0 GROUP by areacode order by lc desc limit 12
        Ȼ�����areacode ��� �������ƺ�pinyin
        */
        $lastdodate = mktime(0, 0, 0, date('m'), date('d') - 1, date('Y'));
        $p          = array(
            'usertype' => 1,
            'lastdodate' => $lastdodate
        );
        $list       = \Rpc::getData('LawyerOnline.queryLawyerOnlineFlAreaList', 1, 12, $p);
        return $list;
    }
    
    /**
     * ��ѯ������ʦ���߻�Ծ֮�������Ϣ (ȡĳ���� ���� �ظ���������λ��ʦ) 
     *
     * @param type $areacodeBegin desc
     * @param type $areacodeEnd   desc
     *
     * @return array
     */
    public function queryYesterdaystarList($areacodeBegin, $areacodeEnd)
    {
        $p            = array(
            'areacodeBegin' => $areacodeBegin,
            'areacodeEnd' => $areacodeEnd
        );
        $p['dayInt']  = date('Ymd', strtotime('-1 days'));
        $p['orderBy'] = 'a.repnum';
        //print_r($p);
        $list         = \Rpc::getData('Ask.queryGongYiList2', 1, 2, $p);
        
        $parentobj = new \Parents\FrontCommonController();
        $list = $parentobj->getLawyerListFromUc($list);
        if ($list) {
            foreach ($list as &$l) {
                $l['mobil'] = $l['mobile'];
            }
        }
        return \Tools\Url::get_site_url($list);
    }
    
    /**
     * ���µ�����ʦ������ѯ��¼
     *
     * @param type $areacodeBegin desc
     * @param type $areacodeEnd   desc
     *
     * @return array
     */
    public function newOnlineAskRecord($areacodeBegin, $areacodeEnd)
    {
        $getNum = 10;
        $p      = array(
            'areacodeBegin' => $areacodeBegin,
            'areacodeEnd' => $areacodeEnd
        );
        $list   = \Rpc::getData('Online.queryLastAskOnlineMapList', $p, $getNum + 5);
        // print_r($list);exit;
        $num    = 0;
        $relist = array();
        foreach ($list as $k => $v) {
            if (intval($v['regdate']) == 0) {
                continue;
            }
            //$lawyerMessage = $v['lawyerMessage'];
            $row           = array();
            
            $row['time']     = $this->_dealtime($v['regdate']);
            $row['userid'] = $v['lawyeruserid'];
            $row['leoid']    = $v['leouserid'];
            
            
            $num++;
            $relist[] = $row;
            
            if ($num >= $getNum) {
                break;
            }
        }
        
        $parentobj = new \Parents\FrontCommonController();
        $relist = $parentobj->getLawyerListFromUc($relist);
        
        return \Tools\Url::get_site_url($relist);
    }
    /**
      * desc
      *
      * @param type $cdate desc
      *
      * @return array
      */
    private function _dealtime($cdate)
    {
        $cha1 = time() - $cdate + 300;
        if ($cha1 < 0) {
            $cha1 = 3;
        }
        if ($cha1 <= 60) {
            $cha = "��" . $cha1 . "��ǰ";
        } elseif ($cha1 < 3600 && $cha1 > 60) {
            $cha = "��" . floor($cha1 / 60) . "��ǰ";
        } elseif ($cha1 >= 3600 && $cha1 < 86400) {
            $cha = "��" . floor($cha1 / 3600) . "Сʱǰ";
        } else if ($cha1 >= 86400) {
            $cha = date('Y-m-d', $cdate);
            $cha = "��" . $cha;
        }
        return $cha;
    }
    
    /**
     * ��ѯ��¼��ҳ�б�
     *
     * @param type $page     desc
     * @param type $pagesize desc
     * @param type $p        desc
     * @param type $getCount desc
     *
     * @return array
     */
    public function zixunjiluList($page, $pagesize, $p, $getCount = false)
    {
        //$p['ifaudit'] = 1;
        $listtmp      = \Rpc::getData('Online.queryAskOnlineMapList', $page, $pagesize, $p);
        $list         = array();
        foreach ($listtmp as $v) {
            $row                    = array();
            $row['leoid']           = $v['leouserid'];
            $row['time']            = $this->_dealtime($v['regdate']);
            $row['userid']          = $v['lawyeruserid'];
            $row['id']              = $v['lawyerid'];
            $row['qid']             = $v['id'];
            $row['title']           = $v['title'];
            $row['onlineDetailUrl'] = \Tools\Lawyer::lawyerOnlineDetailUrl($v['id'], $v['repid'], $v['regdate']);
            
            $list[]         = $row;
        }
        
        $parentobj = new \Parents\FrontCommonController();
        $list = $parentobj->getLawyerListFromUc($list);
        $list = \Tools\Url::get_site_url($list);
        
        if ($getCount) {
            $count = \Rpc::getData('Online.queryAskOnlineMapListCount', $p);
            return array(
                'list' => $list,
                'count' => $count
            );
        }
        return $list;
    }
    
    /**
     * ������б�  a.repnum*2 ��Ϊ������ּ�ȥ������ֵĲ�ֵ
     *
     * @param type $areacodeBegin desc
     * @param type $areacodeEnd   desc
     * @param type $getNum        desc
     * @param type $orderBy       desc
     *
     * @return array
     */
    public function queryGongYiList($areacodeBegin, $areacodeEnd, $getNum, $orderBy = 'a.repnum')
    {
        $p = array(
            'orderBy' => $orderBy
        );
        if ($areacodeBegin) {
            $p['areacodeBegin'] = $areacodeBegin;
        }
        if ($areacodeEnd) {
            $p['areacodeEnd'] = $areacodeEnd;
        }
        $p['dayInt'] = date('Ymd', strtotime('-1 days'));
        $list        = \Rpc::getData('Ask.queryGongYiList2', 1, $getNum + 10, $p);
        
        $num = 0;
        
        $relist = array();
        foreach ($list as $k => $v) {
            $row = array();
            if (!isset($v['jifengAsk'])) {
                continue;
            }

            $row['userid']       = $v['userid'];
            $row['profession']   = $v['profession'];
            $row['jifengAsk']    = $v['jifengAsk']; //���Ļ���        
            $row['goodcommentnum'] = $v['supportcount']; //������
            $row['online_ans']   = $v['onlineAns']; //��������
            $row['islxt']        = $v['islxt'];
            $row['isonline']     = (time() - $v['lastdodate']) > $this->onlinetime ? 1 : 2;
            $relist[]            = $row;
            $num++;
            if ($num >= $getNum) {
                break;
            }
        }

        $relist = \Tools\Ads::get_ad_file($relist);
        
        $parentobj = new \Parents\FrontCommonController();
        $relist = $parentobj->getLawyerListFromUc($relist);
        
        return \Tools\Url::get_site_url($relist);
    }


    /**
      * �Թ�����ݽ�������ͷ�ҳ�Լ���ȡ��ϸ��Ϣ
      *
      * @param type $lawyerinfo  desc
      * @param type $page        desc
      * @param type $pagesize    desc
      * @param type $pageurlhead desc
      * @param type $orderBy     desc
      * @param type $profession  desc
      * 
      * @return type
      */
    public function lawyerinfoAndPage($lawyerinfo, $page, $pagesize, $pageurlhead, $orderBy, $profession='')
    {
        $pagenum = $page;
        
        $userids = array();
        foreach ($lawyerinfo as $key => $val) {
            $userids[] = $val['username']; //�������username ��userid            
        }    
        
        $p           = array(
            //'userids' => $userids,
            'useridsOrderFlag' => 0,
            'lastdodateflag' => '1',
            'lastdodate' => time() - $this->onlinetime, //�ò����������� �ǹ���
            'orderBy' => $orderBy
        );
        if (!empty($userids)) {
            $p['userids'] = $userids;
        }
        if ($profession!='') {
            $p['profession'] = $profession;
            $p['profname'] = $profession;
            $info         = $this->queryProfOnlineLawyerList($page, $pagesize, $p, $orderBy, true);
        } else {
            $info         = $this->onlineCityLawyerList($page, $pagesize, $p, true);
        }
        $relist      = $info['list'];
        $lawyercount = $info['count'];
        $pagetotal   = ceil($lawyercount / $pagesize);
        
        $classhtml = 'class="hover"';
        
        $parm          = array(
            'conhtml' => '��������һҳ���鿴����������ʦ',
            'lawyerpage' => 'y'
        );
        $parm["pparm"] = '/page_';
        $xuanze        = "3";
        $page1         = $this->pageBreak(
            $lawyercount, $pagetotal, $pagenum, $pageurlhead, $classhtml, $parm, $pagesize, $xuanze
        );
        
        return array(
            'pageHtml' => $page1,
            'list' => $relist
        );
    }

    /**
      * ר���б�
      *
      * @return type
      */
    public function getProfList()
    {
        return array(
            'zaiwu' => 'ծ��ծȨ',
            'hunyinjiating' => '������ͥ',
            'mingyi' => '�����ٰ�',
            'baoli' => '�����˺�',
            'fuyouquanyi' => '����Ȩ��',
            'yizhu' => '�����̳�',
            'hetong' => '��ͬ����',
            'laodong' => '�Ͷ�����',
            'jiaotong' => '��ͨ�¹�',
            'yiliaoshigu' => 'ҽ���¹�',
            'xiaofeiquanyi' => '������Ȩ��',
            'baoxian' => '��������',
            'danbao' => '��Ѻ����',
            'chanpin' => '��Ʒ����',
            'lihun' => '���',
            'jicheng' => '�̳�',
            'laodonghetong' => '�Ͷ���ͬ',
            'gongshang' => '�����⳥',
            'renshensunhai' => '�������⳥',
            'fangchan' => '��������',
            'caichan' => '�Ʋ�����',
            'bank' => '����',
            'jinrong' => '����',
            'fangwuchaiqian' => '���ݲ�Ǩ',
            'gongchenghetong' => '���̺�ͬ',
            'xintuo' => '����',
            'zhengquan' => '֤ȯ',
            'piaoju' => 'Ʊ��',
            'qihuo' => '�ڻ�',
            'dianzishangwu' => '��������',
            'zhaobiao' => '�б�Ͷ��',
            'lsjm' => '��������',
            'nlmy' => 'ũ������',
            'fengxian' => '����Ͷ��',
            'fanjingzheng' => '������������',
            'ad' => '�������',
            'tech' => '�߿Ƽ���Ŀ',
            'gongchengjz' => '��������',
            'lvyoujiufen' => '���ξ���',
            'gongsi' => '��ҵ���ɹ���',
            'shougou' => '��˾�չ�',
            'gufenzr' => '�ɷ�ת��',
            'gaizhi' => '��ҵ����',
            'pochan' => '�Ʋ�����',
            'paimai' => '�ʲ�����',
            'gongshangsw' => '����˰��',
            'gongsifa' => '��˾��',
            'guquan' => '��Ȩ',
            'xingshibianhu' => '���±绤',
            'xingzhengsusong' => '��������',
            'guojiapeichang' => '�����⳥',
            'huanjing' => '��������',
            'peichang' => '���⳥',
            'sixing' => '���̱绤',
            'haishi' => '���º���',
            'guojimaoyi' => '����ó��',
            'guojizc' => '�����ٲ�',
            'wstouzi' => '����Ͷ��',
            'fanqx' => '������',
            'shewaihunyin' => '�������',
            'shewailihun' => '�������',
            'yimin' => '����',
            'chanquan' => '֪ʶ��Ȩ',
            'zhuzuo' => '����Ȩ',
            'shangbiao' => '�̱�',
            'zhuanli' => 'ר��',
            'zhongcai' => '�ٲ�',
            'edu' => '����'
        );
    }
    
    /**
      * ��ȡ������Ϣ
      *
      * @param type $area_name ������
      * @param type $prof_name ������
      *
      * @return type
      */
    public function areaNavInfo($area_name, $prof_name)
    {
        return \Models\AreaStation\AreaStationModel::getNavInfo($area_name, $prof_name);
    }

    /**
      * ר����ϸ��Ϣ
      *
      * @param type $profPinyin ר��pinyin
      *
      * @return type
      */
    public function profInfo($profPinyin)
    {
        $arr = \Tools\FileDataQuery::import('sort')->getSort();
        $info = array();
        foreach ($arr as $k=>$v) {
            if (isset($v['askpinyin']) && $v['askpinyin'] == $profPinyin) {
                $info = $v;
            }
        }
        return $info;
    }

    /**
      * pageBreak�����ķ�װ
      *
      * @param type $recordCount desc
      * @param type $pagetotal   desc
      * @param type $curPage     desc
      * @param type $pageurlhead desc
      * @param type $classhtml   desc
      * @param type $parm        desc
      * @param type $pageSize    desc
      * @param type $xuanze      desc
      *
      * @return html
      */
    public function pageBreak($recordCount, $pagetotal, $curPage, $pageurlhead, $classhtml, $parm, $pageSize, $xuanze)
    {
        //ֻ��һҳ�ǲ���ʾ��ҳ
        if ($pagetotal <= 1) {
            return '';
        }

        $html = \Tools\Page::pageBreak($recordCount, $pagetotal, $curPage, $pageurlhead, $classhtml, $parm, $pageSize, $xuanze);
        
        //��һҳ����ʾ��ҳ����һҳ
        if ($curPage==1) {
            $rule = '/<li>\s*<a\s*href="([^<>]+?)">��ҳ<\/a><\/li>\s*<li><a href="(.+?)">��һҳ<\/a><\/li>/ims';
            $html = preg_replace($rule, '', $html);            
        }

        //���һҳ����ʾ��һҳ��ĩҳ
        if ($curPage==$pagetotal) {
            $rule = '/<li><a href="([^<>]+?)">��һҳ<\/a><\/li><li><a href="(.+?)">δҳ<\/a><\/li>/ims';
            $html = preg_replace($rule, '', $html);            
        }
        return $html;
    }
}