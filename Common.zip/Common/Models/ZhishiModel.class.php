<?php
/**
 *  yun_ask����ģ��
 *  
 *  @author wrd <xx@qq.com>
 */
namespace Models;
use Models;

/**
 *  yun_ask����ģ��
 *  
 *  @author wrd <xx@qq.com>
 */
class ZhishiModel extends \Think\Model
{
    protected  $connection;
    
    /**
     *	init
     *  
     *  @return null
     */
    public function __construct($tbleName='')
    {
            $hb_config_db = C('cms_config_db33506');
            $hb_config_db = array(
                'db_type' => $hb_config_db['dbms'],                 //���ݿ�����  mysql,
                'db_user'  => $hb_config_db['username'],             //�û���,
                'db_pwd'   => $hb_config_db['password'],             //����,
                'db_host'  => $hb_config_db['hostname'],                 //host,
                'db_port'  => $hb_config_db['hostport'],
                'db_name'  => $hb_config_db['database'],
                'db_charset' =>    'gbk',
            );
            $this->connection = array_merge($hb_config_db, $this->config());
            if (!empty($tbleName)) {
                $this->tableName = $tbleName;
            }
            parent::__construct();  
    }
    
    /**
     *	config
     *  
     *  @return null
     */
    public function config()
    {
        return array(
        ) ;
    }
}
