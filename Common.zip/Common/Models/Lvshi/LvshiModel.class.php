<?php
/**
 * ��һ����ʦ����ģ��
 *  
 * @author huanggongqiang <huanggongqiang@findlaw.cn>
 *
 *  @data 2015-11-7
 */
namespace Models\Lvshi;

/**
 * ��һ����ʦ����ģ��
 *  
 * @author huanggongqiang <huanggongqiang@findlaw.cn>
 *
 *  @data 2015-11-7
 */
class LvshiModel
{
    /**
     * ���ݵ���+��Ŀid��ѯ��ʦ�б�
     * 
     * @param integer $currentPage ��ǰҳ
     * @param string  $pageSize    ÿҳ��ʾ��¼��
     * @param string  $params      ��ѯ����
     * @param array   $fields      ��ѯ�ֶ�
     * @param array   $orders      �ֶ�����
     *
     * @return array/false
     */
    public function selectClassPage($currentPage = 1, $pageSize = 10, $params = '', $fields = '*', $orders = '`weight` DESC, lid ASC')
    {
        $findlaw_db = new \Models\FindlawModel();
        $findlaw_db->table('fl_lvshi_class');
        $rowFirst = $pageSize*($currentPage-1);
        return $findlaw_db->where($params)->field($fields)->join('LEFT JOIN fl_lvshi_class_data ON fl_lvshi_class.id=fl_lvshi_class_data.id')->group('fl_lvshi_class.lid')->order($orders)->limit($rowFirst, $pageSize)->select();
    }
    
    /**
     * ���ݵ���+��Ŀid��ѯ��ʦͳ����
     *
     * @param string $params ��ѯ����
     *
     * @return intval
     */
    public function countClass($params = '')
    {
        $findlaw_db = new \Models\FindlawModel();
        $findlaw_db->table('fl_lvshi_class');
        $count = $findlaw_db->where($params)->count('DISTINCT(lid)');
        return $count;
    }
    
    /**
     * ���ݵ���+��Ŀid+��ʦ�칫��/�ز�ѯ��ʦ�б�
     * 
     * @param integer $currentPage ��ǰҳ
     * @param string  $pageSize    ÿҳ��ʾ��¼��
     * @param string  $params      ��ѯ����
     * @param array   $orders      �ֶ�����
     *
     * @return array/false
     */
    public function selectClassPageByCountry($currentPage = 1, $pageSize = 10, $params = '', $orders = '`weight` DESC, lid ASC')
    {
        $findlaw_db = new \Models\FindlawModel();
        $rowFirst = $pageSize*($currentPage-1);
        
        $where = 'c.areacode = ' . $params['areacode'] . ' AND l.areacode = ' . $params['countrycode'] . ' AND c.classid = ' . $params['classid'] . ' AND c.ifaudit = ' . $params['ifaudit'];
        $sql   = 'SELECT l.areacode as countrycode, c.*, d.* FROM `fl_lvshi` l LEFT JOIN fl_lvshi_class c ON l.lid = c.lid LEFT JOIN fl_lvshi_class_data d ON c.id = d.id WHERE ' . $where . ' ORDER BY ' . $orders . ' LIMIT ' . $rowFirst . ', ' . $pageSize;
        return $findlaw_db->query($sql);
    }
    
    /**
     * ���ݵ���+��Ŀid+��ʦ�칫��/�ز�ѯ��ʦͳ����
     *
     * @param string $params ��ѯ����
     *
     * @return intval
     */
    public function countClassByCountry($params = '')
    {
        $findlaw_db = new \Models\FindlawModel();
        $where = 'c.areacode = ' . $params['areacode'] . ' AND l.areacode = ' . $params['countrycode'] . ' AND c.classid = ' . $params['classid'] . ' AND c.ifaudit = ' . $params['ifaudit'];
        $sql   = 'SELECT l.areacode as countrycode, c.*, d.* FROM `fl_lvshi` l LEFT JOIN fl_lvshi_class c ON l.lid = c.lid LEFT JOIN fl_lvshi_class_data d ON c.id = d.id WHERE ' . $where;
        
        $data = $findlaw_db->query($sql);
        return count($data);
    }
    
    /**
     *  ������ʦID��ѯ��ʦ�б�
     *
     *  @param array  $lids   ��ʦ
     *  @param string $fields ��ѯ����
     *  @param string $orders �ֶ�����
     *
     *  @return array
     */
    public static function select($lids, $fields = '*', $orders = '`weight` DESC')
    {
        if (empty($lids) || !is_array($lids)) {
            return array();
        }
       
        $findlaw_db = new \Models\FindlawModel();
        
        $sql = 'select ' . $fields . ' from fl_lvshi l left join fl_lvshi_major m on l.lid = m.lid where l.lid in (' . implode(',', $lids) . ') ORDER BY ' . $orders;
        return $findlaw_db->query($sql);
    }
    
    /**
     *  ��ѯ��ʦ����
     *
     *  @param intval $lid    ����ID
     *  @param string $fields ��ѯ����
     *
     *  @return array
     */
    public static function find($lid, $fields = '*')
    {
        if (empty($lid)) {
            return array();
        }
        $findlaw_db = new \Models\FindlawModel();
        
        $sql  = 'select ' . $fields . ' from fl_lvshi l left join fl_lvshi_major m on l.lid = m.lid where l.lid=' . $lid;
        $info = $findlaw_db->query($sql);
        return $info[0];
    }

    /**
     *  ��ѯ�����ʦ����
     *
     *  @param array  $lids   IDS
     *  @param string $fields ��ѯ����
     *
     *  @return array
     */
    public static function findmore($lids, $fields = '*')
    {
        if (empty($lids)) {
            return array();
        }
        $lids = implode(",", $lids);
        $findlaw_db = new \Models\FindlawModel();
        
        $sql  = 'select ' . $fields . ' from fl_lvshi l left join fl_lvshi_major m on l.lid = m.lid where l.lid in (' . $lids.')';
        $info = $findlaw_db->query($sql);
        return $info;
    }

    /**
     *  ��ѯ��ʦ����
     *
     *  @param array  $params ��������
     *  @param string $fields ��ѯ����
     *
     *  @return array
     */
    public static function findByUid($params, $fields = '*')
    {
        if (empty($params)) {
            return array();
        }
        $findlaw_db = new \Models\FindlawModel();
        $findlaw_db->table('fl_lvshi');
        $info = $findlaw_db->where($params)->field($fields)->join('LEFT JOIN fl_lvshi_major ON fl_lvshi.lid=fl_lvshi_major.lid')->find();
        return $info;
    }
    
    /**
     *  ��ѯ��ʦ��ͨר�� �� fl_lvshi_class
     *
     *  @param intval $lid    lid
     *  @param string $fields ��ѯ�ֶ�
     *
     *  @return array
     */
    public static function selectTableClassByLid($lid, $fields = '*')
    {
        if ($lid <= 0) {
            return array();
        }
        
        $findlaw_db = new \Models\FindlawModel();
        $findlaw_db->table('fl_lvshi_class');
        return $findlaw_db->where(array('lid' => $lid))->field($fields)->select();
        
    }
    
    /**
     *  ��ѯ������ƽ̨��ʦ����
     *
     *  @param intval $id ����ID
     *
     *  @return array
     */
    public static function getfind($id)
    {
        if (empty($id)) {
            return array();
        }
        
        $info = \Rpc::getShortlinkData('Lawyercenter.getOtPeopleMainLawyer', $id);
        $info['otPeopleLawyerSub']['jianjie'] = str_replace(array('?','��'), '', $info['otPeopleLawyerSub']['jianjie']);
        return $info;
    }

    /**
     *  ��ѯ������ƽ̨�����ʦ����
     *
     *  @param intval $ids ����ID
     *
     *  @return array
     */
    public static function getfindmore($ids)
    {
        if (empty($ids)) {
            return array();
        }        
        $info = \Rpc::getShortlinkData('Lawyercenter.queryOtPeopleMainLawyerByIds', $ids);
        //$info['otPeopleLawyerSub']['jianjie'] = str_replace(array('?','��'), '', $info['otPeopleLawyerSub']['jianjie']);
        return $info;
    }

    /**
     * ��ѯ��ʦ�б�
     * 
     * @param integer $currentPage ��ǰҳ
     * @param string  $pageSize    ÿҳ��ʾ��¼��
     * @param string  $params      ��ѯ����
     * @param array   $fields      ��ѯ�ֶ�
     * @param array   $orders      �ֶ�����
     *
     * @return array/false
     */
    public function selectPage($currentPage = 1, $pageSize = 10, $params = '', $fields = '*', $orders = '`weight` DESC, lid ASC')
    {
        $findlaw_db = new \Models\FindlawModel();
        $findlaw_db->table('fl_lvshi');
        $rowFirst = $pageSize*($currentPage-1);
        return $findlaw_db->where($params)->field($fields)->order($orders)->limit($rowFirst, $pageSize)->select();
    }
    
    /**
     * ��ѯ��ʦͳ����
     *
     * @param string $params ��ѯ����
     *
     * @return intval
     */
    public function counts($params = '')
    {
        $findlaw_db = new \Models\FindlawModel();
        $findlaw_db->table('fl_lvshi');
        $count = $findlaw_db->where($params)->count('DISTINCT(lid)');
        return $count;
    }
    
    /**
     *  ���Źؼ���
     *
     *  @param intval $areacode ��ѯ����
     *
     *  @return ajax
     */
    public static function hotKeyword($areacode)
    { 
        if (empty($areacode)) {
            return array();
        }
        
        // ȫ�����ų���
        $hotCity = array(110101,140101,170200,170300,120101,230200,130101,240200,400200,260200,290200,360200,330200,160200,150200,171400,330300,170900,261100,400400,210700,171200,170400,260900,261300,250200,280200,100500,261000,190200,390200);
        
        // ȫ���������
        $classList = \Tools\LvshiClass::getParentList();
        $classids  = array();
        foreach ($classList as $v) {
            foreach ($v['childList'] as $vo) {
                $classids[] = $vo['id'];
            }
        }
        
        // ��ȡ��������
        $cityMap = \Tools\Iparea::getNearUcAreaMap($areacode, 5);
        $cityArr = array($areacode);
        foreach ($cityMap as $v) {
            $cityArr[] = $v['id'];
        }
        
        // �ų���ͬ����
        $hotCity = array_diff($hotCity, $cityArr);
        // ���5������
        $cityOne  = array_rand($hotCity, 5);
        $cityTwo  = array_rand($hotCity, 5);
        
        // �����ȡ��Ŀ
        $classOne = array_rand($classids, 4);
        $classTwo = array_rand($classids, 5);
        
        $keyword  = array();
        
        // ��װ����
        foreach ($cityArr as $k => $v) {
            $areaInfo = \Tools\Iparea::getAreainfoByareacode($v);
            if ($k < 4) {
                $classInfo = \Tools\LvshiClass::getClassInfoByClassid($classids[$classOne[$k]]); 
                $keyword[] = array(
                    'name' => $areaInfo['city'] . $classInfo['name'] . '��ʦ',
                    'url'  => 'http://china.findlaw.cn/' . $areaInfo['pinyin'] . '/' . $classInfo['pinyin'] ,
                );
            }
            $keyword[] = array(
                'name' => $areaInfo['city'] . '��ʦ',
                'url'  => 'http://china.findlaw.cn/findlawyers/area/' . $areaInfo['pinyin'],
            );
        }
        
        foreach ($cityOne as $k => $v) {
            $areaInfo  = \Tools\Iparea::getAreainfoByareacode($hotCity[$v]);
            $classInfo = \Tools\LvshiClass::getClassInfoByClassid($classids[$classTwo[$k]]);
            $keyword[] = array(
                'name' => $areaInfo['city'] . $classInfo['name'] . '��ʦ',
                'url'  => 'http://china.findlaw.cn/' . $areaInfo['pinyin'] . '/' . $classInfo['pinyin'] ,
            );
        }
        
        foreach ($cityTwo as $v) {
            $areaInfo = \Tools\Iparea::getAreainfoByareacode($hotCity[$v]);
            $keyword[] = array(
                'name' => $areaInfo['city'] . '��ʦ',
                'url'  => 'http://china.findlaw.cn/findlawyers/area/' . $areaInfo['pinyin'],
            );
        }
        
        // �������
        $lists = array(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19);
        shuffle($lists); 
        
        foreach ($lists as $k => $v) {
            $lists[$k] = $keyword[$v];
        }
        
        return $lists;
    }
}
