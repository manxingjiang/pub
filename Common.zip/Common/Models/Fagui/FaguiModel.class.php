<?php
/**
 * ��������API
 *  
 * @author wujifeng <wujifeng@findlaw.cn>
 */
namespace Models\Fagui;

/**
 * ��������API
 *  
 * @author wujifeng <wujifeng@findlaw.cn>
 */
class FaguiModel
{
    /**
     * ������ ����������
     *
     * @return array
     */
    public function fl_area_list_with_cat()
    {
        $list = self::get_area_list(false);        
        $newfg_area_cat = array(
            1 => array(
                'name' => '��������',
                'provinces' => array('hebei','heilongjiang','jl','liaoning','neimenggu','shanxi')
            ),
            2 => array(
                'name' => '��������',
                'provinces' => array('anhui','fujian','jiangsu','shandong','zhejiang')
            ),
            3 => array(
                'name' => '�в�����',
                'provinces' => array('gansu','guizhou','henan','hubei','hunan','jiangxi','ningxia','qinghai','sichuan','xizang','xinjiang','yunnan')
            ),
            4 => array(
                'name' => '���ϵ���',
                'provinces' => array('guangdong','guangxi', 'hainan')
            )
        );        
        $relist = array();
        foreach ($newfg_area_cat as $k => $v) {
            $relist[$k] = $v;
            foreach ($relist[$k]['provinces'] as $province) {
                if (isset($list[$province])) {
                    $relist[$k]['childs'][$province] = $list[$province];
                }
            }
        }        
        return $relist;
    }
    
    /**
     *  ȡ�õ�������(�ּ�)
     *
     *  @param boole $is_add_count �Ƿ����ӵ�����������
     *
     *  @return void
     */
    public static function get_area_list($is_add_count = true)
    {
        $list            = self::fl_area_list();
        $relist          = array();
        $gradeone_pinyin = '';
        $gradetwo_pinyin = '';
        foreach ($list as $k => $v) {
            if ($is_add_count) {
                $v['count'] = self::countFaguiByAreacode($v['id']);
            }            
            if ($v['grade'] == 0) {
                $v['link']            = '/' . 'fagui' . '/area/' . $v['pinyin'] . '/p_1/';
                $relist[$v["pinyin"]] = $v;
                $gradeone_pinyin      = $v['pinyin'];
            } elseif ($v['grade'] == 1) {
                $v['link']                                        = '/' . 'fagui' . '/area/' . $gradeone_pinyin . '_' . $v['pinyin'] . '/p_1/';
                $relist[$gradeone_pinyin]['childs'][$v["pinyin"]] = $v;
                $gradetwo_pinyin                                  = $v['pinyin'];
            } else {
                $v['link']                                                                    = '/' . 'fagui' . '/area/' . $gradeone_pinyin . '_' . $gradetwo_pinyin . '_' . $v['pinyin'] . '/p_1/';
                $relist[$gradeone_pinyin]['childs'][$gradetwo_pinyin]['childs'][$v["pinyin"]] = $v;
            }
        }
        return $relist;
    }
    
    /**
     * fl_area ������ԭʼ����
     *
     * @param int $grade ȡ���ټ��ĵ�������
     *
     * @return void
     */
    public function fl_area_list($grade = 2)
    {
        $gradearr = array();
        switch ($grade) {
        case 1:
            $gradearr = array(0);
            break;
        case 2:
            $gradearr = array(0, 1);
            break;
        case 3:
        default:
            $gradearr = array(null);
            break;
        }
        $arealist = \Rpc::getUCData('Area.queryUcAreaListByGrades', array('grades' => $gradearr, 'orderBy' => 'a.id ASC'), 1, 0);
        foreach ($arealist as $k => &$v) {
            unset($v['template']);
            unset($v['type']);
            unset($v['rank']);
        }
        return $arealist;
    }

    /**
     * ���ݵ�����ͳ�Ʒ�������
     *
     * @param int $areacode ������
     *
     * @return void
     */
    public function countFaguiByAreacode($areacode)
    {
        //�������Է������ͳ��
        $count = 0;        
        static $area_count_arr = null;        
        if ($area_count_arr == null) {         
            $result          = \Rpc::getData('Fagui.queryNewfgFaguiCountMap');            
            foreach ($result as $v) {
                $area_count_arr[$v["areacode"]] = $v['count'];
            }
            unset($result);
            $onearealist = self::fl_area_list(1);//���Ϸ�����û���ݵ�ʡ��
            foreach ($onearealist as $onev) {
                $area_count_arr[$onev["id"]] = isset($area_count_arr[$onev["id"]]) ? $area_count_arr[$onev["id"]] : 0;
            }
            unset($onearealist);            
            //ʡ��������������=�����м����������������ܺ�+��ǰʡ�������ķ�����
            $list   = self::fl_area_list(2);
            $kclist = array();
            foreach ($list as $k => $v) {
                $kclist[$v["id"]] = $v;
            }
            unset($list);            
            foreach ($area_count_arr as $id => $count) {
                if ($kclist[$id]['grade'] == 0) {
                    $clist = self::get_childen_area_list($id, false);
                    foreach ($clist as $cv) {
                        if (isset($area_count_arr[$cv["id"]])) {
                            $area_count_arr[$id] = $area_count_arr[$id] + $area_count_arr[$cv["id"]];
                        }
                    }
                    unset($clist);
                }
            }
        }        
        if (isset($area_count_arr[$areacode])) {
            $count = $area_count_arr[$areacode];
        }        
        return $count;
    }      
    
    /**
     * ȡ���ӵ����б�
     *
     *  @param int $area        δ֪
     *  @param int $containself δ֪
     *
     *  @return : array
     */
    public function get_childen_area_list($area, $containself = true)
    {        
        $list = self::fl_area_list();
        if (is_numeric($area)) {
            $key = 'id';
        } else {
            $key = 'pinyin';
        }        
        $areainfo = array();
        foreach ($list as $k => $v) {
            if ($v[$key] == $area) {
                $areainfo = $v;
                break;
            }
        }        
        $areacode = $areainfo['id'];        
        $list = self::get_area_fjlist();
        $re   = isset($list[$areacode]) ? $list[$areacode] : array();
        if ($containself) {
            $re[$areainfo["id"]] = $areainfo;
        }
        return $re;
    }
    
    /**
     * δ֪
     *
     * @return void
     */
    public function get_area_fjlist()
    {        
        $file = TEMP_PATH . 'area_pc_list1.php';        
        if (!file_exists($file)) {
            $pclist  = array();
            //һ���б�
            $onelist = self::fl_area_list(1);
            foreach ($onelist as $k => $v) {                
                $v['parentid']       = 0;
                $pclist[0][$v["id"]] = $v;                
                //�����б�(id ,pinyin)
                //$etc       = "1 and  province='" . $v['province'] . "' and id<>'" . $v['id'] . "' and grade='1' ";                
                $twolist = \Rpc::getUCData('Area.queryUcAreaListByUcAreaForm', array('province'=>$v['province'],'id'=>$v['id'],'grade'=>1), 1, 0);
                foreach ($twolist as $tk => &$tv) {
                    unset($tv['city']);//fagui.class.php�в�û�з���city�Ͷ�ȡ�����б�
                    unset($tv['province']);
                    unset($tv['country']);
                    unset($tv['grade']);
                    unset($tv['gradeSalse']);
                    unset($tv['rank']);
                    unset($tv['template']);
                    unset($tv['type']);
                    $tv['parentid']              = $v['id'];
                    $pclist[$v["id"]][$tv["id"]] = $tv;                    
                    //��ȡ�����б�
                    //$etc       = "1 and  city='" . $tv['city'] . "' and id<>'" . $tv['id'] . "' and grade='2' ";
                    //$threelist = \Rpc::getUCData('Area.queryUcAreaListByUcAreaForm', array('city'=>$tv['city'],'id'=>$tv['id'],'grade'=>2), 1, 0);
                    //foreach ($threelist as &$thv) {
                    //    $thv['parentid']               = $tv['id'];
                    //    $pclist[$tv["id"]][$thv["id"]] = $thv;
                    //}
                }
            }            
            $con = '<?php return ' . var_export($pclist, true) . ';';
            file_put_contents($file, $con);            
        } else {            
            $pclist = include_once $file;
        }
        return $pclist;
    }        
}