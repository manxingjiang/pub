<?php
/**
 *  fl_ask����ģ��
 *  
 *  @author zsg <xx@qq.com>
 */
namespace Models;
use Models;

/**
 *  fl_ask����ģ��
 *  
 *  @author zsg <xx@qq.com>
 */
class FlsystemModel extends \Think\Model
{
    protected  $connection;
    
    /**
     *	init
     *  
     *  @return null
     */
    public function __construct()
    {
            require "include/config_findlaw_db.php";
            $cms_config_db33506 = array(
                'db_type' => $cms_config_db33506['dbms'],                 //���ݿ�����  mysql,
                'db_user'  => $cms_config_db33506['username'],             //�û���,
                'db_pwd'   => $cms_config_db33506['password'],             //����,
                'db_host'  => $cms_config_db33506['hostname'],                 //host,
                'db_port'  => $cms_config_db33506['hostport'],
                'db_name'  => $cms_config_db33506['database'],
                'db_charset' =>    'gbk',
            );
            $this->connection = array_merge($cms_config_db33506, $this->config());
            parent::__construct();  
    }
    
    /**
     *	config
     *  
     *  @return null
     */
    public function config()
    {
        return array(
           'db_name'=>'fl_system'
        ) ;
    }
}
