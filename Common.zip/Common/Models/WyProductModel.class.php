<?php
/**
 *  findlaw_db����ģ��
 *  
 *  @author zsg <xx@qq.com>
 */
namespace Models;
use Models;

/**
 *  findlaw_db����ģ��
 *  
 *  @author zsg <xx@qq.com>
 */
class WyProductModel extends \Think\Model
{
    protected  $connection;
    
    /**
     * init
     *  
     * @param string $name $name
     *
     *  @return null
     */
    public function __construct($name='')
    {
        require "include/config_findlaw_db.php";
        $config = array(
            'db_type' => $product_config_db33605['dbms'],                 //���ݿ�����  mysql,
            'db_user'  => $product_config_db33605['username'],             //�û���,
            'db_pwd'   => $product_config_db33605['password'],             //����,
            'db_host'  => $product_config_db33605['hostname'],                 //host,
            'db_port'  => $product_config_db33605['hostport'],
            'db_name'  => $product_config_db33605['database'],
            'db_charset' => 'gbk',
        );
        $this->connection = array_merge($config, $this->config());
        if (empty($name)) {
            $this->tableName = 'product_website_tpl';
        } else {
            $this->tableName = $name;
        }
        parent::__construct();  
    }
    
    /**
     *	config
     *  
     *  @return null
     */
    public function config()
    {
        return array(
        ) ;
    }
    
    /**
     * ȡ��ʦ��ǰ��Ч�ĸ�����վģ��id
     * 
     * @param string $userid ��ʦ�û���
     * 
     * @return void
     */
    public static function getSaleTplId($userid)
    {
        $model = new \Models\WyProductModel('product_website_tpl');
        $data = $model->field('distinct(`tplid`)')->where(array('userid' => $userid, 'state' => 1))->select();
        //echo $model->getLastSql();
        $saleTplIds = array();
        if ($data) {
            foreach ($data as $key => $val) {
                $saleTplIds[] = $val['tplid'];
            }
        }
        return $saleTplIds;
    }
    
    /**
     * ȡ��ʦָ��ģ��
     * 
     * @param string $userid ��ʦ�û���
     * @param string $tplid  ģ��Id
     * 
     * @return void
     */
    public static function getSaleTplInfo($userid, $tplid)
    {
        $model = new \Models\WyProductModel('product_website_tpl');
        return $model->where(array('userid' => $userid, 'state' => 1, 'tplid' => $tplid))->select();
    }

    /**
     * ����
     *
     * @param array $data ����
     *
     * @return void
     */
    public static function pdebug($data)
    {
        if ($data) {
            echo "<pre>";
            print_r($data);
            echo "</pre>";
        };
    }
}
