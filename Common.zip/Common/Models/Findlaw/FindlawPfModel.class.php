<?php
/**
 * �ҷ�ҵ���������
 *
 * @author lihuanlin <birdy@findlaw.cn>
 */
namespace Models\Findlaw;

/**
 * �ҷ�ҵ���������
 *
 * @author lihuanlin <birdy@findlaw.cn>
 */
class FindlawPfModel
{
    protected $uid         = 0;
    protected $userid      = ''; 
    protected $lawyer      = array();  //��ʦ��Ϣ
    protected $checkInfo   = array();  //���������
    protected $errorInfo   = array();  //��Ч������
    protected $error = '';             //������Ϣ
    
    //��Ҫ���������ģ�飬��001,002������
    private $checkModel = array();
    
    //�ֶ�����
    //name�� �ֶ���������
    //check����˴��ţ���ѡֵ005 �ȣ�Ϊ��ʱ����ʾ����Ҫ���
    //type�� ����field:���ֶΣ����е��У���one:������¼(���ж���)��mul:���¼(���ж���)��special:���⴦�����Զ��庯��ȥ������Ĭ��Ϊfield
    //table����Ӧ�ı� tblmember,vlawyer_web,vlawyer_message
    //�����ֶΣ�function,method
    protected $field = array(
        "webtitle2" => array(
            "name" => "��վ����",
            "table" => "vlawyer_web",
            "check" => "006",
        ),
        "headTitle2" => array(
            "name" => "�м�ͨ������",
            "table" => "vlawyer_web",
            "check" => "006",
        ),
        "userTitle2" => array(
            "name" => "�û��ƺ�",
            "table" => "vlawyer_web",
            "check" => "006",
        ),
        "qqApiInfo" => array(
            "name" => "QQ����",
            "table" => "tblmember",
            "check" => "006"
        ),
        "notice2" => array(
            "name" => "����",
            "table" => "vlawyer_message",
            "check" => "006"
        ),
    );
    
    /**
     * ��ʼ��
     * 
     * @param int    $uid    �û�ID���ش�
     * @param string $userid �˺�
     * @param array  $user   ��ʦ����
     * 
     * @return void
     */
    public function __construct($uid=0, $userid="", $user=array())
    {
        $this->uid = intval($uid);
        $this->userid = $userid;
        $this->lawyer = $user;
    }
    
    /**
     * ��ʼ��������
     * 
     * @param array $data Ҫ����������
     * 
     * @return void
     */
    public function start($data = array())
    {
        if (!$data) {
            $this->setError("û����Ҫ����������");
            return false;
        }
        foreach ($data as $k=>$data) {
            if (isset($this->field[$k])) {
                $field = $this->field[$k];
                $data = $this->formateData($data, $field);
                $check  = isset($field['check']) ? $field['check'] : false;
                $type   = isset($field['type'])  ? $field['type']  : 'field';
                $table  = isset($field['table']) ? $field['table'] : '';
                
                if ($type === "special") {
                    
                } else if ($check) {
                    $this->checkInfo[$table][$k] = $data;
                }
            } else {
                $this->errorInfo[] = $data;
            }
        }
        if ($this->checkError()) {
            $this->dealCheckInfo(); //������Ҫ��˵���Ϣ
        } else {
            return false;
        }
        
        
        if ($this->checkError()) {
            if ($this->checkModel) { //��������ܱ�
                $old = \Rpc::getUCData("Audit.admin.getAuAuditMainByUid", $this->uid);
                if ($old) {
                    $info = explode(",", $old['info']);
                    if ($info) {
                        $info = array_unique(array_merge($info, $this->checkModel));
                    } else {
                        $info = $this->checkModel;
                    }
                    $update = array(
                        "uid" => $this->uid,
                        "updatetime" => time(),
                        "ifaudit"  => 0,
                        "info" => implode(",", array_filter($info))
                    );
                    \Rpc::getUCData("Audit.admin.updateAuAuditMainByUid", $update);
                } else {
                    $insert = array(
                        "uid"      => $this->uid,
                        "userid"   => $this->userid,
                        "username" => $this->lawyer['username'],
                        "areacode" => $this->lawyer['areacode'],
                        "updatetime" => time(),
                        "ifaudit"  => 0,
                        "info"     => implode(",", array_filter($this->checkModel))
                    );
                    \Rpc::getUCData("Audit.admin.insertAuAuditMainSel", $insert);
                }
            }
        } else {
            return false;
        }
                
        return true;
    }
    
    /**
     * ÿ�δ�������һ��ģ������ݣ��˷����������ڵ����޸�ĳ���ֶΣ�ĳ�����컯����
     * 
     * @param string $key   �ֶ���
     * @param string $value Ҫ�޸ĵ�ֵ
     * 
     * @return void
     */
    public function startByKeyValue($key, $value)
    {
        return $this->start(array($key=>$value));
    }
    
    /**
     * ������Ҫ��˵�����
     * 
     * @return void
     */
    private function dealCheckInfo()
    {
        if ($this->checkInfo) {
            $content = array('newData'=>array(), 'oldData'=>array());
            foreach ($this->checkInfo as $table=>$v) {
                $method = "deal_".$table;
                if (method_exists($this, $method)) {
                    $rs = $this->$method($v);
                    if ($rs['newData']) {
                        $content['newData'] = array_merge($content['newData'], $rs['newData']);
                        $content['oldData'] = array_merge($content['oldData'], $rs['oldData']);
                    }
                }
            }
            if ($content['newData']) {
                $this->checkModel[] = "006";
                $old = \Models\UcAuditModel::getByType($this->uid, "006", 0);
                if (!$this->lawyer) {
                    $this->lawyer = \Rpc::getUCData('Member.getUcLawyerByPKSel', $this->uid, 1, 1);
                }
                if ($old) {
                    $contentOld = unserialize($old['content']);
                    $content['newData'] = array_merge($contentOld['newData'], $content['newData']);
                    $content['oldData'] = array_merge($contentOld['oldData'], $content['oldData']);
                    $content['userid']  = $this->userid;
                    \Models\UcAuditModel::update($old['id'], "006", $content);
                } else {
                    \Models\UcAuditModel::insert($this->uid, $this->lawyer['areacode'], "006", $content);
                }
            }
        }
        return true;
    }
    
    
    /**
     * ����vlawyer_web��
     * 
     * @param array $data ����
     * 
     * @return array
     */
    private function deal_vlawyer_web($data)
    {
        $rs = array();
        $old = \Rpc::getData(array('Lawyer.getVlawyerWeb', array('H-N'=>'YES')), $this->userid);
        foreach ($data as $k=>$v) {
            $rs['newData'][$k] = $v;
            $rs["oldData"][$k] = $old[$k] ? $old[$k] : '';
        }
        return $rs;
    }
    
    /**
     * ����vlawyer_message��
     * 
     * @param array $data ����
     * 
     * @return array
     */
    private function deal_vlawyer_message($data)
    {
        $rs = array();
        $old = \Rpc::getData(array('Lawyer.getVlawyerMessageByUserid', array('H-N'=>'YES')), $this->userid);
        foreach ($data as $k=>$v) {
            $rs['newData'][$k] = $v;
            $rs["oldData"][$k] = $old[$k] ? $old[$k] : '';
        }
        return $rs;
    }
    
    /**
     * ��ʽ������
     * 
     * @param unknown $data  Ҫ��ʽ��������
     * @param array   $field �ֶ��䱸����
     * 
     * @return unknown
     */
    private function formateData($data, $field)
    {
        if ($field['function'] && function_exists($field['function'])) {
            $data = call_user_func($field['function'], $data);
        } else if ($field['method'] && method_exists($this, $field['method'])) {
            $data = call_user_func($field['method'], $data);
        }
        return $data;
    }
    
    /**
     * ����Ƿ�������
     * 
     * @return bool
     */
    protected function checkError()
    {
        return empty($this->error) ? true : false;
    }
    
    /**
     * ���ô�����Ϣ
     * 
     * @param type $info ������Ϣ
     * 
     * @return void
     */
    protected function setError($info = '')
    {
        $this->error = $info ? $info : '';
    }
    
    /**
     * ��ȡ������Ϣ
     * 
     * @return string
     */
    public function getError()
    {
        return $this->error;
    }
}
