<?php
/**
 *  findlaw_db����ģ��
 *  
 *  @author zsg <xx@qq.com>
 */
namespace Models;
use Models;

/**
 *  findlaw_db����ģ��
 *  
 *  @author zsg <xx@qq.com>
 */
class UcUserCloudModel extends \Think\Model
{
    protected  $connection;
    
    /**
     *	init
     *  
     *  @return null
     */
    public function __construct($name='')
    {
            require "include/config_findlaw_db.php";
            $hb_config_db57789 = array(
                'db_type' => $hb_config_db57789['dbms'],                 //���ݿ�����  mysql,
                'db_user'  => $hb_config_db57789['username'],             //�û���,
                'db_pwd'   => $hb_config_db57789['password'],             //����,
                'db_host'  => $hb_config_db57789['hostname'],                 //host,
                'db_port'  => $hb_config_db57789['hostport'],
                'db_name'  => $hb_config_db57789['database'],
                'db_charset' =>    'gbk',
            );
            $this->connection = array_merge($hb_config_db57789, $this->config());
            if (empty($name)) {
                $this->tableName = 'lawyer';
            } else {
                $this->tableName = $name;
            }
            parent::__construct();  
    }
    
    /**
     *	config
     *  
     *  @return null
     */
    public function config()
    {
        return array(
        ) ;
    }
    
    /**
     * ͨ�� ��ʦuids ȡ������--����uid ��������ʱ���ã� ͨ������������ʦ�����������ݣ���������(����ʱ��һ��)
     * 
     * @param array $uids ��ʦid
     * 
     * @return array һά���� key:uid, value:����
     */
    public function getLawyerRoomByUids($uids)
    {
        if (count($uids) > 0) {
            $key = "ucUserModel_getLawyerRoomByUids";
            $lawyerLawRooms = S($key);
            if (empty($lawyerLawRooms)) {
                $this->table("uc_lawyer");
                $sql = 'select uid, lawyer_lawroom from uc_lawyer where lawyer_lawroom != "" and ifaudit = 1' ;
                $lawRoomData = $this->query($sql);
                $lawyerLawRooms = array();
                foreach ($lawRoomData as $k => $v) {
                    $lawyerLawRooms[$v['uid']] = $v['lawyer_lawroom'];
                }
                S($key, $lawyerLawRooms, 86400);
            }


            foreach ($uids as $k => $uid) {
                if (empty($lawyerLawRooms[$uid])) {
                    $uids[$k] = '';
                } else {
                    $uids[$k] = $lawyerLawRooms[$uid];
                }
            }
            return $uids;
        }
        return array();
    }
    
    /**
     * ͨ�� ��ʦuids ȡ������--����uid ��������ʱ���ã� ͨ������������ʦ������ʦͷ�����ݣ���������(����ʱ��һ��)
     *
     * @param array $uids ��ʦid
     *
     * @return array һά���� key:uid, value:����
     */
    public function getLawyerPhotoByUids($uids)
    {
        if (count($uids) > 0) {
            $key = "ucUserModel_getLawyerFileByUids";
            $lawyerPhotos = S($key);
            if (empty($lawyerPhotos)) {
                $this->table("uc_lawyer");
                $sql = 'select uid, photo from uc_lawyer_file where photo != "" and photo != "blank.jpg" ' ;
                $lawPhotoData = $this->query($sql);
                $lawyerPhotos = array();
                foreach ($lawPhotoData as $k => $v) {
                    $lawyerPhotos[$v['uid']] = $v['photo'];
                }
                S($key, $lawyerPhotos, 86400);
            }
    
    
            foreach ($uids as $k => $uid) {
                if (empty($lawyerPhotos[$uid])) {
                    $uids[$k] = '';
                } else {
                    $uids[$k] = $lawyerPhotos[$uid];
                }
            }
            return $uids;
        }
        return array();
    }
}
