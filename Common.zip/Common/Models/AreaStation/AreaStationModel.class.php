<?php
/**
 * �°���ʦ��������
 *
 * @author    zhangshengguang <1649353934@qq.com>
 */

namespace Models\AreaStation;

/**
 * �°���ʦ��������
 *
 * @author    zhangshengguang <1649353934@qq.com>
 */
class AreaStationModel
{
    /**
      * ͷ��ͳ������
      *
      * @param type $pinyin    ����ƴ��
      * @param type $prof_sid  ר��id
      * @param type $prof_name ר����
      * @param type $getw      ͳ��ʲô
      *
      * @return type
      */
    public static function pageHeaderCount($pinyin, $prof_sid, $prof_name, $getw)
    {
        /*  
        $getw : ��Ҫͳ��ʲô����
            'askcount',     //��ѯ����
            'flalcount',     //�ɹ���������
            'newscount',    //������Ѷ���� 
            'countflfg',    //���ɷ�������
            'lswjcount',    //��ʦ�ļ�����
        */

        $areaInfo = \Rpc::getData('Area.queryAreaInfo', $pinyin);
        $areagrade = $areaInfo['areaGrade'];
        $areacode6 = $areaInfo['areacode'];
        $province_name = $areaInfo['province_name'];
        $area_name = $areaInfo['area_name'];

        switch ($areagrade) {
        case 0:
            $areacode = substr($areacode6, 0, 2);
            break;
        case 1:
            $areacode = substr($areacode6, 0, 4);
            break;
        case 2:
            $areacode = $areacode6;
            break;
        }

        $re = array();
        
        if (in_array('askcount', $getw)) {
            //��ѯ����
            if ($prof_sid == '') {
                $askcount = self::arealist_askcount($areacode, $prof_sid);
            } else {
                $month = date('Ym', time());
                $askcount = self::arealist_askcount($areacode, $prof_sid, $month);
                if ($askcount == 0) {
                    $month = date('Ym', strtotime('-1 month'));
                    $askcount = self::arealist_askcount($areacode, $prof_sid, $month);
                }
            }
            $re['askcount'] = $askcount;    
        }
        
        if (in_array('flalcount', $getw)) {
            //�ɹ���������
            $flal_arr = self::areacodeBeginEndParam($areacode);
            $flal_arr['cysort'] = $prof_name;
            $flal_arr['ifaudit'] = 1;
            $flalcount = \Rpc::getData(array("Lawcase.queryLawcaseCount", array('H-N'=>'YES')), $flal_arr);
            $re['flalcount'] = $flalcount;    
        }

        if (in_array('newscount', $getw)) {
            //������Ѷ����
            $newscount = \Rpc::getData("Dedecms.queryDedeArchivesCount", 'dede_news', $area_name, 41);
            $re['newscount'] = $newscount;        
        }
        
        if (in_array('countflfg', $getw)) {
            //���ɷ�������
            $diqufagui   = self::get_diqufagui();
            $dedetypeid  = $diqufagui[$province_name][0];
            $countflfg = \Rpc::getData("Dedecms.queryDedeArchListCount", 'findlaw_dedecms', $area_name, $dedetypeid, null);
            $re['countflfg'] = $countflfg;
        }

        if (in_array('lswjcount', $getw)) {
            //��ʦ�ļ�����
            $lswjcount = self::arealswj_count($areacode);
            $re['lswjcount'] = $lswjcount;
        }

        return $re;
    }

    /**
      * ��ʦ�ļ�����
      *
      * @param type $areacode areacode
      *
      * @return type
      */
    public static function arealswj_count($areacode)
    {
        if (strlen($areacode) == 6) {
            $areacodeBegin = $areacodeEnd = '';
        } else if (strlen($areacode) == 4) {
            $areacodeBegin = $areacode . '00';
            $areacodeEnd   = $areacode . '99';
            $areacode      = null;
        } else if (strlen($areacode) == 2) {
            $areacodeBegin = $areacode . '0000';
            $areacodeEnd   = $areacode . '9999';
            $areacode      = null;
        }
        $lswjcount = \Rpc::getData("Article.queryArticleCount", intval($areacodeBegin), intval($areacodeEnd), intval($areacode));
        return $lswjcount;
    }
    
    /**
      * �б�ҳ��ѯ����  ͳ�������µ���ѯ����
      * ���ݵ���ͳ�Ʒ�ҳ����ѯ����
      *
      * @param type $areacode ��������
      * @param type $sid      sid
      * @param type $month    0Ϊͳ����������µ���ѯ
      *
      * @return type
      */
    public static function arealist_askcount($areacode, $sid = null, $month = 0)
    {
        if ($month != 0) {
            $thismonth = $month;
        } else {
            $thismonth = date('Ym', time());
            $premonth  = date('Ym', strtotime('-1 month'));
        }
        $askcount = self::queryAskQuestionMapListCount($areacode, $sid, $thismonth, 'all');
        
        if (isset($premonth)) {
            $askcount += self::queryAskQuestionMapListCount($areacode, $sid, $premonth, 'all');
        }
        return $askcount;
    }
    
    /**
     * ͳ�ƹ�����ѯ�б����ݼ�¼��
     * 
     * @param int    $areacode ��������ʡ2λ  �� 4λ ������ 6λ  ��0��ʾ�����������ң� 
     * @param int    $prof     ר������ר������ (0��ʾ����ר������)
     * @param int    $month    �·� ��ʽ 201210 Ĭ�ϵ�ǰ��
     * @param String $typeFlag ���ݼ�����  all:ȫ��; wait:�����; resolved:�ѽ��;zero:0�ظ�;high:�߷���ѯ ����Ϊ��
     * 
     * @return array
     */
    public static function queryAskQuestionMapListCount($areacode, $prof, $month, $typeFlag)
    {
        if (!$areacode) {
            $areacode = 0;
        }
        if (!$prof) {
            $prof = 0;
        }
        return \Rpc::getData(
            'Ask.queryAskQuestionMapListCount', 
            $areacode,
            $prof,
            $month,
            $typeFlag
        );
    }
    
    /**
     * ����ID����
     *
     * @param int $areacode ����id
     *
     * @return array
     */
    public static function areacodeBeginEndParam($areacode)
    {
        $p = array();
        if (strlen($areacode) == 6) {
            $p['areacode'] = $areacode;
        } else if (strlen($areacode) == 4) {
            $p['areacodeBegin'] = $areacode . '00';
            $p['areacodeEnd']   = $areacode . '99';
        } else if (strlen($areacode) == 2) {
            $p['areacodeBegin'] = $areacode . '0000';
            $p['areacodeEnd']   = $areacode . '9999';
        }
        return $p;
    }

    /**
      * ������Ϣ����
      *
      * @return array
      */
    public static function get_diqufagui()
    {
        $list = array(
            '����' => array('74', 'anhui'), '����' => array('76', 'aomen'), 
            '����' => array('47', 'beijing'),
            '����' => array('70', 'fujian'), '����' => array('59', 'gansu'), 
            '�㶫' => array('48', 'guangdong'),
            '����' => array('57', 'guangxi'), '����' => array('65', 'guizhou'), 
            '����' => array('73', 'hainan'),
            '�ӱ�' => array('55', 'hebei'), '����' => array('56', 'henan'), 
            '������' => array('72', 'heilongjiang'),
            '����' => array('50', 'hubei'), '����' => array('63', 'hunan'), 
            '����' => array('52', 'jilin'),
            '����' => array('68', 'jiangsu'), '����' => array('58', 'jiangxi'), 
            '����' => array('49', 'liaoning'),
            '���ɹ�' => array('60', 'neimenggu'), '����' => array('67', 'ningxia'), 
            '�ຣ' => array('66', 'qinghai'),
            'ɽ��' => array('61', 'shandong'), 'ɽ��' => array('53', 'shanxi'), 
            '����' => array('64', 'shanxi2'),
            '�Ϻ�' => array('45', 'shanghai'), '�Ĵ�' => array('71', 'sichuan'), 
            '̨��' => array('78', 'taiwan'),
            '���' => array('46', 'tianjin'), '����' => array('54', 'xizang'), 
            '���' => array('77', 'xianggang'),
            '�½�' => array('75', 'xinjiang'), '����' => array('51', 'yunnan'), 
            '�㽭' => array('69', 'zhejiang'),
            '����' => array('62', 'chongqing')
        );
        return $list;
    }
        
    /**
      * ������վͷ������--��������{$area_name}��ʦ
      *
      * @param type $pinyin pinyin
      *
      * @return array
      */
    public static function areaNavList($pinyin)
    {   
        $areaInfo = \Rpc::getData('Area.queryAreaInfo', $pinyin);
        if (empty($areaInfo)) {
            return array();
        }
        $area_name = $areaInfo['area_name'];
        $area_countrys = isset($areaInfo['area_countrys']) ? $areaInfo['area_countrys'] : array();
        $thisarea = $areaInfo['thisarea'];

        $relist = array();
        if (in_array($pinyin, array('aomen', 'taiwan','xianggang'))) {
            $relist[] = array(
                'name'=>$area_name,
                'pinyin'=>$pinyin,
                'url'=>'http://china.findlaw.cn/'.$pinyin
            );            
        } else {
            if (!empty($area_countrys)) {
                if ($areaInfo['grade'] == 1 ) {
                    if (!empty($thisarea)) {
                        $v = $thisarea[0];
                        $relist[] = array(
                                'name' => str_replace('��', '', $v['name']),
                                'pinyin' => $v['pinyin'],
                                'url' => 'http://china.findlaw.cn/'.$v['pinyin']
                           );
                    }
                }
                foreach ($area_countrys as $v) {
                    if ($v['pinyin']=='zixing') {
                        $relist[] = array(
                            'name' =>'����',
                            'pinyin' => $v['pinyin'],
                            'url' => 'http://china.findlaw.cn/'.$v['pinyin']
                        );
                        continue;
                    } else if ($v['pinyin']=='jinshi') {
                        $relist[] = array(
                            'name' =>'����',
                            'pinyin' => $v['pinyin'],
                            'url' => 'http://china.findlaw.cn/'.$v['pinyin']
                        );
                        continue;
                    } else if ($v['country']) {
                        $relist[] = array(
                            'name' => str_replace('��', '', $v['country']),
                            'pinyin' => $v['pinyin'],
                            'url' => 'http://china.findlaw.cn/'.$v['pinyin']
                        );
                    }
                }
            } else {
                foreach ($thisarea as $v) {
                    if ($v['pinyin'] == 'jl') {
                        continue;
                    }
                    $relist[] = array(
                        'name' => str_replace('��', '', $v['name']),
                        'pinyin' => $v['pinyin'],
                        'url' => 'http://china.findlaw.cn/'.$v['pinyin']
                    );
                }
            }
        }
        return $relist;
    }
    
    /**
      * ��ȡר��������
      *
      * @param type $pinyin ר��ƴ��
      *
      * @return ר��������
      */
    public static function getShortProfNameByPinyin($pinyin)
    {
        $pinyin = trim($pinyin);
        $list = \Tools\Prof::getlawyerproflist();
        foreach ($list as $v) {
            if ($v['pinyin'] == $pinyin) {
                return $v['name'];
            }
        }
        return '';
    }


    
    /**
      * ��ȡ������Ϣ
      *
      * @param type $areaName ������
      * @param type $profName ר����
      *
      * @return array
      */
    public static function getNavInfo($areaName, $profName='')
    {
        $area_name = $areaName;
        $area_name_len = strlen($area_name) / 2;
        // ��ȡ��������
        $navinfo = \Rpc::getData(
            "Zhishi.queryNavInfo", null, $area_name.$profName.'��ʦ', null, array('fs'=>14, 'ow'=>32, 'w'=>709, 'mw'=>78)
        );
        
        //�����滻null
        foreach ($list['dataTagsMore'] as $k => $v) {
            $navinfo['dataTagsMore'][$k]['name'] = str_replace('null', '', $v['name']);
        }
        foreach ($list['dataTags'] as $k => $v) {
            $navinfo['dataTags'][$k]['name'] = str_replace('null', '', $v['name']);
        }
        $navlist = array_merge($navinfo['dataTags'], $navinfo['dataTagsMore']);
        if (count($navlist) > 6) {
            $nav_main = array_slice($navlist, 0, -6);
            $nav_more = array_slice($navlist, -6, 6);
        } else {
            $nav_main = $navlist;
            $nav_more = array();
        }
        
        if ($area_name_len == 2) {
            $sublen = 5;
        } elseif ($area_name_len == 3 ) {
            $sublen = 5;
            $nav_main = array_splice($nav_main, 0, $sublen);
            if (count($nav_main) == 5 ) {
                $nav_main[4]['name'] = str_replace($area_name, '', $nav_main[4]['name']);
            }
        } elseif ($area_name_len == 4 ) {
            $sublen = 5;
            $nav_main = array_splice($nav_main, 0, $sublen);
            if (count($nav_main) == 5 ) {
                $nav_main[4]['name'] = str_replace($area_name, '', $nav_main[4]['name']);
                $nav_main[3]['name'] = str_replace($area_name, '', $nav_main[3]['name']);
            } elseif (count($nav_main) == 4 ) {
                $nav_main[3]['name'] = str_replace($area_name, '', $nav_main[3]['name']);
            }
        } elseif ($area_name_len == 5 || $area_name_len == 6 ) {
            $sublen = 4;
            $nav_main = array_splice($nav_main, 0, $sublen);
            if (count($nav_main) ==4 ) {
                $nav_main[3]['name'] = str_replace($area_name, '', $nav_main[3]['name']);
            }
        } elseif ($area_name_len > 6 ) {
            foreach ($nav_main as $k => $v ) {
                $nav_main[$k]['name'] = str_replace($area_name, '', $nav_main[$k]['name']);
            }
        }
        if ($profName != '') {
            $apleng = strlen($area_name.$profName) / 2;
            if ($apleng > 8) {
                foreach ($nav_main as $k => $v ) {
                    $nav_main[$k]['name'] = str_replace($area_name, '����', $nav_main[$k]['name']);
                }
            }
        }
        return array(
            'nav_main' => $nav_main,
            'nav_more' => $nav_more
        ); 
    }
}