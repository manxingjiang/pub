<?php
/**
 * �û���ϵ - �������ģ��
 *
 * @author lihuanlin <birdy@findlaw.cn>
 */
namespace Models;

/**
 * �û���ϵ - �������ģ��
 *
 * @author lihuanlin <birdy@findlaw.cn>
 */
class UcAuditModel
{
    //֧�ֵ�ģ��
    public static $models = array("001", "002", "003", "004", "005", "006");
    
    /**
     * ������¼
     * 
     * @param int    $uid      UID
     * @param string $areacode ����
     * @param string $type     ����
     * @param array  $data     ����
     * 
     * @return void
     */
    public static function insert($uid, $areacode="", $type="001", $data=array())
    {
        if ($data) {
            $content = $data;
        } else {
            $content = null;
        }
        $insert = array();
        $insert['inputtime'] = time();
        $insert['ifaudit']   = 0;
        $insert['audittime'] = 0;
        $insert['uid']       = $uid;
        $insert['areacode'] = $areacode;
        $insert['content']  = serialize($content);
        \Rpc::getUCData("Audit.admin.insertAuAuditinfoSel", $insert, $type);
    }
    
    /**
     * ���¼�¼
     * 
     * @param int    $id   ��¼ID
     * @param string $type ����
     * @param array  $data ����
     * 
     * @return void
     */
    public static function update($id, $type="001", $data=array())
    {
        if ($data) {
            $content = $data;
        } else {
            $content = null;
        }
        
        $update = array();
        $update['id'] = $id;
        $update['inputtime'] = time();
        $update['content'] = serialize($content);
        \Rpc::getUCData("Audit.admin.updateAuAuditinfoByPKSel", $update, $type);
    }

    /**
     * ��ȡ����
     * 
     * @param int    $uid     UID
     * @param string $type    ����
     * @param int    $ifaudit ���״̬
     * 
     * @return void
     */
    public static function getByType($uid, $type="001", $ifaudit=0)
    {
        if ($uid > 0 && in_array($type, self::$models)) {
            $type = $type;
            $map = array();
            $map['num']     = $type;
            $map['uids']    = array($uid);
            $map['ifaudit'] = intval($ifaudit);
            $map['orderBy'] = "id desc";
            $rs = \Rpc::getUCData("Audit.queryAuditinfoList", 1, 1, $map);
            if ($rs) {
                return $rs[0];
            }
        }
        return null;
    }
}
