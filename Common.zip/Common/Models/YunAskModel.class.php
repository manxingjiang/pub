<?php
/**
 *  yun_ask����ģ��
 *  
 *  @author wrd <xx@qq.com>
 */
namespace Models;
use Models;

/**
 *  yun_ask����ģ��
 *  
 *  @author wrd <xx@qq.com>
 */
class YunAskModel extends \Think\Model
{
    protected  $connection;
    
    /**
     *	init
     *  
     *  @return null
     */
    public function __construct($tbleName='')
    {
            $hb_config_db_33666 = C('hb_config_33666');
            $hb_config_db = array(
                'db_type' => $hb_config_db_33666['dbms'],                 //���ݿ�����  mysql,
                'db_user'  => $hb_config_db_33666['username'],             //�û���,
                'db_pwd'   => $hb_config_db_33666['password'],             //����,
                'db_host'  => $hb_config_db_33666['hostname'],                 //host,
                'db_port'  => $hb_config_db_33666['hostport'],
                'db_name'  => $hb_config_db_33666['database'],
                'db_charset' =>    'gbk',
            );
            $this->connection = array_merge($hb_config_db, $this->config());
            if (!empty($tbleName)) {
                $this->tableName = $tbleName;
            }
            parent::__construct();  
    }
    
    /**
     *	config
     *  
     *  @return null
     */
    public function config()
    {
        return array(
        ) ;
    }
}
