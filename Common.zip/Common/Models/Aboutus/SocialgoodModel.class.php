<?php
/**
 * ��ṫ��
 *  
 * @author huanggongqiang <huanggongqiang@findlaw.cn>
 *
 * @data 2016-08-11
 */
namespace Models\Aboutus;
/**
 * ��ṫ��
 *
 * @author huanggongqiang <huanggongqiang@findlaw.cn>
 * 
 */
class SocialgoodModel
{
    /**
     * ��ȡ��ҳ�б�
     * 
     * @param intval $currentPage ��ǰҳ
     * @param intval $pageSize    ÿҳ��ʾ��¼��
     * @param array  $where       ��ѯ����
     * @param string $fields      ��ѯ�ֶ�
     * @param string $orders      �ֶ�����
     * 
     * @return array/false
     */
    public function selectPage($currentPage = 1, $pageSize = 10, $where = array(), $fields = '*', $orders = '`eventtime` DESC,`id` DESC')
    {
        $rowFirst = $pageSize*($currentPage-1);
        $db = new \Models\FindlawModel();
        $db->table('aboutus_socialgood');
        return $db->field($fields)->where($where)->order($orders)->limit($rowFirst, $pageSize)->select();
    }
    
    /**
     * ��ȡ����
     * 
     * @param array $where ����
     * 
     * @return int ����
     */
    public function count($where = array())
    {
        $db = new \Models\FindlawModel();
        $db->table('aboutus_socialgood');
        return $db->where($where)->count();
    }
    
    /**
     * ����ID����ȡ����
     * 
     * @param int $id ����
     * 
     * @return int ����
     */
    public function findById($id)
    {
        $db = new \Models\FindlawModel();
        $db->table('aboutus_socialgood');
        return $db->find($id);
    }
}













