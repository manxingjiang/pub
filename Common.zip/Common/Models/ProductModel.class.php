<?php
/**
 *  fl_ask����ģ��
 *  
 *  @author zsg <xx@qq.com>
 */
namespace Models;
use Models;

/**
 *  fl_ask����ģ��
 *  
 *  @author zsg <xx@qq.com>
 */
class ProductModel extends \Think\Model
{
    protected  $connection;
    
    /**
     *	init
     *  
     *  @return null
     */
    public function __construct()
    {
            require "include/config_findlaw_db.php";
            $product_config_db33605 = array(
                'db_type' => $product_config_db33605['dbms'],                 //���ݿ�����  mysql,
                'db_user'  => $product_config_db33605['username'],             //�û���,
                'db_pwd'   => $product_config_db33605['password'],             //����,
                'db_host'  => $product_config_db33605['hostname'],                 //host,
                'db_port'  => $product_config_db33605['hostport'],
                'db_name'  => $product_config_db33605['database'],
                'db_charset' =>    'gbk',
            );
            $this->connection = array_merge($product_config_db33605, $this->config());
            parent::__construct();  
    }
    
    /**
     *	config
     *  
     *  @return null
     */
    public function config()
    {
        return array(
           'db_name'=>'wy_product'
        ) ;
    }
}
