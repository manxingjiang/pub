### 新目录结构说明

├── Common                                       
│   ├── Conf                                     #公共配置目录
│   │   ├── config.php
│   ├── FrameWork                                #框架目录
│   │   └── ThinkPHP3.2.2
│   ├── Parents                                  #公共父类目录
│   │   ├── CommonController.class.php
│   │   ├── FrontCommonController.class.php
│   │   ├── BackCommonController.class.php
│   │   └── ShareCommon.class.php
│   ├── JavaRpc                                  #Rpc核心目录
│   ├── Models                                   #数据模型目录
│   ├── Share                                    #共享代码目录
│   │   ├── Areastation_front                    #软指向china.findlaw.cn/areastation_front/trunk/Share/Areastation_front
│   │   │   └── Browse.class.php
│   │   ├── Ask                                  #软指向china.findlaw.cn/ask_front/trunk/Share/Ask_front
│   │   │   └── Browse.class.php
│   │   └── externals.txt                        #软链接配置文件
│   ├── Tools                                    #公共类库目录
│   └── readme.txt
└── china.findlaw.cn                            #项目目录
    ├── weixin_front                                #这是一个项目目录
    │   ├── branches                                #项目的分支目录，里面可建多个子目录， 每个子目录一个分支
    │   ├── index.php                               #项目入口文件,分支开发时,可更改该文件的APP_PATH到指定目录
    │   └── trunk                                   #项目的主线目录
    │       ├── Api
    │       │   ├── Conf
    │       │   │   └── config.php                  #项目独立配置目录
    │       │   ├── Controller                      #控制器目录
    │       │   │   ├── DemoController.class.php
    │       │   │   └── FindlawController.class.php
    │       │   ├── Model     
    │       │   ├── View                            #模板目录
    │       └── Share                               #项目的共享代码目录
    │           └── Weixin_front
    │               └── FlweixinShare.class.php
    └── touch_front                                   #这是另一个项目目录
        ├── branches
        ├── index.php
        └── trunk
            ├── Home
            │   ├── Conf
            │   │   ├── config.php
            │   ├── Controller
            │   │   ├── IndexController.class.php
            │   ├── Model
            │   ├── View
            └── Share
                └── Ask_front
                    └── AskShare.class.php

### 如何调用当前项目的共享代码
    eg:  在touch_front项目里面调用touch_front项目的 trunk/Share/Touch_front/AskShare.class.php 里的 pubask 方法
    $re = $this->share('Ask')->pubask($mobile, $qcontent, $uid, $userid,$username);

### 如何调用其它项目的共享代码
    eg:  在weixin_front项目里面调用touch_front项目的 trunk/Share/Touch_front/AskShare.class.php 里的 pubask 方法
    $re = $this->share('Touch_front.Ask')->pubask($mobile, $qcontent, $uid, $userid,$username);
    执行这行代码，实际调用的是  findlaw.cn/Common/Share/Touch_front/AskShare.class.php

### 如何调用java中间件
    使用默认配置
    $asklist = \Rpc::getData('Ask.queryAskQuestionMapList', 1, 5, 0, 0, '201405', 'all');
    print_r($asklist);
    使用UC配置
    $asklist = \Rpc::getUCData('...', 1, 5, 0, 0, '201405', 'all');
    print_r($asklist); 

### 检出单个项目
    1. 在findlaw.cn目录下检出Common目录
    3. 在findlaw.cn/china.findlaw.cn目录下检出项目目录
    4. 在findlaw.cn/new.findlaw.cn/images.findlaw.cn目录下检出js,css,img目录

### 检出全部项目
    1. 直接检出findlaw.cn目录

### 如何新建一个项目
    1. cd findlaw.cn/china.findlaw.cn           进入项目根目录
    2. php createproject.php index_front        执行createproject.php, 后面的参数index_front为项目名

### 217分支开发测试流程
    1. svn copy 项目trunk目录到branches/xxx子目录
    2. 修改项目入口文件的APP_PATH常量， 当ip为217时，指向branches/xxx目录 
    3. branches/xxx分支目录217测试完成后合并到项目trunk目录
    4. 发布项目目录到外网测试服务器测试
    5. 同步外网正式服务器

### 修改A项目的Share目录文件时， 如果通知调用了该项目Share文件的其它项目作相应修改
    方法待定

### 设置软链接操作步骤
    1. cd Common/Share      
    2. svn ps svn:externals . -F externals.txt
    5. svn up                       更新下
    6. svn ci -m '提交软链接' .
    
### 一些规范和约定
    1. 前台项目名称加后缀  _front
    2. 后台项目名称加后辍  _back
    3. 项目名称全部字母统一小写  eg.   ask_front
    4. 项目Share目录下只能有一个文件夹，该文件夹名称必须跟项目名称统一, 并且首字母大写
       eg.   china.findlaw.cn/ask_front/trunk/Share/Ask_front
    5. 所有前台项目的控制器必须继承 \Parents\FrontCommonController 
    6. 所有后台项目的控制器必须继承 \Parents\BackCommonController 
    7. 所有的共享代码模块必须继承   \Parents\ShareCommon
    8. Common/Tools/ 下面的工具类命名规范
        ---首字母大写
        ---类名跟文件名对应， 以.class.php为后辍
        ---命名空间使用Tools
        
    
