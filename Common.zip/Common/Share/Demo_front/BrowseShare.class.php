<?php
/**
 *  demo��Ŀ����ģ��
 *
 *  @author xx <xx@qq.com>
 */
namespace Share\Demo_front;
use Share\Demo_front;
/**
 *  demo��Ŀ����ģ��
 *
 *  @author xx <xx@qq.com>
 */
class BrowseShare extends \Parents\ShareCommon
{
    /**
     * �������Է���
     *
     * @param int   $page     page
     * @param int   $pagesize pagesize
     * @param array $other    other
     *
     * @return array
     */
    public function asklist($page, $pagesize, $other)
    {
        return array('in Demo', $page, $pagesize, $other);
    }
}
