<?php
/**
 *  ��������ؼ���
 *
 *  @author whj <2851026524@qq.com>
 */
namespace Share\Touch_front;
use Share\Touch_front;

/**
 * ��������ؼ���
 *
 * @author whj <2851026524@qq.com>
 */
class KeyworkShare extends \Parents\ShareCommon
{

    /**
     * �������Է���
     *
     * @param int $page
     *            page
     * @param int $pagesize
     *            pagesize
     * @param array $other
     *            other
     *            
     * @return array
     */
    
    /**
     * ���ò���
     */
    private $page = 1;

    private $header = array(
            
            // ��ʹ�û���
            'H-N' => 'NO'
    );

    private $arr = array();
    // 'orderBy'=>'pubdate DESC'
    

    /**
     * ȡ������ؼ���
     *
     * @return NULL
     */
    public function isfromsearch ()
    {

        $referer_keyword = isset($_COOKIE['referer_keyword']) ? urldecode($_COOKIE['referer_keyword']) : '';
        $usertype = isset($_COOKIE['usertype']) ? urldecode($_COOKIE['usertype']) : '';
        
        //$re = \Tools\Email::send('weihongjiang@findlaw.cn', '��ַ', $_SERVER['HTTP_REFERER']);
        //var_dump($re);
        if ($_SERVER['HTTP_REFERER'] != '') {

            //var_dump($_SERVER['HTTP_REFERER']);die;
            //echo $_SERVER['HTTP_REFERER'];
            if (preg_match('/http\:\/\/m\.baidu\.com/i', $_SERVER['HTTP_REFERER']) &&preg_match("/wo*r*d=([^&]*|$)/i", urldecode($_SERVER['HTTP_REFERER']))) {
                return $server_referer = 1;
                 /*} elseif (preg_match('/https?\:\/\/www\.google\.com/',$_SERVER['HTTP_REFERER'])&&preg_match("/q=([^&]*|$)/i",urldecode($_SERVER['HTTP_REFERER']))){$server_referer=1;*/
            } elseif (preg_match('/https\:\/\/www\.baidu\.com/s', $_SERVER['HTTP_REFERER'])&&preg_match("/wo*r*d=([^&]*|$)/i", urldecode($_SERVER['HTTP_REFERER']))) {
                return $server_referer = 1;
            } elseif (preg_match('/http\:\/\/www\.baidu\.com/i', $_SERVER['HTTP_REFERER']) &&preg_match("/wo*r*d=([^&]*|$)/i", urldecode($_SERVER['HTTP_REFERER']))) {
                
                return $server_referer = 1;
            } elseif (
                    preg_match('/http\:\/\/3g\.sogou\.com/', $_SERVER['HTTP_REFERER']) &&preg_match("/query=([^&]*|$)/i",  urldecode($_SERVER['HTTP_REFERER']))) {
                
                return $server_referer = 1;
            } elseif ((
                    preg_match('/http\:\/\/m\.so\.com/', $_SERVER['HTTP_REFERER']) || preg_match('/http\:\/\/www\.so\.com/', $_SERVER['HTTP_REFERER'])) &&
                    preg_match("/q=([^&]*|$)/i", urldecode($_SERVER['HTTP_REFERER']))) {
                return $server_referer = 1;
            } elseif ($referer_keyword != '' && $usertype != 1) {
                return $match[1] = $referer_keyword;
                return $server_referer = 1;
            } else {
                return $server_referer = 0;
            }
        } else {
            return $server_referer = 0;
        }
    }

    /**
     * ȡ������ؼ���
     *
     * @return string
     */
    public function getkeywork ()
    {
        if ($match[1] == '') {
            $tmpurl = $_SERVER['HTTP_REFERER'];
            if (preg_match('/http\\:\\/\\/m\\.baidu\\.com/i', $tmpurl) || preg_match('/http\\:\\/\\/www\\.baidu\\.com/i', $tmpurl)) {
                $m_re = preg_match("/wo*r*d=([^&]*|$)/i", urldecode($tmpurl), $match);
            } elseif (preg_match('/https?\\:\\/\\/www\\.google\\.com/', $tmpurl)) {
                $m_re = preg_match("/q=([^&]*|$)/i", urldecode($tmpurl), $match);
            } elseif (preg_match('/http\\:\\/\\/3g\\.sogou\\.com/', $tmpurl)) {
                $m_re = preg_match("/query=([^&]*|$)/", urldecode($tmpurl), $match);
            } elseif (preg_match('/http\\:\\/\\/so\\.360\\.cn/', $tmpurl) ||
                     preg_match('/http\\:\\/\\/m\\.so\\.com/', $tmpurl)) {
                $m_re = preg_match("/q=([^&]*|$)/i", urldecode($tmpurl), $match);
            }
            $match[1] = mb_convert_encoding($match[1], "GBK", "auto"); // MiscFunc::utf8Gbk(urldecode($match[1]));
                                                                           // // //
                                                                           // //
                                                                           // iconv('UTF-8','GBK',$match[1]);
            $match[1] = trim(preg_replace('/site:.*/', '', $match[1]));
            if ($match[1]) {
                $pattern = '/[^\x00-\x80]/';
                if (preg_match($pattern, $match[1])) {
                    return $match[1];
                } else {
                    return null;
                }
            }
        }
    }
}