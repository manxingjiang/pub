<?php
/**
 * ������Ŀ����ģ��
 *
 * @author wrd <xx@qq.com>
 */
namespace Share\Touch_front;
use Share\Touch_front;
/**
 *  ������Ŀ����ģ��
 *
 *  @author wrd <xx@qq.com>
 */
class AskShare extends \Parents\ShareCommon
{
    /**
     * ����uid��ȡ���ֻ���
     *
     * @param unknown $uid uid
     *
     * @return unknown|boolean
     */
    public function queryBindMobil($uid)
    {
        $tmp = \Rpc::getData('Member.getUserMobileEmailByUid', $uid);
        if ($tmp && isset($tmp['mobil'])) {
            return $tmp['mobil'];
        }
        return false;
    }
    
    /**
     * desc��ѯIP������������array
     *
     * @param type $ip     ipip��ַ
     * @param type $update update
     *
     * @return type
     * @author author
     */
    public function checkIP($ip, $update = 'update')
    {
        $ip3arr          = explode('.', $ip);
        $ip3             = $ip3arr[0] . '.' . $ip3arr[1] . '.' . $ip3arr[2] . '.0';
        $ip3num          = ip2long($ip3);
        $ipnum           = ip2long($ip);
        
        $re1 = \Rpc::getData('FilterIp.Admin.queryFilterIpList', 1, 1, array('ip'=>$ipnum));
        if (!empty($re1)) {
            return $re1;
        }
        $re2 = \Rpc::getData('FilterIp.Admin.queryFilterIpList', 1, 1, array('ip3'=>$ip3num));
        if (!empty($re2)) {
            return $re2;
        }
        return array();
    }
    
    
    /**
     * �����ֻ���ǰ7λ��ȡ���ڵ���Ϣ
     *
     * @param int $tel �û��ֻ��ţ�ǰ7λ��ע���ų�ǰ��� '+86'��'0'��
     *
     * @return Array
     */ 
    public function getWyTelAreaByTel($tel)
    {
        if (strlen($tel) != 7) {
            return array(
                'id' => 110102,
                'province' => '����',
                'city' => '����',
                'country' => '������',
                'pinyin' => 'haidian',
                'grade' => 2,
            );
        }
        return \Rpc::getShortlinkData("Mobile.getWyTelAreaByTel", $tel);
    }
    
    /**
     * ��ѯ����
     * 
     * @param string $qcontent ��ѯ����
     * @param array  $uinfo    �û���Ϣ
     * @param array  $currarea ������Ϣ //areacode,province,city
     * @param string $mobile   �ֻ���
     * 
     * @return array
     */
    public function pubask($qcontent, $uinfo, $currarea, $mobile = '')
    {
        
        //����
        $qtitle = \Org\Util\Strings::msubstr($qcontent, 0, 50, 'GBK', false);  //cut_str($qcontent,  50, 'GBK', '');
        if ($qtitle == '') {
            return array(false, array('msg'=>'����д����<a href="javascript:history.go(-1);">����</a>'));
        }
        if ($_COOKIE['asksubmit_title']) { //�ظ�������
            $checktitle = explode('|', $_COOKIE['asksubmit_title']);
            if ($checktitle[0]==$qtitle) {
                return array(false, array('qid'=>$checktitle[1], 'msg'=>'��ѯ�Ѿ����ڣ������ĵȴ���ʦ�ظ�'));
            }
        }
        // ����ԤԼ��ϢCOOKIE
        cookie('qcontent', $qcontent, 3600 * 3);
        //��ȡ���д�
        $illegalkeywords = \Tools\Split::existsMgWord($qtitle.$qcontent);
        if ($illegalkeywords == false) {
            $illegalkeywords = '';
        }
        //ƥ��ר��
        $matchre = \Tools\Ask::matchAskSort($qtitle);

        $sid1 = $matchre['sid1'];
        $sid2 = $matchre['sid2'];
        if ($sid1==0 && $sid2==0) {
            $sid1 = 8;
            $sid2 = 63;
        }
        $mobile = empty($mobile) ? (empty($uinfo['mobile']) ? '' : $uinfo['mobile']) : $mobile;
        $stayphone = empty($mobile) ? 0 : 1;        
        //������ѯ�����Ϣ
        $insertData = array(
                'regflag'         => 0,
                'uid'             => $uinfo['uid'],
                'userid'          => $uinfo['userid'],
                'username'        => $uinfo['username'] ? $uinfo['username'] : '�� ��',
                'uprovince'       => $currarea['province'],//�û�����ʡ
                'ucity'           => $currarea['city'],//�û������� 
                'title'           => $qtitle,
                'supplement'      => $qcontent,
                'sid1'            => $sid1,
                'sid2'            => $sid2,
                'sid3'            => 0,
                'score'           => 0,
                'areacode'        => $currarea['areacode'],         //����areacode
                'city'            => $currarea['areacode'],         //�е�areacode
                'province'        => $currarea['areacode'],         //ʡ��areacdoe
                'ip'              => ip2long(\Tools\Iparea::getClientIp()), //�û�ip
                'keywords'        => '',                                //���գ���������
                'illegalkeywords' => $illegalkeywords,
                'iswrite'         => 2,                                 // ��̨¼���־ 0 �ⲿpc��վ 1 �ڲ�  2wap �ֻ�¼�� 3�ֻ�����Ϣ¼�� 4 �ֻ�appӦ��',
                'stayphone'       => $stayphone,                        //�Ƿ����绰
                'email'           => '',
                'mobile'          => $mobile,
                'callname'        => '',                                //��ν
                'qq'              => '',
                'frompage'        => 'mobile_touch',
        );
        //235 ���� 126����ѯ
        $res = \Tools\Ask::questionTypeId($qcontent);
        if (!$res) {
            $insertData['disputeid'] = 0; //$res['sort']['id'];
            $typeid = 0;
        } else {
            $typeid = intval($res['level']);
            $insertData['disputeid'] = $res['disputeid'] > 0 ? $res['disputeid'] : 0;
        }
        $insertData['typeid'] = $typeid;
        if (!$stayphone && in_array($typeid, array(3, 4, 5))) {
            $reptypeid = 1;
            $insertData['typeid'] = $reptypeid;
            $typeid = $reptypeid;
        }
        //�ж��Ƿ����Զ����ʱ���  ifaudittime =1010 Ϊ�Զ���˱�־  //����15�������� �������ַ����֡�������� �� �ؼ��ʿ���� �� by liujian
        $shenhetimes = \Rpc::getData('FlShenhe.queryFlShenheByForm', array('status'=>1));
        foreach ($shenhetimes as $v) {
            $tmp = preg_split('/,/', $v['timeJson']);
            $len = strlen($insertData['supplement']);
            $biaodian = '[#|@|#|$|\^|&|\*|\(|\)|-|_|=|\+|\[|\]|{|}|<|>|\/]+';
            $allcheck = '/[A-Za-z0-9]+|'.$biaodian.'/i';
            preg_match($allcheck, $insertData['supplement'].$insertData['title'], $matches);
            if (strtotime(date('H:i')) > strtotime($tmp[0]) && strtotime(date('H:i')) < strtotime($tmp[1]) && $illegalkeywords == '' && $len >= 34 && count($matches) <= 0) {
                $insertData['ifaudit'] = 1;
                $insertData['ifaudittime'] = 1010;
            }
        }
        //�������
        //���Ϊ3,4,5����40%���ʷ���������ʦ �������ֻ���
        //$rand < 2 40%���� (2015��1��12��ֹͣ������$rand<0)
        $rand = rand(0, 4);
        if ($rand < 2) {
            $ishlscity=$this->share('Lawyer')->ishlscity($insertData['areacode']);//����ʦ����
        } else {
            $ishlscity = false;
        }
        //$stayphone &&��in_array($typeid, array(3, 4, 5)) && $ishlscity
        if ($stayphone && in_array($typeid, array(3, 4, 5)) && $ishlscity) {
            $insertInfo = $this->questolscn($insertData);
        } else {
            //$this->pdebug($insertData);
            $insertInfo = \Rpc::getData('Ask.Admin.insertAskQuesB', $insertData);
        }        
        if ($insertInfo['state'] == '01') {
            unset($_SESSION['__hash__']);        
            $qid = $insertInfo['qid'];
            if ($insertInfo['qid'] > 0 && in_array($typeid, array(3, 4, 5))) {
                $ques345 = true;
            }
        }

        // ������Դ��¼ û��ֵ�򲻴洢
        $source = \Tools\Request::getstrparam('source', 'POST');
        if ($source) {
            $source_arr = explode('_', $source);
            if (count($source_arr) >= 2 && preg_match('/^[a-z]$/i', $source_arr[0])) { // �򵥹����ж�
                $insertSource = array(
                        'qid' => $insertInfo['qid'],
                        'col' => $source_arr[0],
                        'subCol' => intval($source_arr[2]) ? intval($source_arr[2]) : 0,
                        'position' => $source_arr[1],
                        'asktime' => time()
                );
                if ($insertSource['qid'] > 0) {
                    \Rpc::getData('Stat.Admin.insertSel', $insertSource);
                }
            }
        }
        
        // ����COOKIE��
        setcookie('havedsubmitask', time(), time() + 180, '/');
        // �洢��ѯ���������ظ��ж�
        setcookie('asksubmit_title', $qtitle . '|' . $insertInfo['qid'], time() + 3600, '/');
        $insertInfo['areacode'] = $currarea['areacode'];
        $insertInfo['stayphone'] = $stayphone;
        return array(
                true,
                $insertInfo
        );
        
    }
    
    /**
     * ������ѯ�����ɹ��󣬶����Ƽ���ʦ
     * 
     * @param array $uinfo ������Ϣ
     * 
     * @return array
     */
    public function recSmsLawyer($uinfo)
    {
        if (empty($uinfo['uid']) || empty($uinfo['userid']) || empty($uinfo['areacode']) || empty($uinfo['mobile'])) {
            return array('status' => 0, 'msg' => '��������ȷ��');
        }
        if (empty($uinfo['psw'])) {
            //��ѯ��������
            $uinfo['psw'] = \Rpc::getUCData('Member.admin.getUcTblleoPasswordBySel', $uinfo['uid']);
        }
        // ���Ͷ���
        $msgcon = sprintf("��ѯ�ɹ����û���%s����%s", $uinfo['userid'], $uinfo['psw']);
        $lawyerinfo = \Rpc::getData('Member.querySmsLaywerList', $uinfo['areacode']);
        $res = \Rpc::getUCData('Member.getUcLawyerByUcLawyerParasFormUserid', array('pid'=>1, 'parameters'=>array('ucLawyer'), 'columns'=>array('username,mobile'), 'ifaudit'=>1, 'userid'=>$lawyerinfo['userid']));
        $lawyer_username = $res['ucLawyer']['username'];
        $lawyer_mobile = $res['ucLawyer']['mobile'];
        if ($lawyer_username && $lawyer_mobile) {
            $msgcon .= "���Ƽ�{$lawyer_username}��ʦ";
            $msgcon .= "{$lawyer_mobile}";
        } else {
            $msgcon .= '��';
        }
        $msgcon = trim($msgcon);
        \Tools\Sms::sendSms($uinfo['mobile'], $msgcon);
        return array('status' => 1, 'msg' => '���ŷ��ͳɹ�');
    }

    /**
     * ȡ������ѯ������Ϣ
     * 
     * @param int    $areacode ��������
     * @param string $mobile   �ֻ���
     * 
     * @return array
     */
    public function getAskArea($areacode = 0, $mobile = '')
    {
        $areainfo = \Tools\Iparea::getAreainfoByareacode($areacode);
        if ($mobile) {
            $areainfo = \Tools\Iparea::getWyTelAreaByTel($mobile);
            if (!empty($areainfo)) {
                $areainfo = array(
                        'id' => $areainfo['id'],
                        'province' => $areainfo['province'],
                        'city' => $areainfo['city'],
                        'pinyin' => $areainfo['pinyin'],
                        'areacode' => $areainfo['id'],
                );
            }
        }
        if (!empty($areainfo)) {
            \Tools\Iparea::setArea($areainfo);
        } else {
            $areainfo = \Tools\Iparea::getIpReviseArea();
        }
        if (empty($areainfo['areacode']) && $areainfo['id'] > 0) {
            $areainfo['areacode'] = $areainfo['id'];
        } 
        return $areainfo;
    }
    /**
     * ģ����: ���⵼���������ʦ�����
     * 
     * @param array $insertData ��������
     *
     * @author whj <weihongjiang@findlaw.cn>
     * 
     * @return array
     */
    public function questolscn ($insertData)
    {
        if ($insertData) {
            if ($insertData['regflag'] == 1) {
                $tblleoForm = array(
                        'userid' => $insertData['userid'],
                        'username' => $insertData['username'],
                        'psw' => $insertData['psw'],
                        'sex' => 1,
                        'ifaudit' => 'N',
                        'inputdate' => time(),
                        'ip' => \Tools\Iparea::encode_ip(\Tools\Iparea::getClientIP()),
                        'areacode' => $insertData['areacode'],
                        'city' => $insertData['city'],
                        'province' => $insertData['province'],
                        'mobil' => $insertData['mobile'],
                );
                
                $insertInfo = \Rpc::getData('Member.Admin.addRegTblleo', $tblleoForm);
            
                if ($insertInfo['state'] === '01') {
                    $insertData['uid']=$insertInfo['uid'];
                    //���ֻ��ŵ�¼
                    \Rpc::getData('Member.Admin.updateUserAddMobil', $insertInfo['uid'], $insertInfo['userid'], 2, $insertData['mobile']);
            
                    //ע���û���������
                    $UcBaseData = array(
                            'userid' =>  $insertData['userid'], //�û��� Сд��ĸ�»�������
                            'password' => $insertData['psw'],//����
                            'mobile' => $insertData['mobile'],//�ֻ�
                            'regtime' => time(),//ע��ʱ��
                            'regip' => ip2long(\Tools\Iparea::getClientIP()), //ע��ip
                            'passIntensity' => \Tools\User::getPassIntensity($insertData['psw']), //����ǿ��
                            'membertype' => 2, //�û����� 1��ʦ 2���� 3����
                            'regfrom' => 4,//�û�ע����Դ:0-����,1-pc��,2-��׿app,3-ƻ��app,4-webapp ��ģ��ע��
                            'url' => 'http://m.findlaw.cn/c=ask', //ע����Դ
                    );
                    $UcBaseData['uid'] = $insertInfo['uid'];
                    //�����û�ע��
                    $res =  \Rpc::getUCData("Member.admin.insertUcTblleoSel", $UcBaseData);
                    if ($res['state'] == '01') {
                        //$ret = \Tools\User::dologin($mobil, $password, 31536000, 'http://m.findlaw.cn');
                        //�û�ϵͳ�����½״̬
                        $uclogin = new \Tools\UcLogin();
                        $uclogin->userIdentSave($insertInfo['uid'], $insertInfo['userid'], $insertInfo['pwd'], '', time()+3600*24*365, array(1, 2, 3));
                    }
                }
            }
            $special='';
            $special1 = (int) \Tools\Special::special_rel_fl($insertData['sid1']);
            $special2 = (int) \Tools\Special::special_rel_fl($insertData['sid2']);
            if ($special2 == 9900 && $special1) {
                $special = $special1;
            } else {
                $special = $special2;
            }
            $params = array(
                    'title' => $insertData['title'],
                    'content' => $insertData['supplement'],
                    'areacode' => (int)$insertData['areacode'],
                    'caseArea' => (int)$insertData['areacode'],
                    'clientIp' => (int)ip2long(\Tools\Iparea::getClientIp()),
                    'special' => $special,
                    'keywords' => $insertData['keywords'],
                    'illegalkeywords' => $insertData['illegalkeywords'],
                    'inputTime' => time(),
                    'uid' => (int)$insertData['uid'],
                    'mobile' =>$insertData['mobile'],
                    'amount' => 0,
                    'from' => 'm_fl_ask',
                    'frompage' => 'http://m.findlaw.cn/c=ask',
                    'ifaudit' => 0
            );
            //print_r($params);exit;
            $ls_insertInfo=\rpc::getHlsData('AskMain.Admin.insertAskMainDetails', $params);
            //print($ls_insertInfo);exit;
            if ($ls_insertInfo>0) {
                $insertInfo['state'] = '01';
                $insertInfo['tolscn']=1;
                $insertInfo['qid']=$ls_insertInfo;
            }
            return $insertInfo;
        }
    }
    /**
     * ������֤��
     *
     * @param unknown $mobile   mobil
     * @param unknown $businame ҵ������
     *
     * @return array
     */
    public function sendValidCode($mobile, $businame='maskmobilecode')
    {         
        if (isset($_SESSION['phonenum'])  && (time() - $_SESSION['lastsendTime']) < 60) {
            $senttimeout =60-(time() - $_SESSION['lastsendTime']);
            
            return array(1, $senttimeout);
        }
        if (!\Tools\Validate::isMobil($mobile)) {
            //return array(2, '�ֻ�������!');
            return array(2, $mobile);
        }
        
        //if (\Rpc::getData('PHPBB.getCdbMembersCountByMobil', $mobile, '')) {
        if ($businame != 'maskmobilecode') {
            if (\Rpc::getData('Member.getUserMobileEmailByMobile', $mobile) || \Rpc::getUCData("Member.getExistMobile", null, $mobile, '1')) {
                return array(3, "�ֻ���" . $mobile . "�ѱ�ע��");
            }
        }
    
        $code  = \Tools\Strings::randMobileValidCode();
        //���ò����ֻ���,�����Ͷ��ţ�Ĭ����֤��12345
        $mobiles = array(
             '18719378272','18177627403','15920918307','13144238529','15820255572'
             );
        if (in_array($mobile, $mobiles)) {
             $code = '12345';
             $ret = true;
        } else {
             $content ='������֤���ǣ�'.$code.'���벻Ҫ����֤��й¶�������ˡ���Ǳ��˲������ɲ������ᣡ';
             $ret = \Tools\Sms::sendSms($mobile, $content, 1, 'gbk', 1);
        }
        if ($ret) {
            $_SESSION['phonenum'] = $mobile;
            $_SESSION['lastsendTime'] = time();
            $_SESSION[$businame] = $code;
            return array(0, '���ͳɹ�');
        } else {
            return array(99, '����ʧ��');
        }
    }
    
    /**
     * �����֤���Ƿ���ȷ
     *
     * @param unknown $code     code
     * @param unknown $phonenum phonenum
     * @param unknown $businame businame
     *
     * @return null
     */
    public function checkValidCode($code, $phonenum, $businame)
    {
        if (!isset($_SESSION[$businame])) {
            return false;
        }
        if (!isset($_SESSION['phonenum'])) {
            return false;
        }
        return $_SESSION[$businame] == $code && $_SESSION['phonenum'] == $phonenum;
    }
    
    /**
     * ��ִҵ֤�л�ȡִҵ����
     * 
     * @param unknown $code      code
     * @param int     $workyears workyears
     *  
     * @return int
     */
    public function getLawyerFromCode($code, $workyears=0)
    {
        if (strlen($code) == 17) {
            $y = intval(date('Y')) - intval(substr($code, 5, 4)) + 1;
            return $y;
        } else {
            if ($workyears == 0) {
                return 1;
            }
            return intval(date('Y')) - intval($workyears) + 1;
        }
    }
    
    /**
     * ���ӹ�����ѯ׷��
     *
     * @param type $qid             qid
     * @param type $aid             aid
     * @param type $pid             pid
     * @param type $utypeid         utypeid
     * @param type $uid             uid
     * @param type $userid          userid
     * @param type $username        username
     * @param type $content         content
     * @param type $ip              ip
     * @param type $illegalkeywords illegalkeywords
     * @param type $answeruid       answeruid
     * @param type $answeruserid    answeruserid
     *
     * @return type
     * @author author
     */
    public function insertAskAddB($qid, $aid, $pid, $utypeid, $uid, $userid, $username, $content, $ip, $illegalkeywords = null, $answeruid = null, $answeruserid = null)
    {
        if ($ip) {
            $ip = ip2long($ip);
        }
        return \Rpc::getData(
            'Ask.Admin.insertAskAddB',
            $qid,
            $aid,
            $pid,
            $utypeid,
            $uid,
            $userid,
            $username,
            $content,
            $ip,
            $illegalkeywords,
            $answeruid,
            $answeruserid,
            2
        );
    }
     
    /**
     * ��ȡ���û��Ƽ���������ʦ   
     * 
     * @param unknown $qid qid
     * 
     * @return array
     */
    public function recommentLawyer($qid)
    {
        $recom_lawyer = \Rpc::getData("Ask.queryAskQuestionRecommendList", 1, 5, array('qid'=>$qid, 'isvip'=>1, 'sortEnd'=>100, 'orderBy'=>'sort asc'));
        $uids = array();
        foreach ($recom_lawyer as $v) {
            $uids[] = $v['uid'];
        }
        if (empty($uids)) {
            return array();
        }

        $tmp = \Rpc::getData('Ask.queryDayStatListB', 1, 5, array('uids'=>$uids));
        $tmp = \Tools\Ads::get_ad_file($tmp);
        foreach ($tmp as $k=>$v) {
            $tmp[$k]['profname'] = \Tools\Prof::cutLawyerProfession($v['profession'], 1, false);
            $tmp[$k]['zhiyeYear'] = $this->getLawyerFromCode($v['LawyerMessage']['lawercode']);
        }
        $lawyers = array();
        foreach ($tmp as $k => $v) {
            $lawyers[$v['uid']] = $v;
        }
        foreach ($recom_lawyer as $k => $v) {
            $recom_lawyer[$k] = $lawyers[$v['uid']];
        }
        
        
        return $recom_lawyer;
    }

    /**
     * ��ȡ���û��Ƽ�Ʒ����ʦ������ȡvip��ʦ   
     * 
     * @param int    $areacode ��������
     * @param int    $number   ȡ��ʦ��
     * @param string $prof     ר����
     * 
     * @return array
     */
    public function recommentLawyerByArea($areacode, $number = 3, $prof = '')
    {
        $recom_lawyer =  \Rpc::getData('Ask.queryAreaMemByRand', $areacode, 3, $prof);
        $uids = array();
        foreach ($recom_lawyer as $v) {
            $uids[] = $v['uid'];
        }
        if (empty($uids)) {
            return array();
        }
        //ȡ��ʦ��ϸ��Ϣ
        \Tools\Lawyer::setUcLawyerKey($recom_lawyer);
        //$lawyers = \Tools\Lawyer::getLawyerListByKey();
        $lawyers = \Tools\Lawyer::getUcLawyerInfo(2);
        foreach ($recom_lawyer as $k => $v) {
            $recom_lawyer[$k] =array_merge($recom_lawyer[$k], $lawyers['uid'][$v['uid']]);
        }
        $tmp = \Tools\Ads::get_ad_file($recom_lawyer);
        return $tmp;
    }
    
    /**
     * ��ȡ�б���id����ֵ
     *
     * @param unknown $askAddlist askAddlist
     *
     * @return int
     */
    public function getMaxId($askAddlist)
    {
        if (empty($askAddlist)) {
            return 0;
        }
        $maxid = 0;
        foreach ($askAddlist as $k=>$v) {
            if ($v['id'] > $maxid) {
                $maxid = $v['id'];
            }
        }
        return $maxid;
    }
    
    /**
     * ����������ѯ����ѯ�ظ�ʱ�ж����йؼ���
     * 
     * @param unknown $content content
     * @param unknown $type    type
     * 
     * @return string
     */
    public function mgkeyword($content, $type)
    {
        $type = $type ? $type : 1;
        $type_arr = array(1=>'lanjie_keyword', 2=>'abuse_keyword');
        if (!in_array($type, array_keys($type_arr))) {
            $type = 1;
        }
        $lanjieword = \Tools\Split::splitWord($content, $type_arr[$type]);
        if ($lanjieword) {
            $lanjiearr = array_unique(array_filter(explode(' ', trim($lanjieword))));
            if ($lanjiearr) {
                $lanjiestr = '';
                if (count($lanjiearr) > 3) {
                    $lanjiearr = array_slice($lanjiearr, 0, 3);
                    $lanjiestr = '...';
                }
                return '�������дʣ�'.implode('��', $lanjiearr).$lanjiestr.'��';
            }
        }
        return '';
    }
}