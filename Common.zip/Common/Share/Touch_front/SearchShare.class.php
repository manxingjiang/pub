<?php

/**
 * ����������
 *
 * @author    whj <weihongjiang@findlaw.cn>
 */
namespace Share\Touch_front;
use Share\Touch_front;

/**
 * ����������
 *
 * @author whj <weihongjiang@findlaw.cn>
 */
class SearchShare
{

    public $hb_search;

    public $debug;

    public $SearchShare;

    public $keyword; // �����ؼ���
    
    /**
     * ���캯��
     * */

    public function __construct ()
    {
        C(include ROOT_PATH .'china.findlaw.cn/touch_front/trunk/Home/Conf/hb_search_conf.php');
        // ��ʼ���࣬���ӷ�ʽ
        $this->hb_search = $this->get_hb_search_obj();
        $this->debug = isset($_GET['debug']) ? $_GET['debug'] : '';
        // ʵ���� SearchShare
        // $this->SearchShare = new SearchShare($this->hb_search);
        // �����ؼ���
        $URL = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        // echo $URL;
        $module_name = strtolower(MODULE_NAME);
        // assign��ǰģ����Ϣ
        // $module_list = $this->module_list();
        // $this->moduleinfo = $module_list[$module_name];
    }

    /**
     * ��ʼ��������
     * 
     * @return array
     */
    public function get_hb_search_obj ()
    {
        return $this->new_hb_search_obj();
    }

    /**
     * �½�������
     * 
     * @return array
     */
    public function new_hb_search_obj ()
    {
        // require_once('include/hb_search.class.php');
        $hb_search = new hb_search();
        $hb_search->SET_DB_SESSION_CONFIG(C("DB_SESSION_CONFIG"));
        $host = C('hb_search_host');
        $port = C('hb_search_port');
        $hb_search->connect($host, $port);
        return $hb_search;
    }
    
    /**
     * ȫ������
     * 
     * @param string $keyword �ؼ���
     * 
     * @return array
     *  */

    public function Search ($keyword)
    {
        
        // ���ܲ���
        $p = isset($_GET['p']) ? (int) trim($_GET['p']) : 1;
        $prof = isset($_GET['prof']) ? trim($_GET['prof']) : '';
        $order = isset($_GET['order']) ? trim($_GET['order']) : '';
        
        $hb_search = $this->hb_search;
        $searchcommon = $this->searchcommon;
        
        // �б� �������� ר������
        $hb_search->filter('ifaudit', array(1));     
        $table = 'fl_news';
        if ($order == 1) {
            $order_mode = 'grade desc,@barrel desc,@log2(@weight) desc,@timesegment(updatetime) desc';
        } elseif ($order == 2) {
            $order_mode = '@timesegment(inputtime) desc,@barrel desc,@log2(@weight) desc,@timesegment(id) desc';
        } else {
            $order_mode = '@barrel desc,@log2(@weight) desc,@timesegment(updatetime) desc';
        }
        $fields = '';
        $page_size = 10;
        $offset = ($p - 1) * $page_size;
        $limit = 10;
        $hb_search->set_group('catid1,catid');
        // ���ר��
        $left = $hb_search->query($content, $fields, $table, $order_mode, $offset, $limit, HB_MATCH_ALL);
        // ����ѡ��
        
        if ($prof) {
            $hb_search->filter('catid', array($prof));
        }
        // ��ע
        // $member=$this->searchcommon->is_log();
        if (empty($member)) {
            $hb_search->comment();
        } else {
            $hb_search->comment($member['uid']);
        }
        $num = $hb_search->query($content, $fields, $table, $order_mode, $offset, $limit, HB_MATCH_ALL);
        
        // ȡ����
        $result = $hb_search->result($num);
        
        // ����
        $result_count = $hb_search->sum($num1);
        
        if ($result_count == 0) {
            $result['count'] = 0;
        }
        return $result;
    }

    /**
     * ���ӱ�ע
     * 
     * @return null
     */
    public function addcomment ()
    {
        if ($this->logininfo['is_login'] == 1) {
            $this->hb_search->comment($this->logininfo['userid']);
        } else {
            $this->hb_search->comment();
        }
    }

    /**
     * ���������Ϣ
     * 
     * @param string &$sc sc
     * 
     * @return null
     */
    public function sdebug (&$sc = null)
    {
        if ($this->debug == 1) {
            $o = $sc ? $sc : $this->hb_search;
            $o->prints();
            echo 'warning:';
            var_dump($o->warning());
            echo '<br>';
            echo 'error:';
            var_dump($o->error());
        }
    }
}
