<?php
/**
 *  ������Ŀ����ģ��
 *
 *  @author whj <2851026524@qq.com>
 */
namespace Share\Touch_front;
use Share\Touch_front;

/**
 * ������Ŀ����ģ��
 *
 * @author whj <2851026524@qq.com>
 */
class MessageboxShare extends \Parents\ShareCommon
{
    private  $header= array(
            "H-N"=>"YES"
    );
    /**
     * Header����Ϣ����
     * 
     * @return int
     */
    function getNewMessage()
    {
        $currUser = \Tools\User::currUser();
        $map = array();
        $map['projectid'] = 1;
        $map['msgtoUid']  = $currUser['uid'];
        $map['readflag']  = 0;
        if ($currUser['usertype'] === "2") { //����
             $map['businessids'] = array(2, 4, 7);
             $qid = intval($_GET['qids']);
        } else {
             $map['businessids'] = array(1, 3);
        }
        
        return $rs = \Rpc::getUCData("Pms.queryPageListByProjectidCount", $map);
    }
    
    /**
     * ����Ϣ����
     * 
     * @param int $uid      uid
     * @param int $usertype usertype
     * 
     * @return void
     */
    function getNewMessagelist($uid,$usertype)
    {
        $map = array();
        $map['projectid'] = 1;
        $map['msgtoUid']  = $uid;
        //$map['readflag']  = 0;
        if ($usertype === "2") { //����
            $map['businessids'] = array(2, 4, 7);
            $qid = intval($_GET['qids']);
            if ($qid < 1) {   
            }
        } else {
            $map['businessids'] = array(1, 3);
            if ($_GET["qids"] && $_GET["qids"] !== "0") {
                $qids = explode(",", trim($_GET['qids']));
            }
        }
        $list=\Rpc::getUCData(array("Pms.queryPageListByProjectid", $this->header), 1, 200, $map);
        foreach ($list as $k=>$v) {
            $list[$k]['date']=date("Y-m-d", $v['sendtime']);           
        }        
        return $list;
    }
    
    /**
     * ��Ϣ����
     *
     * @return int
     */
    function getMessageCount()
    {
        $currUser = \Tools\User::currUser();
        $map = array();
        $map['projectid'] = 1;
        $map['msgtoUid']  = $currUser['uid'];
        //$map['readflag']  = 0;
        if ($currUser['usertype'] === "2") { //����
            $map['businessids'] = array(2, 4, 7);
            $qid = intval($_GET['qids']);
        } else {
            $map['businessids'] = array(1, 3);
        }
        //������Ϣ��    
        return $rs = \Rpc::getUCData("Pms.queryPageListByProjectidCount", $map);
    }
    

    /**
     * ��Ϣ�б�
     *
     * @param int $page     page
     * @param int $pageSize pageSize
     *
     * @return void
     */
    function getMessagelist($page,$pageSize)
    {      
        $currUser = \Tools\User::currUser();
        $map = array();
        $map['projectid'] = 1;
        $map['msgtoUid']  = $currUser['uid'];
        //$map['orderBy'] = "readflag ASC,id DESC";
        //$map['readflag']  = 0;
        if ($currUser['usertype'] === "2") { //����
            $map['businessids'] = array(2, 4, 7);
            $qid = intval($_GET['qids']);
        } else {
            $map['businessids'] = array(1, 3);
        }
        
        $list=\Rpc::getUCData(array("Pms.queryPageListByProjectid", $this->header), $page, $pageSize, $map);
        foreach ($list as $k=>$v) {
            $list[$k]['date']=date("Y-m-d", $v['sendtime']);
            trim($v['title']);
            trim($v['content']);
            if ($v['title']!='') {
                $list[$k]['title']=$v['title'];                
            } else if ($v['content']!='' && $v['title']=='') {
                $list[$k]['title']=substr($v['content'], 0, 30)."...";                
            } else {
                $list[$k]['title']= "����һ���µ���Ϣ...  ";
            }
        }
        return $list;
    }
}