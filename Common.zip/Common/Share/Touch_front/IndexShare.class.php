<?php
/**
 *  ������Ŀ����ģ��
 *
 *  @author whj <2851026524@qq.com>
 */
namespace Share\Touch_front;
use Share\Touch_front;

/**
 * ������Ŀ����ģ��
 *
 * @author whj <2851026524@qq.com>
 */
class IndexShare extends \Parents\ShareCommon
{

    /**
     * �������Է���
     * 
     * @param int $page
     *            page
     * @param int $pagesize
     *            pagesize
     * @param array $other
     *              other
     *            
     * @return array
     */
    
    /**
     * ���ò���
     */
    private $page = 1;

    private $header = array(            
            // ��ʹ�û���
            'H-N' => 'NO'
    );

    private $arr = array(
    // 'orderBy'=>'pubdate DESC'
            );
    
    /**
     * ȡ�÷����б�
     * 
     * @param int $pagesize pagesize  
     *       
     * @return array
     */
    public function faguilist ($pagesize)
    {
        // ȡ�÷����б�
        $arr=array(
                'orderBy'=>'id DESC'
        );
        $List = \Rpc::getData(array("Zhishi.queryFlFaguiPageList", $this->header), $this->page, $pagesize, $arr);
        foreach ($List as $k => $val) {
            $List[$k]['shorttitle'] = $this->UIsubstr($val['title'], 0, 14, 'gbk');
            $List[$k]['date'] = date('Y-m-d', $val['updatetime']);
            $List[$k]['murl'] = "http://m.findlaw.cn/fagui/article_{$val['id']}.html";
        }
        return $List;
    }

    /**
     * ȡ�������б�
     *
     * @param int $pagesize pagesize  
     *       
     * @return array
     */
    public function wenshulist ($pagesize)
    {       
        $catids='857,901,1213,1382,1649,1757,2101,3448,3545,4335,4547,4763,5217,5220,6255,6582,7011,7870,8873,9243,9244,9245,9852,9857,10104,10479,10514,11170,11433,11490,12149,12590,12628,12783,13337,13874,14175,14544,14994';
        $arrcatid=explode(",", $catids);
        $arr=array(
                'catids'=>$arrcatid,
                'orderBy'=>'id DESC'
        );
        
        // ȡ�������б�
        $List = \Rpc::getData(array("Zhishi.queryFlNewsList", $this->header), $this->page, $pagesize, $arr);
        foreach ($List as $k => $val) {
            $List[$k]['shorttitle'] = $this->UIsubstr($val['title'], 0, 14, 'gbk');
            $List[$k]['date'] = date('Y-m-d', $val['updatetime']);
            $List[$k]['murl'] = $this->share('Zhishi')->mzsdetailurl($val['url'], $val['id']);
        }        
        return $List;
    }

    /**
     * ȡ�ð����б�
     * 
     * @param int $pagesize pagesize  
     *       
     * @return array
     */
    public function anlilist ($pagesize)
    {
        $catids='293,448,488,530,700,707,835,858,952,1063,1210,1241,1326,1380,1406,1415,1426,1447,1450,1451,1452,1453,1454,1616,1647,1691,1758,1769,2102,2138,2383,2384,2385,2388,2391,2392,2393,2394,2395,2396,2397,2398,2399,2400,2401,2402,2403,2404,2405,2406,2407,2408,2409,2410,2411,2412,2413,2414,2415,2619,2725,2774,2776,2889,3230,3238,3239,3240,3292,3355,3396,3437,3447,3473,3482,3615,3632,3695,4017,4060,4079,4093,4094,4095,4096,4097,4098,4277,4278,4279,4280,4379,4471,4527,4644,4777,4855,4912,4973,4976,4977,4978,4979,4980,4982,4983,5074,5095,5097,5098,5099,5100,5101,5110,5126,5140,5229,5268,5364,5396,5562,5640,5687,5757,5777,5803,5820,5847,5870,5883,5922,5964,5987,5996,6021,6058,6062,6070,6072,6082,6097,6103,6125,6136,6143,6436,6493,6494,6495,6496,6497,6498,6499,6500,6501,6502,6503,6505,6506,6507,6508,6514,6608,6633,6737,6813,6898,6909,6910,6916,6933,6992,7008,7050,7064,7096,7098,7499,7631,7799,7839,7967,8023,8024,8025,8026,8202,8280,8281,8282,8284,8285,8286,8287,8326,8457,8871,9323,9832,9833,9834,9835,9836,9837,9838,9839,984';
        $arrcatid=explode(",", $catids);
        $arr=array(
                'catids'=>$arrcatid,
                'orderBy'=>'id DESC'
        );
        // 'orderBy'=>'pubdate DESC'
        
        // ȡ�ð����б�
        $List = \Rpc::getData(array("Zhishi.queryFlNewsList", $this->header), $this->page, $pagesize, $arr);
        foreach ($List as $k => $val) {
            $List[$k]['shorttitle'] = $this->UIsubstr($val['title'], 0, 14, 'gbk');
            $List[$k]['date'] = date('Y-m-d', $val['updatetime']);
            $List[$k]['murl'] = $this->share('Zhishi')->mzsdetailurl($val['url'], $val['id']);
        }
        return $List;
    }

    /**
     * ȡ�ö�̬�б�
     * 
     * @param int $pagesize pagesize  
     *       
     * @return array
     */
    public function newslist ($pagesize)
    {
        //����ID
        $catids='2,305,468,509,805,843,904,905,967,1066,1214,1392,1409,1419,1595,1619,1663,1742,1762,1851,2081,2136,2493,2596,2674,2703,2867,2884,3378,3456,3597,3945,4394,4413,4543,4619,4793,5373,5460,5997,6104,6243,6555,6583,6924,6993,7373,7484,7623,7855,7954,8050,8314,8556,8590,8853,9309,9907,9966,10135,10238,10281,10515,11013,11159,11172,11204,11225,11468,11580,11947,11957,12003,12027,12131,12178,12198,12289,12352,12458,12490,12594,12615,12618,12620,12668,12792,12976,13122,13196,13308,13315,13878,13959,14156,14547,14971,14972,14973,14995,14997,14999,15222';
        $arrcatid=explode(",", $catids);
        // print_r($arrcatid);
        $arr=array(
                'catids'=>$arrcatid,
                'orderBy'=>'id DESC'
        );
        
        // ȡ�ö�̬�б�
        $List = \Rpc::getData(array("Zhishi.queryFlNewsList", $this->header ), $this->page, $pagesize, $arr);
        foreach ($List as $k => $val) {
            $List[$k]['shorttitle'] = $this->UIsubstr($val['title'], 0, 14, 'gbk');            
            $List[$k]['date'] = date('Y-m-d', $val['updatetime']);
            $List[$k]['murl'] = $this->share('Zhishi')->mzsdetailurl($val['url'], $val['id']);
        }
        return $List;
    }

    /**
     * �����ظ���ʦ
     * 
     * @param array &$brandList brandList
     * @param array &$vipList   vipList
     * 
     * @return array
     */

    protected function removeRand(&$brandList, &$vipList)
    {
        
        if ($brandList == null || $vipList ==null) {
            return ;
        }
        
        foreach ($brandList as $brand) {
            $uid = $brand['id'];
            for ($i=0; $i < count($vipList); $i++) {
                if ($uid == $vipList[$i]['id']) {
                    unset($vipList[$i]);
                }
            }
            
            // array_splice($vipList);
        }
    }
    
    /**
     * ����������ȡ�Ƽ���ʦ
     * 
     * @param int $areaCode areacode
     * 
     * @return multitype:array|NULL
     */
    public function getRecommentLawyerList($areaCode)
    {
        $arr = array(
                'areacodeBegin' => substr($areaCode, 0, 4) . "00",
                'areacodeEnd' => substr($areaCode, 0, 4) . "99",
                'isbrand' => 1,
        );
        $askstr="Ask.queryDayStatListB";
        
        $brandList = \Rpc::getData(array($askstr, $this->header), 1, 100, $arr);
        $retList = null;
        
   
        $arr = array(
                'areacodeBegin' => substr($areaCode, 0, 4) . "00",
                'areacodeEnd' => substr($areaCode, 0, 4) . "99",
                'vipflag' => 1,
        );
        $vipList = \Rpc::getData(array($askstr, $this->header),  1, 100, $arr);
        if ($brandList != null && count($brandList) > 0) {
            
            //$retList = $brandList;
            if ($vipList != null && count($vipList) > 0) {
                shuffle($brandList);
                shuffle($vipList);
                $this->removeRand($brandList, $vipList);
                $retList = array_merge($brandList, $vipList);
            }
            

        } else if ($vipList != null && count($vipList) > 0) {
            shuffle($vipList);
            $retList = $vipList;
            
        } else {
            $arr = array(
                'areacodeBegin' => substr($areaCode, 0, 4) . "00",
                'areacodeEnd' => substr($areaCode, 0, 4) . "99",
            );
            $retList = \Rpc::getData(array($askstr,  $this->header), 1, 15, $arr);
            shuffle($retList);
        }
        $retList = \Tools\Ads::get_ad_file($retList);
        \Tools\Lawyer::setUcLawyerKey($retList);
        $List = \Tools\Lawyer::getLawyerListByKey();
        //$List = \Tools\Lawyer::getUcLawyerInfo(2);
        
        foreach ($retList as $k=>$v) {
            $retList[$k] =array_merge($retList[$k], $List['uid'][$v['uid']]);
            //�Ƿ��и���64�ߴ��ͷ��
            $retList[$k]['isphoto64'] = preg_match("/my\/lawyer_64\/64.jpg$/", $retList[$k]['file6464']) ? 1 : 0;
            if ($retList[$k]['isphoto64']==1) {
                $retList[$k]['file6464'] = \Tools\Image::imagesReplace('/my/photo/' . $v['photo']);
            }
                // ֱϽ����ʾ��
            if ($retList[$k]['province'] == $retList[$k]['city']) {
                $retList[$k]['city'] = $retList[$k]['country'];
            }
            $arr = explode(',', $v['profession']);
            $retList[$k]['profession1']=$arr[0];
            $retList[$k]['profession2']=$arr[1];
        }
        $lawyers=array();
        foreach ($retList as $k => $v) {
            if ($v['uid']) {
                $lawyers[] = $v;
            }
        }
        if ($_GET['debug'] == 'list') {
            print_r($brandList);
            print_r($vipList);
            print_r($lawyers);
        }    
        return $lawyers;
    }

      
    /**
     * ��ȡ�ַ�
     * 
     * @param string $str      str
     * @param int    $start    start
     * @param int    $length   length
     * @param int    $encoding encoding
     * 
     * @return string
     */
    function UIsubstr ($str, $start, $length , $encoding = 'gbk')
    {
        $str =str_replace(array('&lt;', '&gt;', '&amp;', '&nbsp;'), array('<', '>', '&', ' '), $str);
        return mb_substr($str, $start, $length, $encoding);
    }


     /**
     * ȡ��ʦִҵ����
     * uִҵ���ޣ�ִҵ֤��Ϊ17λ����ʦ��ȡ��ʦְҵ֤������ĵ�6��9λ����6��9λΪ�״���׼��ʦִҵ����ȴ��롤��֤����ִֹҵ����������ִҵ�ġ�Ϊ��׼����ִҵ����ȴ��룮����ʼ����ʦ��ְҵʱ�䣬
     * �����ŏ�����ʦ�ǡ�2010��������ְҵ����Ӧ����5�ꣻ
     * ִҵ֤�Ų���17λ����ʦ��ȡ��ʦ���֡��������ϡ��еġ�ִҵ��ݡ���ʼ����ʦ��ִҵʱ�䣻
     * �����ʦִҵ֤�Ų���17λҲû����дʱ��Ĭ����ʾ��רְ��ʦ����
     * ִҵ����С�ڵ���2��ʱ����ʾ�ɡ�רְ��ʦ����
     * 
     * @param array $lawyerInfo ��ʦ��Ϣ
     *  
     * @return string
     */
    public function getLawyerYear($lawyerInfo)
    {
        $lawyerYear = '';
        $thisYear = date('Y', time());
        $lawyerCode = $lawyerInfo['lawercode'];
        $lawyerBeginYear = $lawyerInfo['workyears'];
        if (strlen($lawyerCode) == 17) {
            $yearBegin = substr($lawyerCode, 5, 4);
            $lawyerYear = $thisYear - $yearBegin +1;
            $lawyerYear = $lawyerYear."��";
        } else {
            $lawyerYear = 'רְ��ʦ';
        }
        return $lawyerYear;        
    }
    
    /**
     *  ģ����:404ҳ��
     *
     *  @author whj <weihongjiang@findlaw.cn>
     *  
     *  @return NULL
     */
    public function errorpage()
    {
            Header("Location: http://m.findlaw.cn/404.html");
            exit();
    }
    
}