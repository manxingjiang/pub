<?php
/**
 *  ������Ŀ����ģ��
 *
 *  @author zsg <xxx@qq.com>
 */
namespace Share\Touch_front;
use Share\Touch_front;
/**
 * ������Ŀ����ģ��
 *
 * @author zsg <xxx@qq.com>
 */
class AreaShare extends \Parents\ShareCommon
{
    /**
     * ���ų���
     *
     * @return null
     */
    public function getHotCity()
    {
        return array(
            '140101'  => '�Ϻ�',
            '110101'  => '����',
            '170200'  => '����',
            '170300'  => '����',
            '260200'  => '�Ͼ�',
            '171200'  => '��ɽ',
            '400200'  => '����',
            '290300'  => '����',
            '330300'  => '�ൺ',
            '330800'  => '��̨',
            '330200'  => '����',
            '260700'  => '̩��',
            '331300'  => '����',
            '330900'  => '����',
            '331200'  => '����',
            '250200'  => '��ɳ',
            '240200'  => '�人',
            '261200'  => '����',
            '400300'  => '����',
            '260800'  => '��ͨ',
            '200300'  => '����',
            '100200'  => '�Ϸ�',
            '210200'  => 'ʯ��ׯ',
            '380200'  => '��³ľ��',
            '300200'  => '���ͺ���',
            '440101'  => '���',
            '450101'  => '����',
        );
    }   
    
    /**
     * �����л�
     * 
     * @param unknown $newAreacode newareacode
     * 
     * @return boolean
     */
    public function switcharea($newAreacode)
    {
        $iAreacode = substr($newAreacode, 0, 4).'00';
        $aAreaInfo = \Rpc::getData("Area.getAreaInfo", $iAreacode);
        if (empty($aAreaInfo)) {
            $aAreaInfo = \Rpc::getData("Area.getAreaInfo", $newAreacode);
        }
        if (isset($aAreaInfo) && $aAreaInfo['id']>0) {
            $currarea = array(
                    'cn'   => array(
                            'province' => $aAreaInfo['province'],
                            'city'     => $aAreaInfo['city'],
                            'country'  => $aAreaInfo['country'],
                    ),
                    'py'   => array(
                            'province' => empty($aAreaInfo['city']) ? $aAreaInfo['pinyin'] : '',
                            'city'     => empty($aAreaInfo['country']) ? $aAreaInfo['pinyin'] : '',
                            'country'  => !empty($aAreaInfo['country']) ? $aAreaInfo['pinyin'] : '',
                    ),
                    'code' => array(
                            'province' => empty($aAreaInfo['city']) ? $aAreaInfo['id'] : '',
                            'city'     => empty($aAreaInfo['country']) ? $aAreaInfo['id'] : '',
                            'country'  => !empty($aAreaInfo['country']) ? $aAreaInfo['id'] : '',
                    ),
            );
        
            //�޸�COOKIE
            $currarea_utf8 = \Tools\Strings::utf8Gbk($currarea, 'utf8');
            //$aAreaInfo = \Tools\Strings::utf8Gbk($aAreaInfo, 'utf8');
            setcookie('currarea', json_encode($currarea_utf8), time() + 604800, '/', '.findlaw.cn');
            //���õ���ͳһcookie��ʽ
            setcookie("areainfo[province]", $aAreaInfo['province'], time()+60*60*24*30, '/', '.findlaw.cn');
            setcookie("areainfo[city]", $aAreaInfo['city'], time()+60*60*24*30, '/', '.findlaw.cn');
            setcookie("areainfo[pinyin]", $aAreaInfo['pinyin'], time()+60*60*24*30, '/', '.findlaw.cn');
            setcookie("areainfo[areacode]", $aAreaInfo['id'], time()+60*60*24*30, '/', '.findlaw.cn');
            setcookie("areainfo[default]", 0, time()+60*60*24*30, '/', '.findlaw.cn');
            return true;
        } else {
            return false;
        }
    }
}

