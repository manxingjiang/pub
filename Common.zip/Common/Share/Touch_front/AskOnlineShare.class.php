<?php
/**
 * һ��һ��ѯ������Ŀ����ģ��
 *
 * @author wrd <xx@qq.com>
 */
namespace Share\Touch_front;
use Share\Touch_front;
/**
 *  һ��һ��ѯ������Ŀ����ģ��
 *
 *  @author wrd <xx@qq.com>
 */
class AskOnlineShare extends \Parents\ShareCommon
{
    /**
     * ���ڻ�ȡһ��һ��ѯ�б�
     *
     * @param int   $page     ��ǰҳ��
     * @param int   $pageSize ÿҳ����
     * @param array $data     ��ѯ����
     *
     * @return array
     */
    public function userGetAskOnlineList($page=1, $pageSize=10, $data=array())
    {
        if ($page <= 0 || $pageSize <= 0 || empty($data)) {
            return array();
        } else {
            $askOnlineList = \Rpc::getData(array('Online.queryPubAskOnlineMapList', array('H-N' => 'YES')), $page, $pageSize, $data);
            $questionList  = array();
            if (!empty($askOnlineList)) {
                foreach ($askOnlineList as $k=>$v) {
                    $_v                = array();
                    $_v['qurl']        = 'http://m.findlaw.cn/?c=Leoadmin&a=myAskOnlineDetail&qid=' . $v['id'];
                    $_v['title']       = $v['title'];
                    $_v['answercount'] = $v['repCount'];
                    $_v['askdate']     = date('Y-m-d', $v['regdate']);
                    $questionList[]    = $_v;
                }
            }
            if ($_GET['debug'] == '999') {
                print_r($askOnlineList);
            }
            return $questionList;
        }
        
    }

    /**
     * ���ڻ�ȡһ��һ��ѯ�б�����
     * 
     * @param array $data ��ѯ����
     *
     * @return int
     */
    public function userGetAskOnlineListCount($data=array())
    {
        if (empty($data)) {
            return 0;
        } else {
            return \Rpc::getData(array('Online.queryPubAskOnlineMapListCount', array('H-N' => 'YES')), $data);
        }
    }

    /**
     * ���ڻ�ȡһ��һ��ѯ����
     *
     * @param int $qid ��ѯid
     * @param int $uid �û�uid
     * 
     * @return array
     */
    public function userGetAskOnlineDetail($qid, $uid)
    {
        if ($qid <= 0 || $uid <= 0) {
            return array();
        } else {
            $detail = \Rpc::getData(array('Online.getPubAskOnlineMap', array('H-N' => 'YES')), '', $qid, $uid);
            if (!empty($detail) && !empty($detail['askOnlineRepList'])) {
                foreach ($detail['askOnlineRepList'] as $k=>$v) {
                    //��ѯ��ʦ��Ϣ
                    $ucinfo = \Rpc::getUCData('Member.getUcLawyerByPKSel', $v['lawyerid'], 1, 2);
                    $detail['askOnlineRepList'][$k]['mobile']           = $ucinfo['mobile'];
                    $detail['askOnlineRepList'][$k]['province']         = $ucinfo['province'];
                    $detail['askOnlineRepList'][$k]['city']             = $ucinfo['city'];
                    $detail['askOnlineRepList'][$k]['lawyeryuming']     = $ucinfo['yuming'];
                    $detail['askOnlineRepList'][$k]['lawroomname']      = $ucinfo['lawyerLawroom'];
                    $detail['askOnlineRepList'][$k]['photo']            = $ucinfo['photo'];
                    $detail['askOnlineRepList'][$k]['lawyerurl']        = 'javascript:;';
                    $detail['askOnlineRepList'][$k]['file6464']         = 'http://images.findlaw.cn/my/photo/' . $ucinfo['photo'];
                    $detail['askOnlineRepList'][$k]['askOnlineAddList'] = array_reverse($v['askOnlineAddList']);
                }
            }
            return $detail;
        }
    }

    /**
     * �����ύһ��һ��ѯ׷��
     *
     * @param string $content   ����
     * @param int    $qid       ����id
     * @param int    $aid       �ظ�id
     * @param int    $pid       ׷�ʸ�id
     * @param int    $lawyeruid ��ʦid
     * @param int    $currUser  ��ǰ��¼�û���Ϣ
     * 
     * @return array
     */
    public function userSubmitAskOnlineAdd($content, $qid, $aid, $pid, $lawyeruid, $currUser)
    {
        //��������
        $result = array('msg'=>'�����ɹ�', 'status'=>1, 'data'=>array());
        //��֤����
        if ($qid <= 0 || $aid <= 0 || $lawyeruid <= 0 || $pid <= 0) {
            $result['msg']    = '��Ч����Ϣ';
            $result['status'] = 0;
            return $result;
        }
        if ($content == '') {
            $result['msg']    = '������׷������';
            $result['status'] = 0;
            return $result;
        }
        //һ��һ��ѯ����
        $detail     = $this->userGetAskOnlineDetail($qid, $currUser['uid']);
        //׷�ʵ���ʦ��Ϣ
        $lawyerInfo = array();
        if (empty($detail)) {
            $result['msg']    = '��Ч����Ϣ';
            $result['status'] = 0;
            return $result;
        } else {
            foreach ($detail['askOnlineRepList'] as $k=>$v) {
                if ($v['lawyerid'] == $lawyeruid) {
                    $lawyerInfo = \Rpc::getUCData('Member.getUcLawyerByPKSel', $v['lawyerid'], 1, 1);
                }
            }
            if (empty($lawyerInfo)) {
                $result['msg']    = '��Ч����Ϣ';
                $result['status'] = 0;
                return $result;
            }
        }

        //����׷�ʵ�����
        $userip = ($_SERVER["HTTP_VIA"]) ? $_SERVER["HTTP_X_FORWARDED_FOR"] : $_SERVER["REMOTE_ADDR"];
        $userip = str_replace('.', '', $userip);
        $arr    = array(
                    'pid'           => $pid ,
                    'qid'           => $qid,
                    'aid'           => $aid,
                    'uid'           => $currUser['uid'],
                    'userid'        => $currUser['userid'],
                    'username'      => $currUser['username'],
                    'answeruid'     => $lawyerInfo['uid'],
                    'answeruserid'  => $lawyerInfo['userid'],
                    'addcontent'    => $content,
                    'areacode'      => $detail['areacode'],
                    'ip'            => $userip,
                    'utypeid'       => 1,
                    'contentType'   => 1,
                    'iswrite'       => 0,
                    'onlineregdate' => $detail['regdate']
                );

        //�������йؼ����Զ�����
        $mgkeys = \Tools\Split::existsMgWord($content);
        if ($mgkeys !== false) {
            $arr['illegalkeywords'] = $mgkeys;
            //��¼���йؼ����Զ����ε�����
            $split = new \Tools\Split();
            $split->filterInfoDone(0, $qid, $mgkeys);
        }
        $rs   = \Rpc::getData('Online.Admin.insertAskOnlineAdd', $arr);
        //�޸�Ϊδ��״̬
        \Rpc::getResponse('Online.Admin.updateAskOnlineAddReadflagByIds', array($qid), $lawyeruid, 0);
        if ($rs == 1) {
            $result['msg']    = '����ʧ��!���Ѿ�׷�ʣ�';
            $result['status'] = 0;
        } elseif ($rs == 0) {
            $result['msg']    = '����ʧ��! ׷�ʳ���5��!';
            $result['status'] = 0;
        } else {
            $result['msg']    = '�����ɹ�';
            $result['status'] = 1;
        }
        return $result;
    }

    /**
     * ��ʦ��ȡһ��һ��ѯ�б�
     *
     * @param int $page     ��ǰҳ��
     * @param int $pageSize ÿҳ����
     * @param int $data     ��ѯ����
     *
     * @return array
     */
    public function lawyerGetAskOnlineList($page=1, $pageSize=10, $data=array())
    {
        if ($page <= 0 || $pageSize <= 0 || empty($data)) {
            return array();
        } else {
            $list = \Rpc::getData('Online.queryAskOnlineMapList', $page, $pageSize, $data);
            if ($list) {
                foreach ($list as $k => $v) {
                    $list[$k]['title_cut'] = '';
                    if (strlen($v['title']) >= 30) {
                        //���ⳤ�ȳ���25����ʱ��ֻ��ʾ25����
                        $list[$k]['title_cut'] = \Tools\Strings::cut_str($v['title'], 30, "...");
                    }
                    if ($v['leouserid'] == 'sys_mobileuser') {
                        $list[$k]['telephone'] = '';
                    }
                    if (empty($v['repcon']) && $item == 2) {
                        unset($list[$k]['repcon']);
                    }
                    $list[$k]['myall']     = ($item == 1) ? 1 : 0;
                    $list[$k]['onlineAdd'] = 0;
                    $tmpAddr               = explode('-', $v['addr']);
                    $list[$k]['addr']      = $tmpAddr[0] . '-' . $tmpAddr[1];
                }
            }
            return $list;
        }
    }

    /**
     * ��ʦ��ȡһ��һ��ѯ����
     *
     * @param array $data ��ѯ����
     * 
     * @return int
     */
    public function lawyerGetAskOnlineListCount($data)
    {
        if (empty($data)) {
            return 0;
        } else {
            return \Rpc::getData('Online.queryAskOnlineMapListCount', $onlineParams);
        }
    }

    /**
     * ��ʦ��ȡһ��һ��ѯ����
     *
     * @param int $qid      ��ѯid
     * @param int $repid    �ظ�id
     * @param int $lawyerid ��ʦuid
     * @param int $ifaudit  ���״̬
     * 
     * @return array
     */
    public function lawyerGetAskOnlineDetail($qid, $repid, $lawyerid, $ifaudit=1)
    {
        if ($qid <= 0 || $repid <= 0 || $lawyerid <= 0) {
            return array();
        } else {
            $data = array(
                'id'        => $qid,
                'repid'     => $repid,
                'lawyerid'  => $lawyerid,
                'ifaudit'   => $ifaudit
            );
            $detail = \Rpc::getData('Online.getAskOnlineMap', $data);
            if (empty($detail)) {
                return array();
            } else {
                //��׷���������½��з�������
                $add      = array_reverse($detail['ltOnlineAddList']);
                $addindex = $laddindex = 0;
                foreach ($add as $k=>$v) {
                    if ($v['utypeid'] == 1) {
                        $addindex++;
                        $add[$k]['addindex'] = $addindex;
                    } else {
                        $laddindex++;
                        $add[$k]['addindex'] = $laddindex;
                    }
                    //������һ��׷��ID
                    if ($k > 0) {
                        $add[$k]['previd'] = $add[$k-1]['id'];
                    } else {
                        $add[$k]['previd'] = 0;
                    }
                }
                $detail['add'] = $add;
                return $detail;
            }
        }
    }

    /**
     * ��ʦ�ظ�׷����Ϣ
     *
     * @param string $content    �ظ�����
     * @param int    $qid        ����id
     * @param int    $aid        �ظ�id
     * @param int    $pid        ׷�ʸ�id
     * @param array  $lawyerInfo ��ǰ��¼��ʦ��Ϣ
     *
     * @return array
     */
    public function lawyerSubmitAskOnlineAdd($content, $qid, $aid, $pid, $lawyerInfo)
    {
        //��������
        $result = array('msg'=>'�����ɹ�', 'status'=>1, 'data'=>array());

        //��֤����
        if ($content == '' || $qid <= 0 || $aid <= 0) {
            $result['msg']    = '��Ч����Ϣ';
            $result['status'] = 0;
            return $result;
        }
        $detail = $this->lawyerGetAskOnlineDetail($qid, $aid, $lawyerInfo['uid'], 1);
        if (empty($detail)) {
            $result['msg']    = '��Ч����Ϣ';
            $result['status'] = 0;
            return $result;
        } else {
            //����׷�ʵ�����
            $userip = ($_SERVER["HTTP_VIA"]) ? $_SERVER["HTTP_X_FORWARDED_FOR"] : $_SERVER["REMOTE_ADDR"];
            $userip = str_replace('.', '', $userip);
            $arr = array(
                    'pid'           => $pid ,
                    'qid'           => $qid,
                    'aid'           => $aid,
                    'uid'           => $lawyerInfo['uid'],
                    'userid'        => $lawyerInfo['userid'],
                    'username'      => $lawyerInfo['username'],
                    'answeruid'     => $lawyerInfo['uid'],
                    'answeruserid'  => $lawyerInfo['userid'],
                    'addcontent'    => $content,
                    'areacode'      => $detail['areacode'],
                    'ip'            => $userip,
                    'utypeid'       => 2,
                    'contentType'   => 1,
                    'iswrite'       => 0,
                    'onlineregdate' => $detail['regdate']
            );

            //�������йؼ����Զ�����
            $mgkeys = \Tools\Split::existsMgWord($content);
            if ($mgkeys !== false) {
                $arr['illegalkeywords'] = $mgkeys;
                //��¼���йؼ����Զ����ε�����
                $split = new \Tools\Split();
                $split->filterInfoDone(0, $qid, $mgkeys);
            }
            $rs = \Rpc::getData('Online.Admin.insertAskOnlineAdd', $arr);
            /*
            //�޸�Ϊδ��״̬
            \Rpc::getResponse('Online.Admin.updateAskOnlineAddReadflagByIds', array($qid), $lawyeruid, 0);

            if ($rs == 1) {
                $result['msg']    = '����ʧ��!���Ѿ�׷�ʣ�';
                $result['status'] = 0;
            } elseif ($rs == 0) {
                $result['msg']    = '����ʧ��! ׷�ʳ���5��!';
                $result['status'] = 0;
            } else {
                $result['msg']    = '�����ɹ�!';
                $result['status'] = 1;
            }
            */
            return $result;
        }
    }

    /**
     * ��ʦ�ظ�һ��һ��ѯ
     *
     * @param int $id         id
     * @param int $qid        ����id
     * @param int $repcon     �ظ�����
     * @param int $lawyerInfo ��ʦ��Ϣ
     * 
     * @return array
     */
    public function lawyerSubmitAskOnline($id, $qid, $repcon, $lawyerInfo)
    {
        $result               = array('msg'=>'�����ɹ�', 'status'=>1, 'data'=>array());
        $lawyerip             = \Tools\Iparea::getClientIp();
        $lawyerip             = empty($lawyerip) ? '0.0.0.0' : $lawyerip;
        $lawyeriplong         = ip2long($lawyerip);
        $userIParea           = \Tools\iparea::getIpReviseArea();
        $data                 = array();
        $data['id']           = $id;
        $data['pid']          = $qid;
        $data['repcon']       = $repcon;
        $data['repcon']       = iconv('UTF-8', 'GBK//IGNORE', $data['repcon']);
        $data['lawyerip']     = $lawyeriplong;
        $data['lawyerareaid'] = $userIParea['areacode'];
        $data['lawyeruserid'] = $lawyerInfo['userid'];
        $data['lawyerid']     = $lawyerInfo['uid'];
        $data['iswrite']      = 0;
        $data['ifaudit']      = 0;
        $data['status']       = 1;
        $data['frompage']     = '006';
        $data['contentType']  = 1;
        $data['repdate']      = time();
        if ($data['id'] <= 0 || $data['pid'] <= 0) {
            $result['msg']    = '��Ч����Ϣ';
            $result['status'] = 0;
            return $result;
        }
        if ($data['repcon'] == '') {
            $result['msg'] = '������ظ�����';
            $result['status'] = 0;
            return $result;
        }

        //�������йؼ����Զ�����
        $mgkeys = \Tools\Split::existsMgWord($data['repcon']);
        if ($mgkeys !== false) {
            $data['illegalkeywords'] = $mgkeys;
            $data['ifaudit']         = 3;
        }

        $rs = \Rpc::getResponse('Online.Admin.updateAskOnlineRepByPKSel', '', $data);
        if ($rs->isSuccess()) {
            \Rpc::getResponse('Column.Admin.updateByAskid', 1, $data['qid']);
            return $result;
        } else {
            $result['msg'] = '����ʧ��';
            $result['status'] = 0;
            return $result;
        }
    }

}