<?php 
/**
 *  ������Ŀ����ģ��
 *
 *  @author whj <2851026524@qq.com>
 */
namespace Share\Touch_front;
use Share\Touch_front;

/**
 * ������Ŀ����ģ��
 *
 * @author zsg <xxx@qq.com>
 */
class ZhishiShare extends \Parents\ShareCommon
{
    /**
     * ȡ��֪ʶ��ϸ��Ϣ
     * 
     * @param int $id id
     *       
     * @return array
     */
    public function flnewsdetail ($id)
    {
        $detail = \Rpc::getData('Zhishi.getFlNews', $id);
        $detaildata = \Rpc::getData('Zhishi.getFlNewsData', $id);
        if ($detail != null && $detaildata != null) {
            return array_merge($detail, $detaildata);
        } elseif ($detail != null) {
            return $detail;
        } else {
            return $detaildata;
        }
    }
    
    /**
     * ȡ��֪ʶר���б�
     * 
     * @param int $catids catids
     * @param int $imgs   imgs
     *       
     * @return array
     */
    public function proflist($catids, $imgs = array())
    {
        $imgpre = 'http://img.findlawimg.com/cms/news/index/img/special/%s.jpg';
        $proflist = \Rpc::getData('Zhishi.queryFlCategoryList', 1, 200, array('catids'=>$catids));
        $catorder = array();

        foreach ($proflist as $k=>$v) {
            //$arr = $arr = explode(',', $v['arrchildid']);
            $arr=$this->gettypecatids($v['catid'], $v['type']);
            $proflist[$k]['profimg'] = sprintf($imgpre, $imgs[$v["catid"]]);
            $proflist[$k]['newslist'] = \Rpc::getData("Zhishi.queryFlNewsList", 1, 3, array('catids'=>$arr, 'islink'=>0, 'orderBy'=>'updatetime desc'));
            //$proflist[$k]['proforder'] = $this->array_index($catids, $v['catid']);
            $catorder[$k] = $this->array_index($catids, $v['catid']);
            foreach ($proflist[$k]['newslist'] as $key => $val) {
                $proflist[$k]['newslist'][$key]['murl'] = $this->mzsdetailurl($val['url'], $val['id']);
            }
        }
        //print_r($catorder);
        array_multisort($catorder, SORT_ASC, $proflist);        
        //print_r($proflist);exit;
        return $proflist;
    }      
    
    /**
     * ��ѯ��������λ�� 
     * 
     * @param unknown $arr  arr
     * @param unknown $item arr�е�һ��
     * 
     * @return unknown|number
     */
    public function array_index($arr, $item)
    {
        foreach ($arr as $k=>$v) {
            if ($v == $item) {
                return $k;
            }
        }
        return -1;
    }
    
    /**
     * ����ר��ȡ��֪ʶ�б�
     *
     * @param unknown $typecatids type
     * @param unknown $page       page
     * @param unknown $pagesize   pagesize
     *
     * @return array
     */
    public function zslist($typecatids, $page, $pagesize)
    {
        if (empty($typecatids)) {
            return array();
        }
        //$_GET['debug'] = 'rpcjson';        
        $list = \Rpc::getData("Zhishi.queryFlNewsList", $page, $pagesize, array('catids'=>$typecatids, 'islink'=>0, 'orderBy'=>'updatetime desc'));
        
        $rec_list = array();
        if ($page == 1) {
            //$typecatids = array();
            //print_r($typecatids);
            $rec_list = \Rpc::getData('Zhishi.queryFlPositionData', $typecatids, 0, 0, 5);
            foreach ($rec_list as $k=>$v) {
                $rec_list[$k]['is_rec'] = 1;
            }
        }
        
        $re =  empty($rec_list)? $list : array_merge($rec_list, $list);
        foreach ($re as $k=>$v) {
            $re[$k]['timeago'] =  \Tools\Time::convert2timeago($v['updatetime']);
            $re[$k]['murl'] = $this->mzsdetailurl($v['url'], $v['id']);
        }
        return $re;
    }
    
    /**
     * ͳ��
     * 
     * @param unknown $typecatids ttt
     * 
     * @return Ambigous <Ambigous, NULL, mixed, unknown, string>
     */
    public function zslist_count($typecatids)
    {
        return \Rpc::getData("Zhishi.queryFlNewsListCount", array('catids'=>$typecatids));
    }
    
    /**
     * ����֪ʶ����ͷ������ͣ� ȡ����������id
     * 
     * @param unknown $top_catid catid
     * @param unknown $cattype   cattype
     * 
     * @return multitype:|unknown
     */
    public function gettypecatids($top_catid, $cattype)
    {
        if (!in_array($cattype, array(0, 1,2,3,4))) {
            die('wroing cattype');
            return array();
        }
        //$dongtai_catids = '2,305,468,509,805,843,904,905,967,1066,1214,1392,1409,1419,1595,1619,1663,1742,1762,1851,2081,2136,2493,2596,2674,2703,2867,2884,3378,3456,3597,3945,4394,4413,4543,4619,4793,5373,5460,5997,6104,6243,6555,6583,6924,6993,7373,7484,7623,7855,7954,8050,8314,8556,8590,8853,9309,9907,9966,10135,10238,10281,10515,11013,11159,11172,11204,11225,11468,11580,11947,11957,12003,12027,12131,12178,12198,12289,12352,12458,12490,12594,12615,12618,12620,12668,12792,12976,13122,13196,13308,13315,13878,13959,14156,14547,14971,14972,14973,14995,14997,14999';
        //$fagui_catids = '469,510,663,806,861,968,1095,1230,1394,1410,1420,1617,1622,1664,1760,1773,1868,1869,1870,1871,1872,1873,1874,1875,1876,1877,1887,1902,2087,2124,2279,2281,2508,2748,2756,2905,3232,3342,3407,3443,3969,4062,4404,4414,4544,4637,4734,4842,4845,4848,4865,4866,4879,6129,6288,6290,6437,6538,6584,6590,6591,6592,6593,6596,6597,6640,6679,6748,6756,6783,6794,6814,6864,6921,7095,7354,7507,7634,7823,7856,8075,8620,8964,9906,9923,9985,9986,10066,10232,10534,10548,10925,10955,10996,11012,11040,11056,11071,11084,11156,11171,11203,11224,11499,11582,11919,11948,12004,12061,12159,12189,12202,12318,12420,12494,12565,12602,12613,12616,12619,12630,12700,12900,12979,13160,13309,13596,13787,14354,14998,15067';
        //$anli_catids = '293,448,488,530,700,707,835,858,952,1063,1210,1241,1326,1380,1406,1415,1426,1447,1450,1451,1452,1453,1454,1616,1647,1691,1758,1769,2102,2138,2383,2384,2385,2388,2391,2392,2393,2394,2395,2396,2397,2398,2399,2400,2401,2402,2403,2404,2405,2406,2407,2408,2409,2410,2411,2412,2413,2414,2415,2619,2725,2774,2776,2889,3230,3238,3239,3240,3292,3355,3396,3437,3447,3473,3482,3615,3632,3695,4017,4060,4079,4093,4094,4095,4096,4097,4098,4277,4278,4279,4280,4379,4471,4527,4644,4777,4855,4912,4973,4976,4977,4978,4979,4980,4982,4983,5074,5095,5097,5098,5099,5100,5101,5110,5126,5140,5229,5268,5364,5396,5562,5640,5687,5757,5777,5803,5820,5847,5870,5883,5922,5964,5987,5996,6021,6058,6062,6070,6072,6082,6097,6103,6125,6136,6143,6436,6493,6494,6495,6496,6497,6498,6499,6500,6501,6502,6503,6505,6506,6507,6508,6514,6608,6633,6737,6813,6898,6909,6910,6916,6933,6992,7008,7050,7064,7096,7098,7499,7631,7799,7839,7967,8023,8024,8025,8026,8202,8280,8281,8282,8284,8285,8286,8287,8326,8457,8871,9323,9832,9833,9834,9835,9836,9837,9838,9839,984';
        //$lunwen_catids = '292,447,489,531,701,708,834,859,1064,1211,1379,1407,1416,1446,1460,1461,1462,1463,1464,1615,1648,1692,1759,1770,2103,2166,2416,2419,2420,2421,2422,2423,2594,2620,2724,2767,2883,3616,3633,3692,3960,4016,4281,4380,4472,4645,4813,5096,5151,5194,5366,5395,6102,6261,6574,6934,6991,7501,7632,7969,8069,8327,8387,8609,8869,9111,9324,9822,9824,9825,9826,9827,9828,9829,9830,9831,9924,10025,10093,10132,10207,10231,10296,10512,10715,10716,10717,10911,10956,11014,11041,11158,11201,11241,11410,11421,11443,11489,11546,12025,12026,12126,12151,12301,12380,12592,12612,12617,12650,12682,12730,12807,12839,12996,13120,13145,13208,13313,13340,13615,13664,13873,13994,14174,14216,14564,15012';
        //$wenshu_catids = '857,901,1213,1382,1649,1757,2101,3448,3545,4335,4547,4763,5217,5220,6255,6582,7011,7870,8873,9243,9244,9245,9852,9857,10104,10479,10514,11170,11433,11490,12149,12590,12628,12783,13337,13874,14175,14544,14994';
        /*
         select group_concat(catid) from fl_category where arrparentid like '%3944%' and catname like '%����' and siteid=1\G;
        select group_concat(catid) from fl_category where arrparentid like '%8852%' and catname like '%����' and siteid=1\G;
        select group_concat(catid) from fl_category where arrparentid like '%888%' and catname like '%����' and siteid=1\G;
        select group_concat(catid) from fl_category where arrparentid like '%5352%' and catname like '%����' and siteid=1\G;
        select group_concat(catid) from fl_category where arrparentid like '%2595%' and catname like '%����' and siteid=1\G;
        select group_concat(catid) from fl_category where arrparentid like '%6554%' and catname like '%����' and siteid=1\G;
        select group_concat(catid) from fl_category where arrparentid like '%1799%' and catname like '%����' and siteid=1\G;
        select group_concat(catid) from fl_category where arrparentid like '%6176%' and catname like '%����' and siteid=1\G;
        select group_concat(catid) from fl_category where arrparentid like '%11946%' and catname like '%����' and siteid=1\G;
        select group_concat(catid) from fl_category where arrparentid like '%4792%' and catname like '%����' and siteid=1\G;
        select group_concat(catid) from fl_category where arrparentid like '%1836%' and catname like '%����' and siteid=1\G;
        select group_concat(catid) from fl_category where arrparentid like '%1810%' and catname like '%����' and siteid=1\G;
        */
        $dongtai_catids = array(
            3944=>array(3945),
            8852=>array(8853,9907),
            888=>array(889,904,905,967,1066,1214,1392,1409,1419),
            5352=>array(5373,5460),
            2595=>array(2703,2884),
            6554=>array(6555,6583,6924,6993),
            1799=>array(1800,1851,2136,2674,3378),
            6176=>array(6243),
            11946=>array(11957,12178),
            4792=>array(4793),
            1836=>array(2867,3456),
            1810=>array(2081,3597)
        );
        $fagui_catids = array(
            3944=>array(3946,3969,15067),
            8852=>array(8875,8964,9906,9923),
            888=>array(891,907,908,927,968,1068,1095,1215,1230,1394,1410,1420),
            5352=>array(5376,7095),
            2595=>array(2704,2756),
            6554=>array(6557,6584,6590,6591,6592,6593,6596,6597,6640,6679,6748,6756,6783,6794,6814,6864,6921),
            1799=>array(1801,1863,1868,1869,1870,1871,1872,1873,1874,1875,1876,1877,1878,1879,1880,1881,1887,1902,2279,2281,2675,2748,3232,3342,3407),
            6176=>array(6244,6288,6290,6437,6538),
            11946=>array(12189),
            4792=>array(4794,4842,4845,4848,4865,4866,4879),
            1836=>array(2868,2905,3443),
            1810=>array(2087,2124)
        );
        $anli_catids = array(
                3944=>array(3959,4079,4093,4094,4095,4096,4097,4098),
                8852=>array(8871,8872,9832,9833,9834,9835,9836,9837,9838,9839,9840,9841,9842,9843,9844,9845,9846,9847,9848,9849,9888,9895,9912),
                888=>array(899,952,1063,1210,1326,1380,1406,1415,1426,1447,1450,1451,1452,1453,1454),
                5352=>array(5396,5562,5640,5687,5757,5777,5803,5847,5870,5883,5922,5987,5996,6021,6058,6062,6070,6072,6082,6097,6125,6136,6143,7096,7098),
                2595=>array(2725,2889,3292,3447,3632,3695,5964),
                6554=>array(6575,6608,6633,6737,6813,6898,6909,6910,6916,6933,6992,7050),
                1799=>array(1826,2138,2383,2384,2385,2388,2391,2392,2393,2394,2395,2396,2397,2398,2399,2400,2401,2402,2403,2404,2405,2406,2407,2408,2409,2410,2411,2412,2413,2414,2415,2774,2776,3230,3238,3239,3240,3355,3396,15149),
                6176=>array(6256,6258,6436,6493,6494,6495,6496,6497,6498,6499,6500,6501,6502,6503,6505,6506,6507,6508,6514),
                11946=>array(11984,12125,12194,12279,12280,12281,12282,12283,12284,12285,12286),
                4792=>array(4804,4912,4973,5074,5097,5098,5099,5100,5101,5126),
                1836=>array(2881,3437,3473,3482),
                1810=>array(2102,3615)
        );
        $lunwen_catids = array(
                3944=>array(3960),
                8852=>array(8869,8870,9111,9822,9824,9825,9826,9827,9828,9829,9830,9831,9924),
                888=>array(902,1064,1211,1379,1407,1416,1446,1460,1461,1462,1463,1464),
                5352=>array(5395),
                2595=>array(2724,3633,3692),
                6554=>array(6574,6934,6991),
                1799=>array(1830,2166,2416,2419,2420,2421,2422,2423,2767),
                6176=>array(6261),
                11946=>array(12026,12126),
                4792=>array(4813,5194),
                1836=>array(2883),
                1810=>array(2103,3616)
        );
        $wenshu_catids = array(
            3944=>array(4547,4763),
            8852=>array(8873,8874,9852,9857),
            888=>array(901,1213,1382),
            5352=>array(),
            2595=>array(),
            6554=>array(6578,6582,7011),
            1799=>array(),
            6176=>array(6255),
            11946=>array(11968),
            4792=>array(4812,5217,5220),
            1836=>array(3448,3545),
            1810=>array(2101)
        );
        $catids = array(
            $dongtai_catids,
            $fagui_catids,
            $anli_catids,
            $lunwen_catids,
            $wenshu_catids,
        );
        
        /*$prof = \Rpc::getData('Zhishi.queryFlCategoryList', 1, 200, array('catid'=>$top_catid));
        print_r($prof);
        $prof = $prof[0];
        $arrchildid = explode(',', $prof['arrchildid']);
        print_r($arrchildid);
        */
        $typecatids = $catids[$cattype][$top_catid];
        return $typecatids;
    }
    
    /**
     * ƽ̨cms ������ҳurl,�޸�Ϊ m վ��url
     * 
     * @param string $url url
     * @param int    $id  ����ҳ��id
     * 
     * @return string
     */
    public function mzsdetailurl($url, $id = null)
    {
        
        
        $urlinfo = parse_url($url);
        
        if (!preg_match('/^\/info/', $urlinfo['path'])) {
            $urlinfo['path'] = '/info' . $urlinfo['path'];
        }

        return "http://m.findlaw.cn{$urlinfo['path']}";
        
        
        //���к���ķ���2015��4��29��  @author whj <weihongjiang@findlaw.cn> �޸� ������ȫ���ҷ�֪ʶ

        if (is_numeric($id)) {
            if (!preg_match('/\/[\d]+\.html/', $urlinfo['path'])) {
                $urlinfo['path'] .= "{$id}.html";
            } else {
                $urlinfo['path'] = preg_replace('/\/[\d]+\.html$/', "/{$id}.html", $urlinfo['path']);
            }
        }
        return "http://m.findlaw.cn{$urlinfo['path']}";
        
        
    }
    
    /**
     * ֪ʶҳ�� url ����
     * 
     * @param string $urlParam url����
     * 
     * @return void
     */
    
    public function zhishiurlDeal($urlParam)
    {
        /**
         * �ٶȣ������pc�˵�url
         * http://china.findlaw.cn/shuofa/shuofadetail/440.html
         * ָ���ƶ��� �����url��
         * http://m.findlaw.cn/info/shuofa/shuofadetail/440.html
         * ������������ر���
         */ 

        $flag = preg_match('/shuofa\/shuofadetail\/[\d]+\.html/', $urlParam, $idstr);
        if ($flag) {
            header('HTTP/1.1 301 Moved Permanently');
            header("Location:" . "http://china.findlaw.cn/" . $urlParam);
        }
    }

}

