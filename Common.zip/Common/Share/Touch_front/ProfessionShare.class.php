<?php
/**
 *  ������Ŀ����ģ��
 *
 *  @author whj <2851026524@qq.com>
 */

namespace Share\Touch_front;

use Share\Touch_front;

/**
 * ������Ŀ����ģ��
 *
 * @author zsg <xxx@qq.com>
 */
class ProfessionShare extends \Parents\ShareCommon
{
    /**
     * ��ȡר��
     *   
     * @return array
     */
    public function getProfession()
    {
        return array(
            array(
                'name'  => '������',
                'child' => array(
                    array(
                        'name'  => '������',
                        'url'   => 'http://m.findlaw.cn/info/hy/list.html',
                        'child' => array(
                            array(
                                'name' => '���',
                                'url'  => 'http://m.findlaw.cn/info/hy/jiehun/list.html',
                            ),
                            array(
                                'name' => '���',
                                'url'  => 'http://m.findlaw.cn/info/hy/lihun/list.html',
                            ),
                            array(
                                'name' => '���޲Ʋ�',
                                'url'  => 'http://m.findlaw.cn/info/hy/caichanfenge/list.html',
                            ),
                            array(
                                'name' => '��Ů����',
                                'url'  => 'http://m.findlaw.cn/info/hy/zinvfuyang/list.html',
                            ),
                            array(
                                'name' => '��ͥ����',
                                'url'  => 'http://m.findlaw.cn/info/hy/jiatingbaoli/list.html',
                            ),
                            array(
                                'name' => '�������',
                                'url'  => 'http://m.findlaw.cn/info/hy/shewaihunyin/list.html',
                            ),
                            array(
                                'name' => '���˻���',
                                'url'  => 'http://m.findlaw.cn/info/hy/jrhy/list.html',
                            ),
                            array(
                                'name' => '�ػ�',
                                'url'  => 'http://m.findlaw.cn/info/hy/chonghun/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '֪ʶ��Ȩ',
                        'url'   => 'http://m.findlaw.cn/info/chanquan/list.html',
                        'child' => array(
                            array(
                                'name' => '�̱귨',
                                'url'  => 'http://m.findlaw.cn/info/chanquan/shangbiaofa/list.html',
                            ),
                            array(
                                'name' => 'ר����',
                                'url'  => 'http://m.findlaw.cn/info/chanquan/zhuanlifa/list.html',
                            ),
                            array(
                                'name' => '����Ȩ��',
                                'url'  => 'http://m.findlaw.cn/info/chanquan/zhuzuoquanfa/list.html',
                            ),
                            array(
                                'name' => '������������',
                                'url'  => 'http://m.findlaw.cn/info/chanquan/fbzdjzf/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '��˾��',
                        'url'   => 'http://m.findlaw.cn/info/gongsifalv/list.html',
                        'child' => array(
                            array(
                                'name' => '��˾����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/gongsishelifa/list.html',
                            ),
                            array(
                                'name' => '��˾����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/shangshi/list.html',
                            ),
                            array(
                                'name' => '��ҵ����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/gaizhizhongzu/qiyegaizhi/list.html',
                            ),
                            array(
                                'name' => '�ɶ�Ȩ��',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/gudongquanyi/list.html',
                            ),
                            array(
                                'name' => '��˾��ɢ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/gongsijiesan/list.html',
                            ),
                            array(
                                'name' => '��˾����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/gongsiqingsuan/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '��ͬ��',
                        'url'   => 'http://m.findlaw.cn/info/hetongfa/list.html',
                        'child' => array(
                            array(
                                'name' => '��ͬ����',
                                'url'  => 'http://m.findlaw.cn/info/hetongfa/hetongdedingli/list.html',
                            ),
                            array(
                                'name' => '��ͬ����',
                                'url'  => 'http://m.findlaw.cn/info/hetongfa/hetongdelvxing/list.html',
                            ),
                            array(
                                'name' => '��ͬ���',
                                'url'  => 'http://m.findlaw.cn/info/hetongfa/hetongdebiangeng/list.html',
                            ),
                            array(
                                'name' => '��ͬת��',
                                'url'  => 'http://m.findlaw.cn/info/hetongfa/hetongdezhuanrang/list.html',
                            ),
                            array(
                                'name' => '��ͬ���',
                                'url'  => 'http://m.findlaw.cn/info/hetongfa/hetongfa/htjc/list.html',
                            ),
                            array(
                                'name' => '��ͬ��ֹ',
                                'url'  => 'http://m.findlaw.cn/info/hetongfa/hetongdezhongzhi/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '�Ͷ�����',
                        'url'   => 'http://m.findlaw.cn/info/laodongfa/list.html',
                        'child' => array(
                            array(
                                'name' => '�Ͷ���ͬ',
                                'url'  => 'http://m.findlaw.cn/info/laodongfa/laodonghetongfa/list.html',
                            ),
                            array(
                                'name' => '�Ͷ��ٲ�',
                                'url'  => 'http://m.findlaw.cn/info/laodongfa/laodongzhongcai/list.html',
                            ),
                            array(
                                'name' => '�Ͷ���ϵ',
                                'url'  => 'http://m.findlaw.cn/info/laodongfa/laodongguanxi/list.html',
                            ),
                            array(
                                'name' => '�Ͷ�����',
                                'url'  => 'http://m.findlaw.cn/info/laodongfa/laodongbaoxian/list.html',
                            ),
                            array(
                                'name' => '�����¹�',
                                'url'  => 'http://m.findlaw.cn/info/laodongfa/gongshangshigu/list.html',
                            ),
                            array(
                                'name' => '���˽��',
                                'url'  => 'http://m.findlaw.cn/info/laodongfa/ctjg/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '���շ�',
                        'url'   => 'http://m.findlaw.cn/info/baoxian/list.html',
                        'child' => array(
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/baoxian/bxlp/list.html',
                            ),
                            array(
                                'name' => '���պ�ͬ',
                                'url'  => 'http://m.findlaw.cn/info/baoxian/baoxianhetong/list.html',
                            ),
                            array(
                                'name' => '���մ���',
                                'url'  => 'http://m.findlaw.cn/info/baoxian/bxdl/list.html',
                            ),
                            array(
                                'name' => '��ᱣ��',
                                'url'  => 'http://m.findlaw.cn/info/baoxian/shbx/list.html',
                            ),
                            array(
                                'name' => 'ʧҵ����',
                                'url'  => 'http://m.findlaw.cn/info/baoxian/shiyebaoxian/list.html',
                            ),
                            array(
                                'name' => '�Ʋ����պ�ͬ',
                                'url'  => 'http://m.findlaw.cn/info/baoxian/cqbx/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '��������',
                        'url'   => 'http://m.findlaw.cn/info/fangdichan/list.html',
                        'child' => array(
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/fangdichan/fangwumaimai/list.html',
                            ),
                            array(
                                'name' => '���ݵ�Ѻ',
                                'url'  => 'http://m.findlaw.cn/info/fangdichan/fangwudiya/list.html',
                            ),
                            array(
                                'name' => '����ָ��',
                                'url'  => 'http://m.findlaw.cn/info/fangdichan/goufangzhinan/list.html',
                            ),
                            array(
                                'name' => '��Ǩ��ʦ',
                                'url'  => 'http://m.findlaw.cn/info/fangdichan/chaiqian/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/fangdichan/fangwuzulin/list.html',
                            ),
                            array(
                                'name' => '���ַ�',
                                'url'  => 'http://m.findlaw.cn/info/fangdichan/qtzsd/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => 'ҽ���¹�',
                        'url'   => 'http://m.findlaw.cn/info/yiliao/list.html',
                        'child' => array(
                            array(
                                'name' => 'ҽ���¹��϶�',
                                'url'  => 'http://m.findlaw.cn/info/yiliao/yldgrd/list.html',
                            ),
                            array(
                                'name' => 'ҽ���¹ʴ���',
                                'url'  => 'http://m.findlaw.cn/info/yiliao/ylsgql/list.html',
                            ),
                            array(
                                'name' => 'ҽ���¹ʼ���',
                                'url'  => 'http://m.findlaw.cn/info/yiliao/yldgjd/list.html',
                            ),
                            array(
                                'name' => 'ҽ���¹��⳥',
                                'url'  => 'http://m.findlaw.cn/info/yiliao/ylsgbc/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => 'ծ��ծȨ',
                        'url'   => 'http://m.findlaw.cn/info/minshang/zwzq/list.html',
                        'child' => array(
                            array(
                                'name' => 'ծȨ',
                                'url'  => 'http://m.findlaw.cn/info/minshang/zwzq/zqrql/list.html',
                            ),
                            array(
                                'name' => 'ծȨת��',
                                'url'  => 'http://m.findlaw.cn/info/minshang/zwzq/zqzr/list.html',
                            ),
                            array(
                                'name' => 'ծ��ת��',
                                'url'  => 'http://m.findlaw.cn/info/minshang/zwzq/zwzr/list.html',
                            ),
                            array(
                                'name' => 'ծ������',
                                'url'  => 'http://m.findlaw.cn/info/minshang/zwzq/zwcz/list.html',
                            ),
                            array(
                                'name' => '���ծ��ծȨ',
                                'url'  => 'http://m.findlaw.cn/info/minshang/zwzq/lhzqzw/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '��ͨ�¹�',
                        'url'   => 'http://m.findlaw.cn/info/jiaotongshigu/list.html',
                        'child' => array(
                            array(
                                'name' => '��ͨ�¹��϶�',
                                'url'  => 'http://m.findlaw.cn/info/jiaotongshigu/jtsgld/list.html',
                            ),
                            array(
                                'name' => '��ͨ�¹�����',
                                'url'  => 'http://m.findlaw.cn/info/jiaotongshigu/jtsgss/list.html',
                            ),
                            array(
                                'name' => '��ͨ�¹ʴ���',
                                'url'  => 'http://m.findlaw.cn/info/jiaotongshigu/jtsgql/list.html',
                            ),
                            array(
                                'name' => '��ͨ�¹��⳥',
                                'url'  => 'http://m.findlaw.cn/info/jiaotongshigu/jtsgpc/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '���⳥',
                        'url'   => 'http://m.findlaw.cn/info/shpc/list.html',
                        'child' => array(
                            array(
                                'name' => '��Ȩ���⳥',
                                'url'  => 'http://m.findlaw.cn/info/shpc/qinquansunhaipeichang/list.html',
                            ),
                            array(
                                'name' => '�������⳥',
                                'url'  => 'http://m.findlaw.cn/info/shpc/jingshensunhaipeichang/list.html',
                            ),
                            array(
                                'name' => '�Ʋ����⳥',
                                'url'  => 'http://m.findlaw.cn/info/shpc/caichansunhaipeichang/list.html',
                            ),
                            array(
                                'name' => '������άȨ',
                                'url'  => 'http://m.findlaw.cn/info/shpc/shpc/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '���ز�Ǩ',
                        'url'   => 'http://m.findlaw.cn/info/fangdichan/fangwuchaiqian/list.html',
                        'child' => array(
                            array(
                                'name' => '���ز���',
                                'url'  => 'http://m.findlaw.cn/info/fangdichan/zhengdibuchang/list.html',
                            ),
                            array(
                                'name' => '��Ǩ����',
                                'url'  => 'http://m.findlaw.cn/info/fangdichan/fangwuchaiqian/cqbc/list.html',
                            ),
                            array(
                                'name' => '��Ǩ����',
                                'url'  => 'http://m.findlaw.cn/info/fangdichan/fangwuchaiqian/cqcx/list.html',
                            ),
                            array(
                                'name' => '��Ǩ����',
                                'url'  => 'http://m.findlaw.cn/info/fangdichan/fangwuchaiqian/cqjf/list.html',
                            ),
                            array(
                                'name' => '��Ǩ����',
                                'url'  => 'http://m.findlaw.cn/info/fangdichan/fangwuchaiqian/zhengce/list.html',
                            ),
                            array(
                                'name' => '���ݲ�Ǩ��Χ',
                                'url'  => 'http://m.findlaw.cn/info/fangdichan/fangwuchaiqian/cqfw/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '�̳з�',
                        'url'   => 'http://m.findlaw.cn/info/hy/jichengfa/list.html',
                        'child' => array(
                            array(
                                'name' => '�����̳�',
                                'url'  => 'http://m.findlaw.cn/info/hy/jichengfa/yizhujc/list.html',
                            ),
                            array(
                                'name' => '�����̳�',
                                'url'  => 'http://m.findlaw.cn/info/hy/jichengfa/fadingjicheng/list.html',
                            ),
                            array(
                                'name' => '�����̳�',
                                'url'  => 'http://m.findlaw.cn/info/hy/jichengfa/fangchanjicheng/list.html',
                            ),
                            array(
                                'name' => '�̳�����',
                                'url'  => 'http://m.findlaw.cn/info/hy/jichengfa/susong/list.html',
                            ),
                            array(
                                'name' => '�̳г���',
                                'url'  => 'http://m.findlaw.cn/info/hy/jichengfa/jccx/list.html',
                            ),
                            array(
                                'name' => '����̳�',
                                'url'  => 'http://m.findlaw.cn/info/hy/jichengfa/shewaijicheng/list.html',
                            ),
                            array(
                                'name' => '��λ�̳�',
                                'url'  => 'http://m.findlaw.cn/info/hy/jichengfa/daiweijicheng/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '������',
                        'url'   => 'http://m.findlaw.cn/info/hy/shouyangfa/list.html',
                        'child' => array(
                            array(
                                'name' => '�����Ǽ�',
                                'url'  => 'http://m.findlaw.cn/info/hy/shouyangfa/sydj/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/hy/shouyangfa/shouyangtiaojian/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/hy/shouyangfa/shouyangshouxu/list.html',
                            ),
                            array(
                                'name' => '��ʵ����',
                                'url'  => 'http://m.findlaw.cn/info/hy/shouyangfa/shishishouyang/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/hy/shouyangfa/shewaishouyang/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name' => '��Ȩ��',
                        'url'  => 'http://m.findlaw.cn/info/wuquanfa/list.html',
                    ),
                    array(
                        'name' => '������',
                        'url'  => 'http://m.findlaw.cn/info/minshang/danbao/list.html',
                    ),
                    array(
                        'name' => '������',
                        'url'  => 'http://m.findlaw.cn/info/jingjifa/paimaifa/list.html',
                    ),
                    array(
                        'name' => '���շ�',
                        'url'  => 'http://m.findlaw.cn/info/hangkongfa/list.html',
                    ),
                    array(
                        'name' => '����׷��',
                        'url'  => 'http://m.findlaw.cn/info/shangzhang/list.html',
                    ),
                    array(
                        'name' => '��ͨ��',
                        'url'  => 'http://m.findlaw.cn/info/minshang/minfa/list.html',
                    ),
                    array(
                        'name' => '��Ȩ���η�',
                        'url'  => 'http://m.findlaw.cn/info/qinquanzerenfa/list.html',
                    ),
                    array(
                        'name' => '�б�Ͷ�귨',
                        'url'  => 'http://m.findlaw.cn/info/jingjifa/zhaobiaotoubiao/list.html',
                    ),
                    array(
                        'name' => '�Ͷ����鷨',
                        'url'  => 'http://m.findlaw.cn/info/laodong/list.html',
                    ),
                ),
            ),
            array(
                'name'  => '������',
                'child' => array(
                    array(
                        'name'  => '����άȨ',
                        'url'   => 'http://m.findlaw.cn/info/xfwq/list.html',
                        'child' => array(
                            array(
                                'name' => '������Ȩ��',
                                'url'  => 'http://m.findlaw.cn/info/xfwq/xiaofeizhedequanyi/list.html',
                            ),
                            array(
                                'name' => '������',
                                'url'  => 'http://m.findlaw.cn/info/xfwq/sanbaofa/list.html',
                            ),
                            array(
                                'name' => 'ʳƷ��ȫ',
                                'url'  => 'http://m.findlaw.cn/info/xfwq/shipinanquan/list.html',
                            ),
                            array(
                                'name' => '��Ʒ����',
                                'url'  => 'http://m.findlaw.cn/info/xfwq/chanpinzhiliang/list.html',
                            ),
                            array(
                                'name' => '�������⳥',
                                'url'  => 'http://m.findlaw.cn/info/xfwq/xiaofeichangshi/shpc/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '�������̾���',
                        'url'   => 'http://m.findlaw.cn/info/fangdichan/jianzhugongcheng/list.html',
                        'child' => array(
                            array(
                                'name' => '�������̹�˾',
                                'url'  => 'http://m.findlaw.cn/info/fangdichan/jianzhugongcheng/jzgs/list.html',
                            ),
                            array(
                                'name' => '��������ʩ��',
                                'url'  => 'http://m.findlaw.cn/info/fangdichan/jianzhugongcheng/gcsg/list.html',
                            ),
                            array(
                                'name' => '������������',
                                'url'  => 'http://m.findlaw.cn/info/fangdichan/jianzhugongcheng/gclww/list.html',
                            ),
                            array(
                                'name' => '�������̰�ȫ',
                                'url'  => 'http://m.findlaw.cn/info/fangdichan/jianzhugongcheng/gcaq/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '��¢�Ϸ�',
                        'url'   => 'http://m.findlaw.cn/info/jingjifa/fldf/list.html',
                        'child' => array(
                            array(
                                'name' => '¢����Ϊ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/fldf/ldxw/list.html',
                            ),
                            array(
                                'name' => '���ʷ�¢��',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/fldf/gjfld/list.html',
                            ),
                            array(
                                'name' => '����������Ϊ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/fldf/jz/bzdjz/list.html',
                            ),
                            array(
                                'name' => '��¢��ָ��',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/fldf/fldzn/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '��˰��',
                        'url'   => 'http://m.findlaw.cn/info/jingjifa/caishuifa/list.html',
                        'child' => array(
                            array(
                                'name' => '��˰����',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/caishuifa/caishuijiufen/list.html',
                            ),
                            array(
                                'name' => '��������˰',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/caishuifa/grsd/list.html',
                            ),
                            array(
                                'name' => '��ҵ����˰',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/caishuifa/qysd/list.html',
                            ),
                            array(
                                'name' => '��˰����',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/caishuifa/ssfz/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => 'ũҵ��',
                        'url'   => 'http://m.findlaw.cn/info/jingjifa/nongyefa/list.html',
                        'child' => array(
                            array(
                                'name' => '���سа���ӪȨ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/nongyefa/nctdzd/tdcbjyg/list.html',
                            ),
                            array(
                                'name' => 'ũ�����سа�',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/nongyefa/nctdzd/nctdcb/list.html',
                            ),
                            array(
                                'name' => 'ũҵ��������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/nongyefa/nyfzs/nyhjbh/list.html',
                            ),
                            array(
                                'name' => 'ũ��Ȩ�汣��',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/nongyefa/nyfzs/nmqybh/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '���з�',
                        'url'   => 'http://m.findlaw.cn/info/jingjifa/yinghanfa/list.html',
                        'child' => array(
                            array(
                                'name' => '��ҵ����	',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/yinghanfa/syyhflzd/list.html',
                            ),
                            array(
                                'name' => '��ҵ���о�Ӫ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/yinghanfa/syyhflzd/syyhjy/list.html',
                            ),
                            array(
                                'name' => '��ҵ���й���',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/yinghanfa/syyhflzd/syyhgl/list.html',
                            ),
                            array(
                                'name' => '���з�֪ʶ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/yinghanfa/yhfzs/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '�۸�',
                        'url'   => 'http://m.findlaw.cn/info/jingjifa/jiagefa/list.html',
                        'child' => array(
                            array(
                                'name' => '�۸���ʽ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/jiagefa/jgxs/list.html',
                            ),
                            array(
                                'name' => '�۸���',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/jiagefa/jgzsptk/jgjc/list.html',
                            ),
                            array(
                                'name' => '�۸��������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/jiagefa/jggltz/list.html',
                            ),
                            array(
                                'name' => '�۸�ල���',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/jiagefa/jgjdjc/list.html',
                            ),
                            array(
                                'name' => '�۸�֪ʶ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/jiagefa/jgfzs/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '������',
                        'url'   => 'http://m.findlaw.cn/info/jingjifa/dianlifa/list.html',
                        'child' => array(
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/dianlifa/dljs/list.html',
                            ),
                            array(
                                'name' => '�����滮',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/dianlifa/dlgh/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/dianlifa/dlsc/list.html',
                            ),
                            array(
                                'name' => '������Ӧ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/dianlifa/dlgyysy/list.html',
                            ),
                            array(
                                'name' => '�����ල���',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/dianlifa/dljdjc/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '���з�',
                        'url'   => 'http://m.findlaw.cn/info/jingjifa/xintuo/list.html',
                        'child' => array(
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/xintuo/xtdsl/list.html',
                            ),
                            array(
                                'name' => '���б��',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/xintuo/xtbgyzz/list.html',
                            ),
                            array(
                                'name' => '���к�ͬ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/xintuo/xtht/list.html',
                            ),
                            array(
                                'name' => '����Ͷ��',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/xintuo/xttz/list.html',
                            ),
                            array(
                                'name' => '���л���',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/xintuo/xtjj/list.html',
                            ),
                            array(
                                'name' => '���з�������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/xintuo/xtflzr/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '��Ʒ�',
                        'url'   => 'http://m.findlaw.cn/info/jingjifa/shenji/list.html',
                        'child' => array(
                            array(
                                'name' => '��Ʒ���',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shenji/sjfl/list.html',
                            ),
                            array(
                                'name' => '��Ʒ���',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shenji/sjff/list.html',
                            ),
                            array(
                                'name' => '��Ƴ���',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shenji/sjcx/list.html',
                            ),
                            array(
                                'name' => '��Ʒ���',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shenji/sjfx/list.html',
                            ),
                            array(
                                'name' => '��Ʒ�������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shenji/sjflzr/list.html',
                            ),
                            array(
                                'name' => '�����������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shenji/sjxzss/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '��Ʒ�',
                        'url'   => 'http://m.findlaw.cn/info/jingjifa/kuaiji/list.html',
                        'child' => array(
                            array(
                                'name' => '���Ҫ��',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/kuaiji/kjys/list.html',
                            ),
                            array(
                                'name' => '��ƴ���',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/kuaiji/kjcl/list.html',
                            ),
                            array(
                                'name' => '��Ƽල',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/kuaiji/kjjd/list.html',
                            ),
                            array(
                                'name' => '��Ʒ�������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/kuaiji/kjflzr/list.html',
                            ),
                            array(
                                'name' => '��Ƶ��㻯',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/kuaiji/kjdsh/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '��淨',
                        'url'   => 'http://m.findlaw.cn/info/jingjifa/guanggao/list.html',
                        'child' => array(
                            array(
                                'name' => '������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/guanggao/ggsc/list.html',
                            ),
                            array(
                                'name' => '�����Ȩ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/guanggao/gghd/ggqq/list.html',
                            ),
                            array(
                                'name' => '�������׼',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/guanggao/scbz/list.html',
                            ),
                            array(
                                'name' => '����ֹ����',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/guanggao/jzqx/list.html',
                            ),
                            array(
                                'name' => '��淨��ʶ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/guanggao/changshi/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '��ϴǮ��',
                        'url'   => 'http://m.findlaw.cn/info/jingjifa/fanxiqianfa/list.html',
                        'child' => array(
                            array(
                                'name' => 'ϴǮ��Ϊ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/fanxiqianfa/xqxw/list.html',
                            ),
                            array(
                                'name' => 'ϴǮ����',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/fanxiqianfa/xqfz/list.html',
                            ),
                            array(
                                'name' => 'ϴǮ������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/fanxiqianfa/xqzlx/list.html',
                            ),
                            array(
                                'name' => '��ϴǮ����',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/fanxiqianfa/fxqdc/list.html',
                            ),
                            array(
                                'name' => '��ϴǮ֪ʶ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/fanxiqianfa/fxqzs/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name' => '������Ȩ',
                        'url'  => 'http://m.findlaw.cn/info/jingjifa/wangluofalv/list.html',
                    ),
                    array(
                        'name' => '�ʲ�����',
                        'url'  => 'http://m.findlaw.cn/info/jingjifa/zichanpaimai/list.html',
                    ),
                    array(
                        'name' => '��������',
                        'url'  => 'http://m.findlaw.cn/info/wuliu/list.html',
                    ),
                    array(
                        'name' => '��ᱣ�Ϸ�',
                        'url'  => 'http://m.findlaw.cn/info/baozhangfa/list.html',
                    ),
                    array(
                        'name' => '��������',
                        'url'  => 'http://m.findlaw.cn/info/jingjifa/dianzishangwufa/list.html',
                    ),
                    array(
                        'name' => '���ױ�����',
                        'url'  => 'http://m.findlaw.cn/info/jingjifa/fuyoubaohufa/list.html',
                    ),
                    array(
                        'name' => '��Ʒ������',
                        'url'  => 'http://m.findlaw.cn/info/chanpinzhiliang/list.html',
                    ),
                    array(
                        'name' => '��������������',
                        'url'  => 'http://m.findlaw.cn/info/jingjifa/jingzheng/list.html',
                    ),
                ),
            ),
            array(
                'name'  => '������',
                'child' => array(
                    array(
                        'name'  => '�����⳥',
                        'url'   => 'http://m.findlaw.cn/info/guojiafa/gjpc/list.html',
                        'child' => array(
                            array(
                                'name' => '�����⳥��Χ',
                                'url'  => 'http://m.findlaw.cn/info/guojiafa/gjpc/gjpcfw/list.html',
                            ),
                            array(
                                'name' => '�����⳥��׼',
                                'url'  => 'http://m.findlaw.cn/info/guojiafa/gjpc/gjpcbz/list.html',
                            ),
                            array(
                                'name' => '�����⳥����',
                                'url'  => 'http://m.findlaw.cn/info/guojiafa/gjpc/gjpccx/list.html',
                            ),
                            array(
                                'name' => '�����⳥������	',
                                'url'  => 'http://m.findlaw.cn/info/guojiafa/gjpc/pcds/pcdl/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '�������ɷ�',
                        'url'   => 'http://m.findlaw.cn/info/xingzheng/xingzhengxuke/list.html',
                        'child' => array(
                            array(
                                'name' => '��������Ȩ',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/xingzhengxuke/xzxkss/xzxkq/list.html',
                            ),
                            array(
                                'name' => '������������',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/xingzhengxuke/xzxksq/list.html',
                            ),
                            array(
                                'name' => '�������ɷ�Χ',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/xingzhengxuke/xzxkfw/list.html',
                            ),
                            array(
                                'name' => '�������ɳ���',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/xingzhengxuke/xzxkcx/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '�������鷨',
                        'url'   => 'http://m.findlaw.cn/info/xingzheng/xingzhengfuyi/list.html',
                        'child' => array(
                            array(
                                'name' => '�������鷶Χ',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/xingzhengfuyi/xzfyfw/list.html',
                            ),
                            array(
                                'name' => '������������',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/xingzhengfuyi/xzfysq/list.html',
                            ),
                            array(
                                'name' => '�����������',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/xingzhengfuyi/fycx/list.html',
                            ),
                            array(
                                'name' => '��������ʱЧ',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/xingzhengfuyi/xzfysx/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '�ΰ�������',
                        'url'   => 'http://m.findlaw.cn/info/xingzheng/zhianchufafa/list.html',
                        'child' => array(
                            array(
                                'name' => '�ΰ���������',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/zhianchufafa/cfcx/list.html',
                            ),
                            array(
                                'name' => '�ΰ�������Χ',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/zhianchufafa/syfw/list.html',
                            ),
                            array(
                                'name' => '�ΰ���������',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/zhianchufafa/zaglcfzl/list.html',
                            ),
                            array(
                                'name' => '�ΰ�����ԭ��',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/zhianchufafa/cftz/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '����������',
                        'url'   => 'http://m.findlaw.cn/info/xingzheng/xzchufa/list.html',
                        'child' => array(
                            array(
                                'name' => '��������Ȩ',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/xzchufa/xzcfq/list.html',
                            ),
                            array(
                                'name' => '������������',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/xzchufa/xzcfzl/list.html',
                            ),
                            array(
                                'name' => '������������',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/xzchufa/xzcfcx/list.html',
                            ),
                            array(
                                'name' => '����������׼',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/xzchufa/xzcfbz/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => 'ʳƷ��ȫ��',
                        'url'   => 'http://m.findlaw.cn/info/jingjifa/shpaq/list.html',
                        'child' => array(
                            array(
                                'name' => 'ʳƷ��ȫ����',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shpaq/spaqfx/list.html',
                            ),
                            array(
                                'name' => '��ҪʳƷ��ȫ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shpaq/zyspaq/list.html',
                            ),
                            array(
                                'name' => 'ʳƷ��ȫ��׼',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shpaq/spaqbzh/list.html',
                            ),
                            array(
                                'name' => 'ʳƷ������Ӫ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shpaq/spscjy/list.html',
                            ),
                            array(
                                'name' => 'ʳƷ����',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shpaq/spjy/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '����������',
                        'url'   => 'http://m.findlaw.cn/info/jingjifa/huanjinbaohu/list.html',
                        'child' => array(
                            array(
                                'name' => '������Ⱦ����',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/huanjinbaohu/wrfz/list.html',
                            ),
                            array(
                                'name' => '��Ⱦ��������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/huanjinbaohu/flzr/list.html',
                            ),
                            array(
                                'name' => '��Ⱦ���ŷű�׼',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/huanjinbaohu/pfbz/list.html',
                            ),
                            array(
                                'name' => '������������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/huanjinbaohu/hjbhws/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '��ȫ������',
                        'url'   => 'http://m.findlaw.cn/info/anquan/list.html',
                        'child' => array(
                            array(
                                'name' => '��ȫ֪ʶ',
                                'url'  => 'http://m.findlaw.cn/info/anquan/aqzs/list.html',
                            ),
                            array(
                                'name' => '��ȫ������׼',
                                'url'  => 'http://m.findlaw.cn/info/anquan/aqscbz/list.html',
                            ),
                            array(
                                'name' => '��ȫ�������',
                                'url'  => 'http://m.findlaw.cn/info/anquan/aqscjc/list.html',
                            ),
                            array(
                                'name' => '��ȫ�¹��⳥',
                                'url'  => 'http://m.findlaw.cn/info/anquan/aqsgpc/list.html',
                            ),
                            array(
                                'name' => '�¹�Ӧ����Ԯ',
                                'url'  => 'http://m.findlaw.cn/info/anquan/sgyjjy/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '����Ա��',
                        'url'   => 'http://m.findlaw.cn/info/guojiafa/gwyf/list.html',
                        'child' => array(
                            array(
                                'name' => '���ҹ���Ա',
                                'url'  => 'http://m.findlaw.cn/info/guojiafa/gwyf/gjgwy/list.html',
                            ),
                            array(
                                'name' => '����Ա����',
                                'url'  => 'http://m.findlaw.cn/info/guojiafa/gwyf/gwyct/list.html',
                            ),
                            array(
                                'name' => '����Ա����',
                                'url'  => 'http://m.findlaw.cn/info/guojiafa/gwyf/gwytx/list.html',
                            ),
                            array(
                                'name' => '����Ա֪ʶ',
                                'url'  => 'http://m.findlaw.cn/info/guojiafa/gwyf/gwyks/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '�����ɹ�',
                        'url'   => 'http://m.findlaw.cn/info/xingzheng/gjcg/list.html',
                        'child' => array(
                            array(
                                'name' => '�����ɹ���ʽ',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/gjcg/zfcgfs/list.html',
                            ),
                            array(
                                'name' => '�����ɹ�����',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/gjcg/zfcgcx/list.html',
                            ),
                            array(
                                'name' => '�����ɹ���ͬ',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/gjcg/zfcght/list.html',
                            ),
                            array(
                                'name' => '�����ɹ�����',
                                'url'  => 'http://m.findlaw.cn/info/xingzheng/gjcg/fvzr/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '��֤��',
                        'url'   => 'http://m.findlaw.cn/info/gongzheng/list.html',
                        'child' => array(
                            array(
                                'name' => '��֤֪ʶ',
                                'url'  => 'http://m.findlaw.cn/info/gongzheng/gzzs/list.html',
                            ),
                            array(
                                'name' => '��֤����',
                                'url'  => 'http://m.findlaw.cn/info/gongzheng/gzcx/list.html',
                            ),
                            array(
                                'name' => '�̳й�֤',
                                'url'  => 'http://m.findlaw.cn/info/gongzheng/jcgz/list.html',
                            ),
                            array(
                                'name' => '������֤',
                                'url'  => 'http://m.findlaw.cn/info/gongzheng/sygz/list.html',
                            ),
                            array(
                                'name' => '���빫֤',
                                'url'  => 'http://m.findlaw.cn/info/gongzheng/zygz/list.html',
                            ),
                            array(
                                'name' => 'ί�й�֤',
                                'url'  => 'http://m.findlaw.cn/info/gongzheng/wtgz/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '���ط�',
                        'url'   => 'http://m.findlaw.cn/info/haiguanfa/list.html',
                        'child' => array(
                            array(
                                'name' => '����֪ʶ',
                                'url'  => 'http://m.findlaw.cn/info/haiguanfa/zhishi/list.html',
                            ),
                            array(
                                'name' => '����ְ��',
                                'url'  => 'http://m.findlaw.cn/info/haiguanfa/hgzn/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/haiguanfa/hgpn/list.html',
                            ),
                            array(
                                'name' => '����ͨ��',
                                'url'  => 'http://m.findlaw.cn/info/haiguanfa/hgtg/list.html',
                            ),
                            array(
                                'name' => '���ع�˰',
                                'url'  => 'http://m.findlaw.cn/info/haiguanfa/hggs/list.html',
                            ),
                            array(
                                'name' => '����˰��',
                                'url'  => 'http://m.findlaw.cn/info/haiguanfa/hgss/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '��ʦ��',
                        'url'   => 'http://m.findlaw.cn/info/lvshi/list.html',
                        'child' => array(
                            array(
                                'name' => '��ʦ�շѱ�׼',
                                'url'  => 'http://m.findlaw.cn/info/findlawyer/shoufei/list.html',
                            ),
                            array(
                                'name' => '��ʦ����Χ',
                                'url'  => 'http://m.findlaw.cn/info/findlawyer/lawsev/list.html',
                            ),
                            array(
                                'name' => '��ʦִҵ�ʸ�',
                                'url'  => 'http://m.findlaw.cn/info/lvshi/lszyzg/list.html',
                            ),
                            array(
                                'name' => '��ʦȨ������',
                                'url'  => 'http://m.findlaw.cn/info/lvshi/qlyyw/list.html',
                            ),
                            array(
                                'name' => '��ʦ��������',
                                'url'  => 'http://m.findlaw.cn/info/lvshi/lsflzr/list.html',
                            ),
                            array(
                                'name' => '��ʦ���ϴ���',
                                'url'  => 'http://m.findlaw.cn/info/lvshi/lsssdl/list.html',
                            ),
                            array(
                                'name' => '�����ϴ���',
                                'url'  => 'http://m.findlaw.cn/info/lvshi/fssdl/list.html',
                            ),
                            array(
                                'name' => '��ʦ����Ȩ��',
                                'url'  => 'http://m.findlaw.cn/info/lvshi/lsddlqx/list.html',
                            ),
                            array(
                                'name' => '��ʦί�д�����ͬ',
                                'url'  => 'http://m.findlaw.cn/info/lvshi/wtdlht/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '�ܷ�',
                        'url'   => 'http://m.findlaw.cn/info/guojiafa/xianfa/list.html',
                        'child' => array(
                            array(
                                'name' => '�����ƶ�',
                                'url'  => 'http://m.findlaw.cn/info/guojiafa/zhidu/list.html',
                            ),
                            array(
                                'name' => '���һ�����֯',
                                'url'  => 'http://m.findlaw.cn/info/guojiafa/jiguanzuzhi/list.html',
                            ),
                            array(
                                'name' => '�ܷ��޸�',
                                'url'  => 'http://m.findlaw.cn/info/guojiafa/xianfa/xiugai/list.html',
                            ),
                            array(
                                'name' => '�ܷ��ƶ�',
                                'url'  => 'http://m.findlaw.cn/info/guojiafa/xianfa/zhiding/list.html',
                            ),
                            array(
                                'name' => '�ܷ�����',
                                'url'  => 'http://m.findlaw.cn/info/guojiafa/xianfa/jieshi/list.html',
                            ),
                            array(
                                'name' => '�ܷ�����',
                                'url'  => 'http://m.findlaw.cn/info/guojiafa/xianfa/shiyong/list.html',
                            ),
                            array(
                                'name' => '�ܷ��ල',
                                'url'  => 'http://m.findlaw.cn/info/guojiafa/xianfa/jiandu/list.html',
                            ),
                            array(
                                'name' => '�ܷ��ṹ',
                                'url'  => 'http://m.findlaw.cn/info/guojiafa/xianfa/jiegou/list.html',
                            ),
                            array(
                                'name' => '�ܷ�ԨԴ',
                                'url'  => 'http://m.findlaw.cn/info/guojiafa/xianfa/yuanyuan/list.html',
                            ),
                            array(
                                'name' => 'Υ�����',
                                'url'  => 'http://m.findlaw.cn/info/guojiafa/xianfa/weixianshencha/list.html',
                            ),
                            array(
                                'name' => '�ܷ�����',
                                'url'  => 'http://m.findlaw.cn/info/guojiafa/xianfa/fenlei/list.html',
                            ),
                        ),
                    ),
                ),
            ),
            array(
                'name'  => '��˾��',
                'child' => array(
                    array(
                        'name'  => '��˾��',
                        'url'   => 'http://m.findlaw.cn/info/gongsifalv/list.html',
                        'child' => array(
                            array(
                                'name' => '��˾����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/gongsishelifa/list.html',
                            ),
                            array(
                                'name' => '��˾����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/shangshi/list.html',
                            ),
                            array(
                                'name' => '�沢�չ�',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/jianbingshougou/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/gaizhizhongzu/list.html',
                            ),
                            array(
                                'name' => '��˾��ɢ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/gongsijiesan/list.html',
                            ),
                            array(
                                'name' => '��˾����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/gongsiqingsuan/list.html',
                            ),
                            array(
                                'name' => '��˾ע��',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/gongsizhuxiao/list.html',
                            ),
                            array(
                                'name' => 'Ͷ��',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/touzi/list.html',
                            ),
                            array(
                                'name' => '����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/rongzi/list.html',
                            ),
                            array(
                                'name' => '��˾����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/gongsizhili/list.html',
                            ),
                            array(
                                'name' => '�ɶ�Ȩ��',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/gudongquanyi/list.html',
                            ),
                            array(
                                'name' => '��˾ծȯ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/gongsizhaiquan/list.html',
                            ),
                            array(
                                'name' => '��Ȩ����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/guquan/list.html',
                            ),
                            array(
                                'name' => '��˾��������',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/falvzeren/list.html',
                            ),
                            array(
                                'name' => '˾��֯����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zuzhijigou/list.html',
                            ),
                            array(
                                'name' => '��ҵ���ɹ���',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/qiyefalvguwen/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '�ϻ���ҵ��',
                        'url'   => 'http://m.findlaw.cn/info/gongsifalv/hhqyf/list.html',
                        'child' => array(
                            array(
                                'name' => '��ͨ�ϻ���ҵ	
                                        ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hhqyf/putong/list.html',
                            ),
                            array(
                                'name' => '���޺ϻ���ҵ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hhqyf/youxian/list.html',
                            ),
                            array(
                                'name' => '���޵ĺϻ���ҵ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hhqyf/yxqy/list.html',
                            ),
                            array(
                                'name' => '�ϻ���ҵ����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hhqyf/putong/sheli/list.html',
                            ),
                            array(
                                'name' => '�ϻ���ҵ��ɢ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hhqyf/qyjs/list.html',
                            ),
                            array(
                                'name' => '�ϻ���ҵ����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hhqyf/qyqs/list.html',
                            ),
                            array(
                                'name' => '�ϻ���ҵ���',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hhqyf/qyrh/list.html',
                            ),
                            array(
                                'name' => '�ϻ���ҵ�˻�',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hhqyf/qyth/list.html',
                            ),
                            array(
                                'name' => '�ϻ�Э��',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hhqyf/hhxy/list.html',
                            ),
                            array(
                                'name' => '���˺ϻ�',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hhqyf/gerenhehuo/list.html',
                            ),
                            array(
                                'name' => '����ϻ���ҵ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hhqyf/tsqy/list.html',
                            ),
                            array(
                                'name' => '�ϻ﷨������',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hhqyf/flzr/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '�Ʋ���',
                        'url'   => 'http://m.findlaw.cn/info/gongsifalv/pochanfa/list.html',
                        'child' => array(
                            array(
                                'name' => '�Ʋ�����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/pochanfa/pcsq/list.html',
                            ),
                            array(
                                'name' => '�Ʋ�����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/pochanfa/pochanchengxu/list.html',
                            ),
                            array(
                                'name' => '�Ʋ�����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/pochanfa/pochanzhongzheng/list.html',
                            ),
                            array(
                                'name' => '�Ʋ��ͽ�',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/pochanfa/pchj/list.html',
                            ),
                            array(
                                'name' => '�Ʋ��Ʋ�',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/pochanfa/pccc/list.html',
                            ),
                            array(
                                'name' => '�Ʋ�����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/pochanfa/pcfy/list.html',
                            ),
                            array(
                                'name' => '�Ʋ�ծȨ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/pochanfa/pczq/list.html',
                            ),
                            array(
                                'name' => '�Ʋ�����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/pochanfa/pochanqingsuan/list.html',
                            ),
                            array(
                                'name' => '�Ʋ�ȡ��Ȩ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/pochanfa/pcqhq/list.html',
                            ),
                            array(
                                'name' => '�Ʋ�����Ȩ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/pochanfa/pccxq/list.html',
                            ),
                            array(
                                'name' => '�Ʋ�����Ȩ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/pochanfa/pcdxq/list.html',
                            ),
                            array(
                                'name' => '�Ʋ����Ȩ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/pochanfa/pcbcq/list.html',
                            ),
                            array(
                                'name' => '�Ʋ�׷��Ȩ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/pochanfa/pczhq/list.html',
                            ),
                            array(
                                'name' => '�Ʋ���������',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/pochanfa/falvzeren/list.html',
                            ),
                            array(
                                'name' => '�Ʋ���ʶ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/pochanfa/pochanleixing/list.html',
                            ),
                            array(
                                'name' => 'ծȨ�˻���',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/pochanfa/zqrhy/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '֤ȯ��',
                        'url'   => 'http://m.findlaw.cn/info/gongsifalv/zhengquanfa/list.html',
                        'child' => array(
                            array(
                                'name' => '֤ȯ֪ʶ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zhengquanfa/zqzs/list.html',
                            ),
                            array(
                                'name' => '֤ȯ����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zhengquanfa/zhengquanfaxing/list.html',
                            ),
                            array(
                                'name' => '֤ȯ����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zhengquanfa/zhengquanchengxiao/list.html',
                            ),
                            array(
                                'name' => '֤ȯ����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zhengquanfa/zhengquanbaojian/list.html',
                            ),
                            array(
                                'name' => '֤ȯ����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zhengquanfa/zhengquanjiaoyi/list.html',
                            ),
                            array(
                                'name' => '֤ȯ��˾',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zhengquanfa/zhengquangongsi/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => 'Ʊ�ݷ�',
                        'url'   => 'http://m.findlaw.cn/info/gongsifalv/piaojufa/list.html',
                        'child' => array(
                            array(
                                'name' => '��Ʊ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/piaojufa/huipiao/list.html',
                            ),
                            array(
                                'name' => '��Ʊ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/piaojufa/bp/list.html',
                            ),
                            array(
                                'name' => '֧Ʊ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/piaojufa/zhipiao/list.html',
                            ),
                            array(
                                'name' => 'Ʊ����Ϊ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/piaojufa/pjxw/list.html',
                            ),
                            array(
                                'name' => '����Ʊ��',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/piaojufa/swpj/list.html',
                            ),
                            array(
                                'name' => '֧Ʊ����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/piaojufa/zpzl/list.html',
                            ),
                            array(
                                'name' => 'Ʊ�ݾ���',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/piaojufa/pjjf/list.html',
                            ),
                            array(
                                'name' => 'Ʊ������',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/piaojufa/pjws/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '����',
                        'url'   => 'http://m.findlaw.cn/info/gongsifalv/jijinfa/list.html',
                        'child' => array(
                            array(
                                'name' => '���������',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/jijinfa/jijinguanliren/list.html',
                            ),
                            array(
                                'name' => '�����й���',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/jijinfa/jijintuoguanren/list.html',
                            ),
                            array(
                                'name' => '����ļ��',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/jijinfa/jijinmuji/list.html',
                            ),
                            array(
                                'name' => '������',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/jijinfa/jijinjiaoyi/list.html',
                            ),
                            array(
                                'name' => '����ݶ�',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/jijinfa/jijinfene/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/jijinfa/jijinyunzuo/list.html',
                            ),
                            array(
                                'name' => '�ල��',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/jijinfa/jianduguanli/list.html',
                            ),
                            array(
                                'name' => '�����ɳ�ʶ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/jijinfa/jijinfalvchangshi/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '���˶���',
                        'url'   => 'http://m.findlaw.cn/info/jingjifa/gerenduzi/list.html',
                        'child' => array(
                            array(
                                'name' => '���˶�����ҵ����',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gerenduzi/grdzqysl/list.html',
                            ),
                            array(
                                'name' => '���˶�����ҵ����˰',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gerenduzi/grdzqysds/list.html',
                            ),
                            array(
                                'name' => '���˶�����ҵ��ɢ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gerenduzi/grdzqyjs/list.html',
                            ),
                            array(
                                'name' => '���˶�����ҵ����',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gerenduzi/grdzqyqs/list.html',
                            ),
                            array(
                                'name' => '���˷�������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gerenduzi/grflzr/list.html',
                            ),
                            array(
                                'name' => '���˶�����ҵ����',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gerenduzi/grdzqyws/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '���ŵ���',
                        'url'   => 'http://m.findlaw.cn/info/gongsifalv/zixindiaocha/list.html',
                        'child' => array(
                            array(
                                'name' => '��ҵ���ŵ���',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zixindiaocha/qyzxdc/list.html',
                            ),
                            array(
                                'name' => '��ҵ���÷���',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zixindiaocha/qyxyfx/list.html',
                            ),
                            array(
                                'name' => '���ŵ����շ�',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zixindiaocha/zxdcsf/list.html',
                            ),
                            array(
                                'name' => '���ŵ�������',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zixindiaocha/zxdczy/list.html',
                            ),
                            array(
                                'name' => '�ŵ�������',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zixindiaocha/zxdcnr/	list.html',
                            ),
                            array(
                                'name' => '���ŵ������',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zixindiaocha/zxdccx/list.html',
                            ),
                            array(
                                'name' => '���ŵ���;��',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zixindiaocha/zxdctj/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '��ҵ����',
                        'url'   => 'http://m.findlaw.cn/info/gongsifalv/zhaoshang/list.html',
                        'child' => array(
                            array(
                                'name' => '��ҵ��������',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zhaoshang/syzslc/list.html',
                            ),
                            array(
                                'name' => '��ҵ����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zhaoshang/qyzs/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zhaoshang/spzs/list.html',
                            ),
                            array(
                                'name' => 'Ͷ�ʴ���',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zhaoshang/tzdk/list.html',
                            ),
                            array(
                                'name' => '���̾���',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zhaoshang/zsjf/list.html',
                            ),
                            array(
                                'name' => '���̺�ͬ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zhaoshang/zsht/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zhaoshang/zsyz/list.html',
                            ),
                            array(
                                'name' => '���ʾ�Ӫ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zhaoshang/hzjy/list.html',
                            ),
                            array(
                                'name' => '������Ӫ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zhaoshang/hzjy/list.html',
                            ),
                            array(
                                'name' => '���̶���',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zhaoshang/wsdz/list.html',
                            ),
                            array(
                                'name' => '����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zhaoshang/rongzi/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zhaoshang/jmzs/list.html',
                            ),
                            array(
                                'name' => '��ҵ���̷�������',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/zhaoshang/syzsflzr/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '�ϻ����',
                        'url'   => 'http://m.findlaw.cn/info/gongsifalv/hehuojiameng/list.html',
                        'child' => array(
                            array(
                                'name' => '�ϻ�Э��',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hehuojiameng/hhxy/list.html',
                            ),
                            array(
                                'name' => '�ϻ��ͬ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hehuojiameng/hhht/list.html',
                            ),
                            array(
                                'name' => '�ϻ����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hehuojiameng/hehuojiufen/list.html',
                            ),
                            array(
                                'name' => '���˺ϻ���ҵ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hehuojiameng/grhhqy/list.html',
                            ),
                            array(
                                'name' => '��ͨ�ϻ���ҵ',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hehuojiameng/pphhqy/list.html',
                            ),
                            array(
                                'name' => '�ϻ���ҵ����',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hehuojiameng/hhqyqs/list.html',
                            ),
                            array(
                                'name' => '�ϻ���ҵ����˰',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hehuojiameng/hhqysds/list.html',
                            ),
                            array(
                                'name' => '�ϻ���ҵ��������˰',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hehuojiameng/hhqygrsds/list.html',
                            ),
                            array(
                                'name' => '˽Ӫ�ϻ���ҵ����˰',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hehuojiameng/syhhqysds/list.html',
                            ),
                            array(
                                'name' => '�ϻ﷨��',
                                'url'  => 'http://m.findlaw.cn/info/gongsifalv/hehuojiameng/fagui/list.html',
                            ),
                        ),
                    ),
                ),
            ),
            array(
                'name'  => '������',
                'child' => array(
                    array(
                        'name'  => '���±绤',
                        'url'   => 'http://m.findlaw.cn/info/bianhu/list.html',
                        'child' => array(
                            array(
                                'name' => '�̷�����',
                                'url'  => 'http://m.findlaw.cn/info/bianhu/xingfazhonglei/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/bianhu/fanzuileixing/list.html',
                            ),
                            array(
                                'name' => '����״̬',
                                'url'  => 'http://m.findlaw.cn/info/bianhu/fzzt/list.html',
                            ),
                            array(
                                'name' => 'ȡ������',
                                'url'  => 'http://m.findlaw.cn/info/bianhu/qubaohoushen/list.html',
                            ),
                            array(
                                'name' => '����绤',
                                'url'  => 'http://m.findlaw.cn/info/bianhu/gezuibianhu/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/bianhu/xsssfzs/list.html',
                            ),
                            array(
                                'name' => '����',
                                'url'  => 'http://m.findlaw.cn/info/bianhu/sixing/list.html',
                            ),
                            array(
                                'name' => '����',
                                'url'  => 'http://m.findlaw.cn/info/bianhu/cqhwzbh/zishou/list.html',
                            ),
                            array(
                                'name' => '����',
                                'url'  => 'http://m.findlaw.cn/info/bianhu/cqhwzbh/ligong/list.html',
                            ),
                            array(
                                'name' => '�̷�����',
                                'url'  => 'http://m.findlaw.cn/info/bianhu/xingfaqingzhong/list.html',
                            ),
                            array(
                                'name' => '���������绤',
                                'url'  => 'http://m.findlaw.cn/info/bianhu/cqhwzbh/list.html',
                            ),
                            array(
                                'name' => '���±绤ָ��',
                                'url'  => 'http://m.findlaw.cn/info/bianhu/bianhuzhinan/list.html',
                            ),
                            array(
                                'name' => '���±绤����',
                                'url'  => 'http://m.findlaw.cn/info/bianhu/bianhujiqiao/list.html',
                            ),
                            array(
                                'name' => '������绤',
                                'url'  => 'http://m.findlaw.cn/info/bianhu/qiangjiezui/list.html',
                            ),
                            array(
                                'name' => '���̱绤',
                                'url'  => 'http://m.findlaw.cn/info/bianhu/sixingbianhu/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '��������',
                        'url'   => 'http://m.findlaw.cn/info/xzss/list.html',
                        'child' => array(
                            array(
                                'name' => '��������֪ʶ',
                                'url'  => 'http://m.findlaw.cn/info/xzss/sszs/list.html',
                            ),
                            array(
                                'name' => '���������ܰ���Χ',
                                'url'  => 'http://m.findlaw.cn/info/xzss/safw/list.html',
                            ),
                            array(
                                'name' => '�������Ϲ�Ͻ',
                                'url'  => 'http://m.findlaw.cn/info/xzss/ssgx/list.html',
                            ),
                            array(
                                'name' => '�������ϲ�����',
                                'url'  => 'http://m.findlaw.cn/info/xzss/sscy/list.html',
                            ),
                            array(
                                'name' => '��������֤��',
                                'url'  => 'http://m.findlaw.cn/info/xzss/sszj/list.html',
                            ),
                            array(
                                'name' => '�������ϳ���',
                                'url'  => 'http://m.findlaw.cn/info/xzss/sscx/list.html',
                            ),
                            array(
                                'name' => '�ϵ���',
                                'url'  => 'http://m.findlaw.cn/info/xzss/sstj/list.html',
                            ),
                            array(
                                'name' => '������Ȩ�⳥',
                                'url'  => 'http://m.findlaw.cn/info/xzss/xzpc/list.html',
                            ),
                            array(
                                'name' => '������������',
                                'url'  => 'http://m.findlaw.cn/info/xzss/swss/list.html',
                            ),
                            array(
                                'name' => '������������',
                                'url'  => 'http://m.findlaw.cn/info/xzss/gyss/list.html',
                            ),
                            array(
                                'name' => '������������',
                                'url'  => 'http://m.findlaw.cn/info/xzss/ssws/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '˾������',
                        'url'   => 'http://m.findlaw.cn/info/sifajianding/list.html',
                        'child' => array(
                            array(
                                'name' => '˾������',
                                'url'  => 'http://m.findlaw.cn/info/sifajianding/sfjd/list.html',
                            ),
                            array(
                                'name' => '˾����������',
                                'url'  => 'http://m.findlaw.cn/info/sifajianding/sfjdfl/list.html',
                            ),
                            array(
                                'name' => '˾����������',
                                'url'  => 'http://m.findlaw.cn/info/sifajianding/sfjdcx/list.html',
                            ),
                            array(
                                'name' => '˾��������',
                                'url'  => 'http://m.findlaw.cn/info/sifajianding/sfjdr/list.html',
                            ),
                            array(
                                'name' => '˾����������',
                                'url'  => 'http://m.findlaw.cn/info/sifajianding/sfjdtz/list.html',
                            ),
                            array(
                                'name' => '˾�������淶',
                                'url'  => 'http://m.findlaw.cn/info/sifajianding/sfjdgf/list.html',
                            ),
                            array(
                                'name' => '˾������������',
                                'url'  => 'http://m.findlaw.cn/info/sifajianding/sfjdsqd/list.html',
                            ),
                            array(
                                'name' => '˾����������',
                                'url'  => 'http://m.findlaw.cn/info/sifajianding/jigou/list.html',
                            ),
                            array(
                                'name' => '˾������ԭ��',
                                'url'  => 'http://m.findlaw.cn/info/sifajianding/sfjdyz/list.html',
                            ),
                            array(
                                'name' => '������֤',
                                'url'  => 'http://m.findlaw.cn/info/sifajianding/jlrz/list.html',
                            ),
                            array(
                                'name' => '�ṹ��֤',
                                'url'  => 'http://m.findlaw.cn/info/sifajianding/jgzz/list.html',
                            ),
                            array(
                                'name' => '�������',
                                'url'  => 'http://m.findlaw.cn/info/sifajianding/jlsc/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '�ٲ�',
                        'url'   => 'http://m.findlaw.cn/info/zhongcai/list.html',
                        'child' => array(
                            array(
                                'name' => '�ٲ�֪ʶ',
                                'url'  => 'http://m.findlaw.cn/info/zhongcai/zczs/list.html',
                            ),
                            array(
                                'name' => '�ٲ�Э��',
                                'url'  => 'http://m.findlaw.cn/info/zhongcai/zcxy/list.html',
                            ),
                            array(
                                'name' => '�ٲó���',
                                'url'  => 'http://m.findlaw.cn/info/zhongcai/zccx/list.html',
                            ),
                            array(
                                'name' => '�ٲòþ�',
                                'url'  => 'http://m.findlaw.cn/info/zhongcai/zccj/list.html',
                            ),
                            array(
                                'name' => '�����ٲòþ�',
                                'url'  => 'http://m.findlaw.cn/info/zhongcai/cxcj/list.html',
                            ),
                            array(
                                'name' => '�����ٲ�',
                                'url'  => 'http://m.findlaw.cn/info/zhongcai/jjzc/list.html',
                            ),
                            array(
                                'name' => '�Ͷ��ٲ�',
                                'url'  => 'http://m.findlaw.cn/info/zhongcai/ldzc/list.html',
                            ),
                            array(
                                'name' => '�����ٲ�',
                                'url'  => 'http://m.findlaw.cn/info/zhongcai/swzc/list.html',
                            ),
                            array(
                                'name' => '�Ͷ��ٲ�',
                                'url'  => 'http://m.findlaw.cn/info/zhongcai/ldzc/list.html',
                            ),
                            array(
                                'name' => '�ٲ�ίԱ��',
                                'url'  => 'http://m.findlaw.cn/info/zhongcai/zcwyh/list.html',
                            ),
                            array(
                                'name' => '�ٲ÷���',
                                'url'  => 'http://m.findlaw.cn/info/zhongcai/zcfb/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => 'ִ��',
                        'url'   => 'http://m.findlaw.cn/info/zhixing/list.html',
                        'child' => array(
                            array(
                                'name' => 'ִ������',
                                'url'  => 'http://m.findlaw.cn/info/zhixing/zhixingshenqing/list.html',
                            ),
                            array(
                                'name' => 'ִ�г���',
                                'url'  => 'http://m.findlaw.cn/info/zhixing/zhixingchengxu/list.html',
                            ),
                            array(
                                'name' => 'ִ�й�Ͻ',
                                'url'  => 'http://m.findlaw.cn/info/zhixing/zhixingguanxia/list.html',
                            ),
                            array(
                                'name' => 'ִ�з���',
                                'url'  => 'http://m.findlaw.cn/info/zhixing/zhixingfeiyong/list.html',
                            ),
                            array(
                                'name' => 'ִ������',
                                'url'  => 'http://m.findlaw.cn/info/zhixing/zhixingyiyi/list.html',
                            ),
                            array(
                                'name' => 'ִ�е���',
                                'url'  => 'http://m.findlaw.cn/info/zhixing/zhixingdanbao/list.html',
                            ),
                            array(
                                'name' => 'ִ�д�ʩ',
                                'url'  => 'http://m.findlaw.cn/info/zhixing/zhixingcuoshi/list.html',
                            ),
                            array(
                                'name' => 'ִ�кͽ�',
                                'url'  => 'http://m.findlaw.cn/info/zhixing/zhixinghejie/list.html',
                            ),
                            array(
                                'name' => '�ָ�ִ��',
                                'url'  => 'http://m.findlaw.cn/info/zhixing/huifuzhixing/list.html',
                            ),
                            array(
                                'name' => '�ս�ִ��',
                                'url'  => 'http://m.findlaw.cn/info/zhixing/zhongjiezhixing/list.html',
                            ),
                            array(
                                'name' => 'ִ�л�ת',
                                'url'  => 'http://m.findlaw.cn/info/zhixing/zhixinghuizhuan/list.html',
                            ),
                            array(
                                'name' => '�ݻ�ִ��',
                                'url'  => 'http://m.findlaw.cn/info/zhixing/zanhuanzhixing/list.html',
                            ),
                            array(
                                'name' => 'ִ�и���',
                                'url'  => 'http://m.findlaw.cn/info/zhixing/zhixinggenju/list.html',
                            ),
                            array(
                                'name' => 'ִ�б��',
                                'url'  => 'http://m.findlaw.cn/info/zhixing/zhixingbiaode/list.html',
                            ),
                            array(
                                'name' => 'ִ����֯',
                                'url'  => 'http://m.findlaw.cn/info/zhixing/zhixingzuzhi/list.html',
                            ),
                            array(
                                'name' => 'ִ�в�����',
                                'url'  => 'http://m.findlaw.cn/info/zhixing/zhixingcanyuren/list.html',
                            ),
                            array(
                                'name' => '����ִ����Ϊ',
                                'url'  => 'http://m.findlaw.cn/info/zhixing/fanghaizhixingxingwei/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '֤��',
                        'url'   => 'http://m.findlaw.cn/info/zhengju/list.html',
                        'child' => array(
                            array(
                                'name' => '��������֤��',
                                'url'  => 'http://m.findlaw.cn/info/zhengju/minssj/list.html',
                            ),
                            array(
                                'name' => '�������Ͼ�֤',
                                'url'  => 'http://m.findlaw.cn/info/zhengju/juzhengqixian/list.html',
                            ),
                            array(
                                'name' => '����������֤',
                                'url'  => 'http://m.findlaw.cn/info/zhengju/zhizheng/list.html',
                            ),
                            array(
                                'name' => '����֤�����',
                                'url'  => 'http://m.findlaw.cn/info/zhengju/zhengjushenhe/list.html',
                            ),
                            array(
                                'name' => '��������֤��',
                                'url'  => 'http://m.findlaw.cn/info/zhengju/xzsszj/list.html',
                            ),
                            array(
                                'name' => '�������ϲ�������',
                                'url'  => 'http://m.findlaw.cn/info/zhengju/caipanyiju/list.html',
                            ),
                            array(
                                'name' => '��������֤��',
                                'url'  => 'http://m.findlaw.cn/info/zhengju/xsszj/list.html',
                            ),
                            array(
                                'name' => '��������֤�����',
                                'url'  => 'http://m.findlaw.cn/info/zhengju/zjscpd/list.html',
                            ),
                            array(
                                'name' => '֤�ݷ��ɳ�ʶ',
                                'url'  => 'http://m.findlaw.cn/info/zhengju/changshi/list.html',
                            ),
                            array(
                                'name' => '֤�����鷶��',
                                'url'  => 'http://m.findlaw.cn/info/zhengju/wsfb/list.html',
                            ),
                        ),
                    ),
                ),
            ),
            array(
                'name'  => '������',
                'child' => array(
                    array(
                        'name'  => '���º���',
                        'url'   => 'http://m.findlaw.cn/info/hshs/list.html',
                        'child' => array(
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/hshs/haishisusong/list.html',
                            ),
                            array(
                                'name' => '���±�ȫ',
                                'url'  => 'http://m.findlaw.cn/info/hshs/haishibaoquan/list.html',
                            ),
                            array(
                                'name' => '���µ���',
                                'url'  => 'http://m.findlaw.cn/info/hshs/hsdb/list.html',
                            ),
                            array(
                                'name' => '���Ѿ���',
                                'url'  => 'http://m.findlaw.cn/info/hshs/hainanjiuzhu/list.html',
                            ),
                            array(
                                'name' => '�����⳥',
                                'url'  => 'http://m.findlaw.cn/info/hshs/haishipeichang/list.html',
                            ),
                            array(
                                'name' => '��������Ȩ',
                                'url'  => 'http://m.findlaw.cn/info/hshs/chuanboyouxianquan/list.html',
                            ),
                            array(
                                'name' => '��������ʱЧ',
                                'url'  => 'http://m.findlaw.cn/info/hshs/haishisusongshixiao/list.html',
                            ),
                            array(
                                'name' => '�������ú�ͬ',
                                'url'  => 'http://m.findlaw.cn/info/hshs/zyht/list.html',
                            ),
                            array(
                                'name' => '�����⴬��ͬ',
                                'url'  => 'http://m.findlaw.cn/info/hshs/zcht/list.html',
                            ),
                            array(
                                'name' => '�⴬���޺�ͬ',
                                'url'  => 'http://m.findlaw.cn/info/hshs/zch/list.html',
                            ),
                            array(
                                'name' => '�����⴬��ͬ',
                                'url'  => 'http://m.findlaw.cn/info/hshs/dzcht/list.html',
                            ),
                            array(
                                'name' => '���������ͬ',
                                'url'  => 'http://m.findlaw.cn/info/hshs/haishanghetong/list.html',
                            ),
                            array(
                                'name' => '�����ϴ���ͬ',
                                'url'  => 'http://m.findlaw.cn/info/hshs/qitahetong/tcht/list.html',
                            ),
                            array(
                                'name' => '���ϱ��պ�ͬ',
                                'url'  => 'http://m.findlaw.cn/info/hshs/haishangbaoxianhetong/list.html',
                            ),
                            array(
                                'name' => '�����ÿ������ͬ',
                                'url'  => 'http://m.findlaw.cn/info/hshs/haishanglvkeyunshuhetong/list.html',
                            ),
                            array(
                                'name' => '���º���֪ʶ',
                                'url'  => 'http://m.findlaw.cn/info/hshs/haishihaishangzhishi/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '����Ͷ��',
                        'url'   => 'http://m.findlaw.cn/info/wstz/list.html',
                        'child' => array(
                            array(
                                'name' => '��ҵ����',
                                'url'  => 'http://m.findlaw.cn/info/wstz/zwqydsl/list.html',
                            ),
                            array(
                                'name' => '��ҵע��',
                                'url'  => 'http://m.findlaw.cn/info/wstz/zwhzjzc/list.html',
                            ),
                            array(
                                'name' => '��ҵ����',
                                'url'  => 'http://m.findlaw.cn/info/wstz/zhongwaihezijingyingqiyeshenpi/list.html',
                            ),
                            array(
                                'name' => '������ҵ',
                                'url'  => 'http://m.findlaw.cn/info/wstz/waiziqiyefa/list.html',
                            ),
                            array(
                                'name' => '���������ҵ',
                                'url'  => 'http://m.findlaw.cn/info/wstz/zwhyf/list.html',
                            ),
                            array(
                                'name' => '���������ҵ',
                                'url'  => 'http://m.findlaw.cn/info/wstz/zwhzjy/list.html',
                            ),
                            array(
                                'name' => '��ҵ��֯����',
                                'url'  => 'http://m.findlaw.cn/info/wstz/zhongwaihezi/list.html',
                            ),
                            array(
                                'name' => '����Ͷ�ʾ���',
                                'url'  => 'http://m.findlaw.cn/info/wstz/tzjf/list.html',
                            ),
                            array(
                                'name' => '����Ͷ��֪ʶ',
                                'url'  => 'http://m.findlaw.cn/info/wstz/waishangtouzizhishi/list.html',
                            ),
                            array(
                                'name' => '����Ͷ������',
                                'url'  => 'http://m.findlaw.cn/info/wstz/wtzizhishi/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '����ó��',
                        'url'   => 'http://m.findlaw.cn/info/jingjifa/gjmyf/list.html',
                        'child' => array(
                            array(
                                'name' => '���ʼ���ó��',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gjmyf/jsmay/list.html',
                            ),
                            array(
                                'name' => '����ó������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gjmyf/liucheng/list.html',
                            ),
                            array(
                                'name' => '���ʻ�������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gjmyf/gjhwysh/list.html',
                            ),
                            array(
                                'name' => '����ó�ױ���',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gjmyf/gjmybx/list.html',
                            ),
                            array(
                                'name' => '����ó�׽���',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gjmyf/jiesuan/list.html',
                            ),
                            array(
                                'name' => '���ʷ���ó��',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gjmyf/fwmy/list.html',
                            ),
                            array(
                                'name' => '����ó�׺�ͬ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gjmyf/gjhwht/list.html',
                            ),
                            array(
                                'name' => '����ó�״���',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gjmyf/mydl/list.html',
                            ),
                            array(
                                'name' => '����ó����թ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gjmyf/myqz/list.html',
                            ),
                            array(
                                'name' => '����ó������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gjmyf/myrz/list.html',
                            ),
                            array(
                                'name' => '����ó������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gjmyf/gjmysy/list.html',
                            ),
                            array(
                                'name' => '��˰',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gjmyf/guanshui/list.html',
                            ),
                            array(
                                'name' => '������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gjmyf/fqx/list.html',
                            ),
                            array(
                                'name' => '������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/gjmyf/fbt/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '�����̼�',
                        'url'   => 'http://m.findlaw.cn/info/baoguanshangjian/list.html',
                        'child' => array(
                            array(
                                'name' => '��˰',
                                'url'  => 'http://m.findlaw.cn/info/baoguanshangjian/guanshui/list.html',
                            ),
                            array(
                                'name' => '���ر���',
                                'url'  => 'http://m.findlaw.cn/info/baoguanshangjian/hgbg/list.html',
                            ),
                            array(
                                'name' => '���ڱ���',
                                'url'  => 'http://m.findlaw.cn/info/baoguanshangjian/jkbg/list.html',
                            ),
                            array(
                                'name' => '���ڱ���',
                                'url'  => 'http://m.findlaw.cn/info/baoguanshangjian/ckbg/list.html',
                            ),
                            array(
                                'name' => '�����̼�',
                                'url'  => 'http://m.findlaw.cn/info/baoguanshangjian/cksj/list.html',
                            ),
                            array(
                                'name' => '�����̼�',
                                'url'  => 'http://m.findlaw.cn/info/baoguanshangjian/jksj/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/baoguanshangjian/bglc/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/baoguanshangjian/bgss/list.html',
                            ),
                            array(
                                'name' => '���ص�֤',
                                'url'  => 'http://m.findlaw.cn/info/baoguanshangjian/bgdz/list.html',
                            ),
                            array(
                                'name' => '���ط�',
                                'url'  => 'http://m.findlaw.cn/info/baoguanshangjian/bgf/list.html',
                            ),
                            array(
                                'name' => '���ص�',
                                'url'  => 'http://m.findlaw.cn/info/baoguanshangjian/bgd/list.html',
                            ),
                            array(
                                'name' => '����Ա',
                                'url'  => 'http://m.findlaw.cn/info/baoguanshangjian/bgy/list.html',
                            ),
                            array(
                                'name' => '�����̼����',
                                'url'  => 'http://m.findlaw.cn/info/baoguanshangjian/bgsjjg/list.html',
                            ),
                            array(
                                'name' => '�����̼취������',
                                'url'  => 'http://m.findlaw.cn/info/baoguanshangjian/bgsjflzr/list.html',
                            ),
                            array(
                                'name' => '����ί����',
                                'url'  => 'http://m.findlaw.cn/info/baoguanshangjian/bgwts/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '��������',
                        'url'   => 'http://m.findlaw.cn/info/yimin/list.html',
                        'child' => array(
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/yimin/ymzl/list.html',
                            ),
                            array(
                                'name' => '�������',
                                'url'  => 'http://m.findlaw.cn/info/yimin/yiminjigou/list.html',
                            ),
                            array(
                                'name' => '����ǩ֤',
                                'url'  => 'http://m.findlaw.cn/info/yimin/yiminqianz/list.html',
                            ),
                            array(
                                'name' => '�������',
                                'url'  => 'http://m.findlaw.cn/info/yimin/yiminfeiy/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/yimin/yinmzc/list.html',
                            ),
                            array(
                                'name' => '���ô�����',
                                'url'  => 'http://m.findlaw.cn/info/yimin/jdym/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/yimin/ayym/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/yimin/mgym/list.html',
                            ),
                            array(
                                'name' => '�¹��������',
                                'url'  => 'http://m.findlaw.cn/info/yimin/dgjhym/list.html',
                            ),
                            array(
                                'name' => '��ѧ����',
                                'url'  => 'http://m.findlaw.cn/info/yimin/lxym/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '������������',
                        'url'   => 'http://m.findlaw.cn/info/jingjifa/fanqingxiaofa/list.html',
                        'child' => array(
                            array(
                                'name' => '������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/fanqingxiaofa/fqx/list.html',
                            ),
                            array(
                                'name' => '����������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/fanqingxiaofa/fqxdc/list.html',
                            ),
                            array(
                                'name' => '��������ʩ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/fanqingxiaofa/qxcx/list.html',
                            ),
                            array(
                                'name' => '������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/fanqingxiaofa/fbt/list.html',
                            ),
                            array(
                                'name' => '����������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/fanqingxiaofa/btdc/list.html',
                            ),
                            array(
                                'name' => '���������������ϴ�ʩ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/fanqingxiaofa/bzcx/list.html',
                            ),
                            array(
                                'name' => '����������������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/fanqingxiaofa/fg/list.html',
                            ),
                        ),
                    ),
                    array(
                        'name'  => '���ⷨ��',
                        'url'   => 'http://m.findlaw.cn/info/jingjifa/shewaifalv/list.html',
                        'child' => array(
                            array(
                                'name' => '�����ͬ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shewaifalv/swht/list.html',
                            ),
                            array(
                                'name' => '����ծ��',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shewaifalv/swzw/list.html',
                            ),
                            array(
                                'name' => '�������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shewaifalv/swhy/list.html',
                            ),
                            array(
                                'name' => '����̳�',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shewaifalv/swjc/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shewaifalv/swsy/list.html',
                            ),
                            array(
                                'name' => '���ⷿ��',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shewaifalv/swfc/list.html',
                            ),
                            array(
                                'name' => '��������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shewaifalv/swss/list.html',
                            ),
                            array(
                                'name' => '�����ٲ�',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shewaifalv/swzc/list.html',
                            ),
                            array(
                                'name' => '���ⷨ������',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shewaifalv/swflsy/list.html',
                            ),
                            array(
                                'name' => '����֪ʶ��Ȩ',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shewaifalv/swzscq/list.html',
                            ),
                            array(
                                'name' => 'WTO����',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shewaifalv/shiwu/list.html',
                            ),
                            array(
                                'name' => '����ó��',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shewaifalv/gjmy/list.html',
                            ),
                            array(
                                'name' => '����Ͷ��',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shewaifalv/jwtz/list.html',
                            ),
                            array(
                                'name' => '����Ͷ��',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shewaifalv/wstz/list.html',
                            ),
                            array(
                                'name' => '���ʲ���',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shewaifalv/wzbg/list.html',
                            ),
                            array(
                                'name' => '���ʺ���',
                                'url'  => 'http://m.findlaw.cn/info/jingjifa/shewaifalv/hzhz/list.html',
                            ),
                        ),
                    ),
                ),
            ),
        );
    }

}