<?php
/**
 *  ������Ŀ����ģ��
 *
 *  @author wrd <xxx@qq.com>
 */
namespace Share\Lawyeradmin_front;
use Share\Lawyeradmin_front;
/**
 * ������Ŀ����ģ��
 *
 * @author wrd <xxx@qq.com>
 */
class FlwltShare extends \Parents\ShareCommon
{
    

    /**
     * ����
     * 
     * @return NULL
     */
    public function test()
    {
        die('test');
    }
    
    /**
     * ����ͨ��ʦ��Ա��Ϣ
     *
     * @param unknown $lawyer_userid lawyer_userid
     *
     * @return array
     */
    public function getWltDetialByUserid($lawyer_userid)
    {
        $wltInfo = \Rpc::getData(array('Wlt.queryWltMemberDetailList', array('H-N'=>'YES')), array('ifaudit'=>1, 'lawyerUserid'=>$lawyer_userid));
        
        if (empty($wltInfo)) {
            return $wltInfo;
        }
        
        $wltInfo = $wltInfo[0];
        
        //���õȼ�
        $wltInfo['creditGrade'] = $this->xinyongToGrade($wltInfo['creditValue']);
        
        //�Ƿ����ô�ʹ  ��7��15����9��15�սɷѵĹ����û���ӵ�С����ô�ʹ����־
        $ds_time_start = strtotime('2013-7-15');
        $ds_time_end = strtotime('2013-9-15');
        
        $wltInfo['isXinyongXF'] = in_array($wltInfo['realName'], $this->xiangfen_lawyers());
        $wltInfo['isXinyongDS'] = $wltInfo['ifauditTime'] > $ds_time_start && $wltInfo['ifauditTime'] < $ds_time_end;
        if ($wltInfo['isXinyongXF']) {
            $wltInfo['isXinyongDS'] = false;
        }
        
        //ѧ��ȡ�÷�ʽ
        $xueliGettype2name = $this->xueliGettypes();
        $wltInfo["xueliGettype"] = isset($xueliGettype2name[$wltInfo["xueliGettype"]]) ? $xueliGettype2name[$wltInfo["xueliGettype"]] : '';
        
        //��ͨ����
        $row = $this->wltKaiTongYear($lawyer_userid);
        $wltInfo['wltYear'] = $row['totalYear'];
        
        $arr[$lawyer_userid] = $wltInfo;
        
        return $arr[$lawyer_userid];
    }
    
    /**
     * ��ѯ��ʦ��ͨ����ͨ����
     *
     * @param unknown $lawyer_userid lawyer_userid
     *
     * @return int
     */
    public function wltKaiTongYear($lawyer_userid)
    {
        $p = array(
            'userid'=>$lawyer_userid,
            'servername'=>'wlt',
            'orderBy' => 'servefirstime asc'
        );
        $list = \Rpc::getData('Member.queryTblmenberserverList', 1, 9999, $p);
    
        if (empty($list)) {
            return array(
                'totalTime'=>0,
                'totalYear'=>1
            );
        }
         
        $arr = array();
    
        foreach ($list as $v) {
    
            if ($v['servefirstime'] >= $v['serveendtime']) {
                continue;
            }
    
            if (empty($arr)) {
                $arr[0] = array($v['servefirstime'], $v['serveendtime']);
            } else {
                $tmp = end($arr);
                if ($v['servefirstime'] <= $tmp[1]) {
                    $arrlen = count($arr);
                    $arr[$arrlen-1][1] = $v['serveendtime'];
                } else {
                    $arr[] = array($v['servefirstime'], $v['serveendtime']);
                }
            }
        }
    
        $totaltime = 0;
        foreach ($arr as $v) {
            $totaltime +=  $v[1] - $v[0];
        }
    
        $r = array(
            'totalTime'=>$totaltime,
            'totalYear'=>ceil($totaltime/20304000)
        );
        if ($r['totalYear'] ==0) {
            $r['totalYear'] = 1;
        }
        return $r;
    }
    
    
    /**
     * �����ȷ���ʦ
     *
     * @return multitype:
     */
    public function xiangfen_lawyers()
    {
        $str = '���հ� ������ ������ ��־ǿ ̷���� ���� ����� ��Ϊ�� ������ ��ƽ�� �鴺�� ����Ȫ ���� �ź��� ������ ����� ���÷ Ӣ���Ŷ�';
        return explode(' ', $str);
    }
    
    /**
     * ����ֵת��Ϊ�ȼ�
     *
     * @param unknown $credit_value credit_value
     *
     * @return number
     */
    public function xinyongToGrade($credit_value)
    {
        $arr = array(
            array(0, 0, 4),
            array(1, 4, 10),
            array(2, 10, 40),
            array(3, 40, 90),
            array(4, 90, 150),
            array(5, 150, 250),
            array(6, 250, 500),
            array(7, 500, 1000),
            array(8, 1000, 2000),
            array(9, 2000, 5000),
            array(10, 5000, 10000),
            array(11, 10000, 20000),
            array(12, 20000, 50000),
            array(13, 50000, 100000),
            array(14, 100000, 200000),
            array(15, 200000, 500000),
            array(16, 500000, 1000000),
            array(17, 1000000, 2000000),
            array(18, 2000000, 5000000),
            array(19, 5000000, 10000000),
            array(20, 10000000, 20000000),
            array(21, 20000000, 50000000),
            array(22, 50000000, 100000000),
            array(23, 100000000, -1),
        );
        foreach ($arr as $v) {
            $s = $v[1];
            $e = $v[2];
            $g = $v[0];
            if ($credit_value>$s && $credit_value<=$e) {
                return $g;
            }
            if ($credit_value>$s && $e==-1) {
                return $g;
            }
        }
        return 0;
    }

    /**
     * ѧ����ȡ��ʽ
     *
     * @return multitype:string
     */
    public function xueliGettypes()
    {
        return array('1'=>'ȫ���Ƹ߿�', '2'=>'�ɽ̸߿�', '3'=>'�Կ�', '4'=>'Զ�̽���', '5'=>'������ѧ');
    }
}

