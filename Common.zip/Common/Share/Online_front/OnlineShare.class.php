<?php
/**
 * ������ѯUrl��Ŀ����ģ��
 *
 * @author wrd <xx@qq.com>
 */
namespace Share\Online_front;
use Share\Online_front;
/**
 *  ������ѯUrl��Ŀ����ģ��
 *
 *  @author wrd <xx@qq.com>
 */
class OnlineShare extends \Parents\ShareCommon
{
    
    public $onlinetime = 1800;
    
    /**
     * �����ֶκ�����ֵ
     *
     * @param type $orderbyCookieName �����cookie����
     * @param bool $isProf            �ǰ�ר��ƥ��
     * 
     * @return array
     */
    public function getOrderBy($orderbyCookieName = 'onlineIndexOrderType', $isProf=false)
    {
        if ($isProf) {
            $profVedictOrder = " b.verdictnum desc, ";
            $orderByArr = array(
                'tuijian' => 'isonline desc, (a.wltflag*1000 + a.lawyertype6*100) desc, '.$profVedictOrder.' (a.wltflag*a.creval) desc, a.preweekaddjifen desc,a.wlttotaltime desc, a.regdate asc',
                'haopin' => 'isonline desc, (a.wltflag*1000 + a.lawyertype6*100) desc, a.goodcommentnum desc, '.$profVedictOrder.' (a.wltflag*a.creval) desc, a.preweekaddjifen desc, a.regdate asc',
                'jifeng_ask' => 'isonline desc, (a.wltflag*1000 + a.lawyertype6*100) desc, a.jifeng_ask desc,'.$profVedictOrder.' (a.wltflag*a.creval) desc, a.preweekaddjifen desc, a.regdate asc',
                'help' => 'isonline desc, (a.wltflag*1000 + a.lawyertype6*100) desc, a.online_ans desc, '.$profVedictOrder.' (a.wltflag*a.creval) desc, a.preweekaddjifen desc, a.regdate asc'
            );
            $orderByArr['tuijianlvshi'] = $orderByArr['tuijian'];
        } else {
            $orderByArr = array(
                'tuijian' => 'isonline desc, (a.wltflag*1000 + a.lawyertype6*100) desc, (a.wltflag*a.creval) desc, a.preweekaddjifen desc,a.wlttotaltime desc, a.regdate asc',
                'haopin' => 'isonline desc, (a.wltflag*1000 + a.lawyertype6*100) desc, a.goodcommentnum desc, (a.wltflag*a.creval) desc, a.preweekaddjifen desc, a.regdate asc',
                'jifeng_ask' => 'isonline desc, (a.wltflag*1000 + a.lawyertype6*100) desc, a.jifeng_ask desc, (a.wltflag*a.creval) desc, a.preweekaddjifen desc, a.regdate asc',
                'help' => 'isonline desc, (a.wltflag*1000 + a.lawyertype6*100) desc, a.online_ans desc, (a.wltflag*a.creval) desc, a.preweekaddjifen desc, a.regdate asc'
            );
            $orderByArr['tuijianlvshi'] = $orderByArr['tuijian'];
        }
        $orderType  = isset($_COOKIE[$orderbyCookieName]) ? $_COOKIE[$orderbyCookieName] : 'tuijian';
        $orderBy    = isset($orderByArr[$orderType]) ? $orderByArr[$orderType] : '';
        return array(
            $orderType,
            $orderBy
        );
    }
    
    /**
     * ��ʦ������ҳ--��ʦ�����б�
     *
     * @param int     $page          ��ǰҳ
     * @param int     $pageSize      ÿҳ��ʾ��
     * @param int     $areacodeBegin areacodeBegin
     * @param int     $areacodeEnd   areacodeEnd
     * @param string  $orderBy       "jifeng_all desc"---��ʦ��������
     *                               "supportcount desc"---����������
     *                               "jifeng_ask desc"---���Ļ�������
     *                               "online_ans desc"---������������
     * @param boolean $getCount      �Ƿ��ȡͳ����
     *
     * @return Array
     */
    public function queryOnlineLawyerList($page, $pageSize, $areacodeBegin, $areacodeEnd, $orderBy = 'jifeng_all', $getCount = false)
    {
        $p = array();
        if ($areacodeBegin > 0) {
            $p['areacodeBegin'] = $areacodeBegin;
        }
        if ($areacodeEnd > 0) {
            $p['areacodeEnd'] = $areacodeEnd;
        }
        $p['orderBy']    = $orderBy ? $orderBy : 'jifeng_all';
        $p['lastdodate'] = time() - $this->onlinetime;
        $p['lastdodateflag'] = 1;
        $p['lawyertype6'] = 1;
        $list            = $this->queryOnlineLawyer($page, $pageSize, $p);
        $list = \Tools\Ads::get_ad_file($list);
        if ($getCount) {
            unset($p['orderBy']);
            unset($p['lastdodate']);
            unset($p['lastdodateflag']);
            $count = \Rpc::getData('LawyerOnline.queryLawyerOnlineListCount', $p);
            return array(
                'list' => $list,
                'count' => $count
            );
        }
        return $list;
    }
    
    
    
    /**
     * ��ʦ�����б�
     *
     * @param type $page     desc
     * @param type $pageSize desc
     * @param type $p        desc
     *
     * @return array
     */
    protected function queryOnlineLawyer($page, $pageSize, $p)
    {
        if ($p['profession']!='') {
            return $this->queryCatOnlineLawyer($page, $pageSize, $p);
        }
        $p['useridsOrderFlag'] = 0;
        if (isset($_GET['db'])) {
            print_r($p);
        }
        if (isset($p['userids'])) {
            if (empty($p['userids'])) {
                unset($p['userids']);
            }
        }
        $list = \Rpc::getData('LawyerOnline.queryOnlineLawyer', $page, $pageSize, $p);
        $relist = array();
        if (empty($list)) {
            return $list;
        }
        $tmp_useridarr = array();    //����ȥ��
        foreach ($list as $k => $v) {
            $LawyerMessage = $v['LawyerMessage'];
            $row           = array();
            if (empty($LawyerMessage['username'])) {
                continue;
            }
    
            //ȥ��
            if (!in_array($LawyerMessage['userid'], $tmp_useridarr)) {
                $tmp_useridarr[] = $LawyerMessage['userid'];
            } else {
                continue;
            }
    
            $row['id']           = $LawyerMessage['id'];
            $row['yuming']       = $LawyerMessage['yuming'];
            $row['photo']        = $LawyerMessage['photo'];
            $row['membertype']   = $LawyerMessage['membertype'];
            $row['username']     = $LawyerMessage['username'];
            $row['userid']       = $LawyerMessage['userid'];
            $row['province']     = $LawyerMessage['province'];
            $row['city']         = $LawyerMessage['city'];
            $row['profession']   = $LawyerMessage['profession'];
            $row['lawerroom']    = $LawyerMessage['lawerroom'];
            $row['addr']         = $LawyerMessage['addr'];
            $row['jifengAsk']    = $LawyerMessage['jifengAsk'];
            $row['supportcount'] = $v['supportcount']; //������
            $row['goodcommentnum'] = $v['goodcommentnum']; //�°������
            $row['online_ans']   = $v['onlineAns']; //��������
            $row['mobil']        = $LawyerMessage['mobil'] ? \Tools\Strings::cut_str($LawyerMessage['mobil'], 11) : \Tools\Strings::cut_str($LawyerMessage['tel'], 13);
            $row['islxt']        = $v['islxt'];
            $row['isonline']     = $v['isonline'] == 1 ? 2 : 1;
            $relist[]            = $row;
        }
        return \Tools\Url::get_site_url($relist);
    }
    
    
    /**
     * ��ʦר�������б�
     *
     * @param type $page     desc
     * @param type $pageSize desc
     * @param type $p        desc
     *
     * @return array xxx
     */
    public function queryCatOnlineLawyer($page, $pageSize, $p)
    {
        //ר�����ش��� ���������queryOnlineLawyer
        if (empty($p['profession'])) {
            return array();
        }
        $params = array(
            'lastdodate'=>time() - $this->onlinetime,
            'profession'=>$p['profession'],
            'profname'=>$p['profession'],
            'lawyertype6'=>1,
            'orderBy'=>$p['orderBy']
        );
        $params = array_merge($p, $params);
        if (isset($params['userids'])) {
            if (empty($params['userids'])) {
                unset($params['userids']);
            }
        }
        $list = \Rpc::getData('LawyerOnline.queryOnlineListMap', $page, $pageSize, $params);
        
        $relist = array();
        foreach ($list as $k => $v) {
            $LawyerMessage = $v['LawyerMessage'];
            $row           = array();
            if (empty($LawyerMessage['username'])) {
                continue;
            }
            $row['id']           = $LawyerMessage['id'];
            $row['yuming']       = $LawyerMessage['yuming'];
            $row['photo']        = $LawyerMessage['photo'];
            $row['membertype']   = $LawyerMessage['membertype'];
            $row['username']     = $LawyerMessage['username'];
            $row['userid']       = $LawyerMessage['userid'];
            $row['province']     = $LawyerMessage['province'];
            $row['city']         = $LawyerMessage['city'];
            $row['profession']   = $LawyerMessage['profession'];
            $row['lawerroom']    = $LawyerMessage['lawerroom'];
            $row['addr']         = $LawyerMessage['addr'];
            $row['jifengAsk']    = $LawyerMessage['jifengAsk'];
            $row['supportcount'] = $v['supportcount']; //������
            $row['goodcommentnum'] = $v['goodcommentnum']; //�°������
            $row['online_ans']   = $v['online_ans']; //��������
            $row['mobil']        = $LawyerMessage['mobil'] ? \Tools\Strings::cut_str($LawyerMessage['mobil'], 11) : \Tools\Strings::cut_str($LawyerMessage['tel'], 13);
            $row['islxt']        = $v['islxt'];
            $row['isonline']     = $v['isonline'] == 1 ? 2 : 1;
            $relist[]            = $row;
        }
        return \Tools\Url::get_site_url($relist);
    }
 
}
