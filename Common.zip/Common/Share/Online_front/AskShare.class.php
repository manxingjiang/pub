<?php
/**
 * һ��һ������ѯ��Ŀ����ģ��
 *
 * @author wrd <xx@qq.com>
 */
namespace Share\Online_front;
use Share\Online_front;
/**
 *  һ��һ������ѯ��Ŀ����ģ��
 *
 *  @author wrd <xx@qq.com>
 */
class AskShare extends \Parents\ShareCommon
{
    
    /**
     * ����һ��һ��ѯ
     * 
     * @param string $qtitle        title
     * @param string $qcontent      content
     * @param array  $lawyeruserids ��ʦuserid����
     * @param int    $mobile        �ֻ���
     * @param string $frompage      ��Դҳ��
     * @param number $jifeng        ����
     * @param number $iswrite       ��Դ��� 
     * 
     * @return array  state;   //״̬���� ��01�� �����ɹ� "02" �û��Ѵ���  "03" ��������ע���û�  04�û����ֲ��������ͻ���
     * @author wrd
     */
    public function pubonlineask($qtitle, $qcontent, $lawyeruserids, $mobile = '', $frompage = '001', $jifeng = 0, $iswrite = 0)
    {
        if (empty($qtitle) || empty($qcontent)|| empty($lawyeruserids)) {
            return array('state' => '11', 'msg' => '�Ƿ��ύ');
        }
        //����
        $qtitle = \Tools\Strings::filterStr($qtitle);
        $qcontent = \Tools\Strings::filterStr($qcontent);
        $nickname = \Tools\Strings::filterStr($nickname);
        $frompage = \Tools\Strings::filterStr($frompage);
        if (!\Tools\Validate::isMobil($mobile)) {
            $tel = $mobile;
            $mobile = '';
        }
        $areainfo = \Tools\Iparea::getIpReviseArea();
        if (!\Tools\User::isLogin()) {
            //�Զ�ע���ʺ�
            $choiceRegData = array();
            if ($mobile) {
                $choiceRegData['mobil'] = $mobile;
            }
            if ($areainfo['areacode'] > 0) {
                $choiceRegData['areacode'] = $areainfo['areacode'];
            } elseif (isset($_COOKIE['areainfo']['areacode'])) {
                $choiceRegData['areacode'] = $_COOKIE['areainfo']['areacode'];
            }
            $ob = new \Tools\AutoLogin;
            $flag = $ob->autoreg_leo($choiceRegData);
            $uinfo = $ob->userinfo;
            
            //���ֻ���
            if (!empty($choiceRegData['mobil'])) {
                $bindinfo = array(
                    'uid' => $uinfo['uid'],
                    'userid' => $uinfo['userid'],
                    'mobile' => $choiceRegData['mobil'],
                    'usertype' => 2
                );
                \Tools\UserManage::bindMobile($bindinfo);
            }
            //�Զ���¼
            //��¼�û�����-�����¼��Ϣ
            $UcLogin = new \Tools\UcLogin();
            $cookietime = 86400 * 7;
            $UcLogin->userIdentSave($uinfo['uid'], $uinfo['userid'], $uinfo['psw'], '', $cookietime, array(1, 2, 3));
        } else {
            if (\Tools\User::isLawyer()) {
                return array('state' => '12', 'msg' => '�Բ���,������������ʦ������ѯ��');
            }
            $uinfo = \Tools\User::currUser();
        }
        
        $mobile && $uinfo['mobile'] = $mobile;
        
        //ȡ��ѯ��ʦ��Ϣ
        $lawyerinfo = \Tools\UserManage::getLawyerByUserid($lawyeruserids);
        $lawyeruids = array();
        $lawyeruserids = array();
        $lawyerusernames = array();
        foreach ($lawyerinfo as $k => $val) {
            if (!empty($val)) {
                $lawyeruids[] = $val['id'];
                $lawyeruserids[] = $val['userid'];
                $lawyerusernames[] = $val['username']; 
            }
        }
        //���˹ؼ���
        $illegalkeywords = ''; //�Ƿ��ؼ���,Ĭ��Ϊ��
        $mgkeys          = \Tools\Split::existsMgWord($qtitle . $qcontent);
        if ($mgkeys != false) {
            $illegalkeywords = $mgkeys;
        }
        
        //��ѯ����
        $data = array();
        $data['regflag']         = 0; //Ϊ0��ͨ����ѯ�ӿ�ע��
        $data['title']           = $qtitle;
        $data['content']         = $qcontent;
        $data['leoid']           = $uinfo['uid'];
        $data['leouserid']       = $uinfo['userid'];
        $data['leousername']     = $uinfo['username'];
        $data['frompage']        = $frompage; //001 ��ʦ������ҳ���
        $data['iswrite']         = $iswrite; //0 �ⲿpc��վ, 1 �ڲ�,  2wap �ֻ�¼��, 3�ֻ�����Ϣ¼��, 4 �ֻ�appӦ��
        $data['lawyerid']        = $lawyeruids;
        $data['lawyeruserid']    = $lawyeruserids;
        $data['lawyerusername']  = $lawyerusernames;
        $data['jifeng']          =  $jifeng;
        $data['province']        = empty($areainfo['province']) ? '' : $areainfo['province'];
        $data['city']            = empty($areainfo['city']) ? '' : $areainfo['city'];
        $data['country']         = empty($areainfo['country']) ? '' : $areainfo['country'];
        $data['areacode']        = $areainfo['areacode'];
        $data['illegalkeywords'] = $illegalkeywords;
        $data['email']           = '';
        $data['tel']             = $tel;
        $data['mobile']          = $mobile;
        $data['qq']              = '';
        $data['leoip']           = str_replace('.', '', $_SERVER['REMOTE_ADDR']);
        $data['encode_ip']       = ip2long(str_replace('.', '', $_SERVER['REMOTE_ADDR']));

        $askinfo = \Rpc::getData('Online.Admin.insertAskOnline', $data);
        $askinfo = array_merge($askinfo, $uinfo);
        return $askinfo;
    }
    

}
