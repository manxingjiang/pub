<?php
/**
 * ������ѯUrl��Ŀ����ģ��
 *
 * @author wrd <xx@qq.com>
 */
namespace Share\Online_front;
use Share\Online_front;
/**
 *  ������ѯUrl��Ŀ����ģ��
 *
 *  @author wrd <xx@qq.com>
 */
class UrlShare extends \Parents\ShareCommon
{
    /**
     * 301ת��
     *
     * @return type
     */
    public function url301()
    {
        $uri      = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        $list_301 = array(
            'http://china.findlaw.cn/china/index.php',
            'http://china.findlaw.cn/china/',
            'http://china.findlaw.cn/china',
            'http://china.findlaw.cn/online'
        );
        if (in_array($uri, $list_301)) {
            header('HTTP/1.1 301 Moved Permanently');
            header("Location:http://china.findlaw.cn/online/");
            exit();
        }
    } 
    
    /**
     * ʡ�������б�, �Ӿɰ�ҳ��ģ������ȡ,  ���ڵ�������δѡ�����ʱ��ʾ��Ĭ�ϵ����б�
     *
     * @return array
     */
    public function provinceList()
    {
        return array(
            0 => array(
                'url' => 'http://china.findlaw.cn/online/anhui/',
                'name' => '����'
            ),
            1 => array(
                'url' => 'http://china.findlaw.cn/online/aomen/',
                'name' => '����'
            ),
            2 => array(
                'url' => 'http://china.findlaw.cn/online/beijing/',
                'name' => '����'
            ),
            3 => array(
                'url' => 'http://china.findlaw.cn/online/chongqing/',
                'name' => '����'
            ),
            4 => array(
                'url' => 'http://china.findlaw.cn/online/fujian/',
                'name' => '����'
            ),
            5 => array(
                'url' => 'http://china.findlaw.cn/online/gansu/',
                'name' => '����'
            ),
            6 => array(
                'url' => 'http://china.findlaw.cn/online/guangdong/',
                'name' => '�㶫'
            ),
            7 => array(
                'url' => 'http://china.findlaw.cn/online/guangxi/',
                'name' => '����'
            ),
            8 => array(
                'url' => 'http://china.findlaw.cn/online/guizhou/',
                'name' => '����'
            ),
            9 => array(
                'url' => 'http://china.findlaw.cn/online/hainan/',
                'name' => '����'
            ),
            10 => array(
                'url' => 'http://china.findlaw.cn/online/hebei/',
                'name' => '�ӱ�'
            ),
            11 => array(
                'url' => 'http://china.findlaw.cn/online/henan/',
                'name' => '����'
            ),
            12 => array(
                'url' => 'http://china.findlaw.cn/online/heilongjiang/',
                'name' => '������'
            ),
            13 => array(
                'url' => 'http://china.findlaw.cn/online/hubei/',
                'name' => '����'
            ),
            14 => array(
                'url' => 'http://china.findlaw.cn/online/hunan/',
                'name' => '����'
            ),
            15 => array(
                'url' => 'http://china.findlaw.cn/online/jl/',
                'name' => '����'
            ),
            16 => array(
                'url' => 'http://china.findlaw.cn/online/jiangsu/',
                'name' => '����'
            ),
            17 => array(
                'url' => 'http://china.findlaw.cn/online/jiangxi/',
                'name' => '����'
            ),
            18 => array(
                'url' => 'http://china.findlaw.cn/online/liaoning/',
                'name' => '����'
            ),
            19 => array(
                'url' => 'http://china.findlaw.cn/online/neimenggu/',
                'name' => '���ɹ�'
            ),
            20 => array(
                'url' => 'http://china.findlaw.cn/online/ningxia/',
                'name' => '����'
            ),
            21 => array(
                'url' => 'http://china.findlaw.cn/online/qinghai/',
                'name' => '�ຣ'
            ),
            22 => array(
                'url' => 'http://china.findlaw.cn/online/shanghai/',
                'name' => '�Ϻ�'
            ),
            23 => array(
                'url' => 'http://china.findlaw.cn/online/shandong/',
                'name' => 'ɽ��'
            ),
            24 => array(
                'url' => 'http://china.findlaw.cn/online/shanxi/',
                'name' => 'ɽ��'
            ),
            25 => array(
                'url' => 'http://china.findlaw.cn/online/shanxi2/',
                'name' => '����'
            ),
            26 => array(
                'url' => 'http://china.findlaw.cn/online/sichuan/',
                'name' => '�Ĵ�'
            ),
            27 => array(
                'url' => 'http://china.findlaw.cn/online/shenyang/',
                'name' => '����'
            ),
            28 => array(
                'url' => 'http://china.findlaw.cn/online/tianjin/',
                'name' => '���'
            ),
            29 => array(
                'url' => 'http://china.findlaw.cn/online/taiwan/',
                'name' => '̨��'
            ),
            30 => array(
                'url' => 'http://china.findlaw.cn/online/xizang/',
                'name' => '����'
            ),
            31 => array(
                'url' => 'http://china.findlaw.cn/online/xinjiang/',
                'name' => '�½�'
            ),
            32 => array(
                'url' => 'http://china.findlaw.cn/online/xianggang/',
                'name' => '���'
            ),
            33 => array(
                'url' => 'http://china.findlaw.cn/online/yunnan/',
                'name' => '����'
            ),
            34 => array(
                'url' => 'http://china.findlaw.cn/online/zhejiang/',
                'name' => '�㽭'
            )
        );
    }
 
}
