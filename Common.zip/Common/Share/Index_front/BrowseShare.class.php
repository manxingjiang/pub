<?php
/**
 *    �ҷ���ҳ����ģ��
 *
 *    @author xx <xx@qq.com>
 */
namespace Share\Index_front;
use Share\Index_front;
/**
 *  �ҷ���ҳ����ģ��
 *
 *  @author xx <xx@qq.com>
 */
class BrowseShare extends \Parents\ShareCommon
{
    /**
     * header�������������
     * 
     * @param int $time ���û���ʱ�� ��λ��
     * 
     * @return null
     */
    public function setbrowsecache($time)
    {
        $expires = 60 * $time;
        header("Content-Type:text/html; charset=gbk");
        header("Cache-Control: public");
        header("Pragma: public");
        header("Cache-Control: must-revalidate, proxy-revalidate, max-age=".$expires.", max-stale=".$expires);
        header("Expires: " . gmdate('D, d M Y H:i:s', $_SERVER['REQUEST_TIME'] + $expires) . ' GMT');
        header("Last-Modified: " .gmdate('D, d M Y H:i:s', $_SERVER['REQUEST_TIME']). " GMT");
        header("ETag: " . dechex($_SERVER['REQUEST_TIME']));
    }
    /**
     *    ��ȡ��ǰ���ʵ� URL
     *
     *    @param boolean $urlEncode �Ƿ���Ҫ����url����
     *
     *    @return string
     */
    public function getCurrUrl($urlEncode = false)
    {
        $pageUrl = '';
        $pageUrl = (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] == 'on') ? 'https' : 'http';
        $pageUrl .= '://';

        if ($_SERVER["SERVER_PORT"] != "80") {
            $pageUrl .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
        } else {
            $pageUrl .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
        }
        if ($urlEncode) {
            $pageUrl = urlencode($pageUrl);
        }
        return $pageUrl;
    }
}
