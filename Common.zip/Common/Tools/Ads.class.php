<?php
/**
 *  ��湤����
 *
 *  @author zsg <xxx@qq.com>
 *
 */
namespace Tools;
use Tools;
/**
 *  ��湤����
 *
 *  @author zsg <xxx@qq.com>
 */
class Ads
{
    /**
     * ��ȡtblmember_file����64X64 80X98 110X135���ֳߴ��ͼƬ��Ϣ
     *
     * @param array $info_arr ���⴫�������
     *
     * @return array ��������
     */
    public static function get_ad_file($info_arr)
    {
        $uids = array();
        foreach ($info_arr as $key => $val) {
            if (!empty($val['uid'])) {
                $uids[]    = $val['uid'];
            } 
        }
        if ($uids) {
            $files_key = 'queryTblMemberFileByUserids'.\Tools\Cache::hash($uids);
            if (!$_GET['nocache']) {
                $files = \Tools\Cache::get($files_key);
            }
            if (!$files) {
                $files = \Rpc::getUCData("Member.queryUcLawyerFileList", $uids);
                \Tools\Cache::set($files_key, $files, rand(300, 600));
            }
            $files = \Tools\Arr::setDataAsKey($files, 'uid');
            foreach ($info_arr as $key => $val) {
                if (!empty($val['uid'])) {
                    $uid = $val['uid'];
                } else {
                    $uid = 0;
                }
                if (isset($files[$uid])) {
                    $filelist = $files[$uid];
                    $info_arr[$key]['img_link']  = $val['link'] ? $val['link'] : $val['yuming'];
                    $info_arr[$key]['img_photo'] = $val['file0'] ? $val['file0'] : $val['photo'];
                    //20X20ͼƬ
                    $file20                      = $filelist['file2020'];
                    if (!empty($file20)) {
                        $info_arr[$key]['file2020'] = $file20;
                    } else {
                        $info_arr[$key]['file2020'] = '';
                    }
                    $info_arr[$key]['file2020'] = Image::getLawyerImgPath($info_arr[$key], 20); 
                    //44X44ͼƬ
                    $file44 = $filelist['file4444'];
                    if (!empty($file44)) {
                        $info_arr[$key]['file4444'] = $file44;
                        $info_arr[$key]['file4444'] = Image::getLawyerImgPath($info_arr[$key], 44);
                    } else if ($filelist['photo']) {
                        $info_arr[$key]['file4444'] = Image::imagesReplace('/my/photo/'.$filelist['photo']);
                    } else {
                        $info_arr[$key]['file4444'] = '';
                        $info_arr[$key]['file4444'] = Image::getLawyerImgPath($info_arr[$key], 44);
                    }
                    //64X64ͼƬ
                    $file64 = $filelist['file6464'];
                    if (!empty($file64)) {
                        $info_arr[$key]['file6464'] = $file64;
                        $info_arr[$key]['file6464'] = Image::getLawyerImgPath($info_arr[$key], 64);
                    } else if ($filelist['photo']) {
                        $info_arr[$key]['file6464'] = Image::imagesReplace('/my/photo/'.$filelist['photo']);
                    } else {
                        $info_arr[$key]['file6464'] = '';
                        $info_arr[$key]['file6464'] = Image::getLawyerImgPath($info_arr[$key], 64);
                    }
                    //80X98ͼƬ
                    $file80 = $filelist['file8098'];
                    if (!empty($file80)) {
                        $info_arr[$key]['file8098'] = $file80;
                        $info_arr[$key]['file8098'] = Image::getLawyerImgPath($info_arr[$key], 80);
                    } else if ($filelist['photo']) {
                        $info_arr[$key]['file8098'] = Image::imagesReplace('/my/photo/'.$filelist['photo']);
                    } else {
                        $info_arr[$key]['file8098'] = '';
                        $info_arr[$key]['file8098'] = Image::getLawyerImgPath($info_arr[$key], 80);
                    }
                    //110X135ͼƬ
                    $file110 = $filelist['file110135'];
                    if (!empty($file110)) {
                        $info_arr[$key]['file110135'] = $file110;
                        $info_arr[$key]['file110135'] = Image::getLawyerImgPath($info_arr[$key], 110);
                    } else if ($filelist['photo']) {
                        $info_arr[$key]['file110135'] = Image::imagesReplace('/my/photo/'.$filelist['photo']);
                    } else {
                        $info_arr[$key]['file110135'] = '';
                        $info_arr[$key]['file110135'] = Image::getLawyerImgPath($info_arr[$key], 110);
                    }
                } else { //����û���ϴ�ͷ�����ʦĬ��ͷ��
                    $info_arr[$key]['file2020'] = Image::getLawyerImgPath($info_arr[$key], 20); 
                    $info_arr[$key]['file4444'] = Image::getLawyerImgPath($info_arr[$key], 44);
                    $info_arr[$key]['file6464'] = Image::getLawyerImgPath($info_arr[$key], 64);
                    $info_arr[$key]['file8098'] = Image::getLawyerImgPath($info_arr[$key], 80);
                    $info_arr[$key]['file110135'] = Image::getLawyerImgPath($info_arr[$key], 110);
                }
            }
        }
        return $info_arr;
    }
    
    /**
     * ʹ��CURLЭ��Զ������������
     *
     * @param int $posvals  ���λID���ɹ���̨�ṩ��
     * @param int $areacode areacode
     * @param int $profid   ר��ID
     *
     * @return jsondata
     */
    public function getChengbaoData($posvals, $areacode, $profid = 0)
    {
        if (empty($posvals) || empty($areacode)) {
            return array();
        }
        
        $url = 'http://g.findlaw.cn/index.php?m=Product&a=cb&pos=' . $posvals . '&area=' . $areacode . '&prof=' . $profid;
        $jsondata = \Tools\Curl::apc_get($url);
        
        $u8data = json_decode(htmlspecialchars_decode(iconv('GB18030', 'UTF-8//TRANSLIT//IGNORE', mb_substr($jsondata, 2, -1, 'gbk')), ENT_COMPAT), true);
        return MiscFunc::utf8Gbk($u8data);
    }
    
    /**
     * ʹ��CURLЭ��Զ������������ ͨ�÷���
     *
     * @param int  $param      �������ݸ�ʽ
     * @param int  $areacode   areacode
     * @param bool $islocation �Ƿ�ʹ��location�������ǲ���ʹ��areacode����������ʹ�õ���ip��ȡ������Ҫע�⣩
     * @param int  $profid     ר��id��Ĭ��Ϊ��
     *
     * @return jsondata
     */
    public function getProductDataByCurl($param, $areacode, $islocation = false, $profid=0)
    {
        //���󼯺ϲ��������ڵ�ʱ��ֱ�ӷ��ؿ�����
        if (empty($param)) {
            return array();
        }
        //1��������� areacode ��Ϊ�� �� location ��������Ҫ����� ���� ������
        //2��������� areacode Ϊ�� �� location ���� �������� ���� ������
        if ((!empty($areacode) && $islocation == false) || (empty($areacode) && $islocation == true)) {
            return array();
        }
        
        $url = 'http://g.findlaw.cn/index.php?m=Product&a=index&param='.$param.'&location='.$areacode.'&requestmode=async';
        $jsondata = \Tools\Curl::apc_get($url);
        
        $u8data = json_decode(htmlspecialchars_decode(iconv('GB18030', 'UTF-8//TRANSLIT//IGNORE', mb_substr($jsondata, 2, -1, 'gbk')), ENT_COMPAT), true);
        return \Tools\Strings::utf8Gbk($u8data);
    }
    
    /**
     * ���ù��ӿڻ�ȡ����
     *
     * @param array $urlParam �������URL�Ĳ������飬�������ַ���
     *
     * @return jsondata
     */
    public static function getApiData($urlParam)
    {
        $str = $urlParam;
        if (empty($urlParam)) {
            return array();
        } elseif (is_array($urlParam)) {
            $str = http_build_query($urlParam);
        }
        $url      = 'http://g.findlaw.cn/index.php?' . $str;
        $info_key = 'Ads:getApiData:'.$url;
        if (!$_GET['nocache']) {
            $info = \Tools\Cache::get($info_key);
            if ($info !== false && $_GET['debug'] == 'rpcExecTime') {
                echo '<b>��cache��</b>'.$info_key.'|<b>��cache��</b><br />';
            }
            if ($info !== false) {
                return $info;
            }
        }
        if (!$info) {
            $jsonData = \Tools\Curl::apc_get($url);
            $u8data   = json_decode(htmlspecialchars_decode(iconv('GB18030', 'UTF-8//TRANSLIT//IGNORE', mb_substr($jsonData, 2, -1, 'gbk')), ENT_COMPAT), true);
            $info = \Tools\Strings::utf8Gbk($u8data);
            if ($info) {
                \Tools\Cache::set($info_key, $info, rand(1800, 3600));
            }
        }
        return $info;
    }
}
