<?php
/**
 *  ���ܹ�����
 *
 *  @author zsg <xxx@qq.com>
 *
 */
/**
 *  ���ܹ�����
 *
 *  @author zsg <xxx@qq.com>
 */
namespace Tools;
use Tools;
class Encrypt
{    
    /**
    * ��dede�ķ������мӽ��� ��Դ�ھ�Ŀ¼�ṹ��Miscfunc
    * 
    * @param string $string    �ַ���
    * @param string $operation ������ʽ decode encode
    * @param string $key       ��Կ
    * @param string $expiry    ..... 
    *
    * @return .....
    **/
    public static function authcode($string, $operation = 'DECODE', $key = '', $expiry = 0)
    {
        $auth_key      = !empty($key) ? $key : '';
        $key           = md5($auth_key);
        $key_length    = strlen($key);
        $string        = $operation == "DECODE" ? base64_decode($string) : substr(md5($string . $key), 0, 8) . $string;
        $string_length = strlen($string);
        $rndkey        = $box = array();
        $result        = "";
        $i             = 0;
        for (; $i <= 255; ++$i) {
            $rndkey[$i] = ord($key[$i % $key_length]);
            $box[$i]    = $i;
        }
        $j = $i = 0;
        for (; $i < 256; ++$i) {
            $j       = ($j + $box[$i] + $rndkey[$i]) % 256;
            $tmp     = $box[$i];
            $box[$i] = $box[$j];
            $box[$j] = $tmp;
        }
        $a = $j = $i = 0;
        for (; $i < $string_length; ++$i) {
            $a       = ($a + 1) % 256;
            $j       = ($j + $box[$a]) % 256;
            $tmp     = $box[$a];
            $box[$a] = $box[$j];
            $box[$j] = $tmp;
            $result .= chr(ord($string[$i]) ^ $box[($box[$a] + $box[$j]) % 256]);
        }
        if ($operation == "DECODE") {
            if (substr($result, 0, 8) == substr(md5(substr($result, 8) . $key), 0, 8)) {
                return substr($result, 8);
            } else {
                return "";
            }
        } else {
            return str_replace("=", "", base64_encode($result));
        }
    }
    
    /**
     * �ӽ��ܷ��� ��Դ�ھ�Ŀ¼�ṹ�� china.findlaw.cn/Common/common.php
     *
     * @param string $string    �ַ���
     * @param string $operation ������ʽ decode encode
     * @param string $key       ��Կ
     * @param string $expiry    .....
     *
     * @return .....
     **/
    public static function auth_code($string, $operation = 'DECODE', $key = '', $expiry = 0)
    {
        $ckey_length = 4;
    
        $key = md5($key ? $key : '9e13yK8RN2M0lKP8CLRLhGs468d1WMaSlbDeCcI');
        $keya = md5(substr($key, 0, 16));
        $keyb = md5(substr($key, 16, 16));
        $keyc = $ckey_length ? ($operation == 'DECODE' ? substr($string, 0, $ckey_length): substr(md5(microtime()), -$ckey_length)) : '';
    
        $cryptkey = $keya.md5($keya.$keyc);
        $key_length = strlen($cryptkey);
    
        $string = $operation == 'DECODE' ? base64_decode(substr($string, $ckey_length)) : sprintf('%010d', $expiry ? $expiry + time() : 0).substr(md5($string.$keyb), 0, 16).$string;
        $string_length = strlen($string);
    
        $result = '';
        $box = range(0, 255);
    
        $rndkey = array();
        for($i = 0; $i <= 255; $i++) {
            $rndkey[$i] = ord($cryptkey[$i % $key_length]);
        }
    
        for($j = $i = 0; $i < 256; $i++) {
            $j = ($j + $box[$i] + $rndkey[$i]) % 256;
            $tmp = $box[$i];
            $box[$i] = $box[$j];
            $box[$j] = $tmp;
        }
    
        for($a = $j = $i = 0; $i < $string_length; $i++) {
            $a = ($a + 1) % 256;
            $j = ($j + $box[$a]) % 256;
            $tmp = $box[$a];
            $box[$a] = $box[$j];
            $box[$j] = $tmp;
            $result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
        }
    
        if($operation == 'DECODE') {
            if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26).$keyb), 0, 16)) {
                return substr($result, 26);
            } else {
                return '';
            }
        } else {
            return $keyc.str_replace('=', '', base64_encode($result));
        }
    }
    
    /**
     * AES���ܽ��ܷ���
     *
     * @param unknown $string    str
     * @param unknown $aesKey    key
     * @param string  $operation ope
     *
     * @return string
     */
    public static function aes_crypt($string, $aesKey, $operation='DECODE')
    {
        require_once 'include/tools/Util/AES.class.php';
        $aes = new \AES(true);    // �Ѽ��ܺ���ַ�����ʮ�����ƽ��д洢
        $keys = $aes->makeKey($aesKey);
        if ($operation == 'DECODE') {
            return $aes->decryptString($string, $keys);
        } else {
            return $aes->encryptString($string, $keys);
        }
    }
}
