<?php
/**
 *  ������������������
 *
 *  @author zsg <xxx@qq.com>
 *
 */
/**
 *  ������������������
 *
 *  @author zsg <xxx@qq.com>
 */
namespace Tools;
use Tools;
class Request
{
    /**
     * ��ȡ���Ͳ���
     *
     * @param unknown $fieldname fieldname
     * @param string  $type      fieldname
     *
     * @return number
     */
    public static function getintparam($fieldname, $type='GET')
    {
        $type = strtoupper($type);
        if ($type == 'GET') {
            $val = isset($_GET[$fieldname]) ? intval($_GET[$fieldname]) : 0;
        } elseif ($type == 'POST') {
            $val = isset($_POST[$fieldname]) ? intval($_POST[$fieldname]) : 0;
        } elseif ($type == 'BOTH') {
            $val = isset($_GET[$fieldname]) ? self::getintparam($fieldname, 'GET') : self::getintparam($fieldname, 'POST');
        }
        return $val;
    }
    
    /**
     * ��ȡ��ҳ����
     *
     * @param unknown $fieldname fieldname
     * @param unknown $type      type
     *
     * @return int
     */
    public static function getpageparam($fieldname, $type="GET")
    {
        $page = self::getintparam($fieldname, $type);
        return $page <=0 ? 1 : $page;
    }
    
    /**
     * ��ȡ�ַ����Ͳ���
     *
     * @param unknown $fieldname fieldname
     * @param string  $type      fieldname
     *
     * @return number
     */
    public static function getstrparam($fieldname, $type='GET')
    {
        $type = strtoupper($type);
        if ($type == 'GET') {
            $val = isset($_GET[$fieldname]) ? trim($_GET[$fieldname]) : '';
        } elseif ($type == 'POST') {
            $val = isset($_POST[$fieldname]) ? trim($_POST[$fieldname]) : '';
        } elseif ($type == 'BOTH') {
            $val = isset($_GET[$fieldname]) ? self::getstrparam($fieldname, 'GET') : self::getstrparam($fieldname, 'POST');
        }
        return $val;
    }
    /**
     *  ��GET��POST��COOKIE�л�ȡ����
     *
     *  @param string  $name        ����
     *  @param array   $type        ���ͣ� ������������˳���ȡ����ȡ��ֵ���Ϸ���
     *  @param boolean $push_params �Ƿ�����ݷŵ�ȫ�ֲ�����
     *
     *  @return mixed
     */
    public static function request($name, array $type = array('GET', 'POST', 'COOKIE'), $push_params=false)
    {
        global $params;
        $allowType = array('GET', 'POST', 'COOKIE');
        foreach ($type as $method) {
            $method = trim($method);
            if (in_array($method, $allowType)) {
                $var = '_'.$method;
                if (isset($GLOBALS[$var][$name])) {
                    
                    if ($push_params && strlen($GLOBALS[$var][$name])) {
                        $params[$name] = $GLOBALS[$var][$name];
                    }
                    return $GLOBALS[$var][$name];
                }
            }
        }
        return null;
    }
}
