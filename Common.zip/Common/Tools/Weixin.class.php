<?php
/**
 *  ΢��api������, �ӿڵ��÷�ʽ��ο�weixin_front/Api/Controller/WeixinApiemoController.class.php
 *
 *  @author zsg <1649353934@qq.com>
 *
 */

namespace Tools;
use Tools;
/**
 *  ΢��api������, �ӿڵ��÷�ʽ��ο�weixin_front/Api/Controller/WeixinApiemoController.class.php
 *
 *  @author zsg <1649353934@qq.com>
 */
class Weixin
{
    //����ŵ�appid��secret,  ��Ҫ�޸ģ� �����set_appid_secret����
    private static $appid = '';
    private static $secret = '';
    
    /**
     * ǩ����֤
     * 
     * @param string $token token
     * 
     * @return boolean
     */
    public static function checkSignature($token)
    {
        $signature = $_GET["signature"];
        $timestamp = $_GET["timestamp"];
        $nonce = $_GET["nonce"];
    
        $tmpArr = array($token, $timestamp, $nonce);
        sort($tmpArr, SORT_STRING);
        $tmpStr = implode($tmpArr);
        $tmpStr = sha1($tmpStr);
    
        if ($tmpStr == $signature) {
            return true;
        } else {
            return false;
        }
    }
    
    /**
     *  ʹ���ض�function������������Ԫ��������
     *
     *  @param string  &$array             Ҫ�������ַ���
     *  @param string  $function           Ҫִ�еĺ���
     *  @param boolean $apply_to_keys_also �Ƿ�ҲӦ�õ�key��
     *
     *  @return null
     **/
    public static function arrayRecursive(&$array, $function, $apply_to_keys_also = false)
    {
        static $recursive_counter = 0;
        if (++$recursive_counter > 1000) {
            die('possible deep recursion attack');
        }
        foreach ($array as $key => $value) {
            if (is_array($value)) {
                self::arrayRecursive($array[$key], $function, $apply_to_keys_also);
            } else {
                $array[$key] = $function($value);
            }
    
            if ($apply_to_keys_also && is_string($key)) {
                $new_key = $function($key);
                if ($new_key != $key) {
                    $array[$new_key] = $array[$key];
                    unset($array[$key]);
                }
            }
        }
        $recursive_counter--;
    }
    
    /**
     *  ������ת��ΪJSON�ַ������������ģ�
     *
     *  @param array $array Ҫת��������
     *
     *  @return string      ת���õ���json�ַ���
     *  @access public
     */
    public static function JSON($array)
    {
        self::arrayRecursive($array, 'urlencode', true);
        $json = json_encode($array);
        return urldecode($json);
    }
    
    /**
     * post json����
     *
     * @param str $url         posturl
     * @param str $data_string json�ַ���
     *
     * @return json_string
     */
    static function postjson($url, $data_string)
    {
        list($err, $rejsondata) = \Tools\Curl::jsonPost($url, $data_string);
        if ($err == 0) {
            return $rejsondata;
        } else {
            return false;
        }
    }
    
    /**
     * ��ȡ appid secret����
     *
     * @return str
     */
    public static function get_appid_secret()
    {
        if (self::$appid == '') {
            self::set_default_appid_secret();
        }        
        return array(self::$appid, self::$secret);
    }
    
    /**
     * ���� Ĭ�ϵ�appid secret����
     *
     * @return str
     */
    public static function set_default_appid_secret()
    {
        //Ĭ��Ϊ�ҷ������
        self::set_appid_secret('wx10be083e0ef04f48', '983f62c7abe87cc37557882408386f15');
    } 
    
    /**
     * ���� appid secret����
     * 
     * @param str $appid  appid
     * @param str $secret secret
     *
     * @return boolean
     */
    public static function set_appid_secret($appid, $secret)
    {
        if ($appid == '' || $secret == '') {
            die("appid, secret is empty!!");
        }
        self::$appid = $appid;
        self::$secret = $secret;
        return true;
    }
    
    /**
    * ΢��.��ȡ΢��token
    *
    * @param string $nocache �Ƿ�ǿˢ
    *
    * @return array
    */
    public function getWeixinToken($nocache = 0)
    {
        $appid = self::$appid;
        return \Rpc::getShortlinkData('Weixin.updateWeixinCodeImageUrl', $appid, $nocache);
    }
    /**
     * ��ȡaccess_token, �Զ�����
     * 
     * @param bool $fresh fresh
     *
     * @return str
     */
    public static function load_access_token($fresh=false)
    {
        return self::getWeixinToken($fresh);
    }
    
    /**
     * �����˵�api, ʹ�÷����ο� weixin_front/trunk/Api/Controller/DemoController.class.php
     * 
     * @param unknown $menu �˵���
     * 
     * @return Ambigous <json_string, mixed>
     */
    public static function menu_create($menu)
    {
        if (empty($menu)) {
            return '$menu����Ϊ��';
        }
        if (!isset($menu['button'])) {
            return '$menu[button]����Ϊ��';
        }
        $data_string = self::JSON($menu);        
        $url = 'https://api.weixin.qq.com/cgi-bin/menu/create?access_token=' . self::load_access_token();
        return self::postjson($url, $data_string);
    }
    
    /**
     * ���Ϳͷ���Ϣ ʹ�÷����ο� weixin_front/trunk/Api/Controller/DemoController.class.php
     * http://mp.weixin.qq.com/wiki/index.php?title=%E5%8F%91%E9%80%81%E5%AE%A2%E6%9C%8D%E6%B6%88%E6%81%AF
     * 
     * @param unknown $data Ҫ���͵���Ϣ����
     * 
     * @return Ambigous <json_string, mixed>
     */
    public static function message_send($data)
    {
        if (empty($data)) {
            return '$data����Ϊ��';
        }
        $data_string = self::JSON($data);
        $url = 'https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token='.self::load_access_token();
        $rejson = self::postjson($url, $data_string);
        $arr = json_decode($rejson, true);
        if ($arr['errcode'] > 0) {
            $url = 'https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token='.self::load_access_token(true);
            $rejson = self::postjson($url, $data_string);
        }
        return $rejson;
    }    
    
    /**
     * ���Ϳͷ�ģ����Ϣ ʹ�÷����ο� weixin_front/trunk/Api/Controller/DemoController.class.php
     * 
     * @param unknown $data        Ҫ���͵���Ϣ����
     * 
     * @param unknown $template_id ģ��id
     * 
     * @return Ambigous <json_string, mixed>
     */
    public static function message_template_send($data, $template_id='fERa5B1OrGKdkDgnGonsgRSRuLiNK1Y-xEY0jobmGfE')
    {
        if (empty($data)) {
            return '$data����Ϊ��';
        }
        if (!$data['template_id']) {
            $data['template_id'] = $template_id;
        }
        $data_string = self::JSON($data);
        $url = 'https://api.weixin.qq.com/cgi-bin/message/template/send?access_token='.self::load_access_token();
        $rejson = self::postjson($url, $data_string);
        $arr = json_decode($rejson, true);
        if ($arr['errcode'] > 0) {
            $url = 'https://api.weixin.qq.com/cgi-bin/message/template/send?access_token='.self::load_access_token(true);
            $rejson = self::postjson($url, $data_string);
        }
        return $rejson;
    }
    
    /**
     * ���ںſ�ͨ�����ӿ�������OpenID��ȡ�û�������Ϣ�������ǳơ�ͷ���Ա����ڳ��С����Ժ͹�עʱ�䡣
     * ʹ�÷����ο� weixin_front/trunk/Api/Controller/DemoController.class.php
     * http://mp.weixin.qq.com/wiki/index.php?title=%E8%8E%B7%E5%8F%96%E7%94%A8%E6%88%B7%E5%9F%BA%E6%9C%AC%E4%BF%A1%E6%81%AF
     *
     * @param unknown $openid �û���openid
     *
     * @return Ambigous <json_string, mixed>
     */
    public static function user_info($openid)
    {
        if ($openid == '') {
            return '$openid����Ϊ��';
        }
        $url = 'https://api.weixin.qq.com/cgi-bin/user/info?access_token='.
        self::load_access_token().'&openid='.$openid.'&lang=zh_CN';
        return self::postjson($url, $data_string);
    }
    
    /**
     * �����ƹ��ά��ͼƬ��ַ��
     * ʹ�÷����ο� weixin_front/trunk/Api/Controller/DemoController.class.php
     * http://mp.weixin.qq.com/wiki/index.php?title=%E8%8E%B7%E5%8F%96%E7%94%A8%E6%88%B7%E5%9F%BA%E6%9C%AC%E4%BF%A1%E6%81%AF
     *
     * @param unknown $scene_id ����id
     *
     * @return Ambigous <json_string, mixed>
     */
    public static function qrcodeurl($scene_id)
    {
        $cache_key = 'qrcodeurl_' .$scene_id . '_' . self::$appid;
        $result = S($cache_key);
        if (!$result) {
            $postdata = array(
                'expire_seconds' => 600000,
                'action_name' => "QR_SCENE",
                'action_info' => array('scene'=>array('scene_id'=>$scene_id)),
            );
            $data_string = self::JSON($postdata);
            
            $url = sprintf("https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=%s", self::load_access_token());
            $rejsondata = self::postjson($url, $data_string);
            $redata = json_decode($rejsondata, true);
            if (isset($redata['errcode']) && $redata['errcode']>0) { 
                $url = sprintf("https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=%s", self::load_access_token(true));
                $rejsondata = self::postjson($url, $data_string);
                $redata = json_decode($rejsondata, true);
            }            
            if (isset($redata['ticket']) && $redata['ticket'] != '') {
                S($cache_key, $result, 550000);
            } 
            if (isset($_GET['debug'])) {
                var_dump('post data=>' . $data_string);
                var_dump('rejsondata=>' . $rejsondata);
            }
            $result =  sprintf('https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=%s', $redata['ticket']);
        }
        return $result;
    }    
    
    /**
     * �����¼�����
     * 
     * @return boolean|SimpleXMLElement
     */
    public static function eventdata()
    {
        $postStr = file_get_contents("php://input");
        if (empty($postStr)) {
            return false;   
        }
        return $postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
    }
}
