<?php
/**
 *  ���湤����
 *
 *  @author YateSun <sunyate@wanglv.com>
 *
 */
namespace Tools;
use Tools;
/**
 *  ���湤����
 *
 *  @author YateSun <sunyate@wanglv.com>
 */
class Cache
{
    /**
     * php memcache ����������
     *
     * @return type
     */
    public static function memcache()
    {
        $memcachecfginfo = C('memcachecfginfo');
        $options = array('host' => $memcachecfginfo[0][0], 'port' => $memcachecfginfo[0][1]);
        return new \Think\Cache\Driver\Memcache($options);
    }
    
    /**
     * php redis ����������
     *
     * @param string $string ��Ƭ����
     *
     * @return type
     */
    public static function redis($string = '')
    {
        $redis_config = C('redis_config');
        $count = count($redis_config);
        if ($count) {
            $node = crc32($string)%$count;
        } else {
            return false;
        }
        $server = explode(':', $redis_config[$node]);
        try {
            $redis = new \Redis();
            $time = time();
            if ($redis->connect($server[0], $server[1], 3) && (time()-$time < 3)) {
                return $redis;
            } else {
                return false;
            }
        } finally {
            if (!$redis->socket) {
                return false;
            }
        }
    }
    /**
     * ����
     * 
     * @param string $string �ַ���
     * 
     * @return boolean
     */
    public static function encode($string)
    {
        if (C('content_encode') == 'UTF-8') {
            return gzcompress(json_encode($string), 9);
        }
        return gzcompress(json_encode(\Tools\Strings::utf8Gbk($string, 'UTF-8')), 9);
    }

    /**
     * ����
     * 
     * @param string $string �ַ���
     * @param string $isutf8 �Ƿ�UTF-8��ʽ
     * 
     * @return boolean
     */
    public static function decode($string, $isutf8 = false)
    {
        $data = gzuncompress($string);
        if ($isutf8) {
            //��ѹ��ֱ�ӷ���
            if ($data === false) {
                return $string;
            }
            //ѹ��������Ҫת��GBK
            return json_decode($data, true);
        }
        if ($data === false) {
            return \Tools\Strings::utf8Gbk($string);
        }
        return \Tools\Strings::utf8Gbk(json_decode($data, true));
    }
    /**
     * ���û���
     * 
     * @param string $key    �����key
     * @param array  $value  ����
     * @param int    $expire ��Чʱ��
     * 
     * @return boolean
     */
    public static function set($key, $value, $expire = null)
    {
        if ($redis = self::redis($key)) {
            try {
                $data = false;
                if ($expire === null) {
                    $data = $redis->set($key, self::encode($value));
                } else {
                    $data = $redis->setex($key, $expire, self::encode($value));
                }
            } finally {
                return $data;
            }
        }
        return false;
    }

    /**
     * ȡ����
     *
     * @param string $key    �����key
     * @param string $isutf8 �Ƿ�UTF-8��ʽ
     *
     * @return array
     */
    public static function get($key, $isutf8 = false)
    {
        if ($redis = self::redis($key)) {
            try {
                $data = false;
                $data = self::decode($redis->get($key), $isutf8);
            } finally {
                return $data;
            }
        }
        return false;
    }
    
    /**
     * increment����
     *
     * @param string $key   �����key
     * @param array  $value ����
     *
     * @return array
     */
    public static function incr($key, $value = 1)
    {
        if ($redis = self::redis($key)) {
            try {
                $data = false;
                $data = $redis->incrby($key, $value);
            } finally {
                return $data;
            }
        }
        return false;
    }

    /**
     * decrement����
     *
     * @param string $key   �����key
     * @param array  $value ����
     *
     * @return array
     */
    public static function decr($key, $value = 1)
    {
        if ($redis = self::redis($key)) {
            try {
                $data = false;
                $data = $redis->decrby($key, $value);
            } finally {
                return $data;
            }
        }
        return false;
    }
    
    /**
     * ɾ������
     *
     * @param string $key �����key
     *
     * @return boolean
     */
    public static function rm($key)
    {
        if ($redis = self::redis($key)) {
            try {
                $data = false;
                $data = $redis->delete($key);
            } finally {
                return $data;
            }
        }
        return false;
    }

    /**
     * ��������й�ϣHash
     *
     * @param array $array array���
     *
     * @return string
     */
    public static function hash($array)
    {
        $serialize = serialize($array);
        if (strlen($serialize) > 70) {
            $serialize = substr($serialize, 0, 15).'-'.substr($serialize, -10, 10).'-'.md5($serialize);
        }
        return 'FL-'.$serialize;
    }
}
?>
