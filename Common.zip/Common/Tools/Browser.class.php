<?php
/**
 *  �����������
 *
 *  @author zsg <xxx@qq.com>
 *
 */
/**
 *  �����������
 *
 *  @author zsg <xxx@qq.com>
 */
namespace Tools;
use Tools;
class Browser
{
    /**
     * �ж��Ƿ��ֻ����ʣ����ж�99.9%���ֻ���.��Դ�ٶ���������л�ٶȸ�л����꣡����http://www.2cto.com/kf/201102/83260.html���ж��Ƿ����ֻ�ͨ���ٶ�������ת������
     *
     * @return bool
     **/
    public static function isMobileBrowse()
    {
        $regex_match="/(nokia|iphone|android|motorola|^mot-|softbank|foma|docomo|kddi|up.browser|up.link|";
        $regex_match.="htc|dopod|blazer|netfront|helio|hosin|huawei|novarra|CoolPad|webos|techfaith|palmsource|";
        $regex_match.="blackberry|alcatel|amoi|ktouch|nexian|samsung|^sam-|s[cg]h|^lge|ericsson|philips|sagem|wellcom|bunjalloo|maui|";
        $regex_match.="symbian|smartphone|midp|wap|phone|windows ce|iemobile|^spice|^bird|^zte-|longcos|pantech|gionee|^sie-|portalmmm|";
        $regex_match.="jigs browser|hiptop|^ucweb|^benq|haier|^lct|operas*mobi|opera*mini|320x320|240x320|176x220";
        $regex_match.=")/i";
        $re = isset($_SERVER['HTTP_X_WAP_PROFILE']) or isset($_SERVER['HTTP_PROFILE']) or preg_match($regex_match, strtolower($_SERVER['HTTP_USER_AGENT']));
        $re1=preg_match('/http\:\/\/www\.baidu\.com/i', $_SERVER['HTTP_REFERER']) && preg_match("/wo*r*d=([^&]*|$)/i", urldecode($_SERVER['HTTP_REFERER']));
        return $re && $re1;
    }
    
    /**
     * �ж��Ƿ��ֻ�΢�ŷ���
     *
     * @return bool
     **/
    public static function isWeixinBrowse()
    {
        if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) {
            return true;
        }
        return false;
    }
    
    /**
     * ���������жϷ����豸��Դ
     *
     * @return string
     */
    public function orderSource()
    {
        if (isset($_GET['vid'])) {
            $vid = \Tools\Request::getintparam('vid');
            if ($vid == 1) {
                return 'iphone';
            } elseif ($vid == 2) {
                return 'android';
            }
        }
    
        $useragent  = strtolower($_SERVER["HTTP_USER_AGENT"]);
        // iphone
        $is_iphone  = strripos($useragent, 'iphone');
        if ($is_iphone) {
            return 'iphone';
        }
        // android
        $is_android    = strripos($useragent, 'android');
        if ($is_android) {
            return 'android';
        }
        // ΢��
        $is_weixin  = strripos($useragent, 'micromessenger');
        if ($is_weixin) {
            return 'weixin';
        }
        // ipad
        $is_ipad    = strripos($useragent, 'ipad');
        if ($is_ipad) {
            return 'ipad';
        }
        // ipod
        $is_ipod  = strripos($useragent, 'ipod');
        if ($is_ipod) {
            return 'ipod';
        }
        // pc����
        $is_pc = strripos($useragent, 'windows nt');
        if ($is_pc) {
            return 'pc';
        }
    
        return 'other';
    }
}
