<?php
/**
 * ΢��֧����
 *
 * @author huanggongqiang <huanggongqiang@findlaw.cn>
 *
 *  @data 2016-08-16
 */
namespace Tools\Pay;

/**
 * ΢��֧����
 * 
 * @author huanggongqiang <huanggongqiang@findlaw.cn>
 */
class Wxpay
{
    protected $_error = '';
    
    /**
     * ��ʼ������
     *
     * @return void
     */
    public function __construct()
    {
        vendor('Pay.Wxpay.lib.WxPay', '', '.Api.php');
    }
    
    /**
     * ���ɶ�ά��URL
     *
     * @param array $param ����
     *
     * @return array / false ��������
     */
    public function codeUrl($param)
    {
        try {
            $input = new \WxPayUnifiedOrder();
            $out_trade_no = \WxPayConfig::MCHID.date('YmdHis');
            
            $input->SetBody($param['body']);
            $input->SetAttach($param['attach']);
            $input->SetOut_trade_no($out_trade_no);
            $input->SetTotal_fee(intval($param['total_fee'] * 100));
            $input->SetTime_start(date('YmdHis'));
            $input->SetTime_expire(date('YmdHis', time() + 3600));
            $input->SetNotify_url('http://z.ls.cn/notify/wxpay');
            $input->SetTrade_type('NATIVE');
            $input->SetProduct_id($param['telephone']);
            $result = $this->GetPayUrl($input);
            
        }  catch (WxPayException $exc) {
            $this->_error = $exc->errorMessage();
            return false;
        }
        
        if ($result['return_code']=='SUCCESS' && $result['result_code']=='SUCCESS') {
            return array(
                'code_url'     => $result['code_url'],
                'out_trade_no' => $out_trade_no,
                'sign'         => md5($out_trade_no.'^8898ABcde#$%!IE$'),
            );
        } else {
            $this->_error = '��������';
            return false;
        }
    }
    
    /**
     * ��ѯ����֧��״̬
     * 
     * @param string $out_trade_no ������
     *
     * @return bool true֧����ɣ�false��֤��֧��ʧ��
     */
    public function notify($out_trade_no)
    {
        $input = new \WxPayOrderQuery();
        $input->SetOut_trade_no($out_trade_no);
        $result = \WxPayApi::orderQuery($input);
        if ($result['return_code']=='SUCCESS' && $result['result_code']=='SUCCESS' && $result['trade_state'] == 'SUCCESS') {
            
            setcookie('wpayResult', 'success', time()+1800, '/', '.findlaw.cn');
            return true;
            
        } else {
            $this->_error = $result['err_code_des'];
            return false;
        }
    }
    
    /**
     * ����ɨ��֧��URL,ģʽһ
     *
     * @param UnifiedOrderInput $productId ����
     *
     * @return string url
     */
    public function GetPrePayUrl($productId)
    {
        $biz = new \WxPayBizPayUrl();
        $biz->SetProduct_id($productId);
        $values = \WxpayApi::bizpayurl($biz);
        $url = 'weixin://wxpay/bizpayurl?' . $this->ToUrlParams($values);
        return $url;
    }
    
    /**
     * ��������ת��Ϊurl����
     *
     * @param array $urlObj ����
     *
     * @return string
     */
    private function ToUrlParams($urlObj)
    {
        $buff = '';
        foreach ($urlObj as $k => $v) {
            $buff .= $k . '=' . $v . '&';
        }
        
        $buff = trim($buff, '&');
        return $buff;
    }
    
    /**
     * ����ֱ��֧��url��֧��url��Ч��Ϊ2Сʱ,ģʽ��
     *
     * @param UnifiedOrderInput $input ����
     *
     * @return string
     */
    public function GetPayUrl($input)
    {
        if ($input->GetTrade_type() == 'NATIVE') {
            $result = \WxPayApi::unifiedOrder($input);
            return $result;
        }
    }
    
    /**
     * ������Ϣ
     * 
     * @return string ������Ϣ
     */
    public function getError()
    {
        return $this->_error;
    }
}