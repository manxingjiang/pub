<?php
/**
 *  Image������
 *
 *  @author wrd <xxx@qq.com>
 *
 */
namespace Tools;
use Tools;
/**
 *  Image������
 *
 *  @author wrd <xxx@qq.com>
 */
class Image
{
    /**
     * ͼƬƥ������
     *
     * @param string $url ͼƬ����
     *
     * @return number
     */
    public static function imagesReplace($url)
    {
        $host_url = '';
        if (strpos(gethostname(), '-') === false) {
            $static_host_url = array('https://img1.findlawimg.com', 'https://img2.findlawimg.com', 'https://img3.findlawimg.com');
            $dyn_host_url = array('https://d01.findlawimg.com', 'https://d02.findlawimg.com', 'https://d03.findlawimg.com');
        } else {
            $static_host_url = array('//img1.findlawimg.com', '//img2.findlawimg.com', '//img3.findlawimg.com');
            $dyn_host_url = array('//d01.findlawimg.com', '//d02.findlawimg.com', '//d03.findlawimg.com');
        }
        $begin = explode('/', $url);
        switch ($begin[1]) {
        case 'img':
            $host_url = $static_host_url;
            break;
        case 'my':
            $host_url = $dyn_host_url;
            break;
        case 'micphoto':
            $host_url = $dyn_host_url;
            break;
        }

        if ($host_url) {
            $name = explode('?', $url);
            $pos = (abs(crc32(trim($name[0])))%3);
            $host_url = $host_url[$pos].$url;
            return $host_url;
        } else {
            echo $url;
        }
    }
    
    /**
     * ��ȡͼƬ��ַ
     *
     * @param array $row  ������
     * @param int   $size ͼƬ��С
     *
     * @return type
     * @author zhangshengguang
     */
    public static function getLawyerImgPath($row, $size)
    {
        $size_field = array(
                '80'=>'file8098',
                '20'=>'file2020',
                '44'=>'file4444',
                '64'=>'file6464',
                '110'=>'file110135'
        );
        if (!isset($size_field[$size])) {
            return 'size error';
        }

        $imgsrc = "/my/lawyer_{$size}/";
        $f = $size_field[$size];
        $imgsrc .= empty($row[$f])?"{$size}.jpg":$row[$f];
        return self::imagesReplace($imgsrc);
    }    
    
    /**
     * �ϴ�ͼƬ����ʱĿ¼
     * 
     * @param string $inputfilename �ϴ������ֶ�
     * @param int    $maxSize       ����ϴ�Mb��
     * @param array  $exts          �����ĸ�ʽ
     * 
     * @return array
     */
    public static function upPhotoToTemp($inputfilename, $maxSize=2, $exts=array('jpg', 'jpeg', 'png', 'gif'))
    {
        $savePath = $svpePath = 'my/temp/'.date("Y/m-d/");
        $curlobj = new \Tools\LtCurl($savePath);
        $curlobj->saveRule = "uniqid";
        $curlobj->formFileName = $inputfilename;
        $curlobj->maxSize = $maxSize * 1024 * 1024;
        $curlobj->allowExts = $exts;
        $jsonstr = $curlobj->upload();
        $imageArr = json_decode($jsonstr, true);
        
        if ($imageArr['status'] == "1") {
            $imageArr['data']['file'] = $savePath.$imageArr['data']['filename'];
        }
        return $imageArr;
    }
    
    /**
     * �ƶ���ʱ�ļ�����ʽĿ¼
     * 
     * @param string $savePath ����Ŀ¼
     * @param string $temp     ��ʱ�ļ�
     * @param string $save     �洢��
     * @param array  $thumb    ����ͼ����
     * 
     * @return array
     */
    public static function moveTempFile($savePath, $temp, $save, $thumb=array())
    {
        $curlobj = new LtCurl($savePath);
        $curlobj->httpFile = $temp;
        $curlobj->saveFile = $save;
        if ($thumb) {
            $curlobj->thumb = $thumb['prefix'] ? $thumb['prefix'] : "thumb_";
            $curlobj->thumbMaxWidth  = $thumb['width'] ? $thumb['width'] : 200;
            $curlobj->thumbMaxHeight = $thumb['height'] ? $thumb['height'] : 200;
        }
        $uploadArr = $curlobj->upload("move_temp_file");
        $uploadArr = json_decode($uploadArr, true);
        return $uploadArr;
    }
}
