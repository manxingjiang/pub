<?php
/**
 * �ҷ������Ի���ҳ��
 *
 * copyright  2012, ���ݺ������ Co. Ltd. ALL RIGHTS RESERVED
 * version     1.0
 * description:��ǿ��ҳ�࣬���ַ�ҳģʽ��Ĭ�ϲ�������baidu,google�ķ�ҳ���
 * 2.0���ӹ��ܣ�֧���Զ������Զ�����ʽ��ͬʱ֧��PHP4��PHP5,
 * to see detail,please visit [url=http://www.phpobject.net/blog/read.php]http://www.phpobject.net/blog/read.php[/url]?
 * example:
 * ģʽ���ַ�ҳģʽ��
 require_once('file:///D|/iis/libs/classes/page.class.php');
 $page=new page(array('total'=>1000,'perpage'=>20));
 echo 'mode:1<br>'.$page->show();
 echo '<hr>mode:2<br>'.$page->show(2);
 echo '<hr>mode:3<br>'.$page->show(3);
 echo '<hr>mode:4<br>'.$page->show(4);
 ����AJAX��
 $ajaxpage=new page(array('total'=>1000,'perpage'=>20,'ajax'=>'ajax_page','page_name'=>'test'));
 echo 'mode:1<br>'.$ajaxpage->show();
 ���ü̳��Զ����ҳ��ʾģʽ��
 demo:http://www.phpobject.net/blog
 *
 * @author     zhangshengguang, huangwh <huangwh@qq.com>
 */
namespace Tools;
use Tools;
/**
 *  �ҷ������Ի���ҳ��
 *
 *  @author     zhangshengguang, huangwh <huangwh@qq.com>
 */
class Page
{
    public $page_name = "p"; //page��ǩ����������urlҳ������˵xxx.php?PB_page=2�е�PB_page
    public $next_page = '>'; //��һҳ
    public $pre_page = '<'; //��һҳ
    public $first_page = 'First'; //��ҳ
    public $last_page = 'Last'; //βҳ
    public $pre_bar = '<<'; //��һ��ҳ��
    public $next_bar = '>>'; //��һ��ҳ��
    public $format_left = '[';
    public $format_right = ']';
    public $is_ajax = false; //�Ƿ�֧��AJAX��ҳģʽ
    public $perpage = 10;
    
    /*url��д�õ�*/
    public $rewrite = 0;
    public $rewrite_ext = "";
    
    /**
     * private
     *
     */
    public $pagebarnum = 10; //���Ƽ�¼���ĸ�����
    public $total = 0; // ������
    public $totalpage = 0; //��ҳ��
    public $ajax_action_name = ''; //AJAX������
    public $nowindex = 1; //��ǰҳ
    public $url = ""; //url��ַͷ
    public $offset = 0;

    /**
     * constructor���캯��
     *
     * @param string $array ����
     */
    public function __construct($array)
    {
        if (is_array($array)) {
            if (!array_key_exists('total', $array)) {
                $this->error(__FUNCTION__, 'need a param of total');
            }
            $this->total             = intval($array['total']);
            $perpage           = (array_key_exists('perpage', $array)) ? intval($array['perpage']) : 10;
            $this->perpage     = $perpage;
            $nowindex          = (array_key_exists('nowindex', $array)) ? intval($array['nowindex']) : '';
            $url               = (array_key_exists('url', $array)) ? $array['url'] : '';
            $this->rewrite     = (array_key_exists('rewrite', $array)) ? 1 : 0;
            $this->rewrite_ext = (array_key_exists('rewriteext', $array)) ? $array['rewriteext'] : '';
        } else {
            $this->total    = $array;
            $perpage  = 10;
            $nowindex = '';
            $url      = '';
        }
        if ((!is_int($this->total)) || ($this->total < 0)) {
            $this->error(__FUNCTION__, $this->total . ' is not a positive integer!');
        }
        if ((!is_int($perpage)) || ($perpage <= 0)) {
            $this->error(__FUNCTION__, $perpage . ' is not a positive integer!');
        }
        if (!empty($array['page_name'])) {
            $this->set('page_name', $array['page_name']); //����pagename
        }
        $this->_set_nowindex($nowindex); //���õ�ǰҳ
        $this->_set_url($url); //�������ӵ�ַ
        $this->totalpage = ceil($this->total / $perpage);
        $this->offset    = ($this->nowindex - 1) * $this->perpage;
        if (!empty($array['ajax'])) {
            $this->open_ajax($array['ajax']); //��AJAXģʽ
        }
    }
    /**
     * ȡ�÷�������
     * 
     * @return array
     */
    public function get_page_info()
    {
        $pageinfo                 = array();
        $pageinfo['cur_page']     = $this->nowindex;
        $pageinfo['record_count'] = $this->record_count;
        $pageinfo['page_size']    = $this->page_size;
        $pageinfo['page_count']   = $this->page_count;
        if ($this->cur_page > 1) {
            $pageinfo['pre_page']        = $pageinfo['cur_page'] - 1;
            $pageinfo['first_page']      = '1';
            $pageinfo['pre_page_link']   = $this->pageurl($pageinfo['pre_page']);
            $pageinfo['first_page_link'] = $this->pageurl($pageinfo['first_page']);
        }
        if ($this->cur_page < $this->page_count) {
            $pageinfo['next_page']      = $pageinfo['cur_page'] + 1;
            $pageinfo['last_page']      = $pageinfo['page_count'];
            $pageinfo['next_page_link'] = $this->pageurl($pageinfo['next_page']);
            $pageinfo['last_page_link'] = $this->pageurl($pageinfo['last_page']);
        }
        
        if ($this->record_count <= 0) {
            return $pageinfo;
        }
        
        //1.2.3.4.5
        $url           = $this->url;
        $links         = array();
        $cur_cool_Page = ceil($this->cur_page / $this->cool_page_size); //��ǰ��ҳ����ҳ��
        for ($i = 1; $i <= $this->cool_page_size; $i++) {
            $page = ($cur_cool_Page - 1) * $this->cool_page_size + $i;
            if ($page != $this->cur_page) {
                if ($page <= $this->page_count) {
                    $links[] = array(
                        'url' => $this->pageurl($page),
                        'page' => $page
                    );
                } else {
                    break;
                }
            } else {
                if ($this->page_count != 1) {
                    $links[] = array(
                        'url' => '',
                        'current' => true,
                        'page' => $page
                    );
                }
            }
        }
        
        $pageinfo['links'] = $links;
        
        return $pageinfo;
    }
    /**
     * �趨����ָ����������ֵ������ı�������������࣬��throwһ��exception
     *
     * @param string $var   var
     * @param string $value value
     *
     * @return string
     */
    public function set($var, $value)
    {
        if (in_array($var, get_object_vars($this))) {
            $this->$var = $value;
        } else {
            $this->error(__FUNCTION__, $var . " does not belong to PB_Page!");
        }
        
    }
    /**
     * �򿪵�AJAXģʽ
     *
     * @param string $action Ĭ��ajax�����Ķ�����
     *
     * @return string
     */
    public function open_ajax($action)
    {
        $this->is_ajax          = true;
        $this->ajax_action_name = $action;
    }
    /**
     * ��ȡ��ʾ"��һҳ"�Ĵ���
     *
     * @param string $style style
     * 
     * @return string
     */
    public function next_page($style = '')
    {
        if ($this->nowindex < $this->totalpage) {
            return $this->_get_link($this->_get_url($this->nowindex + 1), $this->next_page, $style);
        }
        return "<a href=''>" . $this->next_page . "</a>";
    }
    
    /**
     * ��ȡ��ʾ����һҳ���Ĵ���
     *
     * @param string $style style
     * 
     * @return string
     */
    public function pre_page($style = '')
    {
        if ($this->nowindex > 1) {
            return $this->_get_link($this->_get_url($this->nowindex - 1), $this->pre_page, $style);
        }
        return "<a href=''>" . $this->pre_page . "</a>";
    }

    /**
     * ��ȡ��ʾ����ҳ���Ĵ���
     * 
     * @param unknown_type $style style
     * 
     * @return string
     */
    public function first_page($style = '')
    {
        if ($this->nowindex == 1) {
            return "<a href=''>" . $this->first_page . "</a>";
        }
        //return "<a href='#'>".$this->_get_link($this->_get_url(1),$this->first_page,$style)."</a>";
        return $this->_get_link($this->_get_url(1), $this->first_page, $style);
        
    }
    
    /**
     * ��ȡ��ʾ��βҳ���Ĵ���
     *
     * @param unknown_type $style style
     *
     * @return string
     */
    public function last_page($style = '')
    {
        if ($this->nowindex == $this->totalpage) {
            return "<a href=''>" . $this->last_page . "</a>";
        }
        return $this->_get_link($this->_get_url($this->totalpage), $this->last_page, $style);
    }

    /**
     * ��ȡ��ʾ��βҳ���Ĵ���
     *
     * @param string $style          style
     * @param string $nowindex_style nowindex_style
     *
     * @return string
     */    
    public function nowbar($style = '', $nowindex_style = '')
    {
        $plus = ceil($this->pagebarnum / 2);
        if ($this->pagebarnum - $plus + $this->nowindex > $this->totalpage) {
            $plus = ($this->pagebarnum - $this->totalpage + $this->nowindex);
        }
        $begin  = $this->nowindex - $plus + 1;
        $begin  = ($begin >= 1) ? $begin : 1;
        $return = '';
        for ($i = $begin; $i < $begin + $this->pagebarnum; $i++) {
            if ($i <= $this->totalpage) {
                if ($i != $this->nowindex) {
                    $return .= $this->_get_text($this->_get_link($this->_get_url($i), $i, $style));
                } else {
                    $return .= $this->_get_text("<a href='#' class='hover'><b>" . $i . "</b></a>");
                }
            } else {
                break;
            }
            $return .= " ";
        }
        unset($begin);
        return $return;
    }
    /**
     * ��ȡ��ʾ��ת��ť�Ĵ���
     *
     * @return string
     */
    public function select()
    {
        $return = '<select name="PB_Page_Select" >';
        for ($i = 1; $i <= $this->totalpage; $i++) {
            if ($i == $this->nowindex) {
                $return .= '<option value="' . $i . '" selected="selected">' . $i . '</option>';
            } else {
                $return .= '<option value="' . $i . '">' . $i . '</option>';
            }
        }
        unset($i);
        $return .= '</select>';
        return $return;
    }
    
    /**
     * ��ȡmysql �����limit��Ҫ��ֵ
     *
     * @return string
     */
    public function offset()
    {
        return $this->offset;
    }
    
    /**
     * ���Ʒ�ҳ��ʾ��������������Ӧ�ķ��
     *
     * @param int $mode mode
     *
     * @return string
     */
    public function show($mode = 1)
    {
        switch ($mode) {
        case '1':
            $this->next_page = '��һҳ';
            $this->pre_page  = '��һҳ';
            return $this->pre_page() . $this->nowbar() . $this->next_page();
            break;
        case '2':
            $this->next_page  = '��һҳ';
            $this->pre_page   = '��һҳ';
            $this->first_page = '��ҳ';
            $this->last_page  = 'βҳ';
            return $this->first_page() . $this->pre_page() . '[��' . $this->nowindex . 'ҳ]' . $this->next_page() . $this->last_page() . '��' . $this->select() . 'ҳ';
            break;
        case '3':
            $this->next_page  = '��һҳ';
            $this->pre_page   = '��һҳ';
            $this->first_page = '��ҳ';
            $this->last_page  = 'βҳ';
            return $this->first_page() . $this->pre_page() . $this->next_page() . $this->last_page();
            break;
        case '4':
            $this->next_page    = '��һҳ';
            $this->pre_page     = '��һҳ';
            $this->format_left  = "";
            $this->format_right = "";
            return $this->pre_page() . " " . $this->nowbar() . " " . $this->next_page();
            break;
        case '5':
            return $this->pre_bar() . $this->pre_page() . $this->nowbar() . $this->next_page() . $this->next_bar();
            break;
        case '6':
            $this->first_page   = '��ҳ';
            $this->next_page    = '��ҳ';
            $this->pre_page     = '��ҳ';
            $this->last_page    = 'βҳ';
            $this->format_left  = "";
            $this->format_right = "";
            return "��" . $this->totalpage . "ҳ " . "��" . $this->nowindex . "ҳ " . $this->first_page() . " " . $this->pre_page() . " " . $this->nowbar() . " " . $this->next_page() . " " . $this->last_page(). " ��". $this->total. "��" ;
            break;
        case '7':
            $this->first_page   = '��ҳ';
            $this->next_page    = '��ҳ';
            $this->pre_page     = '��ҳ';
            $this->last_page    = 'βҳ';
            $this->format_left  = "";
            $this->format_right = "";
            return "��" . $this->totalpage . "ҳ " . "��" . $this->nowindex . "ҳ " . $this->first_page() . " " . $this->pre_page() . " " . $this->next_page() . " " . $this->last_page();
            break;
        case '8':
            $this->first_page   = '[��ҳ]';
            $this->next_page    = '[��ҳ]';
            $this->pre_page     = '[��ҳ]';
            $this->last_page    = '[βҳ]';
            $this->format_left  = "";
            $this->format_right = "";
            return "��" . $this->totalpage . "ҳ " . "��" . $this->nowindex . "ҳ " . $this->first_page() . " " . $this->pre_page() . " " . $this->next_page() . " " . $this->last_page();
            break;
        case '9':
            $this->first_page   = '��ҳ';
            $this->next_page    = '��ҳ';
            $this->pre_page     = '��ҳ';
            $this->last_page    = 'βҳ';
            $this->format_left  = "";
            $this->format_right = "";
            return $this->first_page() . " " . $this->pre_page() . " " . $this->nowbar() . " " . $this->next_page() . " " . $this->last_page();
            break;
                
        }
        
    }

    /**
     * ����urlͷ��ַ
     *
     * @param String $url url
     *
     * @return boolean
     */
    public function _set_url($url = "")
    {
        if (!empty($url)) {
            //�ֶ�����
            if ($this->rewrite == 1) {
                $this->url = $url;
            } else {
                $this->url = $url . ((stristr($url, '?')) ? '&' : '?') . $this->page_name . "=";
            }
            
        } else {
            //�Զ���ȡ
            if (empty($_SERVER['QUERY_STRING'])) {
                //������QUERY_STRINGʱ
                $this->url = $_SERVER['REQUEST_URI'] . "?" . $this->page_name . "=";
            } else {
                //
                if (stristr($_SERVER['QUERY_STRING'], $this->page_name . '=')) {
                    //��ַ����ҳ�����
                    $this->url = str_replace($this->page_name . '=' . $this->nowindex, '', $_SERVER['REQUEST_URI']);
                    $last      = $this->url[strlen($this->url) - 1];
                    if ($last == '?' || $last == '&') {
                        $this->url .= $this->page_name . "=";
                    } else {
                        $this->url .= '&' . $this->page_name . "=";
                    }
                } else {
                    //
                    $this->url = $_SERVER['REQUEST_URI'] . '&' . $this->page_name . '=';
                } //end if   
            } //end if
        } //end if
    }
    
    /**
     * ���õ�ǰҳ��
     *
     * @param String $nowindex nowindex
     *
     * @return string
     */
    public function _set_nowindex($nowindex)
    {
        if (empty($nowindex)) {
            //ϵͳ��ȡ
            
            if (isset($_GET[$this->page_name])) {
                $this->nowindex = intval($_GET[$this->page_name]);
            }
        } else {
            //�ֶ�����
            $this->nowindex = intval($nowindex);
        }
    }
    
    /**
     * Ϊָ����ҳ�淵�ص�ֵַ
     *
     * @param int $pageno pageno
     *
     * @return string $url
     */
    public function _get_url($pageno = 1)
    {
        if ($this->rewrite == 1) {
            return $this->url . $pageno . $this->rewrite_ext;
        } else {
            return $this->url . $pageno;
        }
        
    }
    
    /**
     * ��ȡ��ҳ��ʾ���֣�����˵Ĭ�������_get_text('<a href="">1</a>')������[<a href="">1</a>]
     *
     * @param String $str str
     *
     * @return string $url
     */
    public function _get_text($str)
    {
        return $this->format_left . $str . $this->format_right;
    }
    
    /**
     * ��ȡ���ӵ�ַ
     *
     * @param string $url   url
     * @param string $text  style
     * @param string $style style
     *
     * @return string $url
     */
    public function _get_link($url, $text, $style = '')
    {
        $style = (empty($style)) ? '' : 'class="' . $style . '"';
        if ($this->is_ajax) {
            //�����ʹ��AJAXģʽ
            return '<a ' . $style . ' href="javascript:' . $this->ajax_action_name . '(' . $url . ')">' . $text . '</a>';
        } else {
            return '<a ' . $style . ' href="' . $url . '">' . $text . '</a>';
        }
    }
    /**
     * ����������ʽ
     *
     * @param string $function function
     * @param string $errormsg errormsg
     *
     * @return string
     */
    public function error($function, $errormsg)
    {
        die('Error in file <b>' . __FILE__ . '</b> ,Function <b>' . $function . '()</b> :' . $errormsg);
    }
    
    /**
     * ��ʦ���߷�ҳ����
     * 
     * @param string $askcount    ��ǰҳ��ʽ
     * @param int    $pagetotal   ��ҳ��
     * @param int    $pagenum     ��ǰҳ
     * @param string $pageurlhead pageurlhead
     * @param string $classhtml   classhtml
     * @param int    $parm        �Ƿ�Ҫ<li>��ǩ
     * @param int    $pagesize    ÿҳ��ʾ����
     * @param int    $online      online
     * 
     * @return string $pageBreak
     */
    public static function pageBreak($askcount,$pagetotal,$pagenum,$pageurlhead,$classhtml,$parm,$pagesize=10,$online="1")
    {
        if ( isset($parm['lawyerpage']) && $parm['lawyerpage']=='y') {
            $pparm = '/page_'; 
        } else {
            $pparm = '/p_';
        }
        $pparm = isset($parm["pparm"]) ? $parm["pparm"] : '_';
        $other_param = isset($parm["other_param"])? $parm["other_param"]:'';//������ҳ����

        if (isset($parm["nowrap"]) && $parm["nowrap"]!='') {
            $classattr = '';
            $wleft = '';
            $wright = '';
            $wleft_calss = '';
        } else {
            $classattr = 'class="hover"';
            $wleft = '<li>';
            $wright = '</li>';
            $wleft_calss = '<li '.$classattr.'>';
        }
        
        $prehtml = $wleft.'<a href="'.$pageurlhead.$pparm.($pagenum-1).$other_param.'">��һҳ</a>'.$wright;
        $nexthtml = $wleft.'<a href="'.$pageurlhead.$pparm.($pagenum+1).$other_param.'">��һҳ</a>'.$wright;
        if ($pagenum == 1) {
            //��һҳ
            $prepage = 1;
            $prehtml = $wleft.'<a href="'.$pageurlhead.$pparm.$prepage.$other_param.'">��һҳ</a>'.$wright;

            //��һҳ
            $nextpage = 2;
            $nexthtml = $wleft.'<a href="'.$pageurlhead.$pparm.$nextpage.$other_param.'">��һҳ</a>'.$wright;
        }

        if ($pagenum == $pagetotal && $pagenum != 1) {
            //��һҳ
            $prepage = $pagenum - 1;
            $prehtml = $wleft.'<a href="'.$pageurlhead.$pparm.$prepage.$other_param.'">��һҳ</a>'.$wright;
            //��һҳ
            $nextpage = $pagenum;
            $nexthtml = $wleft.'<a href="'.$pageurlhead.$pparm.$nextpage.$other_param.'">��һҳ</a>'.$wright;
        } else if ($pagenum == $pagetotal && $pagenum == 1) {
            $prepage = 1;
            $prehtml = $wleft.'<a href="'.$pageurlhead.$pparm.$prepage.$other_param.'">��һҳ</a>'.$wright;

            //��һҳ
            $nextpage = 1;
            $nexthtml = $wleft.'<a href="'.$pageurlhead.$pparm.$nextpage.$other_param.'">��һҳ</a>'.$wright;
        }
        $pagehtml = '';
        if ( $pagetotal <= 5) {
            for ($i=0; $i<$pagetotal; $i++) {
                if (($i+1) == $pagenum) {
                    $w = $wleft_calss;
                    $ahtml = ($i+1);
                } else {
                    $w = $wleft;
                    $ahtml = '<a href="'.$pageurlhead.$pparm.($i+1).$other_param.'">'.($i+1).'</a>';
                }
                $pagehtml .= $w.$ahtml.$wright;
            }
        } else {
            if ($pagenum <= 3) {
                for ($i=0 ; $i<5 ; $i++ ) {
                    if (($i+1) == $pagenum) {
                        $w = $wleft_calss;
                        $ahtml = ($i+1);
                    } else {
                        $w = $wleft;
                        $ahtml = '<a href="'.$pageurlhead.$pparm.($i+1).$other_param.'">'.($i+1).'</a>';
                    }
                    $pagehtml .= $w.$ahtml.$wright;
                }
            }

            if ($pagenum>3) {
                for ($i=$pagenum; $i<($pagenum+5); $i++) {
                    if (($i-2) == $pagenum) {
                        $w = $wleft_calss;
                        $ahtml = ($i-2);
                    } else {
                        $w = $wleft;
                        $ahtml = '<a href="'.$pageurlhead.$pparm.($i-2).$other_param.'">'.($i-2).'</a>';
                    }
                    $pagehtml .= $w.$ahtml.$wright;
                }
            }

            if ($pagenum >= ($pagetotal-2)) {
                $pagehtml = '';
                for ($i=($pagetotal-4); $i<=$pagetotal; $i++) {
                    if ($i == $pagenum) {
                        $w = $wleft_calss;
                        $ahtml = $i;
                    } else {
                        $w = $wleft;
                        $ahtml = '<a href="'.$pageurlhead.$pparm.$i.$other_param.'">'.$i.'</a>';
                    }
                    $pagehtml .= $w.$ahtml.$wright;
                }
            }
        }
        if (isset($parm["pageonly"]) && $parm["pageonly"]!='') {
            $page	 = $wleft.'<a href="'.$pageurlhead.$pparm.'1'.$other_param.'">��ҳ</a>'.$wright;
            $lasthtml = $wleft.'<a href="'.$pageurlhead.$pparm.$pagetotal.$other_param.'">δҳ</a>'.$wright;
            $page	= $page.$prehtml.$pagehtml.$nexthtml.$lasthtml;
             return $page;
        }

        if ($online=="1") {
            $conhtml = $parm['conhtml']?('<ul class="page"><p><span class="fl">'.$parm['conhtml'].'</span>'):'';
            $page	 = $conhtml.'<span class="fr">��<span class="red fb">'.$pagenum.'</span>/<span class="fb">'.$pagetotal.'</span>ҳ ÿҳ<span class="fb">'.$pagesize.'</span>�� ��<span class="fb">'.$askcount.'</span>��</span></p><li><a href="'.$pageurlhead.$pparm.'1'.$other_param.'">��ҳ</a>'.$wright;
            $lasthtml = $wleft.'<a href="'.$pageurlhead.$pparm.$pagetotal.$other_param.'">δҳ</a>'.$wright.($conhtml?'</ul>':'');
            $page .= $prehtml.$pagehtml.$nexthtml.$lasthtml;
        } elseif ($online=="2") {

            $conhtml = '<div class="online_page"><p class="online_page_top"><span class="fl">'.$parm['conhtml'].'</span>';
            $page	 = $conhtml.'<span class="fr">��<span class="red fb">'.$pagenum.'</span>/<span class="fb">'.$pagetotal.'</span>ҳ ÿҳ<span class="fb">'.$pagesize.'</span>�� ��<span class="fb">'.$askcount.'</span>��</span></p><div class="ptb20"><ul class="in_page"><li><a href="'.$pageurlhead.$pparm.'1'.$other_param.'">��ҳ</a>'.$wright;
            $lasthtml = $wleft.'<a href="'.$pageurlhead.$pparm.$pagetotal.$other_param.'">δҳ</a>'.$wright.($conhtml?'</ul>':'');

            if ($pagesize==20) {

                $xuanze='<div class="num_btn">
                                ÿҳ��ʾ������
                                <a class="hover" style="cursor: pointer;" onclick="fenye(20);">20</a>
                                <a  style="cursor: pointer;" onclick="fenye(30);">30</a>
                                <a  style="cursor: pointer;" onclick="fenye(40);">40</a>
                                </div></div></div>';
            } elseif ($pagesize==30) {
                $xuanze='<div class="num_btn">
                                ÿҳ��ʾ������
                                <a  style="cursor: pointer;" onclick="fenye(20);">20</a>
                                <a style="cursor: pointer;" class="hover"  onclick="fenye(30);">30</a>
                                <a  style="cursor: pointer;" onclick="fenye(40);">40</a>
                                </div></div></div>';
            } else {
                  $xuanze='<div class="num_btn">
                                ÿҳ��ʾ������
                                <a   style="cursor: pointer;" onclick="fenye(20);">20</a>
                                <a  style="cursor: pointer;" onclick="fenye(30);">30</a>
                                <a style="cursor: pointer;" class="hover"   onclick="fenye(40);">40</a>
                                </div></div></div>';
            }

            $page .= $prehtml.$pagehtml.$nexthtml.$lasthtml.$xuanze;
        } else {

            $conhtml = '<div class="online_page"><p class="online_page_top"><span class="fl">'.$parm['conhtml'].'</span>';
            $page	 = $conhtml.'<span class="fr">��<span class="red fb">'.$pagenum.'</span>/<span class="fb">'.$pagetotal.'</span>ҳ ÿҳ<span class="fb">'.$pagesize.'</span>�� ��<span class="fb">'.$askcount.'</span>��</span></p><div class="ptb20"><ul class="in_page"><li><a href="'.$pageurlhead.$pparm.'1'.$other_param.'">��ҳ</a>'.$wright;
            $lasthtml = $wleft.'<a href="'.$pageurlhead.$pparm.$pagetotal.$other_param.'">δҳ</a>'.$wright.($conhtml?'</ul>':'');
            $xuanze='<div class="num_btn"></div></div></div>';
            $page .= $prehtml.$pagehtml.$nexthtml.$lasthtml.$xuanze;
        }
        return $page;
    }
}
?>