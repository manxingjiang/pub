<?php
/**
 *  �ֶ������˺���
 *
 *  @author kongwenhua <kongwenhua@findlaw.cn>
 */
namespace Tools;
use Tools;
/**
 *  �ֶ������˺���
 *
 *  @author kongwenhua <kongwenhua@findlaw.cn>
 */
class AutoLogin
{
    private $conn = null;//xxxx
    private $userid = '';
    private $psw = '';
    private $email = '';
    private $address = '';
    private $areainfo = array();
    private $inputdate = 0;
    private $user_ip = '';
    private $ifaudit="N";//��˱�־
    private $uid=0;
    private $mobile = '';
    public  $userinfo = array();//�Զ�ע��ɹ����û���Ϣ-��������ж��Ƿ�ע��ɹ�
    private $frompage = '';  // �Զ�ע����Դ 

    /**
     * ���캯��
     *
     * @param array $conn      x
     * @param int   $record_id xxxx
     * @param int   $user_id   xxx
     *
     * @return mixed
     */
    public function __construct($conn, $record_id=0 ,$user_id=0)
    {
        $this->inputdate = time();
        $this->conn = $conn;
        $this->user_ip = \Tools\Iparea::getClientIP();
        $this->userid = self::_getRandUserid();
        $this->psw = $this->getRandPassword();
        $this->email = $this->getRandEmail();
        $this->areainfo = $this->getIpAreainfo();

    }
    
    /**
     * ����
     * date('Y-m-d H:i:s',ceil((hexdec(�û�id)/1048576)-microtime()))
     *
     * @return ...
     */
    public function getRandUserid()
    {
        return uniqid();
    }

    /**
     * get userid
     *
     *  @return string $userid
     */
    public static function _getRandUserid()
    {
        //�Զ�ע���û�������
        $userid = 'wl';
        $userid .= \Org\Util\Strings::randString(4, 1);//4,1
        $userid .= \Org\Util\Strings::randString(4, 3);//4,3
    
        $member = \Rpc::getUCData('Member.admin.getUcMemberByUserid', $userid);
        if (!empty($member)) {
            return self::_getRandUserid();   
        }
        return $userid;
    }
    /**
     * ��ȡuserid
     *
     * @return mixed
     */
    public function getuserid()
    {
        return $this->userid;
    }

    /**
     * ��ȡ����
     *
     * @return mixed
     */
    public function getpsw()
    {
        return $this->psw ;
    }
    
    /**
     * ��ȡemail
     *
     * @return mixed
     */
    public function getemail()
    {
        return $this->email ;
    }


    /**
     * �����������
     *
     * @return mixed
     */
    public function getRandPassword()
    {        
        return \Org\Util\Strings::randString(8, 1);
    }
    
    /**
     * ����email
     *
     * @return mixed
     */
    public function getRandEmail()
    {
        return 'auto'.time().'@mail.com';
    }
    
    /**
     * ��ip��ȡ����
     *
     * @return mixed
     */
    public function getIpAreainfo()
    {
        $areainfo = \Tools\Iparea::getIpReviseArea();
        $info[] = $areainfo['province'];
        $info[] = $areainfo['city'];
        $info[] = $areainfo['country'];
        return $info;
    }
    
    /**
     * �����¼cookie
     *
     * @param int $uid xxx
     *
     * @return mixed
     */
    public function setOldLoginCookie($uid)
    {
        $cdb_psw = md5($this->psw); $secques = '';  $uid = $uid; 
        $cookietime = 60*60*24*3000; $username = $this->userid;

        $authold = "$cdb_psw\t$secques\t$uid";
        $this->dsetcookie('auth', self::authcode($authold, 'ENCODE'), $cookietime);
        $this->dsetcookie('cdb_auth', self::authcode($authold, "ENCODE", md5('x0qOZP4yZjIPSRZ'.$_SERVER['HTTP_USER_AGENT'])), $cookietime);

        $cflauth = "2\t{$uid}\t{$username}\t����\t20";
        $this->dsetcookie('cflauth', self::authcode($cflauth, 'ENCODE'), $cookietime);
        $this->dsetcookie('logintime', time(), $cookietime);

        //��¼�û�����
        $Uclogin = new \Tools\UcLogin();
        $Uclogin->userIdentSave($uid, $this->userid, $this->psw, '', $cookietime, array(1, 2, 3));

        return;
    }
    
    /**
     * ����cookie
     *
     * @param string $var      �ִ�
     * @param string $value    xxxx
     * @param string $life     xxx  
     * @param int    $httponly xxx
     *
     * @return mixed
     */
    function dsetcookie($var, $value = '', $life = 0, $httponly = false)
    {
        $timenow = time();
        $cookiedomain = '.findlaw.cn';
        $cookiepath = '/';
        if ($value == '' || $life < 0) {
            $value = '';
            $life = -1;
        }
        $life = $life > 0 ? ($timenow + $life) : ( $timenow - 31536000 );
        $path = $httponly && PHP_VERSION < '5.2.0' ? "$cookiepath; HttpOnly" : $cookiepath;
        $secure = $_SERVER['SERVER_PORT'] == 443 ? 1 : 0;
        if (PHP_VERSION < '5.2.0') {
            $ret = setcookie($var, $value, $life, $path, $cookiedomain, $secure);
        } else {
            $ret = setcookie($var, $value, $life, $path, $cookiedomain, $secure, $httponly);
        }
        return $ret;
    }
    
    /**
     * ���ɼ��ܴ�
     *
     * @param string $string    �ִ�
     * @param string $operation xxxx
     * @param string $key       xxx  
     * @param int    $expiry    xxx
     *
     * @return mixed
     */
    public static function authcode($string, $operation = 'DECODE', $key = '', $expiry = 0)
    {
        $auth_key = !empty($key) ? $key : '';
        $key = md5($auth_key);
        $key_length = strlen($key);
        $string = $operation == "DECODE" ? base64_decode($string) : substr(md5($string.$key), 0, 8).$string;
        $string_length = strlen($string);
        $rndkey = $box = array();
        $result = "";
        $i = 0;
        for (; $i <= 255; ++$i) {
            $rndkey[$i] = ord($key[$i % $key_length]);
            $box[$i] = $i;
        }
        $j = $i = 0;
        for (; $i < 256; ++$i) {
            $j = ($j + $box[$i] + $rndkey[$i]) % 256;
            $tmp = $box[$i];
            $box[$i] = $box[$j];
            $box[$j] = $tmp;
        }
        $a = $j = $i = 0;
        for (; $i < $string_length; ++$i) {
            $a = ($a + 1) % 256;
            $j = ($j + $box[$a]) % 256;
            $tmp = $box[$a];
            $box[$a] = $box[$j];
            $box[$j] = $tmp;
            $result .= chr(ord($string[$i]) ^ $box[($box[$a] + $box[$j]) % 256]);
        }
        if ($operation == "DECODE") {
            if (substr($result, 0, 8) == substr(md5(substr($result, 8).$key), 0, 8)) {
                return substr($result, 8);
            } else {
                return "";
            }
        } else {
            return str_replace("=", "", base64_encode($result));
        }
    }
    
    /**
     * �µ� �����û��Զ�ע�᷽�� ͬʱע�� �ҷ����û�����
     *
     * @param array $choiceRegData ��ѡ��ע����Ϣ
     *
     * @return bool ע��ɹ����û���Ϣ������ $this->userinfo��
     */
    public function autoreg_leo($choiceRegData = null)
    {
        //ע���û�����
        $reUc = $this->autoRegUcleo($choiceRegData);
        if ($reUc['state'] == '01') {
            return true;
        }
        /*if ($reUc['state'] == '01') {
            //���ҷ�ע��
            $re = $this->autoRegleo($reUc);
            if ($re['state']=='01') {
                return true;
            } else {
                //�ҷ�ע��ʧ��ɾ���û�����ע����������
                $this->deleteleo($reUc['uid']);
            }
        }*/
        return false;
    
    }
    
    /**
     * ƽ̨�Զ�ע�ṫ���û�
     *
     * @param array $choiceRegData ��ѡ��ע����Ϣ
     *
     * @return regifno
     */
    protected function autoRegleo($choiceRegData = null)
    {
        $regData = array(
            'id' => $choiceRegData['uid'],
            'userid' => $choiceRegData['userid'],
            'username' => empty($choiceRegData['username']) ? '����' : $choiceRegData['username'],
            'email' => $choiceRegData['email'],
            'psw' => $choiceRegData['psw'],
            'sex' => 1,
            'ifaudit' => 'N',
            'inputdate' => $this->inputdate,
            'ip' => \Tools\Iparea::encode_ip($this->user_ip),
            'regfrom' => $choiceRegData['regfrom'] ? $choiceRegData['regfrom'] : 1
        );
        //��ѡ��ע����Ϣ
        $choiceFrom = array('mobil', 'areacode', 'province', 'city', 'tel');
        if (!empty($choiceRegData) && is_array($choiceRegData)) {
            foreach ($choiceFrom as $k => $val) {
                if (!empty($choiceRegData[$val])) {
                    $regData[$val] = $choiceRegData[$val];
                }
            }
        }
        //�ҷ����
        //��state �������룺 "01" �ɹ� "02" �û��Ѵ���  "03" ��������ע���û� 04 ���ֻ���ע�� 05 userid�����Ǵ�����
        $re = \Rpc::getData('Member.Admin.addRegTblleo', $regData);
        if ($re['state'] == '01') {
            $regData['uid'] = $re['uid'];
            $regData['state'] = '01';
            //ע�����Ϣ
            $this->userinfo = $regData;
            return $regData;
        } else {
            return $re;
        }
    }
    /**
     * �û������Զ�ע�ṫ���û�
     *
     * @param array $regData ����Ϊ�ҷ�ƽ̨�Զ�ע������ ����ע��ɹ����uid
     *
     * @return boolean
     */
    protected function autoRegUcleo($regData)
    {
        
        //�ҷ�ע��ɹ�ע���û�����
        $regUcData = array(
            //'uid' => $regData['uid'],
            'userid' => $regData['userid'] ? $regData['userid'] : $this->userid,
            'username' => empty($regData['username']) ? '����' : $regData['username'],
            'password' => $this->psw,
            'mobile' => empty($regData['mobil']) ? '' : $regData['mobil'],
            'areacode' => empty($regData['areacode']) ? 0 : $regData['areacode'],
            'email' => $this->getRandEmail(),
            'regtime' => $this->inputdate,
            'regip' => ip2long($this->user_ip),
            'passIntensity' => \Tools\User::getPassIntensity($this->psw),
            'membertype' => 2,
            'lat' => $_COOKIE['areaGps']['lat'],
            'lon' => $_COOKIE['areaGps']['lng'],
            'regfrom' => empty($regData['regfrom']) ? 1 : $regData['regfrom'],
            'url' => empty($this->frompage) ? substr($_SERVER['HTTP_REFERER'], 0, 200) : $this->frompage
        );
        if (isset($regData['tel'])) {
            $regUcData['tel'] = $regData['tel'];
        }
    
        $reUc = \Rpc::getUCData('Member.admin.addAutoRegTblleo', $regUcData);
        if ($reUc['state']=='01') {
            $regData['psw'] = $regUcData['password'];
            //�ϲ�ԭ��Ϣ���������ҷ�
            $newData = array_merge($reUc, $regData);
            $this->userinfo = $newData;
            return $newData;
        } else {
            return $reUc;
        }
        
    
    
    
    
    }
    /**
     * ɾ�������û�
     *
     * @param int    $uid �û�uid
     * @param number $uc  0��ֻɾ��ƽ̨�û��� 1:ɾ��ƽ̨ͬʱɾ���û�����
     *
     * @return bool
     */
    protected function deleteleo($uid, $uc = 0)
    {
        if (empty($uid) || !is_numeric($uid)) {
            return false;
        }
        $uids = array($uid);
        switch ($uc) {
        case 1:
                $re = \Rpc::getUCResponse('Member.admin.deleteTblleoByUid', $uids, 'autoRegErr');
        case 0:
                //$re = \Rpc::getResponse('Member.Admin.deleteTblleoByIds', $uids);
                $re = \Rpc::getResponse('PHPBB.Admin.deleteCdbMembers', $uid);
                $re = $re->isSuccess();
                $re = true;
            break;
        default:
                $re = false;
        }
    
        return $re;
    
    }

    /**
     * ɾ�������û�
     *
     * @param string $url xxx
     *
     * @return ...
     */    
    public function setFromPage($url)
    {
        $this->frompage = $url;
    }
    
}
