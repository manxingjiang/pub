<?php
/**
  * ����ͨ������
  *
  * @author    zsg <1649353934@qq.com>
  */
namespace Tools;
use Tools;
/**
  * ����ͨ������
  *
  * @author    zsg <1649353934@qq.com>
  */
class FlWlt
{
    /**
     * ����ͨ��ʦ��Ա��Ϣ
     * 
     * @param unknown $lawyer_userid lawyer_userid
     * 
     * @return array
     */
    public function queryWltMemberDetail($lawyer_userid)
    {
        static $arr = array();
        
        if (!isset($arr[$lawyer_userid])) {
            $tmp = \Rpc::getData("Wlt.queryWltMemberDetailList", array('ifaudit'=>1, 'lawyerUserid'=>$lawyer_userid));
            if (empty($tmp)) {
                return $tmp;
            }
            $tmp = $tmp[0];
            
            //���õȼ�
            $tmp['creditGrade'] = $this->xinyongToGrade($tmp['creditValue']);
            
            //�Ƿ����ô�ʹ  ��7��15����9��15�սɷѵĹ����û���ӵ�С����ô�ʹ����־
            $ds_time_start = strtotime('2013-7-15');
            $ds_time_end = strtotime('2013-9-15');
                        
            $tmp['isXinyongXF'] = in_array($tmp['realName'], $this->xiangfen_lawyers());
            $tmp['isXinyongDS'] = $tmp['ifauditTime'] > $ds_time_start && $tmp['ifauditTime'] < $ds_time_end;
            if ($tmp['isXinyongXF']) {
                $tmp['isXinyongDS'] = false;
            }
            
            //ѧ��ȡ�÷�ʽ
            $xueliGettype2name = $this->xueliGettypes();
            $tmp["xueliGettype"] = isset($xueliGettype2name[$tmp["xueliGettype"]]) ? $xueliGettype2name[$tmp["xueliGettype"]] : ''; 
            //print_r($tmp);exit;
            
            //��ͨ����
            $row = $this->wltKaiTongYear($lawyer_userid);
            $tmp['wltYear'] = $row['totalYear'];
            
            $arr[$lawyer_userid] = $tmp;
        
        } 
        
        return $arr[$lawyer_userid];
    }
    
    /**
     * ��ѯ��ʦ��ͨ����ͨ����
     *
     * @param unknown $lawyer_userid lawyer_userid
     *
     * @return int
     */
    public function wltKaiTongYear($lawyer_userid)
    {
        $p = array(
                'userid'=>$lawyer_userid,
                'servername'=>'wlt',
                'orderBy' => 'servefirstime asc'
        );
        $list = \Rpc::getData("Member.queryTblmenberserverList", 1, 9999, $p);
        
        if (empty($list)) {
            return array(
                'totalTime'=>0,
                'totalYear'=>1
            );
        }
         
        $arr = array();
        
        foreach ($list as $v) {
            
            if ($v['servefirstime'] >= $v['serveendtime']) {
                continue;
            }
            
            if (empty($arr)) {
                $arr[0] = array($v['servefirstime'], $v['serveendtime']);
            } else {
                $tmp = end($arr);
                if ($v['servefirstime'] <= $tmp[1]) {
                    $arrlen = count($arr);
                    $arr[$arrlen-1][1] = $v['serveendtime'];
                } else {
                    $arr[] = array($v['servefirstime'], $v['serveendtime']);
                }
            }
        }
        
        $totaltime = 0;
        foreach ($arr as $v) {
            $totaltime +=  $v[1] - $v[0];
        }
                
        $r = array(
            'totalTime'=>$totaltime,
            'totalYear'=>ceil($totaltime/20304000)
        );
        if ($r['totalYear'] ==0) {
            $r['totalYear'] = 1;
        }
        return $r;
    }
    
    /**
     * ��ѯ��ʦִҵ֤��ϸ��Ϣ
     * 
     * @param unknown $lawyer_userid zxx
     * 
     * @return string
     */
    public function queryWltCertificateDetail($lawyer_userid)
    {
        $info = \Rpc::getData("Wlt.queryWltCertificateDetail", 1, $lawyer_userid);
        if (empty($info)) {
            $info = \Rpc::getData('Wlt.queryWltCerInDetail', 1, $lawyer_userid);
        }
        //ִҵ״̬
        $praStatus = array(1=>'����', 2=>'��ҵ');
        $info['praStatus'] = $praStatus[$info["praStatus"]];
        
        //���˽��
        
        $info['certiPic1'] = explode(',', $info['certiPic1']);
        $info['certiPic1'] =  $info['certiPic1'][0];
        
        //֤��ͼƬ
        $md5_lawyerid = md5($info['lawyerUserid']); 
        $certiPic1 = $info['certiPic1'];
        if (!strpos(MiscFunc::url_get_contents('http://images.findlaw.cn/my/myadmin/certificate/'.$md5_lawyerid.'/water_'.$certiPic1), '404 Not Found')) {
            $info['certiPic1'] = 'http://images.findlaw.cn/my/myadmin/certificate/'.$md5_lawyerid.'/water_'.$certiPic1;
            $info['certiPic1_thumb'] = 'http://images.findlaw.cn/my/myadmin/certificate/'.$md5_lawyerid.'/thumb_water_'.$certiPic1;
            $certiPic2 = $info['certiPic2'];
            $info['certiPic2'] = 'http://images.findlaw.cn/my/myadmin/certificate/'.$md5_lawyerid.'/water_'.$certiPic2;
            $info['certiPic2_thumb'] = 'http://images.findlaw.cn/my/myadmin/certificate/'.$md5_lawyerid.'/thumb_water_'.$certiPic2;
        } else {
            $info['certiPic1'] = 'http://images.findlaw.cn/my/myadmin/certificate/'.$md5_lawyerid.'/'.$certiPic1;
            $info['certiPic1_thumb'] = 'http://images.findlaw.cn/my/myadmin/certificate/'.$md5_lawyerid.'/thumb_'.$certiPic1;
            $certiPic2 = $info['certiPic2'];
            $info['certiPic2'] = 'http://images.findlaw.cn/my/myadmin/certificate/'.$md5_lawyerid.'/'.$certiPic2;
            $info['certiPic2_thumb'] = 'http://images.findlaw.cn/my/myadmin/certificate/'.$md5_lawyerid.'/thumb_'.$certiPic2;
        }
        return $info;
    }
    
    /**
     * �����ȷ���ʦ
     * 
     * @return multitype:
     */
    public function xiangfen_lawyers()
    {
        $str = '���հ� ������ ������ ��־ǿ ̷���� ���� ����� ��Ϊ�� ������ ��ƽ�� �鴺�� ����Ȫ ���� �ź��� ������ ����� ���÷ Ӣ���Ŷ�';
        return explode(' ', $str);
    }
    
    /**
     * ������ʦid��ѯ����ͨ��Ա�ۺ�����
     *
     * @param unknown $lawyer_userid lawyer_userid
     *
     * @return array
     */
    public function queryWltZhongheScore($lawyer_userid)
    {
        $list = \Rpc::getData("Wlt.queryWltZhongheScore", $lawyer_userid);
        
        $list1 = array();
        foreach ($list as $k=>$v) {
            $list1[$v["scoreType"]] = $v;
        }
        $list = $list1;
        unset($list1);
                
        $relist = array();
        $types = $this->wltScoreTypes();
        foreach ($types as $k=>$v) {
            $row = array(
                'scoreType'=>$k,
                'scoreTypename'=>$v
            );            
            if (isset($list[$k])) {
                $row['zhongheScore'] = $list[$k]['scoreSum'] / $list[$k]['scoreCount'];
            } else {
                $row['zhongheScore'] = 4;
            }
            $row['scorePercent'] = $row['zhongheScore'] * 100 / 5;
            $relist[] = $row;
        }
        
        return $relist;
    }
    
    /**
     * ����ͨ��������
     * 
     * @return array
     */
    public function wltScoreTypes()
    {
        return array(1=>'̬��', 2=>'רҵ', 3=>'Ч��', 4=>'���');
    }
    /**
     * ��ѯרҵ�б�
     *
     * @param array $ids ids
     * 
     * @return array
     */
    public function queryProfessionListByids($ids)
    {
        $profession = \Rpc::getData("Lawyer.queryProfessionListByids", $ids);
        return $profession;
    }

    /**
     * ��ѯרҵ�б�
     *
     * @param array $uid uid
     * 
     * @return array
     */
    public function queryLawyerRefProfByUidPid($uid)
    {
        if (ACTION_NAME !='siteSet' && ACTION_NAME !='setSort') {//��ʦ���ֲ����뻺��
            C('nocache', 1);
            $profession = \Rpc::getUCData('Member.admin.queryLawyerRefProfByUidPid', $uid, 1);
            C('nocache', 0);
        } else {
            $profession = \Rpc::getUCData('Member.admin.queryLawyerRefProfByUidPid', $uid, 1);
        }
        return $profession;
    }
    /**
     * ��ѯ�о����б�
     *
     * @param unknown $page     page
     * @param unknown $pageSize pageSize
     * @param unknown $param    $param
     *
     * @return array
     */
    public function queryWltVerdictList($page, $pageSize, $param)
    {
        $re = \Rpc::getData("Wlt.queryWltVerdictList", $page, $pageSize, $param);
        
        if (!empty($re)) {
            $typearr = array();
            foreach ($re as $v) {
                $typearr[] = $v['wenshuType'];
            }
            
            //��ѯ��������
            $type2name = array();
            //$tmplist = \Rpc::getData("Lawyer.queryProfessionListByids", $typearr);
            $tmplist = self::queryProfessionListByids($typearr);
            foreach ($tmplist as $v) {
                $type2name[$v["id"]] = $v['name'];
            }
            
            foreach ($re as $k=>$v) {
                $re[$k]['wenshuTypeName'] = $type2name[$v["wenshuType"]];
                $re[$k]['shortContent']  = trim(strip_tags($v['content']));
                $re[$k]['url'] = $this->anliUrl($v['id']);
            }            
        }
        return $re;
    }
    
    /**
     * ��ѯ�о����б�ͳ��
     *
     * @param unknown $param ��ѯ����
     *
     * @return array
     */
    public function queryWltVerdictListCount($param)
    {
        return \Rpc::getData("Wlt.queryWltVerdictListCount", $param);
    }
    
    /**
     * �����о������ͽ���ͳ��
     *
     * @param unknown $lawyer_userid userid
     * @param unknown $count_grade   ��������ͳ�Ƽ���
     *
     * @return array
     */
    public function queryVerdictCountByType($lawyer_userid, $count_grade)
    {
        $re = \Rpc::getData("Wlt.queryVerdictCountByType", $lawyer_userid, $count_grade);
        if (empty($re)) {
            return array();
        }
        $typearr = array();
        foreach ($re as $v) {
            $typearr[] = $v['type'];
        }
        
        //��ѯ��������
        $type2name = array();
        //$tmplist = \Rpc::getData("Lawyer.queryProfessionListByids", $typearr);
        $tmplist = self::queryProfessionListByids($typearr);
        foreach ($tmplist as $v) {
            $type2name[$v["id"]] = $v['name'];
        }
        
        foreach ($re as $k=>$v) {
            $re[$k]['typename'] = $type2name[$v["type"]];
        }
        
        //�ٷֱ�
        $verdictCount = \Rpc::getData("Wlt.queryWltVerdictListCount", array('lawyerUserid'=>$lawyer_userid, 'ifaudit'=>1));
        foreach ($re as $k=>$v) {
            $re[$k]['total'] = $verdictCount;
            $re[$k]['percent'] = $verdictCount>0 ? $v['typeCount'] * 100 /$verdictCount : 0;
        }
        
        return $re;   
    }
    
    /**
     *    �о�����ϸ��Ϣ
     * 
     * @param unknown $id        id
     * @param bool    $isreplace isreplace
     * 
     * @return array
     */
    public function verdictDetail($id, $isreplace = true)
    {
        $re = \Rpc::getData("Wlt.getVerdictDetailById", $id);
        if (!empty($re)) {
            $typeid = $re['wenshuType']; 

            $typename = '';
            $typename1 = $typename2 = '';
            if ($typeid>0 && $typeid<100) {
                //$typelist = \Rpc::getData("Lawyer.queryProfessionListByids", array($typeid));
                $typelist = self::queryProfessionListByids(array($typeid));
                if (!empty($typelist)) {
                    $typename = $typelist[0]['name'];
                    $typename1 = $typename2 = $typename;
                }
            } elseif ($typeid>100) {
                //$typelist = \Rpc::getData("Lawyer.queryProfessionListByids", array(substr($typeid, 0, 2), $typeid));
                $typelist = self::queryProfessionListByids(array(substr($typeid, 0, 2), $typeid));
                if (!empty($typelist)) {
                    $typename1 = '';
                    $typename2 = '';
                    foreach ($typelist as $v) {
                        if ($v['id']<100) {
                            $typename1 = $v['name'];
                        } else {
                            $typename2 = $v['name'];
                        }
                    }    
                    $typename =  $typename1 . '>>' .$typename2;               
                }
            } 
            $re['typename'] = $typename;
            $re['first_typename'] = $typename1;
            $re['last_typename'] = $typename2;
            
            //�滻�ؼ���
            if ($isreplace) {
                $typelist = \Rpc::getData("Wlt.queryWltVerdictkwList", 1, 100, array('verid'=>$id));
                if (!empty($tmplist)) {
                    $trans = array();
                    foreach ($tmplist as $k=>$v) {
                        $trans[$v["searchstr"]] = $v['replacestr'];
                    }
                    $re['content'] = strtr($re['content'], $trans);
                }
            }
        }
        return $re;
    }
    
    /**
     * ���չʾͼƬ
     * 
     * @param unknown $lawyerid lawyerid
     * 
     * @return array
     */
    public function lawyerPhotoList($lawyerid)
    {
        $p = array(
                'userid' => $lawyerid,
                'typeid' => 1,
                'status' => 1,
                'orderBy' => 'id desc,level desc'
        );
        $md5Lawyerid =  md5($lawyerid);
        $photolist = \Rpc::getData("Photo.queryLawyerPhotoList", 1, 20, $p);
        foreach ($photolist as $k=>$v) {
            $photolist[$k]['thumb'] = 'thumb' . '_' . $v['image'];
            $photolist[$k]['thumb_url'] = 'http://images.findlaw.cn/my/myadmin/lawyer/'. $md5Lawyerid . '/' . $photolist[$k]['thumb'];
            $photolist[$k]['image_url'] = 'http://images.findlaw.cn/my/myadmin/lawyer/'. $md5Lawyerid . '/' . $photolist[$k]['image'];
        }
        return $photolist;        
    }
    
    /**
     * ����url
     * 
     * @param unknown $id id
     * 
     * @return string
     */
    public function anliUrl($id)
    {
        return '/lawyer/jdal/d'. $id .'.html';
    }
    
    /**
     * �ļ�url
     *
     * @param unknown $id id
     *
     * @return string
     */
    public function articleUrl($id)
    {
        return '/lawyer/article/d'. $id .'.html';
    }
    
    /**
     * ����ֵת��Ϊ�ȼ�
     *
     * @param unknown $credit_value credit_value
     *
     * @return number
     */
    public function xinyongToGrade($credit_value)
    {
        $arr = array(
                array(0, 0, 4),
                array(1, 4, 10),
                array(2, 10, 40),
                array(3, 40, 90),
                array(4, 90, 150),
                array(5, 150, 250),
                array(6, 250, 500),
                array(7, 500, 1000),
                array(8, 1000, 2000),
                array(9, 2000, 5000),
                array(10, 5000, 10000),
                array(11, 10000, 20000),
                array(12, 20000, 50000),
                array(13, 50000, 100000),
                array(14, 100000, 200000),
                array(15, 200000, 500000),
                array(16, 500000, 1000000),
                array(17, 1000000, 2000000),
                array(18, 2000000, 5000000),
                array(19, 5000000, 10000000),
                array(20, 10000000, 20000000),
                array(21, 20000000, 50000000),
                array(22, 50000000, 100000000),
                array(23, 100000000, -1),
        );
        foreach ($arr as $v) {
            $s = $v[1];
            $e = $v[2];
            $g = $v[0];
            if ($credit_value>$s && $credit_value<=$e) {
                return $g;
            }
            if ($credit_value>$s && $e==-1) {
                return $g;
            }
        }
        return 0;
    }
    
    /**
     * ѧ����ȡ��ʽ
     *
     * @return multitype:string
     */
    public function xueliGettypes()
    {
        return array('1'=>'ȫ���Ƹ߿�', '2'=>'�ɽ̸߿�', '3'=>'�Կ�', '4'=>'Զ�̽���', '5'=>'������ѧ');
    }
}
