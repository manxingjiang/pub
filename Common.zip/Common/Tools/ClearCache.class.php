<?php
/**
 *  ������湤����
 *
 *  @author zsg <xxx@qq.com>
 *
 */
namespace Tools;
use Tools;
/**
 *  ������湤����
 *
 *  @author zsg <xxx@qq.com>
 */
class ClearCache
{
    private static $ips = array('180.186.38','14.17.121');
    
    /**
     * ����Memcache��
     * 
     * @return boolean
     */
    public static function memcache()
    {
        return \Tools\Cache::memcache();
    }
    /**
     * ������ѯ����
     * 
     * @param int   $qid    ��ѯid
     * @param array $value  ����
     * @param int   $expire ��Чʱ��
     * 
     * @return boolean
     */
    public static function setAskCache($qid, $value, $expire = null)
    {
        $key = self::qkey($qid);
        return \Tools\Cache::set($key, $value, $expire);
    }
    
    /**
     * ȡ��ѯ����
     *
     * @param int $qid ��ѯid 
     *
     * @return array
     */
    public static function getAskCache($qid)
    {
        $key = self::qkey($qid);
        return \Tools\Cache::get($key);
    }
    
    /**
     * ���û���
     * 
     * @param string $key    �����key
     * @param array  $value  ����
     * @param int    $expire ��Чʱ��
     * 
     * @return boolean
     */
    public static function setCache($key, $value, $expire = null)
    {
        return \Tools\Cache::set($key, $value, $expire);
    }

    /**
     * ȡ����
     *
     * @param string $key �����key
     *
     * @return array
     */
    public static function getCache($key)
    {
        return \Tools\Cache::get($key);
    }
    
    /**
     * ɾ����ѯ����
     *
     * @param int $qid ��ѯid
     *
     * @return boolean
     */
    public static function rmAskCache($qid)
    {
        $key = self::qkey($qid);
        return \Tools\Cache::rm($key);
    }
    
    /**
     * ɾ������
     *
     * @param string $key �����key
     *
     * @return boolean
     */
    public static function rmCache($key)
    {
        return \Tools\Cache::rm($key);
    }
    /**
     * qkey cache
     *
     * @param int $qid qid
     *
     * @return .....
     **/
    public static function qkey($qid)
    {
        return md5("Fl.Ask.Q.{$qid}");
    }
    
    /**
     * ���������ѯ����
     *
     * @param int|array $qids ������ѯID
     *
     * @return string
     */
    public static function clearQuestionCache($qids)
    {
        if (!is_array($qids)) {
            $qids = array($qids);
        }
        $qids = array_unique($qids);
        $rows = array();
        foreach ($qids as $qid) {
            $key = self::qkey($qid);
            $_rows = self::getDefaultVal($key);
            $rows = array_merge($rows, $_rows);
        }
    
        return self::insertClearCacheTmpByPK($rows);
    }
    
    /**
     * ��ȡһ��Ĭ��ֵ
     *
     * @param string $key key
     *
     * @return string
     */
    public static function getDefaultVal($key)
    {
        $ret = array();
        foreach (self::$ips as $ip) {
            $ret[] = array('key' => $key, 'serverip' => $ip, 'indate' => date('YmdHis', time()), 'type' => 2);
        }
        return $ret;
    }
    
    /**
     * �������(ͨ���������ݿ� �ɵ����������������ѯ����)
     *
     * @param array $rows ��ά���飬�ο� self::getDefaultVal();
     *
     * @return string
     */
    public static function insertClearCacheTmpByPK($rows)
    {
        if ($rows) {
            $re = \Rpc::getResponse('ClearCache.Admin.insertClearCacheTmpByPK', $rows);
        }
        return empty($re) ? false : $re->isSuccess();        
    }
}
?>
