<?php
/**
 *  ΢����Ϣ���ɹ���
 *
 *  @author zsg <1649353934@qq.com>
 *
 */
/**
 *  ΢����Ϣ���ɹ���
 *
 *  @author zsg <1649353934@qq.com>
 */
namespace Tools;
use Tools;
class Weixinmsg
{
    /**
     * text�ı���Ϣ
     * 
     * @return text
     */
    public static function textmsg($postObj, $contentStr)
    {
        $textTpl = "<xml>
            <ToUserName><![CDATA[%s]]></ToUserName>
            <FromUserName><![CDATA[%s]]></FromUserName>
            <CreateTime>%s</CreateTime>
            <MsgType><![CDATA[%s]]></MsgType>
            <Content><![CDATA[%s]]></Content>
            <FuncFlag>0</FuncFlag>
            </xml>";
         $msgType = "text";
         $time = time();
         $resultStr = sprintf($textTpl, $postObj->FromUserName, $postObj->ToUserName, $time, $msgType, $contentStr);
         return $resultStr;
    }
    /**
     * ��ͷ���Ϣ
     * 
     * @return text
     */
    public static function textmsgServ($postObj)
    {
        $xmlTpl = "<xml>
            <ToUserName><![CDATA[%s]]></ToUserName>
            <FromUserName><![CDATA[%s]]></FromUserName>
            <CreateTime>%s</CreateTime>
            <MsgType><![CDATA[transfer_customer_service]]></MsgType>
            </xml>";
        $result = sprintf($xmlTpl, $postObj->FromUserName, $postObj->ToUserName, time());
        return $result;
    }
}