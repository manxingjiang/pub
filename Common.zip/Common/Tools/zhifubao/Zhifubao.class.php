<?php
/**
 *  ֧������ȡ�ӿڣ�����http://m.findlaw.cn/zhifubao/alipay_fuwuchuang/�����ö���demo�
 *
 *  @author lixiaohui <496930310@qq.com>
 *
 */
/**
 *  ֧������ȡ�ӿ�
 *
 *  @author lixiaohui <496930310@qq.com>
 */
namespace Tools\zhifubao;
use Tools;
class Zhifubao
{
    public  $preUrl = "http://m.findlaw.cn/zhifubao/alipay_fuwuchuang/";  //demo·����������ȡ������
    public  $errorMsg = "";                                                       //������Ϣ
    public  $gatewayUrl ="https://openapi.alipay.com/gateway.do";           //֧��������
    public  $appId="2015110500695901";                                         //�����Ӧ��id
    public  $rsaPrivateKeyFilePath = 'key/rsa_private_key.pem';               //�̼�˽Կ·��
    public  $rsaPublicKeyFilePath = 'key/rsa_public_key.pem';                 //�̼ҹ�Կ·��
    public  $alipayPublicKeyFilePath = 'key/alipay_rsa_public_key.pem';      //֧������Կ·��

    public $postCharset = "UTF-8";   // �����ύ�ַ�������
    public $fileCharset = "GBK";   // ��ǰ�ļ��ַ�������
    public $apiVersion = "1.0";       //api�汾
    public $format = "json";          //�������ݸ�ʽ
    public $signType = "RSA";        //ǩ������
    public $terminalType;           //����������Ϊ�գ�
    public $terminalInfo;           //����������Ϊ�գ�
    public $prodCode;                //����������Ϊ�գ�

    public $re_signSourceData = "";    //���ز���������Ҫ
    public $re_sign = "";
    public $RESPONSE_SUFFIX = "_response";
    public $ERROR_RESPONSE = "error_response";
    public $SIGN_NODE_NAME = "sign";



    /**
     * ��ת����Ȩҳ��
     *
     * @param string $backUrl ��ת��Ȩҳ��������url
     *
     * @return boolean
     */
    public function turnAutoUrl($backUrl='') {
        if ($backUrl=='') {
              return false;
        } else {
            $toUrl = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id=".$this->appId."&auth_skip=false&scope=auth_userinfo&redirect_uri=".urlencode($backUrl);
            header("Location:".$toUrl);
            exit;
        }
    }

    /**
     * ����auth_code��ȡ�û�id
     *
     * @param string $auth_code ֧�����û���auth_code
     *
     * @return array
     */
    public function get_userid($auth_code) {
        $result = $this->getUserInfo($auth_code);
        if (!$result) {
            return false;
        } else {
            return $result->alipay_user_id;
        }
    }

    /**
     * ������Ϣ(����)
     *
     * @param string $toUserId Ҫ���͵���֧�����û�id
     * @param string $content  ��ʦ�ش���Ϣ
     *
     * @return boolean
     */

    public function message_custom_send($toUserId, $content)
    {
        $params = array(
            "toUserId"=>$toUserId,
            "msgType"=> "text",
            "createTime" => time(),
            "text"=>array(
                "content"=> iconv('gbk','utf-8',$content)
            )
        );

        $biz_content = json_encode ($params);
        $result = $this->messageCustomSend($biz_content);
        if (isset($result->alipay_system_oauth_token_response)) {
            if ($result->alipay_system_oauth_token_response->code==200) {
                return true;
            } else {
                $this->errorMsg = $result->alipay_system_oauth_token_response->msg;
                return false;
            }
        }
        $this->errorMsg = "������Ϣʧ�ܣ�";
        return false;
    }


    /**
     * ����ģ����Ϣ
     *
     * @param string $toUserId   Ҫ���͵���֧�����û�id
     * @param array  $userParams ��ʦ�ش���Ϣ
     * array��
     *     ��url��=�������Ҫ��ת��url��
     *     ��first��=�������Ҫ��ת��url��
     *     ��keyword1��=������ʦ�Ļش�
     *     ��keyword2��=������ʦ�����֡�
     *     ��keyword3��=������ʦ�ĵ绰��
     * ��
     *
     * @return boolean
     */
    public function message_single_send($toUserId, $userParams)
    {
        //        ����ģ��
        //        $qr_biz = array(
        //            "toUserId"=>$toUserId,
        //            "template"=>array(
        //                "templateId"=>"7c5fd0f984f04b62914364f06ec94dc1",
        //                "context"=>array(
        //                    "headColor"=>"#85be53",
        //                    "url"=>"http://m.ls.cn",
        //                    "actionName"=>"�鿴����",
        //                    "first"=>array(
        //                        "color"=>"#85be53",
        //                        "value"=>"�����������"
        //                    ),
        //                    "keyword1"=>array(
        //                        "color"=>"#000000",
        //                        "value"=>"������ʦ�ı���"
        //                    ),
        //                    "keyword2"=>array(
        //                        "color"=>"#85be53",
        //                        "value"=>"�Ż۽�"
        //                    ),
        //                    "keyword3"=>array(
        //                        "color"=>"#85be53",
        //                        "value"=>"13800000000"
        //                    ),
        //                    "remark"=>array(
        //                        "color"=>"#85be53",
        //                        "value"=>"���������ҳ"
        //                    )
        //                )
        //            )
        //        );

        $params = array(
            "toUserId"=>$toUserId,
            "template"=>array(
                "templateId"=>"7c5fd0f984f04b62914364f06ec94dc1",
                "context"=>array(
                    "headColor"=>"#85be53",
                    "url"=>iconv('gbk','utf-8',$userParams['url']),
                    "actionName"=>iconv('gbk','utf-8',"�鿴����"),
                    "first"=>array(
                        "color"=>"#85be53",
                        "value"=>iconv('gbk','utf-8',$userParams['first'])
                    ),
                    "keyword1"=>array(
                        "color"=>"#000000",
                        "value"=>iconv('gbk','utf-8',$userParams['keyword1']),
                    ),
                    "keyword2"=>array(
                        "color"=>"#85be53",
                        "value"=>iconv('gbk','utf-8',$userParams['keyword2']),
                    ),
                    "keyword3"=>array(
                        "color"=>"#85be53",
                        "value"=>iconv('gbk','utf-8',$userParams['keyword3']),
                    ),
                    "remark"=>array(
                        "color"=>"#85be53",
                        "value"=>iconv('gbk','utf-8',"����鿴")
                    )
                )
            )
        );

        $biz_content = json_encode ($params);

        $result = $this->messageSingleSend($biz_content);
        if (isset($result->alipay_system_oauth_token_response)) {
            if ($result->alipay_system_oauth_token_response->code==200) {
                return true;
            } else {
                $this->errorMsg = $result->alipay_system_oauth_token_response->msg;
                return false;
            }
        }
        $this->errorMsg = "����ģ����Ϣʧ�ܣ�";
        return false;
    }

    /*************************************************����ҵ�񷽷�**********************************************************/
    public static function aaaaaaaaaaaaaaaaa(){
        return true;
    }
    /*************************************************������ķ���**********************************************************/






    /**
     * ������Ϣ
     *
     * @param string $token ֧�����û�����
     *
     * @return array
     */
    public function messageCustomSend($biz_content) {
        $ApiMethodName = "alipay.mobile.public.message.custom.send";
        $apiParams = array(
            "biz_content"        => $biz_content
        );
        $result = $this->execute($ApiMethodName, $apiParams);
        return $result;
    }


    /**
     * ����ģ����Ϣ
     *
     * @param string $token ֧�����û�����
     *
     * @return array
     */
    public function messageSingleSend($biz_content) {
        $ApiMethodName = "alipay.mobile.public.message.single.send";
        $apiParams = array(
            "biz_content"        => $biz_content
        );
        $result = $this->execute($ApiMethodName, $apiParams);
        return $result;
    }


    /**
     * ����auth_code��ȡ�û���Ϣ
     *
     * @param string $auth_code ֧�����û���auth_code
     *
     * @return array
     */
    public function getUserInfo($auth_code) {
        if ($auth_code == '') {
            $this->errorMsg = "auth_code����Ϊ�գ�";
            return false;
        }
        $token = $this->requestToken ( $auth_code );

        if (isset ( $token->alipay_system_oauth_token_response )) {
            // �ɹ�����
            // ʾ����array(
            // 'access_token' => 'publicpBfd7aa055c4c34120949e287f84eee84a',
            // 'expires_in' => 500,
            // 're_expires_in' => 300,
            // 'refresh_token' => 'publicpB343643c1f58b415ab9add66c0ea91fd3',
            // )
            $token_str = $token->alipay_system_oauth_token_response->access_token;
            $user_info = $this->requestUserInfo ( $token_str );
            if (isset ( $user_info->alipay_user_userinfo_share_response )) {
                $user_info_resp = $user_info->alipay_user_userinfo_share_response;
                //                $user_id = $user_info_resp->user_id;
                //                $deliver_fullname = characet ( $user_info_resp->deliver_fullname );
                //                $deliver_mobile = $user_info_resp->deliver_mobile;
                return $user_info_resp;
            }
        } elseif (isset ( $token->error_response )) {
            // �����˴�����Ϣ
            // �磺[code] => 40002
            // [msg] => Invalid Arguments
            // [sub_code] => isv.code-invalid
            // [sub_msg] => ��Ȩ��code��Ч
            // ��¼���󷵻���Ϣ
            $this->errorMsg = "��ȡtokenʧ�ܣ�";
            return false;
        }
    }

    /**
     * ��ȡ�û���Ϣ
     *
     * @param string $token ֧�����û�����
     *
     * @return array
     */
    public function requestUserInfo($token) {
        $ApiMethodName = "alipay.user.userinfo.share";
        $result = $this->execute($ApiMethodName, array(), $token);
        return $result;
    }

    /**
     * ��ȡtoken
     *
     * @param string $auth_code ֧�����û�����
     *
     * @return array
     */
    public function requestToken($auth_code) {
        $ApiMethodName = "alipay.system.oauth.token";
        $apiParams = array(
            "code"        => $auth_code,
            //"refresh_token" => "",
            "grant_type" => "authorization_code"
        );
        $result = $this->execute($ApiMethodName, $apiParams);

        return $result;
    }












    function parserJSONSignData($ApiMethodName, $responseContent, $responseJSON) {
        $this->re_sign = $this->parserJSONSign($responseJSON);
        $this->re_signSourceData = $this->parserJSONSignSource($ApiMethodName, $responseContent);
    }

    function parserJSONSignSource($ApiMethodName, $responseContent) {
        $apiName = $ApiMethodName;
        $rootNodeName = str_replace(".", "_", $apiName) . $this-> RESPONSE_SUFFIX;
        $rootIndex = strpos($responseContent, $rootNodeName);
        $errorIndex = strpos($responseContent, $this->ERROR_RESPONSE);
        if ($rootIndex > 0) {
            return $this->parserJSONSource($responseContent, $rootNodeName, $rootIndex);
        } else if ($errorIndex > 0) {
            return $this->parserJSONSource($responseContent, $this->ERROR_RESPONSE, $errorIndex);
        } else {
            return null;
        }
    }

    function parserJSONSource($responseContent, $nodeName, $nodeIndex) {
        $signDataStartIndex = $nodeIndex + strlen($nodeName) + 2;
        $signIndex = strpos($responseContent, "\"" . $this->SIGN_NODE_NAME . "\"");
        // ǩ��ǰ-����
        $signDataEndIndex = $signIndex - 1;
        $indexLen = $signDataEndIndex - $signDataStartIndex;
        if ($indexLen < 0) {

            return null;
        }

        return substr($responseContent, $signDataStartIndex, $indexLen);

    }

    function parserJSONSign($responseJSon) {

        return $responseJSon->sign;
    }

    function parserXMLSignData($ApiMethodName, $responseContent) {
        $this->re_sign = $this->parserXMLSign($responseContent);
        $this->re_signSourceData = $this->parserXMLSignSource($ApiMethodName, $responseContent);
    }

    function parserXMLSignSource($ApiMethodName, $responseContent) {
        $apiName = $ApiMethodName;
        $rootNodeName = str_replace(".", "_", $apiName) . $this->RESPONSE_SUFFIX;


        $rootIndex = strpos($responseContent, $rootNodeName);
        $errorIndex = strpos($responseContent, $this->ERROR_RESPONSE);


        if ($rootIndex > 0) {
            return $this->parserXMLSource($responseContent, $rootNodeName, $rootIndex);
        } else if ($errorIndex > 0) {
            return $this->parserXMLSource($responseContent, $this->ERROR_RESPONSE, $errorIndex);
        } else {
            return null;
        }
    }

    function parserXMLSource($responseContent, $nodeName, $nodeIndex) {
        $signDataStartIndex = $nodeIndex + strlen($nodeName) + 1;
        $signIndex = strpos($responseContent, "<" . $this->SIGN_NODE_NAME . ">");
        // ǩ��ǰ-����
        $signDataEndIndex = $signIndex - 1;
        $indexLen = $signDataEndIndex - $signDataStartIndex + 1;

        if ($indexLen < 0) {
            return null;
        }
        return substr($responseContent, $signDataStartIndex, $indexLen);
    }

    function parserXMLSign($responseContent) {
        $signNodeName = "<" . $this->SIGN_NODE_NAME . ">";
        $signEndNodeName = "</" . $this->SIGN_NODE_NAME . ">";

        $indexOfSignNode = strpos($responseContent, $signNodeName);
        $indexOfSignEndNode = strpos($responseContent, $signEndNodeName);


        if ($indexOfSignNode < 0 || $indexOfSignEndNode < 0) {
            return null;
        }

        $nodeIndex = ($indexOfSignNode + strlen($signNodeName));

        $indexLen = $indexOfSignEndNode - $nodeIndex;

        if ($indexLen < 0) {
            return null;
        }

        // ǩ��
        return substr($responseContent, $nodeIndex, $indexLen);
    }

    /**
     * ����֧�����ӿ�
     *
     * @param string $ApiMethodName �ӿ���  (alipay.mobile.public.message.custom.send)
     * @param array  $apiParams     ������($apiParams['biz_content'])
     * @param string $authToken     ����
     *
     * @return array
     */
    public function execute($ApiMethodName, $apiParams=array(), $authToken = null) {

        //������
        if ($this->checkEmpty($ApiMethodName)) {
            $this->errorMsg = "execute,��������";
            return false;
        }

        //ƥ�����
        if ($this->checkEmpty($this->postCharset)) {
            $this->postCharset = "UTF-8";
        }
        $this->fileCharset = mb_detect_encoding($this->appId, "UTF-8,GBK");
        if (strcasecmp($this->fileCharset, $this->postCharset)) {
            $this->errorMsg = "execute,���벻һ��";
            return false;
        }

        //��װϵͳ����
        $sysParams["app_id"] = $this->appId;
        $sysParams["version"] = $this->apiVersion;
        $sysParams["format"] = $this->format;
        $sysParams["sign_type"] = $this->signType;
        $sysParams["method"] = $ApiMethodName;
        $sysParams["timestamp"] = date("Y-m-d H:i:s");
        $sysParams["auth_token"] = $authToken;
        $sysParams["alipay_sdk"] = $this->alipaySdkVersion;
        $sysParams["terminal_type"] = $this->terminalType;
        $sysParams["terminal_info"] = $this->terminalInfo;
        $sysParams["prod_code"] = $this->prodCode;
        $sysParams["charset"] = $this->postCharset;

        //ǩ��
        $sysParams["sign"] = $this->generateSign(array_merge($apiParams, $sysParams));

        //ϵͳ��������GET����
        $requestUrl = $this->gatewayUrl . "?";
        foreach ($sysParams as $sysParamKey => $sysParamValue) {
            $requestUrl .= "$sysParamKey=" . urlencode($this->characet($sysParamValue, $this->postCharset)) . "&";
        }
        $requestUrl = substr($requestUrl, 0, -1);

        //����HTTP����
        try {
            $resp = $this->curl($requestUrl, $apiParams);
        } catch (Exception $e) {
            $this::$errorMsg = $e->getCode().','.$e->getMessage();
            return false;
        }

        // �����ؽ��ת�������ļ�����
        $r = iconv($this->postCharset, $this->fileCharset . "//IGNORE", $resp);


        //�������ؽ��
        $respWellFormed = false;
        $signData = null;

        if ("json" == $this->format) {
            $respObject = json_decode($r);
            if (null !== $respObject) {
                $respWellFormed = true;
                $this->parserJSONSignData($ApiMethodName, $resp, $respObject);
            }
        } else if ("xml" == $this->format) {
            $respObject = @ simplexml_load_string($resp);
            if (false !== $respObject) {
                $respWellFormed = true;
                $this->parserXMLSignData($ApiMethodName, $resp);
            }
        }

        //���ص�HTTP�ı����Ǳ�׼JSON����XML
        if (false === $respWellFormed) {
            $this->errorMsg = "check respWellFormed Fail!";
            return false;
        }

        //���AOP�����˴�����
        if (isset ($respObject->sub_code)) {
            $this->errorMsg = "check respObject Fail!";
            return false;
        }

        // ��֤ǩ��
        if (!$this->checkEmpty(ROOT_PATH.'Common/Tools/zhifubao/'.$this->alipayPublicKeyFilePath)) {
            if ($this->checkEmpty($this->re_sign) || $this->checkEmpty($this->re_signSourceData)) {
                $this->errorMsg = "check re_sign��re_signSourceData Fail!";
                return false;
            }

            if (!$this->checkEmpty($respObject->sub_code) || ($this->checkEmpty($respObject->sub_code) && !$this->checkEmpty($this->re_sign))) {
                $checkResult = $this->verify($this->re_signSourceData, $this->re_sign, ROOT_PATH.'Common/Tools/zhifubao/'.$this->alipayPublicKeyFilePath);
                if (!$checkResult) {

                    if (strpos($this->re_signSourceData, "\\/") > 0) {
                        $this->re_signSourceData = str_replace("\\/", "/", $this->re_signSourceData);
                        $checkResult = $this->verify($this->re_signSourceData, $this->re_sign, ROOT_PATH.'Common/Tools/zhifubao/'.$this->alipayPublicKeyFilePath);
                        if (!$checkResult) {
                            $this->errorMsg = "check sign Fail!";
                            return false;
                        }

                    } else {
                        $this->errorMsg = "check sign Fail!";
                        return false;
                    }
                }
            }
        }
        return $respObject;
    }


    /**
     * δ��ʽ������ǩ��
     *
     * @param array $params ������
     *
     * @return array
     */
    public function generateSign($params) {
        return $this->sign($this->getSignContent($params));
    }

    /**
     * ����ת����ǩ����ʽ
     *
     * @param array $params ������
     *
     * @return array
     */
    public function getSignContent($params) {
        ksort($params);
        $stringToBeSigned = "";
        $i = 0;
        foreach ($params as $k => $v) {
            if (false === $this->checkEmpty($v) && "@" != substr($v, 0, 1)) {

                // ת����Ŀ���ַ���
                $v = $this->characet($v, $this->postCharset);

                if ($i == 0) {
                    $stringToBeSigned .= "$k" . "=" . "$v";
                } else {
                    $stringToBeSigned .= "&" . "$k" . "=" . "$v";
                }
                $i++;
            }
        }
        unset ($k, $v);
        return $stringToBeSigned;
    }

    /**
     * ��ʽ����ǩ��
     *
     * @param array $data ������
     *
     * @return array
     */
    public function sign($data) {
        $priKey = file_get_contents(ROOT_PATH.'Common/Tools/zhifubao/'.$this->rsaPrivateKeyFilePath);
        $res = openssl_get_privatekey($priKey);
        openssl_sign($data, $sign, $res);
        openssl_free_key($res);
        $sign = base64_encode($sign);
        return $sign;
    }


    /**
     * ��֤ǩ��
     *
     * @param array  $data ������
     * @param string $sign ǩ������
     * @param string $rsaPublicKeyFilePath ��Կ·��
     *
     * @return array
     */
    public function verify($data, $sign, $rsaPublicKeyFilePath) {
        //��ȡ��Կ�ļ�
        $pubKey = file_get_contents($rsaPublicKeyFilePath);

        //ת��Ϊopenssl��ʽ��Կ
        $res = openssl_get_publickey($pubKey);

        //����openssl���÷�����ǩ������boolֵ
        $result = (bool)openssl_verify($data, base64_decode($sign), $res);

        //�ͷ���Դ
        openssl_free_key($res);

        return $result;
    }


    /**
     * curl��������
     *
     * @param string $auth_code ����
     * @param array  $auth_code ������
     *
     * @return array
     */
    public function curl($url, $postFields = null) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_FAILONERROR, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $postBodyString = "";
        $encodeArray = Array();
        if (is_array($postFields) && 0 < count($postFields)) {
            $postMultipart = false;
            foreach ($postFields as $k => $v) {
                if ("@" != substr($v, 0, 1)) { //�ж��ǲ����ļ��ϴ�
                    $postBodyString .= "$k=" . urlencode($this->characet($v, $this->postCharset)) . "&";
                } else {//�ļ��ϴ���multipart/form-data��������www-form-urlencoded
                    $postMultipart = true;
                    $encodeArray[$k] = urlencode($this->characet($v, $this->postCharset));
                }
            }
            unset ($k, $v);
            curl_setopt($ch, CURLOPT_POST, true);
            if ($postMultipart) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $encodeArray);
            } else {
                curl_setopt($ch, CURLOPT_POSTFIELDS, substr($postBodyString, 0, -1));
            }
        }
        $headers = array('content-type: application/x-www-form-urlencoded;charset=' . $this->postCharset);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $reponse = \Tools\Error::curl_exec($ch);
        if (curl_errno($ch)) {
            throw new Exception(curl_error($ch), 0);
        } else {
            $httpStatusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if (200 !== $httpStatusCode) {
                throw new Exception($reponse, $httpStatusCode);
            }
        }
        curl_close($ch);
        return $reponse;
    }


    /**
     * ת���ַ�������
     *
     * @param $data
     * @param $targetCharset
     *
     * @return string
     */
    public function characet($data, $targetCharset) {
        if (!empty($data)) {
            $fileType = $this->fileCharset;
            if (strcasecmp($fileType, $targetCharset) != 0) {

                $data = mb_convert_encoding($data, $targetCharset);
                //				$data = iconv($fileType, $targetCharset.'//IGNORE', $data);
            }
        }
        return $data;
    }

    /**
     * У��$value�Ƿ�ǿ�
     *  if not set ,return true;
     *    if is null , return true;
     **/
    public function checkEmpty($value) {
        if (!isset($value))
            return true;
        if ($value === null)
            return true;
        if (trim($value) === "")
            return true;

        return false;
    }

}
