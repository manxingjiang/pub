<?php
/**
 * ��Ϣ����
 * 
 * @author WY <chenjinlian@findlaw.com> 
 *
 */
namespace Tools;
use Tools;

/**
 * ��Ϣ����
 * 
 * @author WY <chenjinlian@findlaw.com> 
 *
 */
class MessagPushHelper
{
    //����ƽ̨api
    private  $apiurl;
    //�����ʾ
    private  $channel;
    //Լ������
    private  $plainkey;
    //Լ��aes����,16
    private  $aeskey;
    
    private static $entity;
    public $shortDomain = 'http://lsurl.cn/';//�������������
    
    
    /**
     * ����������ȡһ���¶���
     * 
     * @return MessagPushHelper
     */
    public static function getInstance()
    {
        if (self::$entity == null) {
            
            self::$entity = new MessagPushHelper();
            self::$entity->channel = C('APP_PUSHCONFIG_CHANNEL');
            self::$entity->apiurl = C('APP_PUSHCONFIG_APIURL');
            self::$entity->aeskey = C('APP_PUSHCONFIG_AESKEY');
            self::$entity->plainkey = C('APP_PUSHCONFIG_PLAINKEY');
            
        }
        return self::$entity;
    }
    
    /**
     * ����������ȡtoken
     * 
     * @return string
     */
    private function getAuthtoken()
    {
        include_once 'include/tools/Util/AES.class.php';
        $aes = new \AES(true); // �Ѽ��ܺ���ַ�����ʮ�����ƽ��д洢
        
        $keys = $aes->makeKey($this->aeskey);
        $split = "||";
        $timeLimit = time();
        $plainText = $this->channel.$split.$this->plainkey.$split.$timeLimit;
        $encryptText = $aes->encryptString($plainText, $keys);
        $authtoken = base64_encode($encryptText);
        return $authtoken;
    }
    
    /**
     * ����������ʽ��post����
     * 
     * @param array $postData postData
     * 
     * @return string
     */
    private function formatPostData($postData)
    {
        $postStr = '';
        if (is_array($postData)) {
            if (empty($postData['channel'] )) {
                $postData['channel'] = $this->channel;
            }
            foreach ($postData as $k => $value) {
                if (!is_numeric($value)) {
                    
                    //$value = mb_convert_encoding($value, 'utf-8', 'auto');
                    $value = urlencode($value);
                    
                }
                $postStr .='&'.$k.'='. $value;
            }
            $postStr = substr($postStr, 1);
        } else {
            $postStr = $postData;
        }
        return $postStr;
    }
    
    /**
     * ��������ʶ��gbk
     * 
     * @param String $str �ַ�
     * 
     * @return boolean
     */
    private function isGBK($str) 
    {
        $typeArr = array('ASCII','GB2312','GBK','UTF-8');
        $type = mb_detect_encoding($str, $typeArr);
        if ($type == "GB2312" || $type == 'GBK') {
            return  true;
        } else {
            return false;
        }
    }
    
    
    /**
     * ��������ʶ��utf88
     * 
     * @param String $str �ַ�
     * 
     * @return boolean
     */
    private function isUTF8($str) 
    {
        $typeArr = array('ASCII','GB2312','GBK','UTF-8');
        if (mb_detect_encoding($str, $typeArr) == "UTF-8") {
            return  true;
        } else {
            return false;
        }
    }
    
    
    /**
     * �������� �ύhttp����
     * 
     * @param Array $postData postData
     * 
     * @return String
     */
    private function doPost($postData)
    {
        $postStr = $this->formatPostData($postData);
        
        $ch = curl_init();       
        
        $apiurl = $this->apiurl;
        
        $header = array();
        $header[] = 'content-type: application/x-www-form-urlencoded; charset=UTF-8';
        curl_setopt($ch, CURLOPT_URL, $apiurl);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postStr);
        $returnJson = \Tools\Error::curl_exec($ch);
        curl_close($ch);
        return $returnJson;
    }
    
    /**
     * ����������ȡ�û�δ������
     * 
     * @param int    $uid   uid
     * @param String $xpath xpath
     * 
     * @return array
     */
    public function getUserBadge($uid, $xpath)
    {
        $authtoken = $this->getAuthtoken();
        $postData = array(
                'method' => 'wanyou.app.user.get.badge',
                'authtoken' => $authtoken,
                'uid' => $uid,
                'xpath' => $xpath,
        );
        
        
        $jsonStr = $this->doPost($postData);
        $jsonObj = json_decode($jsonStr);
        $arr = null;
        if ($jsonObj->code == 0) {
            $data = $jsonObj->data;
            $arr = $this->jsonToArray($data);
            if (count($arr) == 0) {
                $arr = null;
            }
        }
        return  $arr;
        
    }
    
    /**
     * ��������json2array
     * 
     * @param sdtClass $jsonObj json����
     * 
     * @return array
     */
    private function jsonToArray($jsonObj)
    {
        $arr = array();
        foreach ($jsonObj as $k => $v) {
            if ( is_array($v) || is_object($v)) {
                $arr[$k] = $this->jsonToArray($v);
            } else {
                $arr[$k] = $v;
            }
        }
        return $arr;
    }
    

    /**
     * ������������δ����Ϣ��
     * 
     * @param [int]    $uid   [uid]
     * @param [String] $xpath [xpath]
     * @param [int]    $num   [δ����]
     *
     * @return bool
     */
    public function setUserBadge($uid, $xpath, $num)
    {
        $authtoken = $this->getAuthtoken();
        $postData = array(
                'method' => 'wanyou.app.user.set.badge',
                'authtoken' => $authtoken,
                'uid' => $uid,
                'xpath' => $xpath,
                'num' => intval($num),
        );
    
    
        $jsonStr = $this->doPost($postData);
        $jsonObj = json_decode($jsonStr);
        $bool = false;
        if ($jsonObj->code == 0 && $jsonObj->data == 'SUCC') {
            $bool = true;
        }
        return $bool;
    
    }
    
    
    /**
     * ������������/����δ����Ϣ��
     *
     * @param int    $uid    uid
     * @param String $xpath  xpath
     * @param int    $addNum ������
     *
     * @return boolean
     */
    public function addUserBadge($uid, $xpath, $addNum)
    {
        $authtoken = $this->getAuthtoken();
        $postData = array(
                'method' => 'wanyou.app.user.add.badge',
                'authtoken' => $authtoken,
                'uid' => $uid,
                'xpath' => $xpath,
                'addNum' => $addNum,
        );
    
    
        $jsonStr = $this->doPost($postData);
        $jsonObj = json_decode($jsonStr);
        $bool = false;
        if ($jsonObj->code == 0 && $jsonObj->data == 'SUCC') {
            $bool = true;
        }
        return $bool;
    
    }
    
    
    /**
     * ��xpath��ȡqid
     * 
     * @param String $path path
     * 
     * @return number
     */
    private function getQidByXpath($path)
    {
        $key = 'lscn/dialogue/qid/';
        $offset = strpos($path, $key);
        $qid = 0;
        if ($offset >= 0) {
            $str = substr($path, $offset + strlen($key));
            $offset2 = strpos($str, '/');
            if ($offset2 > 0) {
                $qid = substr($str, 0, $offset2);
            } else {
                $qid = $str;
            }
            
            $qid = intval($qid);
        }
        
       
        return $qid;
    }
    
    
    /**
     * ��������������Ϣ
     * 
     * @param String $appName ���Ͷ���appӦ�����ƣ����磺weilv haolvshi lscnapp
     * @param String $uidstr  �û�uid���, ����"123,122,124"
     * @param String $title   ��Ϣ����
     * @param String $content ��Ϣ����
     * @param String $params  �������������� "id=23&name=abc"
     * @param int    $timing  ��ʱ���͵�ʱ���������:�룩��0��ʾ��ʱ����
     * @param String $xpath   δ�������µ�·��
     * 
     * @return boolean
     */
    public  function sendPushMsg($appName, $uidstr, $title, $content, $params, $timing=0, $xpath=null)
    {
       
        $authtoken = $this->getAuthtoken();
        $postData = array(
                'method' => 'wanyou.app.message.push',
                'authtoken' => $authtoken,
                'channel' => $this->channel,
                'uids' => $uidstr,
                'appName' => $appName,
                'title' => $title,
                'content' => $content,
                'params' => urlencode($params),
                'timing' => $timing,
                'xpath' => $xpath,
        );
        
        $returnJson = $this->doPost($postData);
        $returnJson = json_decode($returnJson);
        
        if ($returnJson->code == 0) {
            return true;
        }
        return false;
    }
    
    
    /**
     * ����������ѯ�㲥��������ʦ
     * 
     * @param int    $qid      ��ѯid
     * @param int    $areacode ����id
     * @param int    $fromUid  ����id
     * @param int    $sid1     1��ר��id
     * @param int    $sid2     2��ר��id
     * @param String $title    ����
     * @param String $content  �㲥����
     * @param int    $pubTime  �㲥ʱ��
     * 
     * @return boolean
     */
    public function boardcastQuestion($qid, $areacode, $fromUid, $sid1, $sid2, $title, $content, $pubTime=0)
    {
        if ($pubTime == 0) {
            $pubTime = time();
        }
        $authtoken = $this->getAuthtoken();
        $postData = array(
                'method' => 'wanyou.app.message.boardcast',
                'authtoken' => $authtoken,
                'channel' => $this->channel,
                'areacode' => $areacode,
                'qid' => $qid,
                'fromUid' => $fromUid,
                'sid1' => $sid1,
                'sid2' => $sid2,
                'title' => $title,
                'content' => $content,
                'pubTime' => $pubTime
        );
       
        $returnJson = $this->doPost($postData);
        
        $returnJson = json_decode($returnJson);
        
        if ($returnJson->code == 0) {
            return true;
        }
        return false;
        
    }


    /**
     * �������͵�����
     * 
     * @param unknown $detailids ���͵�id����
     * @param unknown $pushtype  ���͵�����
     * 
     * @return boolean
     */
    public function addPush($detailids, $pushtype)
    {

        if (empty($detailids)) {
            echo 'detailids can not be empty!';
            return false;
        }
        switch ($pushtype) {
        case PUSHTYPE_ASK_ANSWER:
            $this->addAskAnswerPush($detailids);
            break;
        /*case PUSHTYPE_ASK_QUESTION_ADD:
            $this->addAskQuestionAddPush($detailids);
            break;*/
        case PUSHTYPE_ASK_ADD:
            $this->addAskAddPush($detailids);
            break;
        case PUSHTYPE_ASK_ONLINE:
            $this->addAskOnlineQuestionPush($detailids);
            break;
        case PUSHTYPE_ASK_ONLINE_ADD:
            $this->addAskOnlineAddPush($detailids);
            break;
        case PUSHTYPE_ASK_ONLINE_REP:
            $this->addAskOnlineRepPush($detailids);
            break;
        default:
            die('wrong pushtype'); 
        }
    }



    /**
     * ����һ��һ��ѯ��������
     *
     * @param array $ids ids
     *
     * @return boolean
     */
    private function addAskOnlineQuestionPush($ids)
    {
        // header("Content-type:text/html;charset=utf-8");
        if (empty($ids)) {
            return false;
        }
        
        $askonline_list = RpcModule('OnlineAsk2Admin')->getAskOnlineMap($ids[0], null);
        $rep_id = $askonline_list['askOnlineRep'][0]['id'];
        $reprow = RpcModule('OnlineAsk2Admin')->getAskOnlineRep($rep_id, null);

        $touids = array();
        $uidtoaid=array();

        $lawyerid = intval($reprow['lawyerid']);
        if ($lawyerid>0 && !in_array($lawyerid, $touids)) {
            $touids[] = $reprow['lawyerid'];
            $uidtoaid[$reprow['lawyerid']]=$reprow;
        }

        //��ÿһ����ʦ������Ϣ
        foreach ($touids as $touid) {
            //������ʦ΢������
            $wx_url = "http://f.ls.cn/index.php?s=/Weixin/sendMessageFl&lawyerids=".$touid."&qid=". $uidtoaid[$touid]['pid']."&type=1&repids=".$uidtoaid[$touid]['id'];
            $wx_ch = curl_init();
            curl_setopt($wx_ch, CURLOPT_URL, $wx_url);
            curl_setopt($wx_ch, CURLOPT_HEADER, 0);
            curl_setopt($wx_ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($wx_ch, CURLOPT_CONNECTTIMEOUT, 10);
            $wx_result = \Tools\Error::curl_exec($wx_ch);
            curl_close($wx_ch);

            //������Ϣ���Զ��ۼ�δ����
            $appName = "weilv";
            $uidstr = $touid;
            $title = mb_convert_encoding('�����µ�һ��һ��ѯ����', 'utf-8', 'gbk');
            $content = mb_convert_encoding($askonline_list['content'], 'utf-8', 'gbk');
            $params = "channel=findlaw_cn&messageType=p2p&qid={$askonline_list['id']}&aid={$uidtoaid[$touid]['id']}&fromuid={$askonline_list['leoid']}&flag=ask";
            $timing = 0;
            $xpath = null;
            $res = $this->sendPushMsg($appName, $uidstr, $title, $content, $params, $timing, $xpath);
        }
    }
    
    /**
     * ���ӹ�����ѯ�ظ�����
     *
     * @param array $aids aids
     *
     * @return boolean
     */
    private function addAskAnswerPush($aids)
    {
        //����aids��ѯask_answer�б�  
        $conditions = array(
            'aids'    => $aids,
            'orderBy' => 'aid DESC'
        );
        $answerList = RpcModule('Ask.AskAdmin')->queryConsultReplayList(1, 999999, $conditions);

        //$this->console('answerList', $answerList);
        //��ask_answer�б�������ȡ���й�����ѯqid
        $qids = array();
        $aid2qid = array();
        $aid2array = array();
        $new_aids = array();
        foreach ($answerList as $v) {
            $new_aids[] = $v['aid'];
            $aid2qid[$v["aid"]] = $v["qid"];
            $aid2array[$v["aid"]] = $v;
            if (!in_array($v['qid'], $qids)) {
                $qids[] = $v['qid'];
            }
        }     
        $aids = $new_aids;
        
        //$this->console('aid2qid', $aid2qid);
        //$this->console('qids', $qids);
                
        //����qids��ѯ���й�����ѯ��Ϣ�б� 
        $conditions = array(
            'qids' => array_unique($qids),
            'orderBy' => 'a.asktime desc'
        );
        $askquestionList     = RpcModule('Ask.AskAdmin')->queryConsultInfoList(1, 300, $conditions);
        //$this->console('askquestionList', $askquestionList);
        //�ڹ�����ѯ�б�������ȡ���ʹ��ڵ�uid
        $uids = array();
        $qid2uid = array();
        foreach ($askquestionList as $v) {
            $qid2uid[$v["qid"]] = $v['uid'];
            $uids[] = $v['uid'];
        }
        //$this->console('qid2uid', $qid2uid);
        //$this->console('uids', $uids);

        //ѭ��ÿһ����ѯ�� �������ͱ�
        foreach ($aids as $aid) {
            $qid = $aid2qid[$aid];
            $touid = intval($qid2uid[$qid]);
            if ($touid == 0) {
                continue;
            }            
            $appName = "haolvshi";
            $uidstr = $touid;
            $title = mb_convert_encoding('�����µĹ�����ѯ�ظ�', 'utf-8', 'gbk');
            $content = mb_convert_encoding($aid2array[$aid]['content'], 'utf-8', 'gbk');
            $params = "channel=findlaw_cn&messageType=pub&qid={$qid}&lawyeruid={$aid2array[$aid]['uid']}&fromuid={$aid2array[$aid]['uid']}";
            $timing = 0;
            $xpath = null;

            //������Ϣ���Զ��ۼ�δ����
            $re=$this->sendPushMsg($appName, $uidstr, $title, $content, $params, $timing, $xpath);
        } 
    }
 
    /**
     * ����һ��һ��ѯ�ظ�����
     *
     * @param array $aid aid
     *
     * @return boolean
     */
    private function addAskOnlineRepPush($aid)
    {
        $askonlinerep_list = RpcModule('OnlineAsk2Admin')->getAskOnlineRep($aid, $year);
        
        //��һ��һ�ظ��б���ȡ����  leoids
        $touids = array();
        $id2array = array();
        $new_ids = array();

        $new_ids[] = $askonlinerep_list['id'];
        $leoid = intval($askonlinerep_list['leoid']);
        $touids[] = $leoid;
        $id2array[$askonlinerep_list["id"]] = $askonlinerep_list;

        if (empty($touids)) {
            return false;
        }
        $ids = $new_ids;
        
        foreach ($ids as $id) {
            $touid = $id2array[$id]['leoid'];
            $appName = "haolvshi";
            $uidstr = $touid;
            $title = mb_convert_encoding('�����µ�һ��һ��ѯ�ظ�', 'utf-8', 'gbk');
            $content = mb_convert_encoding($id2array[$id]['repcon'], 'utf-8', 'gbk');
            $params = "channel=findlaw_cn&messageType=p2p&qid={$id2array[$id]['pid']}&aid={$onlineaddrow['id']}&lawyeruid={$id2array[$id]['lawyerid']}&fromuid={$id2array[$id]['lawyerid']}";
            $timing = 0;
            $xpath = null;
            //������Ϣ���Զ��ۼ�δ����
            $re=$this->sendPushMsg($appName, $uidstr, $title, $content, $params, $timing, $xpath);
        }
    }


    /**
     * ����΢����Ϣ
     *
     * @param [type]  $uid     �û�id
     * @param [type]  $url     url
     * @param [type]  $content ����
     * @param integer $wtid    ģ��id
     * @param integer $type    �û����� 1.��ʦ 2.����
     * 
     * @return [type]           [description]
     */
    public function sendWeixin($uid, $url, $content, $wtid = 1, $type = 1)
    {
        include_once ROOT_PATH . 'Common/Tools/Sms.class.php';
        include_once ROOT_PATH . 'Common/Tools/SmsSDK.class.php';
        include_once ROOT_PATH . 'Common/Tools/Error.class.php';
        if ($type == 1) { // ��ʦ
            $openid_arr = \Rpc::getShortlinkData("Weixin.getWeixinBindOpenIdByUid", $uid, 'fl');
            $openid = $openid_arr['openid'];
            // $openid = 'oXr6VwHElJqPJmkGWqY3Lbdeknw4';
        } else { // ����
            $openid_arr = \Rpc::getData('WeixinBind.queryWeixinBindByUidAndAppid', $uid, 1);
            $openid = $openid_arr[0]['openid'];
            // $openid = 'obD24joIafo4s6Ybt_qj1mZqphBo';
        }
        return \Tools\Sms::sendWeixin($openid, $url, $content, $wtid);
    }

    /**
     * ����վ��ϵͳ��Ϣ
     * 
     * @param [type] $data [description]
     * 
     * @return [type]       [description]
     */
    public function sendSysMessage($data)
    {
        $other_data = array(
            'projectid' => 1,
            'readflag' => 0,
            'sendtime' => time(),
        );
        $sum_data = array_merge($data, $other_data);
        return Rpc::getUCData('Pms.admin.insertMessageSel', $sum_data);
    }


    /**
     * ���ɶ���
     * 
     * @param [type] $url [description]
     * 
     * @return [type]      [description]
     */
    public function getShortLink($url)
    {
        //���ɶ�����
        $shorturlData = array(
            'longurl' => $url,
            'inputtime'=> time(),
        );

        $shortlinkConfig = include ROOT_PATH . 'new.findlaw.cn/findlaw_global_include/include/rpc/shortlink_config.rpc.php';
        $ShortLinkConfig = $shortlinkConfig['hb_config_rpc'];
        $shorturlres = \RpcCallFactory::getData("Shortlink.Admin.insertShortlinkRecord", null, array($shorturlData), true, 'GBK', $ShortLinkConfig);
        if ($shorturlres && $shorturlres['shorturl']) {
            $shorturl = $this->shortDomain.$shorturlres['shorturl'];
            return $shorturl;
        }
    }

    /**
     * ����ַ���
     * 
     * @param [type] $length [description]
     * @param string $chars  [description]
     * 
     * @return [type]         [description]
     */
    public function random($length, $chars = '0123456789abcdefghijklmnopqrstuvwxyzQWERTYUIOPASDFGHJKLZXCVBNM') 
    {
        $hash = '';
        $max = strlen($chars) - 1;
        for ($i = 0; $i < $length; $i++) {
            $hash .= $chars[mt_rand(0, $max)];
        }
        return $hash;
    }



}

?>
