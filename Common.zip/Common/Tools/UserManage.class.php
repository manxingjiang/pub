<?php
/**
 *  �û����ݹ�����
 *
 *  @author wrd <xxx@qq.com>
 *
 */
namespace Tools;
use Tools;
/**
 *  �û����ݹ�����
 *
 *  @author wrd <xxx@qq.com>
 *
 */
class UserManage
{
    /**
     * �ֻ��Ű�
     * ���봫uid,mobile
     * usertype Ĭ��Ϊ2 ���ڣ���ʦ�ش�
     * userid ,���ΰ󶨱ش�
     * 
     * @param array $bindinfo ������
     * 
     * @return boolean
     */
    public static function bindMobile($bindinfo)
    {
        $uid = $bindinfo['uid'];
        $mobile = $bindinfo['mobile'];
        if ($uid <= 0) {
            return 0;
        } 
        $time = time();
        $usertype = empty($bindinfo['usertype']) ? 2 : $bindinfo['usertype'];
        // ���û�����
        $ucEmailMobileForm = array(
            'uid' => $uid,
            'mobileEmail' => $mobile,
            'inputtime' => empty($bindinfo['inputtime']) ? $time : $bindinfo['inputtime'],
            'typeid' => 1,
            'status' =>  1,
            'verifyTime' => empty($bindinfo['verifytime']) ? $time : $bindinfo['verifytime']
        );
        $data = \Rpc::getUCData('Member.admin.getEmailMobileByUidTypeid', $uid, 1);
        //�û�ϵͳ�󶨱�����
        if (empty($data)) {
            $re = \Rpc::getUCResponse('Member.admin.insertUcEmailMobileSel', $ucEmailMobileForm);
        } else {
            $re = \Rpc::getUCResponse('Member.admin.updateEmailMobileByUidTypeid', $ucEmailMobileForm);
        }
        //�û�ϵͳ���ݱ��޸�
        $ucbind = array('uid' => $uid, 'mobile' => $mobile);
        if ($usertype == 1) {
            $re->isSuccess() && $re = \Rpc::getUCResponse('Member.admin.updateUcLawyerByPKSel', $ucbind);
        } else {
            $re->isSuccess() && $re = \Rpc::getUCResponse('Member.admin.updateUcTblleoByPKSel', $ucbind);
        }
        $re->isSuccess() && $re = \Rpc::getUCResponse('Member.admin.updateUcMemberByPKSel', $ucbind);
        
        //�ҷ�ƽ̨(Member.getUserMobileEmailByUid��Member.Admin.updateUserAddMobil��Findlaw.Admin.updateUserMobileByUid||2017-3-27�ӿڲ�Ҫ��)
        //$data = \Rpc::getData('Member.getUserMobileEmailByUid', $uid);
        //�󶨱�û����Ϣʱ ���󶨱�
        //$re->isSuccess() && empty($data) && $re = \Rpc::getResponse('Member.Admin.updateUserAddMobil', $uid, $bindinfo['userid'], $usertype, $mobile);
        
        //$re->isSuccess() && $re = \Rpc::getResponse('Findlaw.Admin.updateUserMobileByUid', $uid, $mobile);
        return $re->isSuccess() ? 1 : 0;
    }
    
    /**
     * ����ֻ��Ű���Ϣ(ֻ���������û�)
     * 
     * @param int $mobile �ֻ��ű���
     * @param int $uid    ����ָ�� ��uid�ֻ���
     *
     * @return array 
     */
    public static function clearBindMobile($mobile, $uid = 0)
    {
        if (empty($mobile)) {
            return false;
        }
        //������Щ�ֻ��ŵ������û�
        $userList = \Rpc::getUCData('Member.queryListUcMemberByMobile', $mobile);
        //���û����Ŀհ󶨱�
        $binduser = \Rpc::getUCData('Member.getByMobileEmail', $mobile, 1);
        if ($binduser['uid'] && $binduser['uid'] != $uid) {
            \Rpc::getUCResponse('Member.admin.deleteEmailMobileByUidTypeid', $binduser['uid'], 1);
        }
        //�ÿ� �д��ֻ��ŵ� �û�
        $uids = array();
        foreach ($userList as $k => $v) {
            if ($v['membertype'] ==2 && $v['uid'] != $uid) {
                $uids[] = $v['uid'];
                empty($v['uid']) || \Rpc::getResponse('Findlaw.Admin.updateUserMobileByUid', $v['uid'], '');
            }
        }
        empty($uids) || \Rpc::getUCResponse('Member.admin.updateMobileNullByUids', $uids, 2);
        return true;
    }
    /**
     * ͨ��userid ȡ��ʦ��Ϣ-ǰ̨����
     * 
     * @param array $userid ��ʦuserid
     * 
     * @return array lawyerinfo
     */
    public static function getLawyerByUserid($userid) 
    {
        $lawyerinfo = array();
        if (!is_array($userid)) {
            $userid = array($userid);
        }
        $lawyerinfo = \Rpc::getUCData('Member.queryUcLawyerList', array('userids'=>$userid), 1, 1);
        foreach ($lawyerinfo as &$lawyer) {
            $lawyer['id'] = $lawyer['uid'];
        }
        return $lawyerinfo;
        
    }
    
    /**
     * ���������ʦ��Ա���ּ���ѯ����
     *
     * @param String $uid   ��ʦ��¼uid
     * @param int    $type  �������� 1 �ļ�����jifen_wenjian; 2 ��������jifeng_anli; 3 ��̳���� jifeng_bbs; 4 ���Ļ��� jifeng_culb; 5 Ԥ����δʹ��;6 ��ѯ��quesnum; 7 һ��һ��ѯjifeng; 8 ������ѯ���� jifeng_ask; 9 ������ѯ���ֺ�˫���ܻ��� jifeng_all, 10 ֻ�����ܻ���
     * @param int    $value ���ӻ���ֵ
     *
     * @return boolean
     */
    public static function addLawyerJifenByUserid($uid, $type, $value)
    {
        if (empty($userid) || ($type < 1 && $type > 10) || !is_int($value)) {
            return false;
        }
        $param = array();
        $param['uid'] = $uid;
        $param['jifengType'] = $type;
        $param['jifengValue'] = $value;
        $rs = \Rpc::getUCData('Member.admin.updateUcLawyerJifenByUid', $param);
        $rs->isSuccess();
        return $rs->isSuccess();
    }

    /**
     * ע��ӿ�
     * 
     * @param array $lawyer ��ʦע����Ϣ
     * 
     * @return int
     */
    public static function rigister($lawyer)
    {
        //�û�ϵͳ ע������
        $passIntensity = \Tools\User::getPassIntensity($lawyer['psw']);
        $ucRegAddPara = array(
            //'uid' => $reginfo['uid'],
            'userid' => $lawyer['userid'],
            'username' => $lawyer['username'],
            'password' => $lawyer['psw'],
            'passIntensity' => $passIntensity,
            'lawyerLawroom' => $lawyer['lawerroom'],
            'lawyerCode' => $lawyer['lawercode'],
            'mobile' => $lawyer['mobil'],
            'areacode' => $lawyer['areacode'],
            'regtime' => time(),
            'regip' => sprintf('%u', ip2long(\Tools\Iparea::getClientIp())),
            'membertype' => 1,
            'regfrom' => $lawyer['frompage'] > 0 ? $lawyer['frompage'] : 4,
            'url' => $_SERVER['HTTP_REFERER']
        );

        //����û�ϵͳ 
        $reUc = \Rpc::getUCData('Member.admin.insertUcLawyerSel', $ucRegAddPara);
        if ($reUc['state']=='01' && $reUc['uid']) {

            //�ҷ�ע������
            $areainfo = \Rpc::getData('Area.getAreaInfo', $lawyer['areacode']);//\Tools\Iparea::getAreainfoByareacode($lawyer['areacode']);
            $lawForm = array();
            $lawForm['id'] = $reUc['uid'];
            $lawForm['userid'] = $lawyer['userid'];
            $lawForm['username'] = $lawyer['username'];
            $lawForm['psw'] = $lawyer['psw'];
            // ����Ϊ lawerroom �� lawyerroom
            $lawForm['lawerroom']  = $lawyer['lawerroom'];
            $lawForm['province'] = $areainfo['province'];
            $lawForm['city'] = $areainfo['city'];
            $lawForm['areacode'] = $lawyer['areacode'];
            $lawForm['sex'] = 0;
            $lawForm['email'] = '';
            $lawForm['lawercode'] = $lawyer['lawercode'];
            $lawForm['membertype'] = 'lawer';
            $lawForm['yuming'] = '';
            $lawForm['qq'] = '';
            $lawForm['ifaudit'] = 'S';
            $lawForm['inputdate'] = time();
            $lawForm['regdate'] = time();
            $lawForm['mobil'] = $lawyer['mobil'];
            $lawForm['photo'] = '';
            $lawForm['workyears'] = 0;
            $lawForm['resume'] = '';
            $lawForm['ifsales'] = 1;
            $lawForm['ip'] = \Tools\Iparea::encode_ip(\Tools\Iparea::getClientIp());
            $lawForm['lawyerpos1'] = 'c';
            $lawForm['sales'] = $lawyer['sales'];
            //���ֶ�ԭ�����ѷ���,��Ϊ��ʦע����Դ,ע����Դ(�û�ע����Դ:0-����,1-pc��,2-��׿app,3-ƻ��app,4-webapp ��ģ��ע��,5-ctiweb
            $lawForm['ifask'] = $lawyer['frompage'] > 0 ? $lawyer['frompage'] : 4; 
        }
        
        return $reUc['uid'] ? $reUc['uid'] : 0;
        
    }
    
    /**
     * ȡ�����û���Ϣ
     * 
     * @param array $uids uids
     * 
     * @return array()  ���ش���uid�Ĺ����û���Ϣ
     */
    public static function getLeoinfoByUids($uids)
    {
        if (!is_array($uids)) {
            return array();
        }
        foreach ($uids as $key => $value) {
            $uids[$key] = intval($value);
        }
        $leoinfo = \Rpc::getUCData('Member.queryUcTblleoListMapByUids', $uids, 1);
        if (empty($leoinfo)) {
            return array();
        }
        foreach ($leoinfo as $key => $value) {
            
            if (empty($value['uid'])) {
                unset($leoinfo[$key]);
                continue;
            }
            //ͷ����
            if ($value['photo']) {
                $value['photosrc'] = \Tools\Image::imagesReplace('/my/pubadmin/tblimg/' . $value['photo']);
            } else {
                $value['photosrc'] = \Tools\Image::imagesReplace('/img/common/pubuser_small.gif');
            }
            //������ʾ������
            if (empty($value['username'])) {
                if (preg_match('/1[3|5|7|8]\d{9}$/', $value['userid'])) {
                    $value['username'] = substr_replace($value['userid'], '****', -8, 4);
                } else {
                    $value['username'] = $value['userid'];
                }
            }
            $leoinfo[$key] = $value;
        }
        return $leoinfo;
    }
    
    /**
     * ͨ�� userid�����û�����
     * 
     * @param string $userid      �û���
     * @param string $newpassword ������
     * 
     * @return array
     */
    public static function setPasswordByUserid($userid, $newpassword) 
    {
        $newpassword = trim($newpassword);
        $info = array();
        if (empty($userid) || empty($newpassword)) {
            $info['status'] = -1;
            $info['msg'] = '�û�����������벻��Ϊ��!';
            return $info;
        }
        $level = \Tools\user::getPassIntensity($newpassword);
        
        $member = \Rpc::getUCData('Member.admin.getUcMemberByUserid', $userid);
        if (empty($member)) {
            $info['status'] = -11;
            $info['msg'] = "�û� {$userid} ������!";
            return $info;
        }
        $uid = $member['uid'];
        $javaMd5 = \RPC::getUCData('Member.admin.encrypt', $newpassword);
        $param = array('uid' => $uid, 'password' => $javaMd5, 'passIntensity' => $level);
        $re = \RPC::getUCResponse('Member.admin.updateUcMemberByPKSel', $param);
        if ($re->isSuccess()) {
            $usertype = $member['membertype'];
            switch ($usertype) {
            case 1:
                //������ʦ�� ����
                \RPC::getResponse('Member.Admin.updateTblmemberPasswordByUserid', $newpassword, $userid);
                \RPC::getResponse('Member.Admin.updateTblmemberSearchPasswordByUserid', $newpassword, $userid);
            case 2:
                //���¹�������
                //\RPC::getResponse('Member.Admin.updateTblleoPswByUserid', $newpassword, $userid);
                //���¹������븽����
                \Rpc::getUCData('Member.admin.updateUcTblleoPasswordBySel', array('uid'=>$uid, 'password'=>$newpassword));
            }
            //�����ܱ� ����
            \RPC::getResponse('PHPBB.Admin.updateCdbMembersPwsByUsername', md5($newpassword), $userid);
            
            $info['status'] = 1;
            $info['msg'] = '�������óɹ�';
        } else {
            $info['status'] = 0;
            $info['msg'] = '��������ʧ��';
        }
        return $info;
    }
    
    /**
     * ����uid��ȡ���ֻ��Ż�����
     *
     * @param int $uid  uid
     * @param int $type 1�ֻ�, 2����
     * 
     * @return string|boolean
     */
    public function getBindInfo($uid, $type = 1)
    {
        if (empty($uid) || $uid < 1) {
            return false;
        }
        $type = $type == 2 ? 2 : 1;
        $bindInfo = \Rpc::getUCData("Member.admin.getEmailMobileByUidTypeid", $uid, $type);
        if ($bindInfo && isset($bindInfo['mobileEmail'])) {
            return $bindInfo['mobileEmail'];
        }
        return false;
    }
    
    /**
     * ͨ����ʦuid ȡ��ʦ�ٶ�ֱ��� appid ����memcache �����ɵ���д�룬
     * 
     * @param int $uid uid
     * 
     * @return int
     */
    public static function getLawZhidahaoAppid($uid) 
    {
        if (empty($uid)) {
            return null;
        }
        //memcacheʵ��
        $mc = \Tools\Cache::memcache();
        return $mc->get(self::zdhKey($uid));
    }
    
    /**
     * �ٶ�ֱ��� appid key
     * 
     * @param int $uid uid
     * 
     * @return number|string
     */
    public static function zdhKey($uid) 
    {
        if (empty($uid)) {
            return 0;
        }
        return md5("Zhidahao_appid_{$uid}") . "_" . $uid;
    }

    /**
     * ��ϵͳ��ʦ�޸���Ϣ
     *
     * @param int    $uid        �û�uid
     * @param string $userid     �û�userid
     * @param string $method     ģ�� (password:�޸�����)
     * @param string $logMessage ��־��Ϣ
     * @param array  $data       ���� 
     *
     * @return bool
     */
    public static function userInfoEditLog($uid, $userid, $method, $logMessage, $data=array())
    {
        if ($uid <= 0 || empty($userid) || empty($method) || empty($logMessage) || !is_array($data)) {
            return false;
        }
        $logData = array(
                    'opId'      => $uid,
                    'opUserid'  => $userid,
                    'opModule'  => $method,
                    'opLog'     => $logMessage,
                    'opData'    => serialize($data),
                    'inputtime' => time(),
                );
        return \Rpc::getUCResponse("Admin.admin.insertAdminLogSel", $logData, '004');
    }

    /**
     * �޸�������־
     *
     * @param int    $uid     �û�uid
     * @param string $userid  �û�userid
     * @param string $newPass ������
     * @param string $oldPass ������
     *
     * @return bool
     */
    public static function editPasswordLog($uid, $userid, $newPass, $oldPass)
    {
        if ($uid <= 0 || empty($userid) || empty($newPass) || empty($oldPass)) {
            return false;
        }
        //��¼��־
        $opData = array(
            'uid'          => $uid,                             //�û�uid
            'userid'       => $userid,                          //�û�userid
            'time'         => time(),                           //ʱ��
            'oldpassword'  => $oldPass,                         //������
            'newpassword'  => $newPass,                         //������
            'http_referer' => $_SERVER['HTTP_REFERER'],         //��Դ
            'curr_url'     => \Tools\Url::getCurrUrl(),         //��ǰ����
            'ip'           => \Tools\Iparea::getClientIp(),     //����ip
            'host_name'    => gethostname(),                    //����������
        );
        $logMessage = sprintf('%s �� %s �޸�����Ϊ��%s', $userid, date('Ymd H:i:s'), $newPass);
        return self::userInfoEditLog($uid, $userid, 'password', $logMessage, $opData);
    }
}
?>
