<?php
/**
 *  Url����������
 *
 *  @author zsg <xxx@qq.com>
 *
 */
 
namespace Tools;
use Tools;

/**
 *  Url����������
 *
 *  @author zsg <xxx@qq.com>
 */
class Url
{
    /**
     * js��ת
     *
     * @param unknown $url url
     *
     * @return null;
     */
    public static function jump($url)
    {
        echo "<script>location.href='$url';</script>";
        exit;
    }
    
    /**
     * �����ʦ������վ��ַ
     *
     * @param array $member_info_list ��ʦ�����б�������Ҫ����tblmember_search����id��yuming�����ֶε���Ϣ
     *
     * @return array $member_info_list ��������վ��ַ����ʦ��Ϣ�б�
     */
    public static function get_site_url($member_info_list = array())
    {
        if (!is_array($member_info_list)) {
            return $member_info_list;
        }
    
        $siteurl	= "";
        foreach ($member_info_list as $key => &$row) {
            $siteurl = '';
            $siteask = '';
            if (isset($row['yuming'])) {
                $yuming  = trim($row['yuming']);
                $yuming  = str_replace('http://', '', $yuming);
                $yuming  = str_replace('.findlaw.cn', '', $yuming);
    
                $siteurl = 'http://'.$yuming.'.findlaw.cn';
                $siteask = 'http://'.$yuming.'.findlaw.cn/lawyer/zxzx.html';
            }
            if ($yuming == "" || $yuming == "www" || $yuming=='(www)') {
                $siteurl = 'http://china.findlaw.cn/ask/';
                $siteask = 'http://china.findlaw.cn/ask/';
            }
            //��ʦ��Ƭ
            $photo = '';
            if (isset($row["photo"])) {
                $photo = trim($row["photo"]);
                $photo = str_replace('http://images.findlaw.cn/my/photo/', '', $photo);
            }
    
            if (!$photo || $photo == 'blank.jpg') {	//ʹ��Ĭ��ͷ��
                $row["photourl"] = \Tools\Image::imagesReplace('/img/common/lawyer_small.gif');
            } else {
                $row["photourl"] = \Tools\Image::imagesReplace('/my/photo/'. $photo);
            }
    
            //��ʦ����
            $blogurl = '';
            if (!empty($row["uid"])) {
                $row["uid"] = trim($row["uid"]);
                $blogurl = 'http://china.findlaw.cn/law/'.$row["uid"];
            }
            $row["blogurl"] = $blogurl;
    
            //��ʦ������վ
            $row["siteurl"]	= $siteurl;
            //��ʦһ��һ��ѯ
            $row["siteask"]	= $siteask;
        }
        return $member_info_list;
    }

    /**
     * �����������ϵõ�������Ϣ�����ӵ�ַ
     * 
     * @param array $firm_info firm_info
     * 
     * @return string
     */
    public static function get_frim_website_new($firm_info = array())
    {
        foreach ($firm_info as $k => &$row) {
            //$row["url"] 	= 'http://china.findlaw.cn/lawfirm/'.$row["id"]; //������ҳ
            $row["yuming"] = trim($row["yuming"]);
            $row["website"] = trim($row["website"]);
    
            if ($row["yuming"] !='' && $row["yuming"] !='www' && $row["yuming"] !='(www)') {
                $row["url"] = 'http://'.$row["yuming"].'.findlaw.cn';
            }
            $website = '';
            if ($row["ifsite"]==1 && $row["website"] && preg_match('/^(http:\/\/)/', $row["website"])) {
                $website = $row["website"];
            }
            if (!$row["url"]) {
                    $row["url"] = self::getMergeUrl('http://china.findlaw.cn/lawfirm/', $row["id"], $website);
            }

            $row["contacturl"] = 'http://china.findlaw.cn/lawfirm/'.$row["id"].'/contact';	//���
            $row["teamurl"]	   = 'http://china.findlaw.cn/lawfirm/'.$row["id"].'/team';		//�Ŷ�
            $row["caseurl"]	   = 'http://china.findlaw.cn/lawfirm/'.$row["id"].'/list_case_p1.html';//�ɹ�����
            $row["profurl"]    = 'http://china.findlaw.cn/lawfirm/'.$row["id"].'/prof';		//����

            //������Ƭ
            $row["photo"] = $row["photo"];

            $row["photourl"] = \Tools\Image::imagesReplace('/my/photo-lawfirm/'.$row["photo"]);

            if ($row["photo"] == '' || $row["photo"] == 'blank.jpg') {
                $row["photourl"] = \Tools\Image::imagesReplace('/img/lawfirm/lvsuo_default.gif');
            }
        }
        return($firm_info);
    }
    
    /**
     * �����ֽ��б���
     * 
     * @param unknown $id id
     * 
     * @return string
     */
    public static function smtyidencode($id)
    {
        if (!is_array($id)) {
            $id = array($id);
        }
        extract($id);

        $key1 = 323982;
        $key2 = 329076;

        $str1 = $id[0] + $key1;
        $str2 = $id[0] + $key2;

        return $str1 . '' . $str2;
    }
    
    /**
     * �����ݱ�Ž���
     *
     * @param unknown $id id
     *
     * @return string
     */
    public static function id_decode($id)
    {
        $key1 = 323982;
        $key2 = 329076;
    
        $len = strlen($id) / 2;
        $str1 = substr($id, 0, $len);
        $str2 = substr($id, $len);
    
        $str1 = $str1 - $key1;
        $str2 = $str2 - $key2;
    
        if ($str1!=$str2) {
            return '-1';
        } else {
            return $str1;
        }
    }
    
    /**
      * script
      * 
      * @param type $js js
      *
      * @return mixed
      */
    public static function script($js)
    {
        die("<script type='text/javascript'>" . $js . "</script>");
    }
    
    /**
     *  ��ʾ404ҳ��
     *
     *  @return void
     */
    public static function show404()
    {
        header('HTTP/1.1 404');
        header('status: 404 Not Found');
        echo '<script language="javascript" type="text/javascript">';
        echo "window.location.href='http://china.findlaw.cn/404.php'";
        echo '</script>';
        echo '<meta http-equiv="refresh" content="0;url=http://china.findlaw.cn/404.php">';

        exit();
    }
    
    /**
     * ��վ��Ϣҳ�� url
     * 
     * @return array
     */
    public static function getsiteinfourl()
    {
        $urls = array(
        'home' => 'http://china.findlaw.cn',                              //��ҳ
        'login' => 'http://uc.findlaw.cn/login/',                         //��¼
        'logout' => 'http://uc.findlaw.cn/index.php?c=Login&a=logout',    //�˳�
        'register' => 'http://uc.findlaw.cn/lawyer',                      //ע��
        'lawyeradmin' => 'http://china.findlaw.cn/lawyeronline_front/',           //��ʦ����
        'leoadmin' => 'http://china.findlaw.cn/leoadmin_front/',                //��������
        'fljieshao' => 'http://china.findlaw.cn/aboutus/fljieshao.html',  //��վ����
        'url_ask' => 'http://china.findlaw.cn/ask',                       //��ѷ�����ѯ
        'url_online' => 'http://china.findlaw.cn/online',                 //һ��һ��ѯ,������ѯ
        'url_anjian' => 'http://china.findlaw.cn/anjian',                 //����ί��
        'cservice' => 'http://china.findlaw.cn/aboutus/cservice.html',    //��ϵ����
        'jiamen' => 'http://china.findlaw.cn/aboutus/jiamen.htm',         //��ʦ����ָ��
        'mianze' => 'http://china.findlaw.cn/aboutus/mian.htm',           //��������
        'sitemap' => 'http://china.findlaw.cn/aboutus/map.htm',           //��վ��ͼ
        'jianyi' => 'http://china.findlaw.cn/aboutus/feedback.php',       //���鷴��
        'friend' => 'http://china.findlaw.cn/aboutus/friend.htm',         //������� 
        );
        return $urls;
    }
    
    /**
     * ��ȡ��ǰURL
     *
     * @param type $urlEncode urlEncode
     * 
     * @return string
     */
    public static function getCurrUrl($urlEncode = false)
    {
        $pageUrl = '';
        $pageUrl = (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] == 'on') ? 'https' : 'http';
        $pageUrl .= '://';

        if ($_SERVER["SERVER_PORT"] != "80") {
            $pageUrl .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
        } else {
            $pageUrl .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
        }
        if ($urlEncode) {
            $pageUrl = urlencode($pageUrl);
        }
        return $pageUrl;
    }
    
    /**
     * ��ȡ$_SERVER['HTTP_REFERER'])
     * 
     * @param type $default url
     *
     * @return string
     */
    function get_referer($default = './')
    {
        $referer = '';
        if (isset($_SERVER['HTTP_REFERER'])) {
            $referer = preg_replace("/([\?&])((sid\=[a-z0-9]{6})(&|$))/i", '\\1', $_SERVER['HTTP_REFERER']);
            $referer = substr($referer, -1) == '?' ? substr($referer, 0, -1) : $referer;
        } else {
            $referer = $default;
        }

        if (!preg_match("/(\.php|[a-z]+(\-\d+)+\.html)/", $referer) || strpos($referer, 'login.php')) {
            $referer = $default;
        }
        return $referer;
    }
    
    /**
     * ���������жϷ�����Դ
     *
     * @return string
     */
    public function order_source()
    {
        if (isset($_GET['vid'])) {
            $vid = tool::getintparam('vid');
            if ($vid == 1) {
                return 'iphone';
            } elseif ($vid == 2) {
                return 'android';
            }
        }
        
        $useragent  = strtolower($_SERVER["HTTP_USER_AGENT"]);
        // iphone
        $is_iphone  = strripos($useragent, 'iphone');
        if ($is_iphone) {
            return 'iphone';
        }
        // android
        $is_android    = strripos($useragent, 'android');
        if ($is_android) {
            return 'android';
        }
        // ΢��
        $is_weixin  = strripos($useragent, 'micromessenger');
        if ($is_weixin) {
            return 'weixin';
        }
        // ipad
        $is_ipad    = strripos($useragent, 'ipad');
        if ($is_ipad) {
            return 'ipad';
        }
        // ipod
        $is_ipod  = strripos($useragent, 'ipod');
        if ($is_ipod) {
            return 'ipod';
        }
        // pc����
        $is_pc = strripos($useragent, 'windows nt');
        if ($is_pc) {
            return 'pc';
        }
        
        return 'other';
    }
    
    /**
     * ��ȡƴ�ӵĵ�ַ
     * 
     * @param string $baseurl   ƴ�ӻ�����ַ   ֧�� \d �滻 ϵͳID
     * @param int    $id        ϵͳID
     * @param string $defineurl �Զ���ĵ�ַ
     * 
     * @return string
     */
    public static function getMergeUrl($baseurl, $id, $defineurl='')
    {
        //�����Զ����ַ
        $findlawdomain = array('china.findlaw.cn'); //�����ҷ�����
        if ($defineurl) {
            $matchfindlaw = false;//δƥ���ҷ�����
            foreach ($findlawdomain as $fd) {
                if (preg_match('/'.$fd.'/', $defineurl)) {
                    $matchfindlaw = true;
                    break;
                }
            }
            if (!$matchfindlaw && preg_match('/^http[s]?:\/\//', $defineurl)) {//���ж�http����
                 return $defineurl;
            }
        }
        $returnurl = '';
        if (strpos($baseurl, '\d')!==false) {
            $returnurl = str_replace('\d', $id, $baseurl);
        } else {
            $returnurl = $baseurl.$id;
        }
        return $returnurl;
    }
    
    /**
     * ͨ������ȡ ��Ӧ  ipArray �ѷ���
     * 
     * @param string $host ����
     * 
     * @return array
     */
    public static function getIparrayByHost($host)
    {
        return array();
        /*
        $node = $_SERVER['SERVER_NODE'];
        switch ($host) {
        case 'g.findlaw.cn':
            $servirIps = C('WEB_SERVERS');
            //��棬������������
            if ($node == 'local' && $host = 'g.findlaw.cn') {
                $node = 'test';
            }
            break;
        case 's.findlaw.cn':
            $servirIps = array('14.17.121.108','120.31.52.227');
            break;
        case 'china.findlaw.cn':
            $servirIps = C('WEB_SERVERS');
            break;
        case 'uc.findlaw.cn':
            $servirIps = C('UC_SERVERS');
            break;
        case 'lsurl.cn':
            $servirIps = C('SHORT_URL');
            break;
        default:
            $ipArray = array();
        }
        $ipArray =  isset($servirIps[$node]) ? $servirIps[$node] : array();
        return $ipArray;
        */
    }
}
