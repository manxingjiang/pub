<?php
/**
 *  �û���ع�����
 *
 *  @author zsg <xxx@qq.com>
 *
 */
namespace Tools;
use Tools;
/**
 *  �û���ع�����
 *
 *  @author zsg <xxx@qq.com>
 */
class User
{
    public static $uinfo = array();  
    
    /**
     * ��ǰ��½�û���Ϣ
     * 
     * @param bool $getareainfo  �Ƿ�ȡ����
     * @param bool $getotherinfo �Ƿ�ȡ�û���������
     *
     * @return array
     **/
    public static function currUser($getareainfo=false, $getotherinfo=false)
    {
        static $currUser = null;
        //��¼�û�
        if (!$currUser && $_COOKIE['c2fc7b3219ceb7bdcfc8f866ea95d8e6']) {
            $uid = self::fetchUcIdent();
            if ($uid && !$_GET['nocache']) {
                $currUser = \Tools\Cache::get('FL:User:currUser:ID:'.$uid);
                if ($_GET['debug'] == 'rpcExecTime') {
                    echo '<b>��cache��</b>FL:User:currUser:ID:'.$uid.'|<b>��cache��</b><br />';
                }
            }
        }

        if ($currUser == null) {
            //��ȡ��ǰ��¼�û���Ϣ
            $currUser = self::userinfo();
            $currUser['uid'] = isset($currUser['uid']) ? $currUser['uid'] : '';
            $currUser['userid'] = isset($currUser['userid']) ? $currUser['userid'] : '';
            $currUser['username'] = isset($currUser['username']) ? $currUser['username'] : '';
            $currUser['usertype'] = isset($currUser['usertype']) ? $currUser['usertype'] : '';
            //�����б仯��д�뻺��
            $first_cache = 1;
        }
        
        $is_get_userdetail = $getotherinfo && !isset($currUser['__detail']);
        
        //��ȡ�û�������Ϣ
        if (($getareainfo||$is_get_userdetail) && !isset($currUser['areainfo'])) {
            $areainfo = \Tools\Iparea::getIpReviseArea();
            $_areainfo = \Tools\Iparea::getAreainfoByareacode($areainfo['areacode']);
            $areainfo = array_merge($areainfo, $_areainfo);
            $currUser['areainfo'] = $areainfo;
            if (!$currUser['areainfo']['city_name']) { //city_name ����Ϊ�յ����
                $currUser['areainfo']['city_name'] = $currUser['areainfo']['city'];
            }
            //�����б仯��д�뻺��
            $first_cache = 1;
        }
       
        //��ȡ�û���������
        if ($is_get_userdetail) {
            $usertype = $currUser['usertype'] == '' ? 0 : $currUser['usertype'];
            if ($usertype == 1) {
                $_tmp = \Rpc::getData('Ask.getAskLawyerInfo', $currUser['userid']);
                $_tmp2 = \Rpc::getUCData('Member.getUcLawyerByPKSel', $currUser['uid'], 1, 1);
                if ($_tmp) {
                    $_tmp = array_merge($_tmp, $_tmp2);
                    $_tmp['lawerroom'] = $_tmp['lawyerLawroom'];
                }
                if (is_array($_tmp)) {
                    $currUser                 = array_merge($currUser, $_tmp);
                    $currUser['audit_status'] = 1; //�����
                } else {
                    $currUser['audit_status'] = 0; //�����
                }
                $_tmp = Url::get_site_url(array($currUser));
                if (is_array($_tmp[0])) {
                    $currUser = array_merge($currUser, $_tmp[0]);
                }
                unset($_tmp);
                if ($currUser['photourl'] == '') {
                    $currUser['photourl'] = Image::imagesReplace('/my/lawyerfiles/201012/blank.jpg');
                }
            } elseif ($usertype == 2) {
                $citycode                   = substr($currUser['areainfo']['areacode'], 0, 4) . '00';
                $_tmp                       = \Rpc::getData('Ask.getAskTblleoInfo', $currUser['userid'], $citycode, $currUser['uid']);
                //��ȡ�û���������
                $_tmp2 = \Rpc::getUCData('Member.getUcTblleoByUserid', $currUser['userid']);
                if ($_tmp) {
                    $_tmp = array_merge($_tmp, $_tmp2);
                }
                $currUser['photourl'] = isset($_tmp['photo']) ? Image::imagesReplace('/my/pubadmin/tblimg/' . $_tmp['photo']) : '//img1.findlawimg.com/img/common/pubuser_small.gif';
                if (is_array($_tmp)) {
                    $currUser = array_merge($currUser, $_tmp);
                }
            } elseif ($usertype == 3) {
                $_tmp = \Rpc::getData('Ask.getAskLawroomInfo', $currUser['userid']);
                if (is_array($_tmp)) {
                    $currUser = array_merge($currUser, $_tmp);
                }
                $_tmp = Url::get_frim_website_new(array($currUser));
                if (is_array($_tmp[0])) {
                    $currUser = array_merge($currUser, $_tmp[0]);
                }
                unset($_tmp);
                if ($currUser['photourl'] == '') {
                    $currUser['photourl'] = Image::imagesReplace('/my/lawyerfiles/201012/blank.jpg');
                }
            }
            $currUser['uc'] = self::getUserInfoByUid($currUser['uid']);
            $currUser['__detail'] = 1;
            //�����б仯��д�뻺��
            $first_cache = 1;
        }
        //���û���߻��棬д��
        if ($first_cache) {
            \Tools\Cache::set('FL:User:currUser:ID:'.$currUser['uid'], $currUser, 3600);
        }
        return $currUser;
    }
    
    /**
     * �ж��Ƿ��е�½
     *
     * @return boolean
     */
    public static function isLogin()
    {
        $currUser = self::currUser();
        return intval($currUser['uid']) > 0;
    }
    
    /**
     * �ж��Ƿ��ǹ����û�
     *
     * @return boolean
     */
    public static function isLeo()
    {
        if (self::isLogin()) {
            $currUser = self::currUser();
            return intval($currUser['usertype']) == 2;
        }
        return false;
    }
    
    /**
     * �ж��Ƿ�����ʦ�û�
     *
     * @return boolean
     */
    public static function isLawyer()
    {
        if (self::isLogin()) {
            $currUser = self::currUser();
            return intval($currUser['usertype']) == 1;
        }
        return false;
    }
    
    /**
    * �ж��Ƿ��½����
    * ȥ�û������ж��Ƿ��¼���ɵ�¼cookie - cflauth ����
    * 
    * @return uid or 0; 0��ʾδ��¼
    **/
    public static function logincheck()
    {   
        
        $uid = self::fetchUcIdent();
        return $uid > 0 ? $uid : 0;       //cdb_member.uid
    }    
    
    /**
     * �����½cookie....
     *
     * @return .....
     **/
    public static function clear_cookie()
    {
        $ret1 = $ret2 = 0;
    
        $ret1 = setcookie('cflauth', '', -1, '/', '.findlaw.cn', 0);
        $ret2 = setcookie('logintime', '', -1, '/', '.findlaw.cn', 0);
    
        setcookie('auth', '', -1, '/', '.findlaw.cn', 0);
        setcookie('cdb_auth', '', -1, '/', '.findlaw.cn', 0);
        setcookie('flucode', '', -1, '/', '.findlaw.cn', 0);
        setcookie('usertype', '', -1, '/', '.findlaw.cn', 0);
        setcookie('idcfind', '', -1, '/', '.findlaw.cn', 0);
        setcookie('cfindname', '', -1, '/', '.findlaw.cn', 0);
        setcookie('status_record_time', '', -1, '/', '.findlaw.cn', 0);
    
        /* �˶δ����������cookie������ҵ��Ա�˳���ʦ�˺ŵ�ͬʱҲ�˳������ۺ�̨�Ⱥ�̨�������ε���
         if (is_array($_COOKIE)){
        foreach ($_COOKIE  as  $key=>$val){
        setcookie($key,'',-1,'/','.findlaw.cn') ;
        }
        }*/
        if ($ret1 && $ret2) {
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * ���ҷ��û����Ļ�ȡ��¼״̬
     *
     * @return δ��¼���� 0,�ѵ�¼�����û�uid
     **/
    public static function fetchUcIdent()
    {
        //print_r($_COOKIE);
        $url = "http://uc.findlaw.cn/index.php?a=identOutput&cfindname=".$_COOKIE['cfindname']."&uid=".$_COOKIE['uuid'];
        $ident_cookie_name = 'c2fc7b3219ceb7bdcfc8f866ea95d8e6';
        //��¼cookie ������
        if (empty($_COOKIE[$ident_cookie_name])) {
            return 0;
        }
        $clientIp = \Tools\Iparea::getClientIp();
        $url1 = \Tools\Url::getCurrUrl();
        $url2 = $_SERVER['HTTP_REFERER'];
        $post_data = array(
                $ident_cookie_name => $_COOKIE[$ident_cookie_name],
                "auth_code" => "12345",
                'clientIp'  => $clientIp,
                'url1'      => $url1,
                'url2'      => $url2
        );

        $ident_str = self::loginCurl($url, $post_data);
        //ȡ��¼uid �����µ�¼Ʊ��
        $uid = self::identUpdate($ident_str);
        /*�ض��û��ĵ�¼״̬�ϸ���*/
        if (self::checkLoginSpecial($uid, $ident_str) === false) {
            //��鲻ͨ������¼ʧ��
            $uid =0;
        }
        
        return $uid;
    }

    /**
     * �ҷ���¼���� curl����
     *
     * @param string $url       url
     * @param string $post_data postdata
     * @param string $ucIp      ip�ѷ���
     *
     * @return void
     */
    public static function loginCurl($url, $post_data, $ucIp = '')
    {
        $ident_cookie_name = 'c2fc7b3219ceb7bdcfc8f866ea95d8e6';
        $login_key = 'loginCurl##'.$_COOKIE['cfindname']."#uid#".$_COOKIE['uuid'].'#ident#'.$_COOKIE[$ident_cookie_name];
        if (!$_GET['nocache'] && $_COOKIE[$ident_cookie_name]) {
            $ident_str = \Tools\Cache::get($login_key);
        }
        if ($ident_str) {
            return $ident_str;
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        if ($_SERVER['HTTP_REFERER']) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Referer:'.$_SERVER['HTTP_REFERER']));
        }
        // post����
        curl_setopt($ch, CURLOPT_POST, 1);
        // post�ı���
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        $ident_str = \Tools\Error::curl_exec($ch);
        curl_close($ch);
        \Tools\Cache::set($login_key, $ident_str, 180);
        return $ident_str;
    }
    
    /**
     * ��¼����Ʊ�ݸ���
     *
     * @param str $ident_str ����¼������Ϣ��
     *
     * @return array
     */
    public static function identUpdate($ident_str)
    {
        $separator = '#';
        $tmp_info = explode($separator, $ident_str);
        //"{$encrypt_str}{$separator}{$lifetime}{$separator}{$login_time}{$separator}{$latest_opt_time}{$separator}{$appid_str}";
        if (count($tmp_info) < 5) {
            return 0;
        }
        //print_r($tmp_info); echo "<br />{$ident_str}<br />";
        $encrypt_str   = $tmp_info[0];
        $lifetime      = (int)$tmp_info[1];
        $login_time    = (int)$tmp_info[2];
        $latest_opt_time = (int)$tmp_info[3];
        $appid_str     = $tmp_info[4];
    
        if ($tmp_info[5]) {
            $uid = $tmp_info[5];
        } else {
            $uid = 0;
        }
    
        $cookie_value = "{$encrypt_str}{$separator}{$lifetime}{$separator}{$login_time}{$separator}{$latest_opt_time}{$separator}{$appid_str}";
        $ident_cookie_name  = 'c2fc7b3219ceb7bdcfc8f866ea95d8e6';
        self::dsetcookie($ident_cookie_name, $cookie_value, $lifetime);
        return $uid;
    }
    
    /**
     * cookie���ü�����
     *
     * @param string $var      cookie����
     * @param string $value    ccookieֵ
     * @param string $life     ��Ч��
     * @param bool   $httponly httponly
     *
     * @return unknow
     */
    public static function dsetcookie($var, $value = '', $life = 0, $httponly = false)
    {
        $timenow = time();
        $cookiedomain = '.findlaw.cn';
        $cookiepath = '/';
        if ($value == '' || $life < 0) {
            $value = '';
            $life = -1;
        }
        $life = $life > 0 ? ($timenow + $life) : ( $timenow - 31536000 );
        $path = $httponly && PHP_VERSION < '5.2.0' ? "$cookiepath; HttpOnly" : $cookiepath;
        //$secure = $_SERVER['SERVER_PORT'] == 443 ? 1 : 0;
        $secure = 0 ;
        if (PHP_VERSION < '5.2.0') {
            $ret = setcookie($var, $value, $life, $path, $cookiedomain, $secure);
        } else {
            $ret = setcookie($var, $value, $life, $path, $cookiedomain, $secure, $httponly);
        }
        return $ret ;
    }
    
    /**
     * ����seeeion_mem �� lawyer_online��
     *
     * @return type
     */
    public static function up_ses_mem()
    {
        $now         = time();
        $lastvistime = intval(isset($_COOKIE['islogin']) ? $_COOKIE['islogin'] : 0);
        $todaybefore = strtotime("yesterday") + 86400;
        $less        = $now - $lastvistime;
        if ($less > 1200) {
            if (isset($_COOKIE['flucode']) && isset($_COOKIE['cflauth'])) {
                $infoarr = self::get_cflauth();
                $usertype = intval($infoarr[0]);
                $uid = intval($infoarr[1]);
                $userid = $infoarr[2];
                $username = $infoarr[3];
                $lastip = \Tools\Iparea::getClientIp();
                $ucode = $_COOKIE['flucode'];
                //�ѷ���
                //\Rpc::getData('Member.updateOnline', $usertype, $ucode, '', $userid, $uid, $lastip);
            }
        } else {
            setcookie('islogin', $now, time() + 1200, '/', '.findlaw.cn', 0);
        }
    }
    
    /**
     * �û���Ϣ�õ�
     *
     * @return .....
     **/
    public static function userinfo()
    {
        $uid = self::logincheck();
        if (!$uid) {
            return false;
        }
        $userinfo = self::getUserBaseInfoByUid($uid);
        //�û������״ε�¼ ���ӻ���
        \Tools\Jifeng::loginJifeng_everyday($uid, $userinfo['userid'], $userinfo['usertype']);
        return $userinfo;
    }
    
    /**
     * ͨ��uid ��ȡ �û���Ϣ ��ת�������� (����Դ���ҷ��û��������û�����)
     *
     * @param int $uid �û�uid
     *
     * @return array
     */
    public static function getUserBaseInfoByUid($uid = 0)
    {
        if (!$uid) {
            return array();
        } 
        $userBaseInfo = self::getUserInfoByUid($uid);
        
        //�ɳ����� 0,1,2,3�±�ȡ�û����ݵģ� ����Ŀ¼�ṹҪ�ĳ� key:userytpe,uid,userid,username
        $userBaseInfo = array(
            'uid' => $userBaseInfo['uid'],
            'userid' => $userBaseInfo['userid'],
            'username' => $userBaseInfo['username'] ? $userBaseInfo['username'] : '����',
            'usertype' => $userBaseInfo['usertype'],
            'accounttype' => $userBaseInfo['usertype'] . '1'
        );
        return $userBaseInfo;
    }
    
    /**
     * ͨ��uid ��ȡ �û���Ϣ ��ת�������� (����Դ���û�����)
     *
     * @param int $uid �û�uid
     *
     * @return userInfo
     */
    public static function getUserInfoByUid($uid = 0)
    {
        if (!$uid) {
            return array();
        }
        static $userInfo = array();
        if (!empty($userInfo) && $userInfo['uid'] == $uid) {
            return $userInfo;
        }
        $ucInfo = \Rpc::getUCData('Member.getUcMemberByUid', $uid);       
        
        if ($ucInfo['membertype'] == 1) {
            //$userInfo = \Rpc::getData('Member.getTblmemberByUserid', $ucInfo['userid']);
            $userInfo = \Rpc::getUCData('Member.getUcLawyerByPKSel', $uid, 1, 2);
            $userInfo['isvip'] = $userInfo['ucLawyerInfo']['isvip'];
        }
        
        if ($ucInfo['membertype'] == 2) {
            //$userInfo = \Rpc::getData('Member.getTblleoByUserid', $ucInfo['userid']);
            $userInfo = \Rpc::getUCData('Member.getUcTblleoByPKSel', $uid, 1);
        }
        if (empty($userInfo)) {
            return array();
        }
        //дcookie��  {cfindname} ������ʦ����ͳ��,��������Ϣȡ�û�����ʱ�����ɾ��
        if (!isset($_COOKIE['cfindname']) || $_COOKIE['cfindname'] != $userInfo['userid']) {
            \Tools\Cookie::dsetcookie('cfindname', $userInfo['userid'], 60*60);
        }
        $userInfo['uid'] = $uid;
        $userInfo['usertype'] = $ucInfo['membertype'];
        return $userInfo;
    }
    
    /**
     * ��ȡ cflauth ��ת��������
     *
     * @return type
     */
    public static function get_cflauth()
    {
        $arrs = \Tools\Encrypt::authcode($_COOKIE['cflauth']);
        $arr  = explode("\t", $arrs);
    
        if (count($arr)==0) {
            return false;
        }
        $count = 5;
        if (intval($arr[0])===1 && count($arr)===6) {
            $count = 6;
        }
    
        if (count($arr) != $count) {
    
            $arr == explode("\\t", $arrs);
            if (count($arr) != $count) {
                return false;
            }
        }
    
        return $arr;
    }
    
    /**
     * ��½ �ɹ� �����û�uid,����С��1
     *
     * @param string $user          �û���
     * @param string $pass          ����
     * @param time   $loginlivetime ��½����ʱ��
     * @param string $url_from      �û����ĵ�ַ����
     *
     * @return .....
     **/
    public static function dologin($user, $pass, $loginlivetime = 31536000, $url_from = 'setsession_first_findlawlogin')
    {
        //���ӶԿ��û����Ϳ�������ж�
        if ($user == '' || $pass == '') {
            return -4;
        }
        //$this->init();
    
        $reinfo = \Rpc::getData('Member.login', $user, $pass);
        $state = $reinfo['state'];
        $userInfo = $reinfo['userInfo'];
        // uc ���ݿ����Ҳ���������ݡ����ݲ�ͬ������������
        if ($state=='02') {
            return 0;
        }
        //�û����ͳ���
        if ($state=='03') {
            return -1;
        }
        self::$uinfo['username'] = $user;
        self::$uinfo['userpass'] = $pass;
        self::$uinfo['uid'] = intval($userInfo['uid']);
        self::$uinfo['userid'] = $userInfo['userid'];
        self::$uinfo['usertype'] = $userInfo['usertype'];
        self::$uinfo['accounttype'] = $userInfo['usertype'] .'1';
        self::$uinfo['uinfo'] = array(
            'uid' =>  $userInfo['uid'],
            'userid' =>  $userInfo['userid'],
            'username' =>  $userInfo['username'],
            'email' =>  $userInfo['email'],
            'psw'=>$pass,
        );
        
        switch (self::$uinfo['usertype']) 
        {
        case 1:
            self::$uinfo['uinfo']['ucode'] =  $userInfo['tblMember']['ucode'];
            self::$uinfo['uinfo']['areacode'] =  $userInfo['tblMember']['areacode'];
            self::$uinfo['cdbpass'] = $userInfo['password'];
            break;
        case 2:
            self::$uinfo['uinfo']['ucode'] = $userInfo['tblleo']['ucode'];
            self::$uinfo['uinfo']['areacode'] = $userInfo['tblleo']['areacode'];
            break;
        case 3:
            self::$uinfo['uinfo']['ucode'] = $userInfo['lawRoom']['ucode'];
            self::$uinfo['uinfo']['areacode'] = $userInfo['lawRoom']['areacode'];
            break;
        default:
            return -1;
            break;
        }
        //print_r($userInfo);
        //exit;
        $cookieUserinfo = array($userInfo['uid'],$userInfo['username'],$userInfo['password']);
         
        //���cookieʧ��
        if (!self::clear_cookie()) {
            return -2;
        }
        //дcooieʧ��
        if (!$ret = self::write_cookie($cookieUserinfo, $loginlivetime)) {
            return -3;
        }
    
        //���õ�½cookie ����ʱ��
        $cookietime = time() + $loginlivetime;
    
        $loginip = \Tools\Iparea::getClientIp();
    
        if (self::$uinfo['uinfo']['ucode'] == '') {
            $url_from = 'setsession_first_findlawlogin';
        } else {
            $url_from    = $url_from ? $url_from : (addslashes($_SERVER['HTTP_REFERER']));
            $url_from    = $url_from . '___ipaddr=' . $_SERVER['SERVER_ADDR'];
        }
        
        //Ӱ�����أ���ʱȥ��
        /*
        $ucode = \Rpc::getData(
            'Member.updateAllAfterLogin',
            self::$uinfo['uid'], 
            $loginip, 
            $cookietime, 
            self::$uinfo['uinfo']['userid'], 
            self::$uinfo['uinfo']['username'], 
            self::$uinfo['usertype'], 
            self::$uinfo['uinfo']['areacode'], 
            $userInfo['password'], 
            self::$uinfo['uinfo']['ucode'], 
            self::$uinfo['uinfo']['email'], 
            $url_from
        );*/
        
        //var_dump($ucode);
        self::dsetcookie("flucode", $ucode, $cookietime, true);
    
        return self::$uinfo['uid'];
    }
    
    /**
     * д��½cookie... Ĭ��ʱ�� 7 ��
     *
     * @param array  $userinfo      �û���Ϣ
     * @param string $loginlivetime ��½����ʱ��
     *
     * @return .....
     **/
    public static function write_cookie($userinfo, $loginlivetime = 604800)
    {
        $ret1 = $ret2 = 0;
    
        ////auth ��ʽ  �û�����(1 2 3 )   �û�uid    �û�userid   �û����� ;
        $authkey  = self::$uinfo['usertype'] . "\t" . self::$uinfo['uid'] . "\t" . 
        self::$uinfo['userid'] . "\t" . self::$uinfo['uinfo']['username'] . "\t" . self::$uinfo['accounttype'];
        if (self::$uinfo['usertype'] ===1) {
            $authkey .= "\t".md5(C('ASK_AUTH_KEY').self::$uinfo['cdbpass']);
        }
        $authkey  = \Tools\Encrypt::authcode($authkey, "ENCODE");
        $logtime  = time();
        //cookie��Ч��7��
        $cookdate = $loginlivetime;
    
        $ret1 = self::dsetcookie("cflauth", $authkey, $cookdate);
        $ret2 = self::dsetcookie("logintime", $logtime, $cookdate);
    
        ///������Ϊ�����ϳ����д..
        $authold = $userinfo[2] . "\t\t" . $userinfo[0];
        self::dsetcookie('auth', \Tools\Encrypt::authcode($authold, "ENCODE"), $cookdate);
        self::dsetcookie('cdb_auth', \Tools\Encrypt::authcode($authold, "ENCODE", md5('x0qOZP4yZjIPSRZ' . $_SERVER['HTTP_USER_AGENT'])), $cookdate);
    
        $flucodeold = self::$uinfo['uinfo']['ucode'];
        self::dsetcookie('flucode', $flucodeold, $cookdate);
        self::dsetcookie('usertype', self::$uinfo['usertype'], $cookdate);
        self::dsetcookie('idcfind', self::$uinfo['uid'], $cookdate);
        self::dsetcookie('cfindname', self::$uinfo['userid'], $cookdate);
        self::dsetcookie('status_record_time', time(), $cookdate);
        ///////////
    
        if ($ret1 && $ret2) {
            return true;
        } else {
            return false;
        }
    }
    
    
    /**
     * �����������
     *
     * @return mixed
     */
    public static function getRandPassword()
    {
        $str = array('0123456789', '0123456789', '0123456789');
        $string = '';
        foreach ($str as $value) {
            $t = rand(0, 2);
            $total=strlen($str[$t]);
            $start = rand(0, $total);
            $string .= substr($str[$t], $start - 1, 1);
        }
        return 'findlaw'.$string;
    }
    
    /**
     * �õ�����ǿ��-���û�ϵͳ
     *
     * @param string $password ����(δ����)
     *
     * @return int ����ǿ�ȣ�0����1�У�2ǿ
     */
    public static function getPassIntensity($password)
    {
        $passIntensity = -1;
        $rule_1 = '/^.*([\W_])+.*$/i';
        $rule_2 = '/^.*([a-zA-Z])+.*$/i';
        $rule_3 = '/^.*([0-9])+.*$/i';
        if (preg_match($rule_1, $password)) {
            $passIntensity++;
        }
        if (preg_match($rule_2, $password)) {
            $passIntensity++;
        }
        if (preg_match($rule_3, $password)) {
            $passIntensity++;
        }
        if (strlen($password) > 10) {
            $passIntensity++;
            $passIntensity = $passIntensity > 2 ? 2 : $passIntensity;
        } else {
            $passIntensity = $passIntensity > 1 ? 1 : $passIntensity;
        }
        return $passIntensity;
    }
    
    /**
     * �û����ĵ�¼ʧ�ܵ�״̬��Ϣ
     * 
     * @param string $status code
     * 
     * @return multitype:string |string|Ambigous <string>
     */
    public static function loginErrorCode($status = '')
    {
        //CURL��ȡ��¼״̬ ʧ�ܴ�����
        $logincode = array(
                '-804' => '��¼��Ϣ������',
                '-702' => '��¼��Ϣ�쳣 ',
                '-701' => '��¼��ʱ ',
                '-604' => '��¼��Ϣ������',
                '-602' => '��¼��Ϣ�쳣',
                '-601' => '��¼��ʱ',
                '-901' => '��ȡmemcacheʧ��',
                '-902' => '��ȡpost��cookieʧ��',
                '-703' => 'cookie��cache��¼Ʊ�ݶԱ� ��һ��'
        );
        if (empty($status)) {
            return $logincode;
        } else {
            if (empty($logincode[$status])) {
                return "δ֪����(״̬��:{$status} ������)";
            } else {
                return $logincode[$status];
            }
        }
    }
    
    /**
     * �ض��û��ĵ�¼״̬�ϸ���
     * 
     * @param int    $uid       uid
     * @param string $ident_str ��¼Ʊ��
     * 
     * @return null
     */
    public static function checkLoginSpecial($uid = 0, $ident_str = '')
    {
        //���ü���û���uid
        $uids = array(21860962,20161947);
        //�ָ���
        $separator = "#";
        $ident_cookie_name = 'c2fc7b3219ceb7bdcfc8f866ea95d8e6';
        if ($uid > 0 && in_array($uid, $uids) && $ident_str) {
            $tmp_info = explode($separator, $ident_str);
            $encrypt_str = $tmp_info[0];
            $flag = false;
            if ($encrypt_str) {
                $ucInfo = \Rpc::getUCData('Member.getUcMemberByUid', $uid);
                if ($ucInfo['uid'] == $uid) {
                    $password = $ucInfo['password'];
                    $encrypt_str_make = md5("{$ucInfo['userid']}{$separator}{$password}{$separator}{$uid}");
                    if ($encrypt_str == $encrypt_str_make) {
                        //���ͨ��
                        $flag = true;
                    }
                }                
            }
            
            if (!$flag) {
                //��鲻ͨ���������¼cookie
                \Tools\Cookie::dsetcookie($ident_cookie_name);
                return false;
            }
        }
        return true;
    }
    
}
