<?php
/**
 *  ip����������
 *
 *  @author zsg <xxx@qq.com>
 */

namespace Tools;
use Tools;
/**
 *  ip����������
 *
 *  @author zsg <xxx@qq.com>
 */
class Iparea
{

    /**
     * ȡ�������е�ַ �����ֱϽ�С���ô�Ͱѵ����������������Ϊ0��ֻȥ���м��������ֱϽ�У�ȥ���м�
     *
     * @param string $areacode ���д���
     * 
     * @return null
     */
    public function getCityCode($areacode)
    {
        if (!in_array(substr($areacode, 0, 2), array(11,12,13,14,43,44,45))) {
            $areacode = substr($areacode, 0, 4).'00';
        } else {
            $areacode = substr($areacode, 0, 4).'01';
        }
        return $areacode;
    }

    /**
     * ȡʡ����д��� ֱϽ��ֱ��ȡֱϽ�У�ʡ��ȡʡ�����
     *
     * @param string $areacode ���д���
     * 
     * @return null
     */
    public function getMainCityCode($areacode)
    {
        if (!in_array(substr($areacode, 0, 2), array(11,12,13,14,43,44,45))) {
            $areacode = substr($areacode, 0, 2).'0200';
        } else {
            $areacode = substr($areacode, 0, 2).'0101';
        }
        return $areacode;
    }

    /**
     * ����IP��ַ��Ӧ��ϵ�� ��ʱ �ѷ���
     *
     * @param string $city ����������������
     * 
     * @return null
     */

    public static function getAreaByCity($city)
    {
        $redis = \Tools\Cache::redis();
        //��Ϊ�۰�̨��ȡʡ��
        if (in_array(substr($city, 0, 2), array(71, 81, 82))) {
            $city = substr($city, 0, 2).'0000';
        }
        $city_key = 'ipip-findlaw-city'.date('Ymd');
        //ͨ��redis���ҳ���/ʡ�ݶ�Ӧ�ĳ���/ʡ�������Ϣ
        $data = unserialize($redis->hGet($city_key, $city));
        //��û�����ݣ���key�����ڣ����ʼ����������
        if (!$data && $redis->hLen($city_key) < 3000) {
            $db=new \Models\UcUserCloudModel();
            //ȡ����ʡ�����ؼ�
            $sql='select id as areacode,province,city,pinyin,code from uc_area order by id asc';
            $list=$db->query($sql);
            //����������д��
            foreach ($list as $v) {
                if ($v['code']) {
                    $redis->hSet($city_key, $v['code'], serialize($v));
                }
                if ($v['areacode']) {
                    $redis->hSet($city_key.'areacode', $v['areacode'], serialize($v));
                }
            }
            //self::getMainCityCode($v['areacode'])
            $data = unserialize($redis->hGet($city_key, $city));
        }
        //ȡ��ʡ�����ؼ���ʱ��ת��Ϊ�м�
        if ($data && !$data['city']) {
            $areacode = self::getMainCityCode($data['areacode']);
            $data = unserialize($redis->hGet($city_key.'areacode', $areacode));
        }
        //�Դ���ĵ�ַ���м�¼
        if (!$data) {
            $redis->sAdd('ipip-findlaw-city-error', $city);
        }
        if ($_GET['yatesun']) {
            var_dump($data);
            var_dump($redis->sMembers('ipip-findlaw-city-error'));
            die();
        }
        return $data;
    }
    /**
     * ͨ��IP���ҵ�ַ
     * 
     * @param string $ip ip
     *  
     * @return string
     */
    public static function search_ip($ip)
    {
        //ͨ�����������ӿ�
        if (!$data) {
            $iprs = \Rpc::getShortlinkData('Ip.getAreaByIp', $ip, 'fl');
            if ($areacode=$iprs['id']) {
                $areacode = self::getCityCode($areacode);
                $data = array('province'=>$iprs['province'],'city'=>$iprs['city'],'pinyin'=>$iprs['pinyin'],'areacode'=>$areacode,'default'=>0);
            }
        }
        //û�У��򷵻�Ĭ��ֵ
        if (!$data) {
            $data = array('province'=>'�㶫', 'city'=>'����', 'pinyin'=>'guangzhou','areacode'=>'170200','default'=>0);
        }
        return $data;
    }

    /**
     * ��ip�ű���     * 
     * 
     * @param unknown $dotquad_ip dotquad_ip
     *  
     * @return string
     */
    public static function encode_ip($dotquad_ip)
    {
        $ip_sep = explode('.', $dotquad_ip);
        return sprintf('%02x%02x%02x%02x', $ip_sep[0], $ip_sep[1], $ip_sep[2], $ip_sep[3]);
    }
    
    /**
     * ��ip��ȡ���ݣ�ip����mysql���ڴ��������һ�����ӡ�
     * ��ͨ��cookie��ȡ�Ƿ������˵�����Ϣ��Ȼ����ip�������������ip��ַ��
     * 
     * @param string $ip ip��ַ
     * 
     * @return array ������Ϣ
     */
    public static function getIpReviseArea($ip='')
    {
        if (empty($ip)) {
            $ip = self::getClientIp();
        }
        if ($_GET['ip'] && $_SERVER['HTTP_HOST'] = 'm.findlaw.cn' && $_SERVER['DOCUMENT_URI'] == '/index.php' && preg_match('/^((?:(?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))\.){3}(?:25[0-5]|2[0-4]\d|((1\d{2})|([1 -9]?\d))))$/', $_GET['ip'])) {
            $ip = $_GET['ip'];
            unset($_COOKIE['areainfo']);
        }
        //$ip = '211.140.160.0';
        //���cookie ���� ���ȶ�ȡcookie
        //����areainfoΪ�û��������û�������վ�ĵ�����Ϣ
        if ($_COOKIE['areainfo']['province'] && $_COOKIE['ip_areainfo']['city']) {
            if (isset($_COOKIE['preview'])) {
                if ($_COOKIE['preview']) {
                    //js������cookie��UTF-8����
                    $_COOKIE['areainfo']['province'] = iconv('utf-8', 'GB18030//TRANSLIT//IGNORE', $_COOKIE['ip_areainfo']['province']);
                    $_COOKIE['areainfo']['city'] = iconv('utf-8', 'GB18030//TRANSLIT//IGNORE', $_COOKIE['ip_areainfo']['city']);
                    \Tools\Cookie::dsetcookie('areainfo[province]', $_COOKIE['ip_areainfo']['province'], 86400);
                    \Tools\Cookie::dsetcookie('areainfo[city]', $_COOKIE['ip_areainfo']['city'], 86400);
                    \Tools\Cookie::dsetcookie('preview');
                    $_COOKIE['preview'] = '';
                }
            }
            $areainfo = $_COOKIE['areainfo'];
            $areainfo['cookie_status'] = 1;// ��¼GPS��λ�ɹ�
        }
        if (!$areainfo) {
            $areainfo = self::search_ip($ip);
        }
        //ip_areainfoΪ�û���ʵ����ʵIP
        $ip_areainfo = $_COOKIE['ip_areainfo'];
        if (!$ip_areainfo && C('ask')) {
            $ip_areainfo = self::search_ip($ip);
            setcookie("ip_areainfo[province]", $ip_areainfo['province'], time()+60*60*24*30, '/', '.findlaw.cn', 0);
            setcookie("ip_areainfo[city]", $ip_areainfo['city'], time()+60*60*24*30, '/', '.findlaw.cn', 0);
            setcookie("ip_areainfo[pinyin]", $ip_areainfo['pinyin'], time()+60*60*24*30, '/', '.findlaw.cn', 0);
            setcookie("ip_areainfo[areacode]", $ip_areainfo['areacode'], time()+60*60*24*30, '/', '.findlaw.cn', 0);
        }
                
        //���õ���ͳһcookie��ʽ
        setcookie("areainfo[province]", $areainfo['province'], time()+60*60*24*30, '/', '.findlaw.cn');
        setcookie("areainfo[city]", $areainfo['city'], time()+60*60*24*30, '/', '.findlaw.cn');
        setcookie("areainfo[pinyin]", $areainfo['pinyin'], time()+60*60*24*30, '/', '.findlaw.cn');
        setcookie("areainfo[areacode]", $areainfo['areacode'], time()+60*60*24*30, '/', '.findlaw.cn');
        setcookie("areainfo[default]", $areainfo['default'], time()+60*60*24*30, '/', '.findlaw.cn');
        $areainfo['cookie_status'] = 0;// ��¼GPS��λʧ��
        if (C('ask')) {
            return $ip_areainfo;
        }
        return $areainfo;
    }
    
    /**
     * ���õ��� cookie
     * 
     * @param array $areainfo ����
     * @param int   $default  �Ƿ�Ĭ��
     * 
     * @return boolean
     */
    public static function setArea($areainfo, $default = 0)
    {
        $default = $default ? 1 : 0; 
        $areacode = $areainfo['id'] ? $areainfo['id'] : $areainfo['areacode'];
        if (empty($areacode) || empty($areainfo['province']) || empty($areainfo['city']) || empty($areainfo['pinyin'])) {
            return false;
        }
        $cookietime = time()+60*60*24*30;
        //���õ���ͳһcookie��ʽ
        setcookie("areainfo[province]", $areainfo['province'], $cookietime, '/', '.findlaw.cn');
        setcookie("areainfo[city]", $areainfo['city'], $cookietime, '/', '.findlaw.cn');
        setcookie("areainfo[pinyin]", $areainfo['pinyin'], $cookietime, '/', '.findlaw.cn');
        setcookie("areainfo[areacode]", $areacode, $cookietime, '/', '.findlaw.cn');
        setcookie("areainfo[default]", $default, $cookietime, '/', '.findlaw.cn');
        return true;
    }
    
    /**
     * ��ȡ�û���¼IP
     *
     * @param int $type Ĭ��ʱȡ�����û�ip(���ip���ܱ�α��),��Ҫ��ip���εȹ���ʱ,�贫�� type=1 ����ȡip 
     * 
     * @return     string ip
     */
    public static function getClientIp($type = 0)
    {
        if ($type == 1 && $_SERVER['REMOTE_ADDR']) {
            return $_SERVER['REMOTE_ADDR'];
        }
        $ip=false;
        foreach (array('HTTP_X_FORWARDED_FOR', 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key) {
            if (array_key_exists($key, $_SERVER)) {
                foreach (explode(',', $_SERVER[$key]) as $ip) {
                    $ip = trim($ip);
                    //����˵�������ַ��˽�е�ַ�ε�IP������ 127.0.0.1�ᱻ����
                    //Ҳ�����޸ĳ�������֤IP
                    if ((bool) filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                        return $ip;
                    }
                }
            }
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(", ", $_SERVER['HTTP_X_FORWARDED_FOR']);
            if ($ip) {
                array_unshift($ips, $ip);
                $ip = false;
            }

            for ($i = 0; $i<count($ips); $i++) {
                if (!preg_match("/^(10|172\.16|127\.0|192\.168)\./i", $ips[$i])) {
                    $ip = $ips[$i];
                    break;
                }
            }
        }
        if (!empty($_SERVER["HTTP_CLIENT_IP"])) {
            $ip = $_SERVER["HTTP_CLIENT_IP"];
        }
        return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
    }
    
    /**
     * ͨ���ֻ��Ż�ȡ����
     * 
     * @param int $mobile �ֻ��� ����ǰҪ���ֻ��ż�飬����ӿڱ���
     * 
     * @return area
     */    
    public static function getWyTelAreaByTel($mobile)
    {
        $mobile = strlen($mobile) > 6 ? substr($mobile, 0, 7) : '';
        if (!empty($mobile)) {
            return \Rpc::getShortlinkData('Mobile.getAreaByTel', $mobile, 'fl');
        } else {
            return null;
        }
    }

    /**
     * GPS ��λ
     * 
     * @param untype $lat  lat
     * @param untype $lng  lng
     * @param string $type returntype
     * 
     * @return jsonData
     */
    public static function getAreaByGPS($lat, $lng, $type='json')
    {
        $lg = $lat.','.$lng;
        $url = "http://api.welegal.cn:8888/router/rest?appKey=00001&v=1.0&method=findlaw.user.gps.info&location={$lg}";
        $jsonData = \Tools\Curl::url_get_contents($url);
        $data = json_decode($jsonData, true);
        $data = \Tools\Strings::utf8Gbk($data);
        $areacode = $data['data']['areacode'];
        if ($areacode) {
            $areacode = substr($areacode, 0, -2).'00';
            setcookie("gps_areacode", $areacode, 3600, '/', '.findlaw.cn', 0);
        }
        //getAreaByGPS
        if ($type == 'array') {                      
            return $data;
        }
        return $jsonData;
    }
    
    /**
     * ȡ�û�ϵͳ������Ϣ
     * 
     * @param unknown $areacode areacode
     * @param string  $isMap    boolean
     * 
     * @return Ambigous <Ambigous, NULL, mixed, unknown, string>
     */
    public static function getAreainfoByareacode($areacode, $isMap = true) 
    {
        if (empty($areacode)) {
            return array();
        }
        $rpcname = is_array($areacode) ? $isMap ? 'Area.queryUcAreaMap' : 'Area.queryUcAreaList' : 'Area.getUcAreaById';
        $areainfo = \Rpc::getUCData($rpcname, $areacode, 1, 0);
        return $areainfo;
    }
    
    /**
     * ȡ�û�ϵͳ���������Ϣ
     * 
     * @param intval $areacode areacode
     * 
     * @return array
     */
    public static function getUcAreaByAreacodeId($areacode) 
    {
        if (empty($areacode)) {
            return array();
        }
        $areainfo = \Rpc::getUCData('Area.getUcAreaByAreacodeId', $areacode, 1, 0);
        return $areainfo;
    }
    
    /**
     * ȡ�û�ϵͳ������Ϣ by pinyin
     *
     * @param string $pinyin pinyin
     *
     * @return array
     */
    public static function getAreainfoBypinyin($pinyin) 
    {
        if (!empty($pinyin)) {
            //$areainfo = \Rpc::getUCData('Area.queryUcAreaListByForm', array('pinyin' => $pinyin), 1, 0);
            //$areainfo = \Rpc::getUCData('Area.getUcAreaByPinyin', $pinyin, 1, 0);
            $info_key = 'Area.getUcAreaByPinyin-'.\Tools\Cache::hash($pinyin);
            $info = \Tools\Cache::get($info_key);
            if (!$info) {
                $info = \Rpc::getUCData('Area.getUcAreaByPinyin', $pinyin, 1, 0);
                \Tools\Cache::set($info_key, $info, 600);
            }
            $areainfo = $info;
        }
        if (empty($areainfo['id'])) {
            $areainfo = array();
        } else {
            $areainfo['areacode'] = $areainfo['id'];
        }
        return $areainfo;
    }
    
    /**
     * ȡ�û�ϵͳ������Ϣ(�����¼�����) by pinyin
     *
     * @param string $pinyin pinyin
     *
     * @return array
     */
    public static function queryFlAreaListMapByPinyin($pinyin) 
    {
        if ($pinyin) {
            $areainfo = \Rpc::getUCData('Area.queryFlAreaListMapByPinyin', $pinyin);
        }
        if (empty($areainfo)) {
            $areainfo = array();
        }
        return $areainfo;
    }
   

    /**
     * ��ѯϵͳ������Ϣ by pinyin
     *
     * @param string $pinyin pinyin
     *
     * @return array
     */
    public static function queryAreaInfo($pinyin)
    {
        if ($pinyin) {
            $areainfo = \Rpc::getData('Area.queryAreaInfo', $pinyin);
        }
        if (empty($areainfo)) {
            $areainfo = array();
        }
        return $areainfo;
    } 
    /**
     * ȡ�û�ϵͳ������Ϣ(��������ʡ�ݡ�ͬ�����С���Ͻ��) by areacode
     *
     * @param intval $areacode �������
     *
     * @return array
     */
    public static function queryFlAreaListMapByAreacode($areacode) 
    {
        if (!empty($areacode)) {
            $areainfo = \Rpc::getUCData('Area.queryFlAreaListMapByAreacode', $areacode);
        }
        if (empty($areainfo)) {
            $areainfo = array();
        }
        return $areainfo;
    }
    
    /**
     * ȡ�û�ϵͳ�������� by areacode
     *
     * @param intval $areacode �������  
     * @param intval $limit    �����������   
     * @param intval $pid      1:�ҷ�ƽ̨��ʶ 2:�쳵ƽ̨��ʶ   
     *
     * @return array
     */
    public static function getNearUcAreaMap($areacode, $limit = 10, $pid = 1) 
    {
        if (!empty($areacode)) {
            $areainfo = \Rpc::getUCData('Area.getNearUcAreaMap', $areacode, $pid, $limit);
        }
        if (empty($areainfo)) {
            $areainfo = array();
        }
        return $areainfo;
    }
    
    /**
     * ȡ��ǰ���������й�Ͻ�ĵ�����Ϣ by areacode
     *
     * @param intval $areacode ������ţ�ʡ���л�����  
     *
     * @return array
     */
    public static function queryFlAreaListMapById($areacode) 
    {
        if (!empty($areacode)) {
            $areainfo = \Rpc::getUCData('Area.queryFlAreaListMapById', $areacode);
        }
        if (empty($areainfo)) {
            $areainfo = array();
        }
        return $areainfo;
    }
    
    /**
     * ��� ȡһ���������� by ������Ϣ����
     *
     * @param unknown $areainfo ������Ϣ���� ����grade,pinyin
     *
     * @return unknown
     */
    public static function rankCountryCode($areainfo)
    {
        switch ($areainfo['grade']) {
        case 0:
            //ʡ��
            $areainfo_tmp = \Tools\Iparea::queryFlAreaListMapByPinyin($areainfo['pinyin']);
            if (empty($areainfo_tmp)) {
                //ȡ����ֵ
                return $areainfo;
            }
            $count = count($areainfo_tmp['thisarea']);
            $areainfo_tmp = $areainfo_tmp['thisarea'][mt_rand(1, $count-1)]; //�����һ����һ������
            //$areainfo_tmp = self::rankCountryCode($areainfo_tmp);
            break;
        case 1:
            //�м�
            $areainfo_tmp = \Tools\Iparea::queryFlAreaListMapByPinyin($areainfo['pinyin']);
            $count = count($areainfo_tmp['area_countrys']);
            $areainfo_tmp = $areainfo_tmp['area_countrys'][mt_rand(1, $count-1)]; //�����һ����һ������
            break;
        case 2:
            break;
        }
        if (!empty($areainfo_tmp)) {
            $areainfo_tmp['areacode'] = $areainfo_tmp['id'];
            return $areainfo_tmp;
        } else {
            return $areainfo;
        }
    }
    
    /**
     * ���ص���ƴ��
     * 
     * @return array
     */
    public static function getAreaPinyin()
    {
        $area=array('aaxq','aba','abaxian','abgq','acheng','aes','ahq','ahqx','aihui','aimin','akesu','akshs','akt','ale','aletai','ali','alke','alsm','alsyq','alszq','ancheng','anciqu','anda','anding','anduo','anfu','anguo','anhua','anhui','anji','anju','ankang','anlong','anlu','anning','anningqu','anping','anqing','anqiu','anren','ansai','anshan','anshun','antu','anxian','anxiang','anxin','anyang','anyi','anyuan','anyuanqu','anyue','anze','aomen','aomenbandao','aomenlidao','aqjiao','aqyx','arq','astiexi','ats','awati','axx','ayx','babu','bachu','badaojiang','badong','bagongshan','baicheng','baihe','bailang','baiquan','baise','baisha','baishan','baishu','baita','baixia','baiyin','baiyinqu','baiyu','baiyun','banan','bange','bangfu','bangshan','banma','baoan','baode','baodi','baoding','baofeng','baohe','baoji','baojing','baokang','baoqing','baoshan','baoshanqu','baota','baoting','baotou','baoxing','baoying','baqiao','baqing','basu','batang','bayan','bazhong','bazhou','bazhouqu','bcqz','bcx','bdlx','bdyx','beian','beibei','beichen','beidaihe','beiguan','beihai','beihu','beijing','beilin','beilinqu','beiliu','beilun','beining','beipiao','beita','benxi','bianba','bijie','bincheng','binchuan','binhai','binhaixinqu','binjiang','binxian','binyang','binzhou','biru','bishan','bjtq','blkh','blyq','blzq','bmyz','boaixian','bobai','boertala','bohu','bole','boli','boluo','bomi','boshan','botou','boxiang','boxing','boye','bsq','btq','butuo','bx','bxmz','bygl','bykq','bynem','byq','byqq','caidian','canglang','cangnan','cangshan','cangshanqu','cangwu','cangxi','cangxian','cangzhou','caoxian','cbcex','cbcx','cbehq','cbmz','cbq','cdlx','cdq','cdx','ceheng','celei','cengong','cenxi','chaling','chancheng','changan','changanqu','changchun','changdao','changde','changdu','changfeng','changge','changhai','changji','changjiang','changjiangqu','changle','changli','changling','changning','changningqu','changping','changqing','changsha','changshan','changshou','changshu','changshun','changtai','changting','changtu','changwu','changxing','changyi','changyiqu','changyuan','changzhi','changzhou','changzhouqu','changzi','chaoan','chaohu','chaonan','chaotian','chaoyang','chaoyangqu','chaozhou','chaya','chayu','chencang','chenduo','chengcheng','chengde','chengdu','chenggong','chenggu','chengguan','chengguanqu','chenghai','chenghua','chengjiang','chengkou','chengmai','chengq','chengqu','chengwu','chengxian','chengxiang','chengyang','chengzhongqu','chenxi','chenzhou','cheyyhq','cheyyqq','cheyyzq','chhzq','chibi','chicheng','chifengshi','chikan','chiping','chishui','chizhou','chongan','chongchuan','chongli','chongming','chongqing','chongren','chongwen','chongxin','chongyang','chongyi','chongzhou','chongzuo','chuanhui','chuanshan','chuanying','chunan','chunhua','chuxiong','chuzhou','chuzhouqu','cili','cixi','cixian','clx','cns','cnx','conghua','congjiang','congtai','congyang','cq','cqu','csx','cuiluan','cuiping','cuomei','cuona','cuoqin','cxq','cytjz','cywz','czhq','czq','czx','daan','daanqu','dachang','dacheng','dachuan','dadong','dadukou','dafang','dafeng','daguan','daguanqu','dailing','daishan','daixian','daiyue','dajiang','dali','dalian','dalishi','dalixian','daming','danba','dancheng','dandong','danfeng','dangchang','dangshan','dangtu','dangxiong','dangyang','daning','danjiangkou','danleng','dantu','danxian','danyang','danzhai','danzhou','daocheng','daofu','daoli','daowai','daoxian','dapu','daqing','dari','dashiqiao','datian','datong','datongqu','dawa','dawu','dawukou','daxian','daxiang','daxin','daxing','dayao','daye','dayi','daying','dayu','dayz','dazhu','dazi','dazu','dcdxw','dcfq','dean','debao','debt','dechang','decheng','dege','deh','dehong','dehua','dehui','dejiang','delingha','dengfeng','dengkou','dengta','dengzhou','deqin','deqing','derong','dexing','deyang','dezhou','dhq','dhyz','dianbai','dianjiang','dianjun','didao','diebu','diecai','dingan','dingbian','dingcheng','dinghai','dinghu','dingjie','dingnan','dingqing','dingri','dingtao','dingxi','dingxiang','dingxing','dingyuan','dingzhou','diqing','djy','dldq','dltq','dong','donga','dongan','donganqu','dongbao','dongchang','dongcheng','dongchuan','dongfang','dongfeng','dongfengqu','donggang','donggangqu','dongguan','dongguang','dongguanqu','donghai','donghe','dongkou','donglan','dongli','dongliao','dongling','dongliqu','dongming','dongning','dongping','dongpo','dongshan','dongshanqu','dongsq','dongtai','dongxiang','dongxing','dongxingqu','dongyang','dongying','dongyingqu','dongyuan','dongzhi','dongzhou','doumen','dqx','dsq','dszq','dthz','dtx','duanzhou','duchang','duji','dulan','dunhua','dunhuang','duodao','duolun','dushan','duyun','dwzm','dxal','dxhq','dxz','dzs','dzylz','ebyz','echeng','eeds','eegn','ejnq','elc','elht','emin','ems','enping','enshi','erdao','erdjq','erqi','eryuan','esyz','etkq','etkqq','ewkz','ezhou','faku','fanchang','fancheng','fangcheng','fangshan','fangshanqu','fangxian','fangyuan','fangzheng','fangzi','fanxian','fanzhi','fc','fcg','fcq','fcyz','feicheng','feidong','feixi','feixian','feixiang','fengcheng','fengdu','fenggang','fenghua','fenghuang','fengjie','fengkai','fengman','fengnan','fengning','fengqing','fengqiu','fengrun','fengshan','fengshun','fengtai','fengtaiqu','fengxiang','fengxianls','fengxianqu','fengxin','fengyang','fengze','fengzhen','fenxi','fenyang','fenyi','ffkq','flejq','fn','fnx','fogang','foping','foshan','fpx','fsx','fuan','fucheng','fuchengqu','fuding','fufeng','fugong','fugouxian','fuguxian','fujian','fujin','fukang','fuliang','fuling','fumin','funan','funing','fuping','fuqing','fuquan','furong','fushan','fushanqu','fushun','fushunshi','fusong','fusui','futian','fuxian','fuxin','fuxing','fuyang','fuyu','fuyuan','fuzhou','fuzhoushi','fx','fxmg','fy','fyx','gaer','gaize','gaizhou','gande','gangba','gangbei','gangcha','gangcheng','gangkou','gangnan','gangu','gangzha','ganluo','gannan','gannanxian','ganquan','gansu','ganxian','ganyu','ganzhou','ganzhouqu','ganzi','gaoan','gaocheng','gaochun','gaogang','gaolan','gaoling','gaomi','gaoming','gaoping','gaopingqu','gaoqing','gaotai','gaotang','gaoxian','gaoxiong','gaoxiongxian','gaoyang','gaoyao','gaoyi','gaoyou','gaozhou','gashi','gax','gbd','gbjd','gclq','gcx','gcyz','geermu','geji','gejiu','genhe','geyang','gjzq','glbyz','glq','gmdz','gongan','gongga','gonghe','gongjing','gongjue','gongliu','gongnong','gongshu','gongxian','gongyi','gsdlz','gtq','guanchenghui','guandu','guangan','guanganqu','guangchang','guangde','guangdong','guangfeng','guanghan','guanghe','guangling','guanglingqu','guangnan','guangning','guangping','guangrao','guangshan','guangshui','guangxi','guangyuan','guangze','guangzhou','guangzong','guannan','guantao','guanxian','guanyang','guanyun','guazhou','gucheng','guchengqu','guichi','guide','guiding','guidong','guigang','guilin','guinan','guiping','guixi','guiyang','guizhou','gujiao','gulang','gulin','gulou','gulouqu','guoluo','gushi','gutian','guxian','guyang','guyequ','guyuan','guzhang','guzhen','gxiuwen','gy','gyq','gyx','gzl','haerbin','haian','haibei','haicang','haicheng','haichengqu','haidian','haidong','haifeng','haikou','hailin','hailing','hailun','haimen','hain','hainan','hainanqu','haining','haishu','haixi','haixing','haiyan','haiyang','haiyuan','haizhou','haizhouqu','haizhu','hami','hanbin','hancheng','hanchuan','handan','hangzhou','hanjiang','hanjiangqu','hannan','hanshan','hanshanqu','hanshou','hantai','hanting','hanyang','hanyin','hanyuan','hanzhong','haojiang','haozhou','hax','hbheshan','hbkse','hbwq','hbxiangshan','hcq','hd','hdmz','hdwx','hdx','hebei','hebeiqu','hebi','hecheng','hechi','hechuan','hedong','hedongqu','hefei','hefeng','hegang','heihe','heilongjiang','heishan','heishui','hejian','hejiang','hejin','hejing','hekou','helan','helong','henan','hengdong','hengfeng','hengnan','hengshan','hengshanqu','hengshui','hengxian','hengyang','heping','hepingqu','hepu','heqing','hequ','heshan','heshanqu','heshui','heshun','heshuo','hetang','hetian','hexi','hexian','heyang','heyuan','heze','hezhang','hezheng','hezhou','hezuo','hgq','hhgq','hhlx','hjhq','hjmnz','hjq','hkyz','hlbe','hleq','hlge','hlgl','hlhz','hndatong','hnmgz','hongan','hongdong','honggang','honggu','honghe','honghex','honghu','hongjiang','hongkou','hongqi','hongqiao','hongshan','hongsibao','hongta','hongwei','hongxing','hongyuan','hongze','houma','hrmz','hs','hsgq','hsjx','hsq','hsx','hsxx','htb','htx','huaan','huachi','huachuan','huade','huadian','huadu','huaian','huaibei','huaibin','huaihua','huaiji','huailai','huainan','huaining','huairen','huairou','huaishang','huaiyang','huaiyin','huaiyinqu','huaiyuan','hualian','huanan','huancui','huangchuan','huangdao','huanggang','huanggu','huanghua','huangling','huanglong','huangmei','huangnan','huangpi','huangping','huangpu','huangpuqu','huangshan','huangshanqu','huangshi','huangyan','huangyuan','huangzhou','huaning','huantai','huanxian','huaping','huarong','huarongqu','huashan','huating','huaxi','huaxian','huayin','huaying','huayuan','huazhou','hubei','hubin','huguan','huhehaote','huian','huichang','huicheng','huidong','huiji','huilai','huili','huimin','huiminqu','huinan','huining','huinong','huishan','huishui','huitong','huixian','huiyang','huize','huizhou','huizhouqu','hukou','hulan','huli','hulin','huludao','huma','hunan','hunchun','hunyuan','huocheng','huojia','huoqiu','huoshan','huozhou','huqiu','huxian','huzhong','huzhou','hx','hy','hyx','hztz','hzxihu','hzy','jax','jchnz','jcjq','jcpq','jdyz','jgdq','jgs','jgyz','jhyz','jiacha','jiading','jiahe','jiajiang','jiali','jialing','jiamusi','jian','jianchang','jianchuan','jiande','jiangan','jianganqu','jiangbei','jiangbeiqu','jiangcheng','jiangchuan','jiangdong','jiangdu','jiange','jianggan','jianghai','jianghan','jiangjin','jiangkou','jiangle','jiangling','jiangmen','jiangnan','jiangning','jiangshan','jiangsu','jiangxi','jiangxia','jiangxian','jiangyan','jiangyang','jiangyin','jiangyong','jiangyou','jiangyuan','jiangzi','jianhe','jianhu','jianhua','jianli','jianning','jianou','jianping','jianshan','jianshi','jianshixian','jianshuixian','jianwei','jianyang','jianye','jianzha','jiaocheng','jiaochengqu','jiaohe','jiaojiang','jiaokou','jiaoling','jiaonan','jiaoqu','jiaozhou','jiaozuo','jiashan','jiawang','jiaxian','jiaxiang','jiaxing','jiayin','jiayu','jiayuguan','jidong','jiedong','jiefang','jieshou','jiexi','jiexiu','jieyang','jiguan','jili','jilin','jilong','jilongs','jimei','jimo','jinan','jinanq','jinanqu','jinanxian','jinchang','jinchangqu','jincheng','jinchuan','jinchuanqu','jindong','jinfeng','jingan','jinganqu','jingbian','jingchuan','jingde','jingdezhen','jinghai','jinghe','jinghong','jinghu','jingjiang','jingkou','jingle','jingmen','jingning','jingshan','jingtai','jingxi','jingxian','jingxing','jingyan','jingyang','jingyangqu','jingyu','jingyuan','jingzhou','jingzhouq','jinhu','jinhua','jining','jiningqu','jinjiang','jinjiangqu','jinjiazhuang','jinkouhe','jinmen','jinmenx','jinming','jinnan','jinning','jinniu','jinping','jinpingqu','jinsha','jinshan','jinshantun','jinshi','jinshui','jinta','jintai','jintan','jintang','jinwan','jinxi','jinxian','jinxiang','jinyang','jinyuan','jinyun','jinzhai','jinzhong','jinzhou','jinzhouqu','jishan','jishou','jishui','jiujiang','jiujiangqu','jiuli','jiulong','jiulongpo','jiulongx','jiuquan','jiutai','jiuzhaigou','jiuzhi','jixi','jixian','jiyang','jiyuan','jize','jizhou','jizhouqu','jjx','jl','jmse','jmswy','jnyz','jpmz','jq','jssbaz','juancheng','juchao','julu','junan','junshan','junxian','jurong','juxian','juyexian','jx','jxkq','jxq','jxs','jxx','jxyz','jy','jys','jyx','jz','jzmz','jzq','jzqx','jzyx','kai','kaifeng','kaifu','kaihua','kaijiang','kaili','kailu','kaiping','kaipingqu','kaiyang','kaiyuan','kangbao','kangding','kangle','kangma','kangping','kangxian','kashi','kdlq','kecheng','kedong','keerqin','kel','kelamayi','kelamayiqu','kelan','kenli','keping','keqyyqq','keqyyzq','keqzyhq','keqzyzq','keshan','kfqx','kfx','klq','klqq','klqzy','kongdong','kq','kske','kskt','kuancheng','kuanchengqu','kuangqu','kuche','kuitun','kuiwen','kunming','kunshan','ky','kzlsk','laian','laibin','laicheng','laifeng','laishan','laishui','laiwu','laixi','laiyang','laiyuan','laizhou','langao','langfang','langkazi','langxi','langxian','langya','langzhong','lankao','lanshan','lanshanq','lanshanqu','lantian','lanxi','lanxian','lanzhou','laobian','laocheng','laohekou','laoshan','lasha','lazi','lc','lclhz','lcmlz','lcq','lcs','lcx','lean','lechang','ledong','ledu','leibo','leishan','leiwuqi','leiyang','leizhou','leling','lenghu','leping','leqing','leshang','leting','leye','lezhi','lfjx','lfx','lfxx','lhq','liancheng','liandu','liangchen','liangdang','lianghe','liangping','liangqing','liangshan','liangyuan','liangzhou','lianhu','lianhua','lianjiang','lianjiangs','liannan','lianping','lianshan','lianshanqu','lianshui','lianyuan','lianyun','lianyungang','lianzhou','liaocheng','liaoning','liaoyang','liaoyuan','liaozhong','libo','licang','licheng','lichengq','lichuan','lieshan','lijiang','lijin','liling','linan','lincang','lincheng','linchuan','lindian','linfen','lingao','lingbao','lingbi','lingchuan','lingdong','linghai','linghe','lingling','lingqiu','lingshan','lingshi','lingshou','lingshui','lingtai','lingui','lingwu','lingxian','lingyi','lingyuan','lingyun','linhai','linhe','linjiang','linkou','linli','linqing','linqu','linquan','linshu','lintan','lintong','linwei','linwu','linxi','linxia','linxian','linxiang','linxiangqu','linxixian','linyao','linying','linyou','linze','linzhang','linzhi','linzhou','linzi','liping','lipu','liquan','lishan','lishi','lishu','lishui','lishuqu','litang','litong','liuan','liuba','liubei','liucheng','liuhe','liuhequ','liujiang','liulin','liunan','liupanshui','liuyang','liuzhou','liwan','lixia','lixian','lixin','liyang','lizhou','ljx','llgz','llq','lnlx','longan','longanqu','longchang','longcheng','longchuan','longde','longfeng','longgang','longgangqu','longhai','longhu','longhua','longhuaqu','longhui','longjiang','longjing','longkou','longli','longling','longmatan','longmen','longnan','longnanxian','longquan','longsha','longshan','longtan','longting','longwan','longwen','longxi','longxian','longyan','longyang','longyao','longyou','longzhou','longzi','longzihu','loudi','louxing','lpbz','lqyq','lqyz','ls','lsgz','lsj','lskq','lslz','lsq','lsszq','lstq','lsx','luancheng','luanchuan','luannan','luanping','luanxian','lubei','lucheng','luchengqu','luchuan','ludian','luding','lueyang','lufeng','luhe','luhuo','lujiang','lujing','luliang','lulong','lunan','luntai','luobei','luochuan','luodian','luoding','luogang','luohe','luohu','luojiang','luojiangqu','luolong','luonan','luoning','luoping','luopu','luoshan','luotian','luoyang','luoyuan','luozha','luozhuang','luqiao','luqu','luquan','lushan','lushanqu','lushi','lushui','lusong','luwan','luxi','luxian','luyang','luyixian','luzhai','luzhou','lvchun','lvfan','lvliang','lvyuan','lx','lxs','lxx','ly','lyx','lyxian','lyyc','lzhq','lzs','lztq','maanshan','macheng','macun','maduo','maerkang','maguan','maiji','majiang','malipo','malong','mancheng','mangkang','mangya','maogang','maojian','maoming','maonan','maoxian','maqin','maqu','mashan','mashanqu','mawei','mazhang','mbyz','meigu','meijiang','meilan','meilie','meishan','meitan','meixi','meixian','meizhou','mengcheng','mengcun','menghai','mengjin','mengla','mengshan','mengxian','mengyin','mengzhou','mengzi','mentougou','mgt','mhhz','mhk','mhongya','mianchi','mianning','mianxian','mianyang','mianzhu','miaoli','midong','midu','milei','milin','miluo','minfeng','mingguang','mingshan','mingshanqu','mingshui','mingxi','minhou','minle','minqin','minqing','minquan','minxian','minxing','miquan','mishan','miyang','miyi','miyun','mizhixian','mjhnz','mldw','mldz','mlhs','mlsdwe','mlzz','mns','mohe','motuo','mouding','moyu','muchuan','mudan','mudanjian','mulan','muleng','muping','mx','myhz','mymz','mzgk','mzl','naidong','naimq','nanan','nananqu','nanao','nanbu','nancha','nanchang','nanchangqu','nancheng','nanchong','nanchuan','nandan','nanfen','nanfeng','nangang','nangong','nangqian','nanguan','nanhai','nanhe','nanhua','nanhui','nanjiang','nanjiao','nanjing','nanjingxian','nankai','nankang','nanle','nanling','nanning','nanpi','nanpiao','nanping','nanqiao','nansha','nanshan','nanshanqu','nanshiqu','nantong','nantou','nanxi','nanxian','nanxiong','nanxun','nanyang','nanyue','nanzhang','nanzhao','nanzheng','napo','naqu','naxi','nayong','ncx','nehe','neihuang','neijiang','neimenggu','neiqiu','neixiang','nenjiang','nima','nimu','ningan','ningbo','ningcheng','ningde','ningdu','ningguo','ninghai','ninghe','ninghua','ningjin','ningling','ningming','ningnan','ningqiang','ningshan','ningwu','ningxia','ningxian','ningxiang','ningyang','ningyuan','njq','njx','njyz','nlk','nlyz','nml','nmq','nongan','nsqd','nujiang','nzsq','ouhai','panan','panji','panjing','panlong','panshan','panshi','panxian','panyu','panzhihua','pbmz','pcx','pdsxinhua','pehnz','peixian','peizhou','pengan','penghu','pengjiang','penglai','pengshan','pengxi','pengyang','pengze','pengzhou','pianguan','pingan','pingba','pingchang','pingchuan','pingding','pingdingshan','pingdong','pingdu','pingfang','pinggu','pingguo','pinghe','pinghu','pingjiang','pingle','pingli','pingliang','pinglu','pingluo','pingluqu','pingnan','pingqiao','pingquan','pingshan','pingshanqu','pingshun','pingtan','pingtang','pingwu','pingxiang','pingxiangshi','pingyang','pingyao','pingyi','pingyin','pingyu','pingyuan','pishan','pixian','pjq','pjx','pld','pnx','potou','poyang','psmztjz','psx','ptlicheng','pubei','pucheng','puding','pudongxinqu','puer','puge','pujiang','pukou','pulan','puning','putian','putuo','putuoqu','puxian','puyang','pxlx','pxx','py','pyx','qax','qbjq','qdq','qdx','qgel','qhmq','qhx','qianan','qiandongnan','qianjiang','qianjiangqu','qianjin','qiannabu','qiannan','qianshan','qianshanqu','qianxi','qianxian','qianxinan','qianyang','qiaocheng','qiaodong','qiaodongqu','qiaojia','qiaokou','qiaox','qiaoxi','qiaoxiqu','qibin','qichun','qidong','qiemo','qiezihe','qihe','qijiang','qilian','qilihe','qilin','qimen','qinan','qinbei','qindu','qingan','qingcheng','qingchengqu','qingchuan','qingdao','qingfeng','qinggang','qinghai','qinghe','qinghequ','qinghuangdao','qingjian','qingliu','qinglong','qingpu','qingpuqu','qingshan','qingshen','qingshui','qingtian','qingxian','qingxin','qingxiu','qingxun','qingyang','qingyangqu','qingyuan','qingyuanqu','qingyuanxian','qingyun','qingzhen','qingzhou','qinhuai','qinnan','qinshui','qintang','qinxian','qinyang','qinyuan','qinzhou','qinzhouqu','qionghai','qiongjie','qionglai','qiongshan','qiongzhong','qiqihaer','qishan','qitai','qitaihe','qiubei','qiuxian','qixia','qixian','qixiaqu','qixing','qiyang','qlx','qsh','qsq','qsx','qsyq','qtx','quangang','quanjiao','quannan','quanshan','quanzhou','queshan','qufushi','qujiang','qujiangqu','qujing','qumalai','qushui','qusong','quwo','quxian','quyang','quzhou','qxx','qy','qymz','qypq','qyx','qyzy','qz','qzx','rangtang','raohe','raoping','raoyang','rcx','renbu','rencheng','renhe','renhua','renhuai','renqiu','renshou','renxian','rhlq','ritu','rizhao','rkz','rongan','rongchangxian','rongcheng','rongchengqu','rongjiang','rongxian','rsmz','rucheng','rudong','rugao','ruian','ruichang','ruicheng','ruijin','ruili','runan','runzhou','ruoergai','rushan','ruyang','ruyuan','ruzhou','rx','saetu','sangti','sangzhi','sanhe','sanmen','sanmenxia','sanming','sanshan','sanshui','sansui','santai','sanya','sanyuan','sanyuanqu','sbxq','sdsz','seda','sfh','sftq','sglq','shache','shaga','shahe','shajia','shancheng','shandan','shandong','shangcai','shangcheng','shangchengqu','shangdu','shanggao','shanghai','shanghang','shanghe','shangjie','shangli','shanglin','shangluo','shangnan','shangqiu','shangrao','shangshui','shangsi','shangyi','shangyou','shangyu','shangzhi','shangzhou','shannan','shanshan','shanting','shantou','shanwei','shanxi','shanxi2','shanxian','shanyang','shanyangqu','shanyin','shaodong','shaoguan','shaoshan','shaowu','shaoxing','shaoyang','shapingba','shashi','shawan','shaxian','shaya','shayang','shayibake','shehong','shenchi','shengsi','shengzhou','shenhe','shenmu','shennongjia','shenqiu','shenxian','shenyang','shenze','shenzha','shenzhen','shenzhou','sheqi','sherong','shexian','sheyang','shgq','shhz','shibei','shibing','shicheng','shidian','shifang','shifeng','shigu','shihe','shihezi','shijiazhuang','shijingshan','shilong','shilou','shimen','shimian','shinan','shiping','shiqian','shiqu','shiquan','shishi','shishou','shitai','shixing','shiyan','shizhong','shizhongq','shizhongqu','shizishan','shizong','shizuishan','shkq','shouguang','shouning','shouxian','shouyang','shuangbo','shuangcheng','shuangfeng','shuangliao','shuangliu','shuangpai','shuangqiao','shuangqiaoqu','shuangqing','shuangyang','shuanyashan','shucheng','shufu','shuicheng','shuifu','shuining','shulan','shulei','shunchang','shuncheng','shunde','shunping','shunqing','shunyi','shuocheng','shuozhou','shushan','shuyang','sichuan','sifang','sihong','sihui','simao','siming','sinan','siping','sishui','sixian','siyang','sjlhz','sjtq','sjtz','sjzxinhua','slm','slq','slyz','smgq','sntyq','sntzq','snx','songbei','songjiang','songling','songming','songpan','songxi','songxian','songyang','songyuan','songzi','sptiedong','sptq','srwy','srx','ssq','stmz','stq','stzq','sucheng','suibin','suichang','suichuan','suide','suihua','suijiang','suileng','suining','suiping','suixi','suixian','suiyang','suiyangqu','suizhong','suizhou','sumin','sunke','sunwu','suoxian','suqian','susongxian','suxian','suyu','suzhou','suzhouqu','suzhoushi','swchengqu','sx','sxx','sybaoshan','syheping','syx','szq','sztjzzz','szwq','tacheng','tachengshi','tahe','taian','taibai','taibei','taicang','taidong','taierzq','taigu','taihe','taihequ','taihu','taijiang','taijiangqu','taikang','tailai','tainan','taining','taiping','taiqian','taishan','taishanqu','taishun','taiwan','taixing','taiyuan','taizhou','taizhoushi','tancheng','tanghai','tanghe','tangshan','tangxian','tangyin','tangyuan','taobei','taocheng','taojiang','taoshan','taoyuan','taoyuanx','tax','tbs','tbx','tcx','tdtz','tekesi','tengchong','tengxian','tengzhou','th','thx','thyc','tianchang','tiandeng','tiandong','tiane','tianhe','tianjiaan','tianjin','tianjun','tianlin','tianmen','tianning','tianqiao','tianquan','tianshan','tianshui','tiantai','tianxin','tianyang','tianyuan','tianzhen','tianzhu','tiedong','tiefeng','tieli','tieling','tieshan','tiexi','tiexiqu','tinghu','tjx','tks','tkt','tl','tljiao','tlx','tmsk','tmtyq','tmtzq','tns','tongan','tongbo','tongcheng','tongchuan','tongchuanqu','tongde','tonggu','tongguan','tongguanshan','tonghai','tonghe','tonghua','tongjiang','tongliang','tongliao','tongling','tonglu','tongnan','tongren','tongrenshi','tongshan','tongtou','tongwei','tongxiang','tongxin','tongxu','tongyu','tongzhou','tongzhouqu','tongzi','tpsq','tsgq','tsx','tthq','tuanfeng','tulufan','tumen','tunchang','tunliu','tunxi','tuoli','tuoqiang','tuquan','twhq','twjyx','tzhq','tzs','tzx','tzzz','wanan','wancang','wancheng','wanchengqu','wangdu','wanghua','wangjiang','wangkui','wangmo','wangqing','wanli','wannian','wanning','wanquan','wanrong','wansheng','wanxiu','wanzai','wanzhou','wblq','wcx','wcyl','wdlc','weibin','weichang','weicheng','weichengqu','weidong','weidu','weifang','weihai','weihui','weili','weinan','weishan','weishi','weixian','weixin','weiyang','weiyuan','wenan','wenchang','wencheng','wenchuan','wendeng','wenfeng','wengan','wenjiang','wenling','wenquan','wenshan','wenshang','wenshanxian','wensheng','wenshui','wensu','wenxi','wenxian','wenyuan','wenzhou','wfd','wftjz','wgs','whx','wjq','wlcb','wlht','wlmqx','wlthq','wltqq','wltzq','wlyq','wntq','wnyz','wolong','woyang','wsq','wstq','wsyz','wuan','wubao','wuchang','wuchangqu','wucheng','wuchengqu','wuchuan','wuda','wudang','wudi','wuding','wudu','wuerhe','wugang','wugong','wuhai','wuhan','wuhe','wuhou','wuhu','wuhua','wuhuaqu','wuji','wujiagang','wujiang','wujiangqu','wujin','wulan','wulian','wuling','wulong','wulumuqi','wumahe','wuming','wuning','wuping','wuqi','wuqia','wuqiang','wuqiao','wuqing','wushan','wushanxian','wushen','wusheng','wusu','wutai','wutongqiao','wuwei','wuxi','wuxiang','wuxing','wuxix','wuxuan','wuxue','wuyang','wuyi','wuying','wuyishan','wuyuan','wuzhai','wuzhi','wuzhong','wuzhongqu','wuzhou','wwx','wx','wxllz','wy','wylq','wyx','wzs','xam','xax','xaxincheng','xbehyq','xbehzq','xbmgz','xbmz','xc','xcq','xcs','xcx','xdhz','xf','xfx','xfxiangyang','xgll','xhlq','xhq','xhsl','xhtz','xhx','xhyq','xi','xiacheng','xiaguan','xiahe','xiajiang','xiajin','xialu','xiamen','xian','xianfeng','xiangan','xiangcheng','xiangchengqu','xiangdong','xiangfan','xiangfang','xiangfen','xianggang','xianggangdao','xianghe','xiangning','xiangqiao','xiangshan','xiangshanqu','xiangshui','xiangtan','xiangxi','xiangxiang','xiangyang','xiangyangqu','xiangyin','xiangyuan','xiangyun','xiangzhou','xiangzhouqu','xianju','xiannan','xianning','xianqu','xiantao','xianxian','xianyang','xianyou','xiaochang','xiaodian','xiaogan','xiaohe','xiaojin','xiaonan','xiaoning','xiaoshan','xiaoting','xiaoxian','xiaoyi','xiapu','xiashan','xiaxian','xiayi','xichang','xicheng','xichong','xichou','xichuan','xide','xiejiaji','xifeng','xifengt','xifu','xigang','xigong','xigu','xihe','xihequ','xihu','xihua','xihuqu','xiji','xilin','xiling','xilinqu','xinan','xincai','xinchang','xincheng','xinchengq','xindu','xinfeng','xinfu','xingan','xinganqu','xingbin','xingcheng','xingguo','xinghai','xinghe','xinghua','xinglong','xingning','xingningqu','xingping','xingren','xingshan','xingshanqu','xingtai','xingtang','xingwen','xingxian','xingye','xingyi','xingzi','xinhe','xinhua','xinhuaqu','xinhui','xining','xinji','xinjian','xinjiang','xinjie','xinjin','xinle','xinlin','xinlong','xinluo','xinmi','xinmin','xinning','xinpu','xinqing','xinqiu','xinrong','xinshao','xinshi','xinshiqu','xintai','xintian','xinxian','xinxiang','xinxing','xinxingqu','xinyang','xinye','xinyi','xinyu','xinyuan','xinzheng','xinzhou','xinzhouqu','xinzhu','xinzhuxian','xiongxian','xiping','xiqing','xishan','xishi','xishuangbanna','xishui','xiucheng','xiufeng','xiuning','xiushui','xiuwu','xiuying','xiuyu','xixia','xixian','xixiang','xixiaqu','xixiu','xiyang','xizang','xizhou','xjx','xlglm','xlglms','xlht','xltq','xmwz','xnygz','xpyz','xqq','xsq','xsqd','xstjzmz','xsx','xt','xtm','xtwx','xtx','xuancheng','xuanen','xuanhan','xuanhua','xuanhuaqu','xuanwei','xuanwu','xuanwuqu','xuanzhou','xuchang','xuchi','xuecheng','xuhui','xunwu','xunyang','xunyangqu','xunyi','xupu','xushui','xuwen','xuyong','xuzhou','xwzm','xxlx','xxtq','xxx','xxyy','xy','xymz','xzgulou','yaan','yadong','yajiang','yanan','yanbian','yanbianshi','yanchang','yancheng','yanchi','yanchuan','yandu','yanfeng','yangcheng','yangchun','yangdong','yanggao','yanggu','yangjiang','yangling','yangming','yangpu','yangquan','yangren','yangshan','yangshuo','yangxi','yangxian','yangxin','yangyuan','yangzhong','yangzhou','yanhu','yanji','yanjiang','yanjin','yanliang','yanling','yanping','yanqing','yanshan','yanshanqu','yanshi','yanshou','yanta','yantai','yantan','yantian','yanting','yanyuan','yanzhou','yaoan','yaodu','yaohai','yaonan','yaozhou','ybq','ybsq','ybx','ybyz','yc','ycs','ycx','yecheng','yexian','yhq','yhtjz','yian','yibin','yichang','yicheng','yichengqu','yichuan','yichun','yichunqu','yichunshi','yidu','yifeng','yihuang','yijiang','yijun','yilan','yilanx','yili','yiliang','yiling','yilong','yima','yimen','yinan','yinchuan','yindu','yingde','yingdong','yingjiang','yingjiangqu','yingjing','yingkou','yingquan','yingshan','yingshang','yingtan','yingxian','yingyang','yingzhe','yingzhou','yinhai','yining','yiningxian','yinzhou','yinzhouqu','yishui','yiwu','yixian','yixing','yiyang','yiyuan','yizhang','yizheng','yizhou','yj','yjhlq','yjhnz','yjs','yjtjz','yjx','yks','yl','yljx','ylnxz','ylx','yms','yn','ynx','yongan','yongchang','yongcheng','yongchuan','yongchun','yongde','yongdeng','yongding','yongdingqu','yongfeng','yongfu','yonghe','yongji','yongjia','yongjin','yongkang','yongnian','yongning','yongping','yongqiao','yongqing','yongren','yongshang','yongsheng','yongshou','yongshun','yongtai','yongxin','yongxing','yongxiu','yongzhou','youhao','youjiang','youxi','youxian','youxianqu','youyi','youyu','yph','yptz','yqhz','yqx','ys','yss','ysx','ysyzk','ytmz','ytx','yuan','yuanan','yuanbao','yuancheng','yuanhui','yuanjiang','yuanling','yuanmou','yuanping','yuanqu','yuanshi','yuanyang','yuanzhou','yubei','yucheng','yuchengqu','yuci','yudu','yuecheng','yuechi','yuehu','yuelu','yuetang','yuexi','yuexiu','yueyang','yufeng','yugan','yuhang','yuhe','yuhong','yuhu','yuhua','yuhuan','yuhuaqu','yuhuatai','yuhui','yujiang','yulin','yulinshi','yunan','yuncheng','yunchengqu','yunchengxian','yunfu','yunlao','yunlian','yunlin','yunlong','yunmeng','yunnan','yunxi','yunxian','yunyan','yunyang','yuqing','yuquan','yushan','yushanqu','yushe','yushu','yushui','yushuxian','yutai','yutian','yuxi','yuxiao','yuxiqu','yuyang','yuyao','yuzhong','yuzhongqu','yuzhou','yuzhouqu','ywtq','ywx','yx','yxx','yy','yylq','yytjzmz','yyx','yzq','zaduo','zanghuang','zaoqiang','zaoyang','zeku','zengcheng','zengdu','zepu','zezhou','zgeq','zgq','zhabei','zhada','zhalantan','zhanang','zhangbei','zhangdian','zhanghua','zhangjiagang','zhangjiajie','zhangjiakou','zhangping','zhangpu','zhangqiu','zhangshu','zhangwan','zhangwu','zhangxian','zhangyi','zhangzhou','zhanhe','zhanhua','zhanjiang','zhanqian','zhanyi','zhaoan','zhaodong','zhaojue','zhaoling','zhaoping','zhaoqing','zhaosu','zhaotong','zhaoxian','zhaoyang','zhaoyangshi','zhaoyuan','zhaozhou','zhaozhuang','zhecheng','zhejiang','zhenan','zhenanqu','zhenba','zhenfeng','zhengan','zhengding','zhenghe','zhengning','zhengyang','zhengzhou','zhenhai','zhenjiang','zhenjiangqu','zhenkang','zhenlai','zhenping','zhenxing','zhenxiong','zhenyuan','zherong','zhidan','zhiduo','zhifu','zhijiang','zhijin','zhong','zhongba','zhongfang','zhongjiang','zhonglou','zhongmou','zhongning','zhongshan','zhongshanqu','zhongwei','zhongxiang','zhongyang','zhongyuan','zhongzhan','zhoucun','zhoukou','zhouning','zhoushan','zhouzhi','zhuanghe','zhuanglang','zhucheng','zhuhai','zhuhui','zhuji','zhumadian','zhuolu','zhuoni','zhuozhou','zhuozi','zhushan','zhushanqu','zhuxi','zhuzhou','zibo','zichang','zichuan','zigong','zigui','zijin','ziliujing','zitong','zixi','zixing','ziyang','ziyangqu','ziyangxian','ziyuan','zizhong','zizhou','zjchz','zjtz','zlq','zlt','zltq','znbyz','zoucheng','zouping','zpx','zsq','zsqd','zsx','zunhua','zunyi','zuogong','zuoquan','zuoshui','zuoyun','zxbq','zxq','zy','zymz','zyq','zys','zyx','zyyz','zzx','zzxiangcheng','zzyicheng','nanhu','ninger','sxian','guangming','longhuaxinqu','pingshanxinqu','dapeng');
        return $area;
    }
    
    /**
     * �Ƿ�ΪֱϽ��
     * 
     * @param int  $areacode areacode
     * @param bool $flag     �Ƿ����ر�������
     *
     * @return int
     */
    public static function isMunicipality($areacode, $flag = true)
    {
        $Municipality = array('11','12', '13', '14');
        $specialCity = array('43', '44', '45');
        if ($flag) {
            $Municipality = array_merge($Municipality, $specialCity);
        }
        $areacode = substr(intval($areacode), 0, 2);
        if (in_array($areacode, $Municipality)) {
            return 1;
        }
        return 0;
    }

    /**
     * ���ݵ�����Ϣ,���ص�������
     * �㶫-����-Խ����
     * getAreaName($areainfo, 5, 0, '#') ���� �㶫#Խ����
     * getAreaName($areainfo, 5, 1, '#') ���� Խ����
     *
     * @param array $areainfo  ������Ϣ
     * @param array $level     ����   1.ʡ�� 2.�м� 4.����
     * @param array $num       ����   
     * @param array $separator �ָ��
     *
     * @return string         ��������
     */
    public static function getAreaName($areainfo, $level=7, $num=0, $separator='-')
    {
        $area = array();
        if (empty($areainfo) || $level < 1) {
            return '';
        }
        if (($level & 1) && $areainfo['province'] != '') {
            $area[] = $areainfo['province'];
        }
        if (($level & 2) && $areainfo['city'] != '') {
            $area[] = $areainfo['city'];
        }
        if (($level & 4) && $areainfo['country'] != '') {
            $area[] = $areainfo['country'];
        }
        if ($num > 0) {
            krsort($area);
            $area = array_slice($area, 0, $num);
        }
        if (!empty($area)) {
            return implode($separator, $area);
        } else {
            return '';
        }
    }
    
    /**
     * ��������ת�ַ���
     *
     * @param int $areacode ��������
     * @param int $sign     0 ��ʾȫ����1 ����ʾʡ
     *
     * @return string
     */
    public static function areacodeToAddr($areacode, $sign = 0) 
    {
        if (empty($areacode)) {
            return '';
        }
        $areainfo = self::getAreainfoByareacode($areacode);
        $country  = empty($areainfo['country']) ? '' : $areainfo['country'];
        $city     = empty($areainfo['city']) ? '' : $areainfo['city'];
        $province = empty($areainfo['province']) ? '' : $areainfo['province'] . 'ʡ';
        if (self::isMunicipality($areacode)) {
            return $city . $country;
        } else {
            $city = empty($city) ? '' : $city . '��';
        }
        if ($sign == 1) {
            $province = '';
        }
        return $province . $city . $country;
    }
}
