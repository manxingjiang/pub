<?php
/**
* 3,4,5��ʦ�Ƽ��㷨
* =======================================================================================
* �������� (new QuestionRecommendRule('��������'))->rule()->getUids();
* =======================================================================================
 * 
* @author WR.dong <firstbloods@findlaw.cn>
*/
namespace Tools;
/**
 * 2��3��4��ʦ�Ƽ��㷨
 *
 * @author lihuanlin <lihuanlin@lawjob.cn>
 */
class QuestionRecommendRule
{
    private $provcode = "11";    //ʡ
    private $citycode = "01";    //��
    private $areacode = "00";    //���� 
    //private $maxActiveLawyer = 4;   //��Ծ��ʦ�Ƽ���
    private $maxLawyer = 5;           //�Ƽ���
    //private $maxNovipLawyer = 2;    //���Ƽ���ʦ��
    private $sid       = 0;         //ר��
    private $uids      = array();     //�Ѿ��Ƽ�����ʦ
    //private $novipuids = array();   //���Ƽ���ʦ
    private $ruleoutUids   = array(); //��Ҫ���ų���uid�������Ѿ�����鵽���Ƽ���ʦuid
    private $ResiduerNum = array();   //
    private $debug     = false;
    //private $maxActiveLimit = 10;   //��Ծ��ʦÿ���������������
    //private $limit = array();
    //��ʦȨ����������
    private $levelConf = array(
            'a' => array(0, 30),
            'b' => array(31, 50),
            'c' => array(51, 9999),
            );
    //����������Ȩ��
    private $levelWeightConf = array('a' => 1, 'b' => 2, 'c' => 3);
    //�۰�̨��ѯ�Ƽ�����ָ��
    private $GAT = array(
            '440101' => 170300, //��� ָ�� ����
            '450101' => 170400, //���� ָ�� �麣
            '430101' => 150300  //̨�� ָ�� ����
            );
    /**
     * �ṹ��
     * 
     * @param int  $areacode �������
     * @param int  $sid      ר��
     * @param bool $debug    ����ģʽ
     */
    public function __construct($areacode, $sid=0, $debug=false)
    { 
        $this->areacode = $areacode;
        $this->provcode = substr($areacode, 0, 2);
        $this->citycode = substr($areacode, 0, 4);
        $this->sid      = $sid;
        $this->debug    = $debug;
    }
    
    /**
     * ��ȡ�Ѿ��Ƽ�����ʦuid
     * 
     * @return array
     */
    public function getUids()
    {
        return $this->uids;
    }
    
    /**
     * ��ȡ��Ҫ���ų���uid�������Ѿ�����鵽���Ƽ���ʦuid
     *
     * @return array
     */
    public function getRuleoutUids()
    {
        $this->ruleoutUids = array_unique(array_merge($this->ruleoutUids, $this->uids));
        return $this->ruleoutUids;
    }
    
    /**
     * �����м�areacode
     * 
     * @param int $areacode areacode
     * 
     * @return number
     */
    public function getCityAreacode($areacode)
    {
        if ($areacode >= 100000 && $areacode < 999999) {
            $cityAreacode = \Tools\Iparea::isMunicipality($this->areacode, true) ?  $this->citycode . "01" : $this->citycode . "00";
        } else {
            if (APP_DEBUG) {
                throw  new \Exception("areacode is error \n", -1);
            } else {
                return 0;
            }
        }
        return $cityAreacode;
    }
    
    /**
     * ͨ���Ƽ����򣬻�ȡ�Ƽ���ʦuid
     * 
     * @return array uids:
     */
    public function rule()
    {
        $cityAreacode = $this->getCityAreacode($this->areacode);
        if ($this->debug) {
            echo "areacode: ".$this->areacode."<br/>";
            echo "cityAreacode: ".$cityAreacode."<br/>";
        }
        $ruleoutUids = $this->getRuleoutUids();
        // ����ѯ�Ƽ�����ȡ��ʦ  ����ר���ֶ�
        // $data = \Rpc::getData('Ask.Admin.queryAskRecommendLawyerByAreacodeProf', null, null, array($this->areacode, $cityAreacode), $this->sid, 1, empty($ruleoutUids) ? null : $ruleoutUids);
        $data = \Rpc::getData('Ask.queryAskRecommendLawyerByAreacode', null, null, array($this->areacode, $cityAreacode), 1, empty($ruleoutUids) ? null : $ruleoutUids);
        //$model = new \Models\FlaskModel('ask_recommend_lawyer_weight');
        //$data = $model->getLawyerByCBcode($this->areacode, $cityAreacode, $this->getRuleoutUids());
        $this->_deal($data);
        if ($this->debug) {
            echo "<hr>cb_lawyer:<br />";
            $this->pdebug($this->uids);
        }
        if (count($this->uids) >= $this->maxLawyer) {
            return $this;
        }
        //����Ƽ��м�������ʦ
        $this->recHzLawyer($cityAreacode);        
        if (count($this->uids) >= $this->maxLawyer) {
            return $this;
        }
        //���۰�̨���������Ƽ���ʽ
        if ($this->GAT[$cityAreacode] > 0) {
            $this->recHzLawyer($this->GAT[$cityAreacode]);
        }
        return $this;
    }

    /**
     * �Ƽ�������ʦ
     * 
     * @param int $cityAreacode �м���������
     * 
     * @return void
     */
    public function recHzLawyer($cityAreacode)
    {
        //�Ƽ��м�������ʦ
        $levelWeightConf = $this->levelWeightConf;
        for ($i = 0; $i < count($this->levelWeightConf); $i++) {
            $level = $this->getRandByWeight($levelWeightConf, 1);
            //�ų��Ѿ���������
            unset($levelWeightConf[$level[0]]);
            list($weightStart, $weightEnd) = $this->levelConf[$level[0]];
            $ruleoutUids = $this->getRuleoutUids();
            $data = \Rpc::getData('Ask.queryAskRecommendLawyerByAreacode', $weightStart, $weightEnd, array($cityAreacode), 0, empty($ruleoutUids) ? null : $ruleoutUids);
            $this->_deal($data);
            if ($this->debug) {
                echo "<hr>{$i} level:<br />";
                $this->pdebug($level);
                echo "hz_lawyer:<br />";
                $this->pdebug($this->uids);
            }
            if (count($this->uids) >= $this->maxLawyer) {
                break;
            }
        }
    }
    
    /**
     * ��һ����Ȩ�ص���ʦ�����У�����Ȩ�ػ�ȡ��ʦuid
     * 
     * @param array $data lawyerList
     * 
     * @return void
     */
    public function _deal($data)
    {
        $residuerNum = $this->maxLawyer - count($this->uids);
        if (count($data) > $residuerNum) {
            $weightArr = array();
            foreach ($data as $k => $v) {
                $weightConf[$v['uid']] +=  intval($v['weightTotal']);
            }
            $uids = $this->getRandByWeight($weightConf, $residuerNum);
        } else {
            $uids = array_keys($data);
        }
        foreach ($uids as $uid) {
            //��¼�Ƽ���ʦ ����ʣ���Ƽ���ѯ��            
            $this->ResiduerNum[$uid] = $data[$uid]['recommendResiduer'];
            //��¼�Ƽ���ʦ
            $this->uids[] = $uid;
        }
    } 
    
    /**
     * ����Ȩ��ȡ����
     * 
     * @param array $weightConf Ȩ����������k-v (eg: uid-weight) 
     * @param int   $num        ȡ�ĸ���
     * 
     * @return uids
     */
    public function getRandByWeight($weightConf = array(), $num = 1)
    {
        if (empty($weightConf) || $num <= 0) {
            return array();
        }
        $weightSum = array_sum($weightConf);
        $rand_num = mt_rand(1, $weightSum);
        foreach ($weightConf as $k => $v) {
            $weightSum = $weightSum - $v;
            if ($rand_num > $weightSum) {
                unset($weightConf[$k]);
                if ($weightConf && $num > 1) {
                    //��Ŀ��������ȡ
                    return  array_merge(array($k), $this->getRandByWeight($weightConf, $num - 1));
                } else {
                    return array($k);
                }
            }
        }
        return array();
    }
    /**
     * ������һ�汾�������
     * 
     * @return array recommend lawyer uids
     */
    public function deal()
    {
        return $this->rule()->getUids();
    }
    /**
     * ��ȡ��Ծ�û�
     * 
     * @return void
     */
    /*
    public function getActiveLawyer()
    {
        //��ȡ��Ծ��ʦ��¼
        $lawyerids = \Rpc::getData("Ask.queryRecommendActiveAllUid");
        $persize = 200;
        $countnum = ceil(count($lawyerids)/$persize);
        $lawyerData = array();
        for ($i=1; $i<=$countnum; $i++) {
            $start = substr($this->areacode, 0, 4);
            $para = array(
                    "areacodeBegin" => $start."00",
                    "areacodeEnd" => $start."99",
            );
            $tmplawyerids =array_slice($lawyerids, ($i-1)*$persize, $persize);
            $para['uids'] = array_values($tmplawyerids);
            $para['time'] = time();
            $para['isvalid'] = 1;
            $para['orderBy'] = "areacode asc";
            $rs = \Rpc::getData("Ask.queryAskRecommendRuleByForm", $para);
            $lawyerData = array_merge($lawyerData, $rs); 
        }
        if ($lawyerData) {
            if ($this->debug) {
                //print_r($lawyerData);
            }
            $uids =  $this->getFieldInList($lawyerData, 'uid');
            if (!$uids) {
                return array();
            }
            $this->limit = \Rpc::getData("Ask.queryAskRecommendLimitInfo", $uids, date("Ymd"));
            foreach ($lawyerData as $k=>$v) {
                $areacode = intval(substr($v['areacode'], 0, 2));
                if ($v['lawyerSort']) {
                    $lawyerData[$k]['lawyerSort'] = explode(',', $v['lawyerSort']);
                }
                $lawyerData[$k]['rateArea'] = 100;
            }
            $realData = $this->dealLawyerDataBySid($lawyerData);
            $this->handLawyerData($realData['sidData'], true);
            $this->handLawyerData($realData['nosidData'], true);
        }
        if ($this->debug) {
            echo '��Ծ��ʦ��';
            print_r($this->uids);
        }
    }
    */
    /**
     * ��ȡ���Ƽ���ʦ
     * 
     * @return  void
     */
    /*
    public function getNovipLawyer()
    {
        $olduids = $this->uids;
        $start = substr($this->areacode, 0, 2);
        $para = array(
                "areacodeBegin" => $start."0000",
                "areacodeEnd" => $start."9999",
        );
        $lawyerData = \Rpc::getData("Ask.queryAskRecommendNovipOnlineByForm", $para);
        if ($lawyerData) {
            $uids =  $this->getFieldInList($lawyerData, 'uid');
            if (!$uids) {
                return array();
            }
            //�ж��Ƿ�����
            $onlinelawyers = \Rpc::getUCData('Member.queryOnlineByUidsMap', $uids);
            $onlineuids = array();
            if ($onlinelawyers) {
                foreach ($onlinelawyers as $k=>$v) {
                    if ($v['pcstate'] || $v['androidstate'] || $v['iphonestate']) {
                        $onlineuids[] = $k;
                    }
                }
            }
            if ($this->debug) {
                echo '<br>������ʦID��';
                print_r($onlineuids);
            }
            if (!$onlineuids) {
                return array();
            }
            $starday=date("Ymd", strtotime("last Sunday +1 day"));  
            $endday=date("Ymd", strtotime("next Sunday")); 
            //��ѯÿ�ܷ�������
            $this->limit = \Rpc::getData("Ask.queryAskLimitSeveralDaysInfo", $onlineuids, $starday, $endday);
            if ($this->debug) {
                echo '<br>�������ޣ�';
                print_r($this->limit);
            }
            foreach ($lawyerData as $k=>$v) {
                if (!in_array($v['uid'], $onlineuids)) { //������������
                    unset($lawyerData[$k]);
                    continue;
                }
                $areacode = intval(substr($v['areacode'], 0, 2));
                $prov = $rateData[$areacode];
                if ($v['lawyerSort']) {
                    $lawyerData[$k]['lawyerSort'] = explode(',', $v['lawyerSort']);
                }
                $lawyerData[$k]['maxDay'] = 2; //�˴�Ϊÿ��������������
                $lawyerData[$k]['rateArea'] = 100;
            }
            $lawyerData = array_values($lawyerData);
            $realData = $this->dealLawyerDataBySid($lawyerData);
            $this->handLawyerData($realData['sidData'], false, true);
            $this->handLawyerData($realData['nosidData'], false, true);
            $this->novipuids = array_diff($this->uids, $olduids);
            if ($this->debug) {
                echo '���Ƽ���ʦ��';
                print_r($this->novipuids);
            }
        }
    }
    */
    /**
     * ���ݴ�����ʽ
     *
     * @param string $type ����
     *
     * @return void
     */
    /*
    public function deal($type="area")
    {
        $lawyerData = $this->getLawersByAreaCode("prov");
        $lawyerData = $this->dealLawyerData($lawyerData);
        if ($lawyerData) {
            foreach ($lawyerData as &$ld) {
                $ld['maxDay'] = 1;//���Ʒǻ�Ծ��ʦÿ���������
            }
        }
        if (in_array($this->provcode, array('43', '44', '45'))) {
            return $this->dealGAT($lawyerData);
        }
        //��ȡ��Ծ�Ƽ���ʦ
        $this->getActiveLawyer();
        
        $uids =  $this->getFieldInList($lawyerData, 'uid');
        if (!$uids) {
            return array();
        }
        $this->limit = \Rpc::getData("Ask.queryAskRecommendLimitInfo", $uids, date("Ymd"));
        $realData = $this->dealLawyerDataBySid($lawyerData);
        $this->handLawyerData($realData['sidData']);
        $this->handLawyerData($realData['nosidData']);
        if (!in_array(67, $this->uids)) {
            //$this->uids[] = 67;
        }
        if ($this->debug) {
            echo '�Ƽ���ʦ��';
            dump($this->uids);
        }
        //��ȡ���߷��Ƽ���ʦ
        // ��ƷҪ�� ��ʱ���Ƽ� ��vip ��ʦ
        //$this->getNovipLawyer();
        
        
        if ($this->debug) {
            echo '<br>������ʦ��';
            dump($this->uids);
        }
        //$this->uids=array(67,30715566,30830345,16453075);
        return $this->uids;
    }
    */
    /**
     * ������ʦ���� �����е�ʡ
     * 
     * @param array $lawyerData ��ʦ����
     * @param bool  $isactive   �Ƿ��Ծ��ʦ Ĭ��false
     * @param bool  $isnovip    �Ƿ��Ƿ��Ƽ���ʦ Ĭ��false
     * 
     * @return void
     */
    /*
    public function handLawyerData($lawyerData, $isactive=false, $isnovip=false)
    {
        if ($isactive) {
            $tmplimit = false;
            $tmpMaxLawyer = $this->maxActiveLawyer;
        } else {
            $tmplimit = true;
            if ($isnovip) {
                $tmpMaxLawyer = $this->maxLawyer + $this->maxNovipLawyer;
            } else {
                $tmpMaxLawyer = $this->maxLawyer;
            }
        }
        if (count($this->uids) < $tmpMaxLawyer) {
            $lawyerData  = $this->formateLawersData($lawyerData);
            $areaData = $lawyerData[$this->provcode."0000"][$this->citycode."00"][$this->areacode];

            $this->dealData($areaData, 'area', $tmplimit, $isactive, $isnovip);
            if (count($this->uids) < $tmpMaxLawyer) {
                $cityData = $lawyerData[$this->provcode."0000"][$this->citycode."00"];
                $this->dealData($cityData, 'city', $tmplimit, $isactive, $isnovip);
            }
        }
    }
    */
    
    /**
     * ������ʦ���� ����ר��ID��Ϊר����ʦ�ͷ�ר����ʦ
     * 
     * @param array $lawyerData ��ʦ����
     * @param int $sid ר��ID
     * 
     * @return void
     */
    /*
    public function dealLawyerDataBySid($lawyerData, $sid)
    {
        if (!$sid) {
            $sid = $this->sid;
        }
        $sidData = array();
        $nosidData = array();
        if ($lawyerData) {
            foreach ($lawyerData as $ld) {
                if ($sid==$ld['sid2'] || ($ld['lawyerSort'] && in_array($sid, $ld['lawyerSort']))) {
                    $sidData[] = $ld;
                } else {
                    $nosidData[] = $ld;
                }
            }
        }
        return array('sidData'=>$sidData, 'nosidData'=>$nosidData);
    }
    */
    /**
     * ������ʦ����
     *
     * @param array $lawyerData ��ʦ����
     *
     * @return void
     */
    /*
    protected function dealLawyerData($lawyerData)
    {
        $rateData = array();
        $data = \Rpc::getData(array("Ask.queryAskRecommendAreaByForm", array("H-FT"=>3600)), null);
        foreach ($data as $data) {
            $prov = substr($data['areacode'], 0, 2);
            $rateData[$prov][] = $data;
        }
        foreach ($lawyerData as $k=>$v) {
            $areacode = intval(substr($v['areacode'], 0, 2));
            $prov = $rateData[$areacode];
            if ($v['lawyerSort']) {
                $lawyerData[$k]['lawyerSort'] = explode(',', $v['lawyerSort']);
            }
            if ($prov) {
                foreach ($prov as $prov) {
                    if ($v['money'] >= $prov['moneyStart'] && $v['money'] <= $prov['moneyEnd'] ) {
                        $lawyerData[$k]['maxDay'] = $prov['recommendMax'];
                        $lawyerData[$k]['rateArea'] = $prov['recommendRate'];
                        break;
                    }
                }
            } else {
                $lawyerData[$k]['maxDay'] = 0;
                $lawyerData[$k]['rateArea'] = 0;
            }
        }
    
        return $lawyerData;
    }
    */
    /**
     * ��ȡ��ʦ�����޺��Ƽ�ϵ��
     *
     * @param array $areacode ����
     * @param array $money    �������
     *
     * @return array
     *
     */
    protected function getLawyerRateAndLimit($areacode, $money)
    {
        static $rateData;
        $areacode = substr($areacode, 0, 2);
        if (!$rateData) {
            $data = \Rpc::getData(array("Ask.queryAskRecommendAreaByForm", array("H-FT"=>3600)), null);
            foreach ($data as $data) {
                $prov = substr($data['areacode'], 0, 2);
                $rateData[$prov][] = $data;
            }
        }
    
        $rate = $rateData[$areacode];
        if ($rate) {
            foreach ($rate as $rate) {
                if ($money >= $rate['moneyStart'] && $money <= $rate['moneyEnd'] ) {
                    return array('rate'=>$rate['recommendRate'], 'limit'=>$rate['recommendMax']);
                }
            }
        }
        return array('rate'=>0, 'limit'=>0);
    }
    
    /**
     * ��������
     *
     * @param array  $data     ��ʦ����
     * @param string $type     ���ͣ���ѡֵ,area,prov,city
     * @param bool   $limit    �Ƿ�������޴���
     * @param bool   $isactive �Ƿ��Ծ��ʦ
     * @param bool   $isnovip  �Ƿ��Ƿ��Ƽ���ʦ
     *
     * @return array
     */
    /*
    protected function dealData($data, $type='area', $limit=true, $isactive=false, $isnovip=false)
    {
        if ($type === "prov") {
            $rs = array();
            foreach ($data as $prov) {
                foreach ($prov as $city) {
                    foreach ($city as $area) {
                        $rs[] = $area;
                    }
                }
            }
            $data = $rs;
            unset($rs);
        } else if ($type === "city") {
            $rs = array();
            foreach ($data as $city) {
                foreach ($city as $area) {
                    $rs[] = $area;
                }
            }
            $data = $rs;
            unset($rs);
        }
    
        if ($isactive) {
            $tmpMaxLawyer = $this->maxActiveLawyer;
        } else {
            if ($isnovip) {
                $tmpMaxLawyer = $this->maxLawyer + $this->maxNovipLawyer;
            } else {
                $tmpMaxLawyer = $this->maxLawyer;
            }
        }
        if ($this->debug) {
            echo $type." - ";
            echo count($data)." - ";
        }
        if ($data) {
            $data = $this->countLawyerData($data);
            if ($limit) {
                if ($this->ruleoutUids) {   //���ų��Ѿ�������������uid
                    foreach ($this->ruleoutUids as $uid) {
                        unset($data[$uid]);
                    }
                }
            } else {
                if ($this->uids) {   //���ų��Ѿ�������������uid
                    foreach ($this->uids as $uid) {
                        unset($data[$uid]);
                    }
                }
            }
            $uids = array_keys($data);
            if ($uids) {
                if ($isactive && $this->maxActiveLimit) { //��Ի�Ծ��ʦ��������
                    foreach ($data as $k=>$one) {
                        $limit = $this->limit[$k] ? $this->limit[$k] : 0;
                        if ($this->maxActiveLimit <= $limit) {
                            $this->ruleoutUids[] = $k;
                            unset($data[$k]);
                        }
                    }
                } else if ($limit) {//���˴ﵽ���޵��û�
                    foreach ($uids as $uid) {
                        //$this->limit[$uid] = 4; //ģ����������
                    }
                    foreach ($data as $k=>$one) {
                        $limit = $this->limit[$k] ? $this->limit[$k] : 0;
                        if ($one['maxDay'] <= $limit) {
                            $this->ruleoutUids[] = $k;
                            unset($data[$k]);
                        }
                    }
                }
    
                if ($data) {
                    $data = $this->dealSort($data, $isactive, $isnovip);
                    $left = $tmpMaxLawyer - count($this->uids);
                    if (count($data) <= $left) {
                        foreach ($data as $k=>$v) {
                            $this->uids[] = $k;
                            $this->ruleoutUids[] = $k;
                        }
                    } else {
                        $rate = $this->formateLawyer($data);
                        for ($i = 0; $i < $left; $i++) {
                            $rid = $this->getRand($rate['rate']); //���ݸ��ʻ�ȡ����id
                            unset($rate['rate'][$rid]);
                            $this->uids[] = $rid;
                            $this->ruleoutUids[] = $rid;
                        }
                    }
                }
            }
        }
    
        if ($this->debug) {
            echo count($data)."<br/>";
        }
        unset($data);
    }
    */
    /**
     * ����ר��
     *
     * @param array $data     ����
     * @param bool  $isactive �Ƿ��Ծ��ʦ
     * @param bool  $isnovip  �Ƿ���Ƽ���ʦ
     *
     * @return void
     */
    /*
    protected function dealSort($data, $isactive=false, $isnovip=false)
    {
        $lawyer = array();
        foreach ($data as $k=>$one) {
            if ($one['sid2'] > 0 && $one['sid2'] == $this->sid) {
                $lawyer[$k] = $one;
            }
        }
        if ($isactive) {
            $tmpMaxLawyer = $this->maxActiveLawyer;
        } else {
            if ($isnovip) {
                $tmpMaxLawyer = $this->maxLawyer + $this->maxNovipLawyer;
            } else {
                $tmpMaxLawyer = $this->maxLawyer;
            }
        }
        if ($lawyer) {
            $left = $tmpMaxLawyer - count($this->uids);
            if (count($lawyer) <= $left) {
                foreach ($lawyer as $k=>$v) {
                    $this->uids[] = $k;
                    $this->ruleoutUids[] = $k;
                    unset($data[$k]);
                }
            } else {
                $rate = $this->formateLawyer($lawyer);
                for ($i = 0; $i < $left; $i++) {
                    $rid = $this->getRand($rate['rate']); //���ݸ��ʻ�ȡ����id
                    unset($rate['rate'][$rid]);
                    $this->uids[] = $rid;
                    $this->ruleoutUids[] = $rid;
                    unset($data[$rid]);
                }
            }
        }
    
        $left = $tmpMaxLawyer - count($this->uids);
        if ($left > 0) {
            $lawyer = array();
            foreach ($data as $k=>$one) {
                if ($this->sid > 0 && in_array($this->sid, $one['lawyerSort'])) {
                    $lawyer[$k] = $one;
                }
            }
    
            if ($lawyer) {
                $left = $tmpMaxLawyer - count($this->uids);
                if (count($lawyer) <= $left) {
                    foreach ($lawyer as $k=>$v) {
                        $this->uids[] = $k;
                        $this->ruleoutUids[] = $k;
                        unset($data[$k]);
                    }
                } else {
                    $rate = $this->formateLawyer($lawyer);
                    for ($i = 0; $i < $left; $i++) {
                        $rid = $this->getRand($rate['rate']); //���ݸ��ʻ�ȡ����id
                        unset($rate['rate'][$rid]);
                        $this->uids[] = $rid;
                        $this->ruleoutUids[] = $rid;
                        unset($data[$rid]);
                    }
                }
            }
        }
        return $data;
    }
    */
    /**
     * ����ʦ�����ظ������ۼ�
     *
     * @param array $data ��ʦ����
     *
     * @return array
     */
    /*
    protected function countLawyerData($data)
    {
        $uids = array();
        $rs = array();
        foreach ($data as $data) {
            $uid = $data['uid'];
            if (in_array($uid, $uids)) {
                $rs[$uid]['maxDay'] += $data['maxDay'];
                $rs[$uid]['rateResource'] += $data['rateResource'];
                $rs[$uid]['rateArea'] += $data['rateArea'];
                $rs[$uid]['rateDiy']  += $data['rateDiy'];
                $rs[$uid]['adddata']  += 1;
            } else {
                $uids[] = $uid;
                $rs[$uid] = $data;
            }
        }
        return $rs;
    }
    */
    /**
     * �۰�̨���ݴ���
     *
     * @param array $data ��ʦ����
     *
     * @return void
     */
    protected function dealGAT($data)
    {
        if (count($data) <= $this->maxLawyer) {
            foreach ($data as $data) {
                $this->uids[] = $data['uid'];
            }
        } else {
            $rate = $this->formateLawyer($data);
            for ($i = 0; $i < $this->maxLawyer; $i++) {
                $rid = $this->getRand($rate['rate']); //���ݸ��ʻ�ȡ����id
                unset($rate['rate'][$rid]);
                $this->uids[] = $rid;
            }
        }
        if (count($this->uids) < $this->maxLawyer) {
            $left = $this->maxLawyer - count($this->uids);
            if ($this->provcode == "43") { //̨��
                $areacode = "15000";        //ָ�򸣽�
            } else if ($this->provcode == "44") { //���
                $areacode = "170000";         //ָ��㶫
                $citycode = array('170300');  //����
            } else if ($this->provcode == "45") { //����
                $areacode = "170000";           //ָ��㶫
                $citycode = array('170400');    //�麣
            }
            $lawyerData = $this->getLawersByAreaCode("prov", $areacode);
            if ($citycode) {
                $rs = array();
                $lawyerData = $this->formateLawersData($lawyerData);
                foreach ($citycode as $citycode) {
                    $city = $lawyerData[$areacode][$citycode];
                    if ($city) {
                        foreach ($city as $city) {
                            $rs = array_merge($rs, $city);
                        }
                    }
                }
                $lawyerData = $rs;
            }
    
            $rate = $this->formateLawyer($lawyerData);
            for ($i = 0; $i < $left; $i++) {
                $rid = $this->getRand($rate['rate']); //���ݸ��ʻ�ȡ����id
                unset($rate['rate'][$rid]);
                $this->uids[] = $rid;
            }
        }
    
        return $this->uids;
    }
    
    /**
     * ��ʽ���Ƽ���ʦ����
     *
     * @param array $rs ��ʦ����
     *
     * @return array
     */
    protected function formateLawersData($rs)
    {
        $lawyer = array();
        foreach ($rs as $rs) {
            $prov = substr($rs['areacode'], 0, 2)."0000";
            $city = substr($rs['areacode'], 0, 4)."00";
            $area = $rs['areacode'];
            $lawyer[$prov][$city][$area][] = $rs;
        }
        return $lawyer;
    }
    
    /**
     * �������ʦ���
     *
     * @param int    $qid    ����ɣ�
     * @param array  $uids   ��ʦ�գɣļ���
     * @param string $issend 0��δ���ͣ�1���ѷ��ͣ�2�ǲ�����
     *
     * @return unknown
     */
    public function insert($qid, $uids, $issend=0)
    {
        $isviparr = array();
        foreach ($uids as $uid) {
            $isviparr[] = 1;
        }
        \Rpc::getData('Ask.Admin.insertAskQuestionRecommend', $qid, $uids, time(), $issend, $isviparr);
        return true;
    }
    
    /**
     * ���½���ʣ���Ƽ���ѯ��
     * ��Ӧ����ʦ ����ʣ���Ƽ���ѯ�� -1 
     * 
     * @param array $uids         �Ƽ��ɹ�����ʦuid
     * @param int   $residuerFlag �޸��Ƽ���ѯʣ������־ 0:�Ǽ�1, 1:�Ǽ�1
     *
     * @return void
     */
    public function updateResiduerNum($uids, $residuerFlag = 0)
    {
        if (count($uids) > 0) {
            \Rpc::getResponse('Ask.Admin.updateRecommendResiduerByUids', $uids, $residuerFlag);
        }        
    }
    
    /**
     * ������Ϣ
     *
     * @param int    $qid     ����ɣ�
     * @param array  $uids    ��ʦ�գɣļ���
     * @param int    $ids     �����ɣļ���
     * @param string $title   ��Ϣ����
     * @param string $content ��Ϣ����
     *
     * @return unknown
     */
    public function pushMessage($qid, $uids, $ids, $title="", $content="")
    {
        //����PC����Ϣ����
        $title = $title ? $title : '���յ�һ���µļӼ�һ��һ��ѯ';
        $data = array();
        $data['projectid']  = 1;
        $data['businessid'] = 1;
        $data['msgfromUid'] = 0;
        $data['readflag'] = 0;
        $data['sendtime'] = time();
        $data['refid1'] = $qid;
        $data['title']  = $title;
        $data['content'] = $content ? $content : $title;

        //���Ͷ���(Ҫ�ų��Լ����ò����Ͷ��ŵ���ʦ)
        $newUids = array();
        foreach ($uids as $val) {
            if (\Rpc::getData('Sms.getSmsControlFlag', $val, 3)) {
                $newUids[] = $val;
            } else {
                \Rpc::getData("Ask.Admin.updateAskQuestionRecommend", array('id'=>$ids[$uid], 'issend'=>2));
            }
        }


        $lawInfo = $this->getLawyers($newUids);

        try { //������Ϣ
            $rs_smsSend = array(); //�������ͽ��            
            foreach ($newUids as $kk => $uid) {
                $data['msgtoUid'] = $uid;
                $lawyer = $lawInfo[$uid];
                // $id = \Rpc::getUCData('Pms.admin.insertMessageSel', $data); // �ɵ���Ϣ��ʽ
                
                $time = intval(date("G"));
                if (!in_array($time, array(8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21))) {
                    continue;
                }
                //����ʦ�����ֻ��ţ����Ͷ�������
                if ($lawyer && $lawyer['phone']) {
                    $token = base64_encode(Encrypt::aes_crypt($uid."|1|".time(), C('TOKEN_LOGIN_KEY'), 'ENCODE'));
                    $url = "http://m.findlaw.cn/touch_front/index.php?c=askmid&a=index&qid=".$qid."&token=".urlencode($token);
                    $url = \Tools\ShortUrlSDK::get_short_url($url);
                    if ($url['url']) {
                        $tpl = $lawyer['name']."��ʦ���е���������������ѯ���ɾ������⣬������ ".$url['url']." �����ظ����ھ�Դ";
                        $rs_smsSend[$uid] = $res = \Tools\Sms::sendSms($lawyer['phone'], $tpl, 2, 'GBK', 0, 0);
                        $rs_smsSend[$uid]['mobile'] = $lawyer['phone'];
                        $rs_smsSend[$uid]['tpl'] = $tpl;
                        if ($res['status'] == 1) {//status
                            \Rpc::getData("Ask.Admin.updateAskQuestionRecommend", array('id'=>$ids[$uid], 'issend'=>1));
                        }
                    }
                }
            }
        } catch (\Exception $ex) {
            return false;
            dump($ex);
            exit;
        }
        return $rs_smsSend;
    }
    
    /**
     * ��ȡ��ʦ��Ϣ
     *
     * @param array $uids ��ʦ�ɣļ���
     *
     * @return void
     */
    public function getLawyers($uids)
    {
        if (is_array($uids) && count($uids) > 0) {
            //$lawyer = RpcCallFactory::getData("Ask.queryDayStatListBNew", array("H-N"=>"YES"), array(1, count($uids), array('uids'=>$uids)));
            //$lawyer = \Rpc::getData(array("Ask.queryDayStatListBNew", array("H-N"=>"YES")), 1, count($uids), array('uids'=>$uids));
            $lawyer = \Rpc::getUCData('Member.queryUcLawyerListByUids', $uids, 1, 1);
            $rs = array();
            foreach ($lawyer as $lawyer) {
                $uid = $lawyer['uid'];
                if ($uid > 0) {
                    $rs[$uid]['name']  = $lawyer['username'];
                    $rs[$uid]['phone'] = $lawyer['mobile'];
                    $rs[$uid]['areacode'] = $lawyer['areacode'];
                }
            }
    
            $oneline = \Rpc::getUCData("Member.queryOnlineByUidsMap", $uids);
            foreach ($oneline as $k=>$v) {
                $rs[$k]['weilv'] = $oneline[$k]['androidstate'] || $oneline[$k]['iphonestate'];
                //$rs[$k]['weixin'] = $oneline[$k]['weixinstate'];
                $rs[$k]['pc'] = $oneline[$k]['pcstate'];
            }
            return $rs;
        }
        return null;
    }
    
    /**
     * ���ݸ���ȡ����
     * 
     * @param array $goodsArr ��Ʒ��������
     * 
     * @return void
     */
    /*
    protected function getRand($goodsArr)
    {
        $result = '';
        $proSum = array_sum($goodsArr); //����������ܸ��ʾ���
        foreach ($goodsArr as $key => $proCur) { //��������ѭ��
            $randNum = mt_rand(1, $proSum);
            if ($randNum <= $proCur) {
                $result = $key;
                break;
            } else {
                $proSum -= $proCur;
            }
        }
        unset($goodsArr);
        return $result;
    }
    */
    /**
     * ��ʽ����ʦ����
     * 
     * @param array $array ��ʦ����
     * 
     * @return array
     */
    protected function formateLawyer($array)
    {
        $rs = array();
        $rate = 0;
        $user = 0;
        foreach ($array as $array) {
            $id = $array['uid'];
            $rs['lawyer'][$id] = $array;
            if ($array['rateArea'] > 0) {
                $user ++;
                $add = $array['rateResource'] + $array['rateDiy'] + $array['rateArea'];
                if ($add <= 0) {
                    $add = 0.5;
                }
                $add = $add * 10;
                $rate += $add;
                $rs['rate'][$array['uid']] = $add;
            }
        }
        
        $rs['rateTotal']= $rate;
        $rs['user'] = $user;
        return $rs;
    }
    
    /**
     * ���ݵ�����ȡ��ʦ
     *
     * @param string $type     ����
     * @param int    $areacode ����
     *
     * @return void
     */
    /*
    public function getLawersByAreaCode($type="area", $areacode="")
    {
        if (!$areacode) {
            $areacode = $this->areacode;
        }
        if ($type === "prov") {
            $start = substr($areacode, 0, 2);
            $para = array(
                    "areacodeBegin" => $start."0000",
                    "areacodeEnd" => $start."9999",
            );
        } else if ($type === "city") {
            $start = substr($areacode, 0, 4);
            $para = array(
                    "areacodeBegin" => $start."00",
                    "areacodeEnd" => $start."99",
            );
        } else if ($type === "area") {
            $para = array(
                    "areacode" => $areacode
            );
        }
        $para['time'] = time();
        $para['isvalid'] = 1;
        $para['orderBy'] = "areacode asc";
        $rs = \Rpc::getData("Ask.queryAskRecommendRuleByForm", $para);
        if ($type === "prov") {
            return $rs;
        }
        if (count($rs) < $this->maxLawyer) {
            if ($type === "area") {
                return $this->getLawersByAreaCode("city");
            } else if ($type === "city") {
                return $this->getLawersByAreaCode("prov");
            } else {
                return $this->getLawersByAreaCode("all");
            }
        } else {
            return $rs;
        }
    }
    */
    
    /**
     * �����ݼ����У���ȡĳ���ֶεļ���
     *
     * @param array  $data  ���ݼ���
     * @param string $field �ֶ���
     *
     * @return void
     */
    protected function getFieldInList($data, $field="uid")
    {
        $rs = array();
        foreach ($data as $k=>$v) {
            $rs[] = $v[$field];
        }
    
        return array_values(array_unique($rs));
    }
    
    /**
     * �����ݼ��ϵļ�ֵ��ɼ����е�ĳ���ֶ�
     *
     * @param array  $data  ����
     * @param string $field �ֶ�
     *
     * @return type
     */
    protected function setDataAsKey($data, $field='id')
    {
        $rs = array();
        foreach ($data as $k=>$v) {
            $key = $v[$field];
            $rs[$key] = $v;
        }
    
        return $rs;
    }
    

    /**
     * ���Դ�ӡ
     *
     * @param mixed $data   ��ӡ����
     * @param bool  $isExit �Ƿ��������
     *
     * @return null
     */
    public function pdebug($data, $isExit = false)
    {
        echo '<div class="debug"><pre>';
        print_r($data);
        echo '</pre><div>';
        if ($isExit) {
            exit;
        }
    }

    /**
     * ��¼��־(��ʱѰ���������־)
     *
     * @param string $str д������
     *
     * @return array
     */
    public function log_sms($str)
    {
        //��¼������־
        //$serverip = $_SERVER['SERVER_ADDR'];//������ip
        //$serverdomain = $_SERVER['SERVER_NAME'];//������������
        //$errorUrl = $_SERVER['REQUEST_URI'];//�����Url
        //$time = date('Y-m-d H:i:s');//����ʱ��
        //$str = $serverip."---".$serverdomain."---".$errorUrl."---".$time."\r\n";
        //$dir = dirname(__FILE__)."/../../../../../weblogs/php_logs/";
        $dir = "/opt/weblogs/php_logs/";
        $file = $dir."sms";
        if (!file_exists($file)) {
            @mkdir($file);
        }
        $logDir = $file."/".date("Ymd").".log";
        $tp = @fopen($logDir, "a+");
        if ($tp) {
            @fwrite($tp, $str);
            @fclose($tp);
        }
    }
    
    /**
     *  ����������Ϣ 2016-9-26 mxj add
     *
     * @param int    $qid     ����ɣ�
     * @param array  $uids    ��ʦ�գɣļ���
     * @param int    $ids     �����ɣ�
     * @param string $title   ��Ϣ����
     * @param string $content ��Ϣ����
     *
     * @return unknown
     */
    public function adDpushMessage($qid, $uids, $ids, $title="", $content="")
    {
        //����PC����Ϣ����
        $title = $title ? $title : '���յ�һ���µļӼ�һ��һ��ѯ';
        $data = array();
        $data['projectid']  = 1;
        $data['businessid'] = 1;
        $data['msgfromUid'] = 0;
        $data['readflag'] = 0;
        $data['sendtime'] = time();
        $data['refid1'] = $qid;
        $data['title']  = $title;
        $data['content'] = $content ? $content : $title;

        //���Ͷ���(Ҫ�ų��Լ����ò����Ͷ��ŵ���ʦ)
        $newUids = array();
        foreach ($uids as $val) {
            if (\Rpc::getData('Sms.getSmsControlFlag', $val, 3)) {
                $newUids[] = $val;
            } else {
                \Rpc::getData("Ask.Admin.updateAskQuestionRecommend", array('id'=>$ids[$uid], 'issend'=>2));
            }
        }
        $lawInfo = $this->getLawyers($newUids);
        try { //������Ϣ
            $rs_smsSend = array(); //�������ͽ��            
            foreach ($newUids as $kk => $uid) {
                $data['msgtoUid'] = $uid;
                $lawyer = $lawInfo[$uid];
                // $id = \Rpc::getUCData('Pms.admin.insertMessageSel', $data); // �ɵ���Ϣ����
                
                $time = intval(date("G"));
                if (!in_array($time, array(8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21))) {
                    continue;
                }
                //����ʦ�����ֻ��ţ����Ͷ�������
                if ($lawyer && $lawyer['phone']) {
                    $token = base64_encode(Encrypt::aes_crypt($uid."|1|".time(), C('TOKEN_LOGIN_KEY'), 'ENCODE'));
                    $url = "http://m.findlaw.cn/touch_front/index.php?c=askmid&a=index&qid=".$qid."&token=".urlencode($token);
                    $url = \Tools\ShortUrlSDK::get_short_url($url);
                    if ($url['url']) {
                        $tpl = $lawyer['name']."��ʦ���е���������������ѯ���ɾ������⣬������ ".$url['url']." �����ظ����ھ�Դ";
                        $rs_smsSend = \Tools\Sms::sendSms($lawyer['phone'], $tpl, 2, 'GBK', 0, 0);
                        if ($rs_smsSend['status'] == 1) {//status
                            \Rpc::getData("Ask.Admin.updateAskQuestionRecommend", array('id'=>$ids[$uid], 'issend'=>1));
                        }
                    }
                }
            }
        } catch (\Exception $ex) {
            return false;
        }
        return $rs_smsSend;
    }

}

