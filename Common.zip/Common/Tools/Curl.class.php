<?php
/**
 *  curl������
 *
 *  @author zsg <xxx@qq.com>
 *
 */
/**
 *  curl������
 *
 *  @author zsg <xxx@qq.com>
 */
namespace Tools;
class Curl
{    
    // ���ߺ��� //
    /* ʹ��curl��postһ��json���� */
    // CURLOPT_SSL_VERIFYPEER,CURLOPT_SSL_VERIFYHOST - ����https��Ҫ�õ�
    // CURLOPT_RETURNTRANSFER - �����ļ������أ���1
    public static function jsonPost($url, $jsonDataString){
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $jsonDataString);
        curl_setopt($curl, CURLOPT_TIMEOUT, 30);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $result = \Tools\Error::curl_exec($curl);
        if (curl_errno($curl)) {
            return array(-1, 'curl falied. Error Info: '.curl_error($curl));
        }
        curl_close($curl);
        return array(0, $result);
    }
    
    /**
     * ����file_get_contents
     *
     * @param string $strUrl ��̬����������file_get_contents
     *
     * @return void
     */    
    public static function url_get_contents($strUrl)
    {
        $ch = curl_init($strUrl);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPGET, true);
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($ch, CURLOPT_REFERER, $_SERVER['HTTP_REFERER']);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
        $response = \Tools\Error::curl_exec($ch);
        if (curl_errno($ch) != 0) {
            return false;
        }
        curl_close($ch);
        return $response;
    }
    
    
    /**
     * ����ip����url
     *
     * @param unknown $url url
     * @param unknown $ip  ip
     *
     * @return mixed
     */
    public static function proxy_request($url, $ip)
    {
        $ch = curl_init();
        $tmp_user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        curl_setopt($ch, CURLOPT_URL, "$url");
        curl_setopt($ch, CURLOPT_USERAGENT, $tmp_user_agent);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_PROXY, "$ip:80");
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        //curl_setopt($ch, CURLOPT_POST, 1);
        //curl_setopt($ch, CURLOPT_POSTFIELDS, $sendData);
        $data = \Tools\Error::curl_exec($ch);
        curl_close($ch);
        return $data;
    }
    
    /**
     * ����ip post����url
     *
     * @param unknown $url      url
     * @param unknown $ip       ip
     * @param unknown $postdata postdata
     *
     * @return mixed
     */
    public static function proxy_post($url, $ip, $postdata)
    {
        $ch = curl_init();
        $tmp_user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        curl_setopt($ch, CURLOPT_URL, "$url");
        curl_setopt($ch, CURLOPT_USERAGENT, $tmp_user_agent);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        if ($ip != '') {
            curl_setopt($ch, CURLOPT_PROXY, "$ip:80");
        }
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        $data = \Tools\Error::curl_exec($ch);
        curl_close($ch);
        return $data;
    }
    
    /**
     * ͨ��wyCurl������� crul - GET ����
     * 
     * @param stirng $url     url
     * @param array  $ipArray ��ȷ���Թ�ѡ��� ip
     * @param int    $timeout ��ʱʱ��(��)
     *
     * @return data
     */
    public static function apc_get($url, $ipArray = array(), $timeout = 5)
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPGET, true);
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($ch, CURLOPT_REFERER, $_SERVER['HTTP_REFERER']);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
        return self::apc_exec($ch, $ipArray, $timeout);
    }
    /**
     * ͨ��wyCurl������� crul - POST ����
     *
     * @param stirng $url     url
     * @param array  $ipArray ��ȷ���Թ�ѡ��� ip
     * @param int    $timeout ��ʱʱ��(��)
     *
     * @return data
     */
    public static function apc_post($url, $postdata = array(), $ipArray = array(), $timeout = 5) {
        $ch = curl_init();
        $tmp_user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        curl_setopt($ch, CURLOPT_URL, "$url");
        curl_setopt($ch, CURLOPT_USERAGENT, $tmp_user_agent);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        return self::apc_exec($ch, $ipArray, $timeout);

    }
    
    /**
     * ���� pc ģ��ġ�curl ����
     * 
     * @param obj   $ch      curlʵ��
     * @param array $ipArray ������ip���ѷ�����
     * @param int   $timeout ��ʱʱ��
     * 
     * @return data
     */
    public static function apc_exec($ch, $ipArray = array(), $timeout = 5)
    {
        //����ʱ�� 300��
        $locktime = 300;
        try {
            return \Tools\Curl\CurlHelper::exec($ch, $timeout, $locktime);
        } catch (\Exception $e) {
            if (APP_DEBUG) {
                //���Ի����������Ϣ
                echo $e->getMessage();
            }
        }
        return false;
    }
}
