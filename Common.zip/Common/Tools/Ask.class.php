<?php
/**
 *  ������ѯ������
 *
 *  @author zsg <xxx@qq.com>
 *
 */
namespace Tools;
use Tools;
/**
 *  ������ѯ������
 *
 *  @author zsg <xxx@qq.com>
 */
class Ask
{
    /**
     * ר��ƥ�䷽��
     *
     * @param str $title title
     *
     * @return array
     */
    public static function matchAskSort($title)
    {
        $re = array('sid1' => 0, 'sid2'=>0, 'grade' => 1, 'method'=>'match faied!');

        // �����½ӿڻ�ȡר��
        require_once 'include/thrift_rpc/Rpc/Client.class.php';
        rpc_load_module('Keyword');
        $rpc = new \KeywordModule();
        $response = $rpc->getProf($title);  
        $prof = array();
        if ($response->isSuccess()) {
            $prof = $response->getData();
            $prof_data = \Rpc::getData('Ask.querySortNameBySids', array($prof['sid']));
            $re = $prof_data[0];
            $re['sid2'] = $re['sid2'] ? $re['sid2'] : $re['sid'];
            return $re;
        }
    
        //��ask_key�ִ�
        $words = trim(\Tools\Split::splitWord($title, 'ask_keys'));
        if ($words=='') {
            $words = $title;
        }
        $re['words'] = $words;
        $words = explode(' ', $words);
        /*
        //�ý�ͷִ� ---��δ���� --- 2015-7-6
        $words = \Rpc::getShortlinkData('Keywords.queryKerKeyWords', $title, 2);
        if (empty($words)) {
            $words = $title;
        }
        */
        $maxlenTwoArr = \Tools\Arr::maxlenTwo($words);
        $maxlenTwo = implode(' ', $maxlenTwoArr);
    
        //�ж����������Ƿ�Ϊר��
        $sortList = array();
        $sortList = \Rpc::getData('Ask.queryListAskSortByArr', array('arr'=>$maxlenTwoArr));  // �ɵĽӿ�

        if (!empty($sortList)) {
            $sort2_info = array();
            $sort1_info = array();
            foreach ($sortList as $k=>$v) {
                if (in_array($v['sort2'], $maxlenTwoArr)) {
                    $sort2_info = $v;
                    break;
                }
                if ($v['sort2']=='' && in_array($v['sort1'], $maxlenTwoArr)) {
                    $sort1_info = $v;
                }
            }
    
            $sortrow = empty($sort2_info) ? $sort1_info : $sort2_info;
            //print_r($sortrow);
            if (trim($sortrow['sort2'])!='') {
                $re = array_merge($re, array('sid1' => $sortrow['sid1'],'sid2' => $sortrow['sid'],'grade' => 2));
            } else {
                $re = array_merge($re, array('sid1' => $sortrow['sid'], 'grade' => 1));
            }
            $re['method'] = 'split';
            $re['maxlenTwo'] = $maxlenTwo;
        } else {
            //ȥ������ѯ����         
            $url = "http://s.findlaw.cn/?m=Api&a=matchAskSort&keyname=" . urlencode($maxlenTwo);
            $response = file_get_contents($url);
            $response = json_decode($response);
            $sid2 = intval($response->sid2);
            /*
            if ($sid2<=0) {
                $url = "http://s.findlaw.cn/?m=Api&a=matchAskSort&keyname=" . urlencode($title);
                $response = file_get_contents($url);
                $response = json_decode($response);
                $sid2 = intval($response->sid2);
            }*/
            if ($sid2>0) {
                $askSortId = $sid2;
                $sorttools = FileDataQuery::import('sort');
                $sortrow   = $sorttools->getSortBySID($askSortId);
                if (isset($sortrow['sort2'])) {
                    $re = array_merge($re, array('sid1' => $sortrow['sort1']['sid'],'sid2' => $askSortId,'grade' => 2));
                } else {
                    $re = array_merge($re, array('sid1' => $askSortId, 'grade' => 1));
                }
                $re['method'] = 'search';
            } else {
                $re['method'] = 'search_sid2_not_found';
            }
            $re['sid2'] = $sid2;
            $re['maxlenTwo'] = $maxlenTwo;
        }
    
        return $re;
    }
    
    /**
     * �ж��Ƿ��������ѯ
     *
     * @param unknown $city          city
     * @param unknown $mobil         mobil
     * @param unknown $questionClass questionClass
     *
     * @return boolean
     */
    public static function isGoodAsk($city, $mobil, $questionClass)
    {
        if (in_array(substr($city, 0, 4), array('1702', '1703', '1714', '1711'))  && Validate::isMobil($mobil)) {
            if ($questionClass == 'A') {
                return true;
            }
        }
        return false;
    }
    
    /**
     * �ж���ѯ���A/B/C���ࣩ
     *
     * @param str $content ���ڷ��������ݣ����ʱ���+�������ݣ�
     *
     * @return mixed
     */
    public static function questionAbc($content)
    {
        require_once 'include/thrift_rpc/Rpc/Client.class.php';    //���ؿͻ���
        rpc_load_module('Naive');    //����ģ��
        $class = '';
        try{
            $rpc = new \NaiveModule();
            $responese = $rpc->guess_abc($content);
            //��������
            $data = $responese->GetData();
            $class = $data[0];
        } catch (Exception $e) {
            $class = 'err';
        }
        return $class;
    }

    /**
     * ��ѯ��Ѷ�б�
     *
     * @param array $useflag $useflag
     *
     * @return mixed
     */
    public static function queryAskIndexCacheInfoList($useflag)
    {
        $info = \Rpc::getData("Ask.queryAskIndexCacheInfoList", $useflag);
        return $info;
    }
    /**
     * �ж���ѯ���1,2,3,4,5,6��
     *
     * @param str $content ���ڷ��������ݣ����ʱ���+�������ݣ�
     *
     * @return mixed
     */
    public static function questionTypeId($content)
    {
        $hostname = gethostname();
        $hostnameInfo = explode('-', $hostname);
        /*if ($hostnameInfo[0] == 'co') {
            $path = dirname(__FILE__);
            $path = substr($path, 0, strlen($path)-12).'new.findlaw.cn/findlaw_global_include/';//����path 
            require_once $path.'include/thrift_rpc/Rpc/Client.class.php';
        } else {
            require_once 'include/thrift_rpc/Rpc/Client.class.php';    //���ؿͻ��� 
        }*/
        require_once 'include/thrift_rpc/Rpc/Client.class.php';    //���ؿͻ��� 
        rpc_load_module('Naive');    //����ģ��
        $class = '';
        try{
            $rpc = new \NaiveModule();
            $responese = $rpc->guess_question_class_v2($content);
            //��������
            $data = $responese->GetData();
            $class = $data;
        } catch (Exception $e) {
            $class = 'err';
        }
        return $class;
    }
    
    /**
     * ��ѯ������ѯ�Ƿ��ڹر�״̬
     * 
     * @param int $questionState $Q['question']['status']
     * 
     * @return boolean
     */
    public static function isClosed($questionState)
    {
        return in_array($questionState, array(2, 3, 4)) ? true : false;
    }
    
    
    /**
     * ȡ���������µĹ�����ѯ����
     *
     * @param int    $num      ȡ������ 
     * @param int    $areacode ��������ʡ 2 λ �� 4 λ ������ 6 λ ��0 ��ʾ�����������ң�
     * @param int    $prof     ר������ר������ (0 ��ʾ����ר������)
     * @param string $typeFlag all:ȫ��; wait:�����; resolved:�ѽ��;zero:0�ظ�;high:�߷���ѯ ����Ϊ�� 
     * @param int    $monthnum n�����ڵ�����
     * 
     * @return array
     */
    public static function queryAskQuestionMapLast($num, $areacode, $prof = 0, $typeFlag = 'all', $monthnum = 4)
    {
        $askList = array();
        for ($i = 0; $i < $monthnum ; $i++) {
            $month = date('Ym', strtotime('-' . $i . ' month'));
            $list = \Rpc::getData('Ask.queryAskQuestionMapList', 1, $num, $areacode, $prof, $month, $typeFlag);
            empty($list) && $list = array();
            $askList = array_merge($askList, $list);
            if (count($list) < $num) {
                $num = $num - count($list);
            } else {
                return $askList;
            }
        }
        return $askList;
    }


    
}
