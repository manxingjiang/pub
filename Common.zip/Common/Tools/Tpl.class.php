<?php
/**
 *  Tpl������
 *
 *  @author zsg <xxx@qq.com>
 *
 */
/**
 *  Tpl������
 *
 *  @author zsg <xxx@qq.com>
 */
namespace Tools;
use Tools;
class Tpl 
{    
    /**
     * �滻js, css, img����
     * 
     * @param string $con ԭʼ����
     * 
     * @return string
     */
    public static function replace($con)
    {
        static $obj = null;
        if ($obj == null) {
            $obj = new \Think\Template();
        }
        return $obj->_replace_content($con);
    }   
}
