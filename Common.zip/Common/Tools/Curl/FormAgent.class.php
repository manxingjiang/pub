<?php
/**
 * ����������
 * @author WY <chenjinlian@findlaw.com> 
 *
 */
namespace Tools\Curl;
use Tools\Curl\CurlHelper;
class FormAgent
{

    private $requestUrl;

    private $cookieFile = null;

    private $curlEntity = null;

    private $getList = array();

    private $postList = array();

    private $fileList = array();
    
    private $balancHostList = array();

    private $header = false;

    private $responseContent = null;

    /**
     * ���ñ���cookie���ļ�
     *
     * @param NULL $cookieFile            
     */
    public function setCookieFile ($cookieFile)
    {
        $this->cookieFile = $cookieFile;
    }

    /**
     *
     * @return the $requestUrl
     */
    public function getRequestUrl ()
    {
        return $this->requestUrl;
    }

    /**
     * @return the $balancHostList
     */
    public function getBalancHostList ()
    {
        return $this->balancHostList;
    }

    
	/**
	 * ���ø��ؾ���IP�б�
     * @param multitype: $balancHostList
     */
    public function setBalancHostList ($balancHostList)
    {
        $this->balancHostList = $balancHostList;
    }

	public function generateHeader ()
    {
        $header = array(
                'X-Apple-Tz: 0',
                'X-Apple-Store-Front: 143444,12',
                "User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:26.0) Gecko/20100101 Firefox/26.0",
                "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        );
        
        $header[] = "Cache-Control: max-age=0";
        $header[] = "Connection: keep-alive";
        $header[] = "Keep-Alive: 300";
        $header[] = "Accept-Charset: ISO-8859-1,gbk,utf-8;q=0.7,*;q=0.7";
        $header[] = "Accept-Language: en-us,en;q=0.5";
        $header[] = "Pragma: "; // browsers keep this blank.
        
        return $header;
    }

    /**
     *
     * @param field_type $requestUrl            
     */
    public function setRequestUrl ($requestUrl)
    {
        $this->requestUrl = $requestUrl;
    }

    /**
     *
     * @return the $header
     */
    public function getHeader ()
    {
        return $this->header;
    }

    /**
     *
     * @param boolean $header            
     */
    public function setHeader ($header)
    {
        $this->header = $header;
    }

    /**
     * ����GET����
     * Author: WY
     * CreateTime: 2014-2-7 ����4:03:56
     *
     * @param unknown_type $name            
     * @param unknown_type $value            
     */
    public function addGetField ($name, $value)
    {
        $this->getList[$name] = $value;
    }

    /**
     * ����POST����
     * Author: WY
     * CreateTime: 2014-2-7 ����4:02:29
     *
     * @param unknown_type $name            
     * @param unknown_type $value            
     */
    public function addPostField ($name, $value)
    {
        $this->postList[$name] = $value;
    }

    /**
     * �����ļ�
     * Author: WY
     * CreateTime: 2014-2-7 ����4:00:26
     *
     * @param �ļ������� $valName            
     * @param �ļ�·�� $fileName            
     */
    public function addFileField ($valName, $fileName)
    {
        $this->fileList[$valName] = substr(trim($fileName), 0, 1) === '@' ? $fileName : '@' +
                 trim($fileName);
    }

    /**
     *
     * @return the $postList
     */
    public function getPostList ()
    {
        return $this->postList;
    }

    /**
     *
     * @param multitype: $postList            
     */
    public function setPostList ($postList)
    {
        if ($this->postList == null) {
            $this->postList = $postList;
        } else {
            $this->postList = array_merge($this->postList, $postList);
        }
    }

    /**
     * �ļ��ϴ�
     * Author: WY
     * CreateTime: 2014-1-26 ����3:16:18
     *
     * @return mixed
     */
    public function doMultiPost ()
    {
        $this->curlEntity = curl_init();
        
        curl_setopt($this->curlEntity, CURLOPT_URL, 
                $this->_getUrlQueryString());
        
        curl_setopt($this->curlEntity, CURLOPT_RETURNTRANSFER, true); // return web page
        
        curl_setopt($this->curlEntity, CURLOPT_HEADER, false); // don't return headers
        
        curl_setopt($this->curlEntity, CURLOPT_FOLLOWLOCATION, true); // follow redirects
        
        curl_setopt($this->curlEntity, CURLOPT_POST, true);
        
        if ($this->cookieFile != null) {
            // �����ļ���ȡ���ύ��cookie·��
            curl_setopt($this->curlEntity, CURLOPT_COOKIEJAR, $this->cookieFile);
            
            curl_setopt($this->curlEntity, CURLOPT_COOKIEFILE, 
                    $this->cookieFile);
        }
        
        curl_setopt($this->curlEntity, CURLOPT_HTTPHEADER, $this->header);
        
        if ($this->postList != null) {
            $multiList = array_merge($this->postList, $this->fileList);
        } else {
            $multiList = $this->fileList;
        }
        
        curl_setopt($this->curlEntity, CURLOPT_POSTFIELDS, $multiList);
        
        // execute the API Call
        $returned_data = \Tools\Error::curl_exec($this->curlEntity);
        $this->responseContent = $returned_data;
        
        curl_close($this->curlEntity);
        
        return $returned_data;
    }

    /**
     * ��������
     * 
     * @param number $timeoutSecond
     * @param number $lockSecond
     * @param string $lockByHostOnly
     * @return Ambigous <NULL, mixed>
     */
    public function doPost($timeoutSecond=1, $lockSecond=1, $lockByHostOnly=false)
    {
        $this->curlEntity = curl_init();
        
        curl_setopt($this->curlEntity, CURLOPT_URL, 
                $this->_getUrlQueryString());
        
        curl_setopt($this->curlEntity, CURLOPT_RETURNTRANSFER, true); // return web page
        
        curl_setopt($this->curlEntity, CURLOPT_HEADER, false); // don't return headers
        
        curl_setopt($this->curlEntity, CURLOPT_FOLLOWLOCATION, true); // follow redirects
        
        curl_setopt($this->curlEntity, CURLOPT_POST, true);
        
        if ($this->cookieFile != null) {
            // �����ļ���ȡ���ύ��cookie·��
            curl_setopt($this->curlEntity, CURLOPT_COOKIEJAR, $this->cookieFile);
            
            curl_setopt($this->curlEntity, CURLOPT_COOKIEFILE, 
                    $this->cookieFile);
        }
        
        curl_setopt($this->curlEntity, CURLOPT_HTTPHEADER, $this->header);
        
        $postData = '';
        foreach ($this->postList as $k => $v) {
            $postData .= "&{$k}=" . urlencode($v);
        }
        if (strlen($postData) > 2) {
            $postData = substr($postData, 1);
        }
        
        curl_setopt($this->curlEntity, CURLOPT_POSTFIELDS, $postData);
        
        // execute the API Call
        try{
            $ipList = $this->getBalancHostList();
            if ( is_array($ipList) && count($ipList) > 0) {
                
                $returned_data = CurlHelper::execWithIP($this->curlEntity, $ipList, $timeoutSecond, $lockSecond);
            } else {
                
                $returned_data = CurlHelper::exec($this->curlEntity, $timeoutSecond, $lockSecond, false);
            }
            
        } catch(Exception $e) {
            $returned_data = null;
        }
        
        $this->responseContent = $returned_data;
        
        curl_close($this->curlEntity);
        
        return $returned_data;
    }

    /**
     * ��ȡform������action
     * Author: WY
     * CreateTime: 2014-2-7 ����5:09:18
     *
     * @return string
     */
    private function _getUrlQueryString ()
    {
        $requestUrl = $this->requestUrl;
        
        if (strpos($requestUrl, "?") == false) {
            $requestUrl .= "?";
        }
        $qstr = '';
        if (count($this->getList) > 0) {
            foreach ($this->getList as $key => $value) {
                $qstr .= "&{$key}=".urlencode($value);
            }
        }
        
        return $requestUrl . $qstr;
    }

    /**
     * ��������
     * 
     * @param number $timeoutSecond
     * @param number $lockSecond
     * @return NULL
     */
    public function doGet($timeoutSecond=1, $lockSecond)
    {
        $this->curlEntity = curl_init();

        curl_setopt($this->curlEntity, CURLOPT_URL, 
                $this->_getUrlQueryString());
        
        curl_setopt($this->curlEntity, CURLOPT_RETURNTRANSFER, true); // return web page
        
        curl_setopt($this->curlEntity, CURLOPT_BINARYTRANSFER, true); // return stream flow
        
        curl_setopt($this->curlEntity, CURLOPT_HEADER, false); // don't return headers
        
        curl_setopt($this->curlEntity, CURLOPT_FOLLOWLOCATION, true); // follow redirects
        
        if ($this->cookieFile != null) {
            // �����ļ���ȡ���ύ��cookie·��
            curl_setopt($this->curlEntity, CURLOPT_COOKIEJAR, $this->cookieFile);
            
            curl_setopt($this->curlEntity, CURLOPT_COOKIEFILE, 
                    $this->cookieFile);
        }
        
        curl_setopt($this->curlEntity, CURLOPT_HTTPHEADER, $this->header);

        // execute the API Call
        try{
            $ipList = $this->getBalancHostList();
            if (is_array($ipList)  && count($ipList) > 0) {
                $returned_data = CurlHelper::execWithIP($this->curlEntity, $ipList, $timeoutSecond, $lockSecond);
            } else {
                
                $returned_data = CurlHelper::exec($this->curlEntity, $timeoutSecond, $lockSecond, false);
            }
            
        } catch(Exception $e) {
            $returned_data = null;
        }
        
        
        curl_close($this->curlEntity);
        
        $this->responseContent = $returned_data;
        
        return $returned_data;
    }

    /**
     * ��ȡ���ص�reponse����
     * Author: WY
     * CreateTime: 2014-1-26 ����4:05:44
     *
     * @return mixed
     */
    public function getResponseContent ()
    {
        return $this->responseContent;
    }
}

?>
