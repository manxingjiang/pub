<?php
/**
 * curl����
 * 
 * @author WY <chenjinlian@findlaw.com> 
 *
 */

/**
 * curl����
 * 
 * @author WY <chenjinlian@findlaw.com> 
 *
 */
namespace Tools\Curl;
use Think\Exception;
class CurlHelper
{
    /**
     * ���ʧ�ܴ���
     * @var number
     */
    private static $maxFailCount = 50;
    
    /**
     * ������hostName,����ip������
     * @var String
     */
    private static $alarmHost = '';
    
    /**
     * ������������url
     * 
     * @param String  $url           �����url
     * @param Integer $timeoutSecond �����ĳ�ʱʱ�䣨�룩
     * 
     * @return void
     */
    public static function setLock($url, $timeoutSecond)
    {
        $key = '[LOCK]'.$url;
        
        self::saveToCache($key, 'lock', $timeoutSecond);
    }
    
    /**
     * ��������ʶ��url�Ƿ�����
     * 
     * @param String $url �����url
     * 
     * @return boolean
     */
    public static function isLocked($url)
    {
        
        $key = '[LOCK]'.$url;
        
        $value = self::getFromCache($key);
        if ($value == 'lock') {
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * �����������浽cache
     * 
     * @param String  $key           key
     * @param String  $value         value
     * @param Integer $timeoutSecond ��ʱ���룩
     * 
     * @return void
     */
    public static function saveToCache($key, $value, $timeoutSecond)
    {
        apcu_store($key, $value, $timeoutSecond);
    }
    
    /**
     * ���������ӻ���ȡ����
     * 
     * @param String $key key
     * 
     * @return mixed
     */
    public static function getFromCache($key)
    {
        return apcu_fetch($key);
    }
    
    /**
     * ����������¼ʧ��host
     * 
     * @param String $host     host
     * @param String $httpCode httpCode
     * 
     * @return boolean
     */
    public static function recordRequestFail($host, $httpCode)
    {
        //���ʧ�ܴ���ĳ����ֵ����������
        if (self::fetchRequestFailNum($host) > self::$maxFailCount) {
    
            self::setLock($host, 0);
            
            $alarmCotent = 'Fail:'.$host."\n";
            $alarmCotent .= 'HttpCode:'.$httpCode;
            $currurl = $_SERVER['HTTP_HOST'] . '?' . $_SERVER['QUERY_STRING'];
            $alarmCotent .= substr($currurl, 0, 200);
            $alarmCotent .= $_SERVER['HTTP_HOST'] . '?' . $_SERVER['QUERY_STRING'];
            //���ͱ���
            self::$alarmHost = gethostname();
            \Tools\Curl\WayouNsca::send(self::$alarmHost, 'curl_request_fail', 2, $alarmCotent);
            
            return  false;
        }
        $key = '[COUNT]'.$host;
        
        $num = apcu_fetch($key);
        if (empty($num)) {
            $num = 1;
        } else {
            $num++;
        }
        apcu_store($key, $num);

        return true;
    }
    
    /**
     * ����������ѯʧ�ܼ�¼��
     * 
     * @param unknown $host host
     * 
     * @return number
     */
    public static function fetchRequestFailNum($host)
    {
        
        $key = '[COUNT]'.$host;
        if (!apcu_exists($key)) {
            return 0 ;
        }
        $num = apcu_fetch($key);
        if ($num != null) {
            $num = intval($num);
        }
        return $num;
    }
   
    
    
    /**
     * ������������ʧ�ܼ�¼
     *
     * @param String $host host
     *
     * @return void
     */
    public static function clearRequestFailNum($host)
    {
        $key = '[COUNT]'.$host;
    
        if (apcu_exists($key)) {
            apcu_delete($key);
        }
        
        $lockKey = '[LOCK]'.$host;
        
        if (apcu_exists($lockKey)) {
            apcu_delete($lockKey);
        }
    }
    
    /**
     * ��������ִ��crul���Զ�������ʱ����
     * 
     * @param Object  &$ch            curlʵ��
     * @param number  $timeoutSecond  ��ʱʱ�䣨�룩
     * @param number  $lockSecond     ����ʱ�䣨�룩
     * @param boolean $lockByHostOnly �Ƿ�ֻͨ��host�������Σ�Ĭ��Ϊ������url����
     * 
     * @throws Exception
     * 
     * @return mixed
     */
    public static function exec(&$ch, $timeoutSecond=1, $lockSecond=1, $lockByHostOnly=false)
    {
        return self::_exec($ch, $timeoutSecond, $lockSecond, false);
    }
    
    /**
     * �����������ķ�����ִ��crul���Զ�������ʱ����
     *
     * @param Object  &$ch            curlʵ��
     * @param number  $timeoutSecond  ��ʱʱ�䣨�룩
     * @param number  $lockSecond     ����ʱ�䣨�룩
     * @param boolean $lockByHostOnly �Ƿ�ֻͨ��host�������Σ�Ĭ��Ϊ������url����
     * @param String  $dnsName        �󶨵�����
     *
     * @throws Exception
     *
     * @return mixed
     */
    private static function _exec(&$ch, $timeoutSecond=1, $lockSecond=1, $lockByHostOnly=false, $dnsName=null)
    {
    
        if (! function_exists("apcu_fetch")) {
            curl_setopt($ch, CURLOPT_TIMEOUT, $timeoutSecond);
            \Tools\Error::curl_exec($ch);
        }
        //��ȡ�����ַ
        $requestUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    
        if (empty($requestUrl)) {
            throw  new \Exception("The requestUrl \"{$requestUrl}\" is null! \n", 100);
        }
    
        $regex = "@^[httpsHTTPS]{4,5}://([^:/]+[:]?[0-9]*)[/]?.*@i";
        preg_match($regex, $requestUrl, $matches);
        if (is_array($matches) && count($matches) > 1) {
            $host = $matches[1];
        }
    
        if (empty($host)) {
            throw  new \Exception("The host is not matched! \n", 101);
        }
    
        if ($dnsName == null) {
            $dnsName = $host;
        }
    
        if ($lockByHostOnly && self::isLocked($host)) {
    
            //����Ѿ�����host���׳��쳣
            throw  new \Exception("The host \"{$host}\" has been locked! \n", 102);
    
        } else if (!$lockByHostOnly && self::isLocked($requestUrl)) {
            //����Ѿ�����url���׳��쳣
            throw  new \Exception("The requestUrl \"{$requestUrl}\" has been locked! \n", 103);
        }
        //���ó�ʱ
        //curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeoutSecond);
    
    
    
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeoutSecond);
        //��������
        $data = \Tools\Error::curl_exec($ch);
        $curl_errno = curl_errno($ch);
        $curl_error = curl_error($ch);
    
        $httpCode = curl_getinfo($ch,CURLINFO_HTTP_CODE);
    
        if ($lockByHostOnly) {
            $lockMark = $host;
        } else {
            $lockMark = $requestUrl;
        }
    
        if ($curl_errno > 0  ) {
    
            self::recordRequestFail($requestUrl, $lockMark, $dnsName, $httpCode);
            throw  new \Exception("RequestUrl:{$requestUrl};\nCURL Error ($curl_errno): $curl_error\n", $curl_errno);
    
        } else if($curl_errno == 0 && $httpCode >= 400){
            self::recordRequestFail($requestUrl, $lockMark, $dnsName, $httpCode);
            throw  new \Exception("RequestUrl:{$requestUrl};\nCURL return httpcode ($httpCode): $curl_error\n", $httpCode);
        } else {
            $num = self::fetchRequestFailNum($lockMark);
            if ($num > 0) {
                self::clearRequestFailNum($lockMark);
            }
            return $data;
        }
    }
    /**
     * ����������ȡһ��û������host
     * 
     * @param array $ipArray ip����
     * 
     * @return Ambigous <NULL, unknown>
     */
    private static function getFreeHost($ipArray)
    {
        $host = null;
        if (is_array($ipArray) && count($ipArray) > 0) {
            $offset = time() % count($ipArray);
            $host = $ipArray[$offset];
          
            if ($host !=null && self::isLocked($host)) {
                unset($ipArray[$offset]);
                $ipArray = array_values($ipArray);
                
                $host = self::getFreeHost($ipArray);
            }
        }
        return $host;
    }
    
    
    /**
     * ��������
     * 
     * @param Object &$ch           curlʵ��
     * @param array  $ipArray       ip����
     * @param number $timeoutSecond ��ʱʱ��
     * @param number $lockSecond    ����ʱ��
     * 
     * @throws Exception
     * 
     * @return void
     */
    public static function execWithIP(&$ch, $ipArray, $timeoutSecond=1, $lockSecond=0)
    {
        $requestUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        $regex = "@^([httpsHTTPS]{4,5}://)([^:/]+)[:]?([0-9]*)([/]?.*)@i";
        preg_match($regex, $requestUrl, $matches);
        
        if (is_array($matches) && count($matches) > 4) {
             $baseSrc = $matches[0];
             $protocol = $matches[1];
             $host = $matches[2];
             $port = $matches[3];
             $requestPath = $matches[4];
            if (is_array($ipArray) && count($ipArray) > 0) {
              
                 $freeHost = self::getFreeHost($ipArray);
                 
                 if (empty($freeHost)) {
                     throw  new \Exception("The requestUrl \"{$requestUrl}\" has been locked! \n", 104);
                 } else {
                     $requestUrl = $protocol.$freeHost.$requestPath;
                 }
                                  
                 
                 //�趨host
                 curl_setopt($ch, CURLOPT_HTTPHEADER, array("Host:".$host));
                 
                 curl_setopt($ch, CURLOPT_URL, $requestUrl);
                 
            } else {
                
                 $requestUrl = $protocol.$host.":".$port.$requestPath;
                 
                 curl_setopt($ch, CURLOPT_URL, $requestUrl);
            }
            
            $dnsName = $host;
            
            try {
                
                $data = self::_exec($ch, $timeoutSecond, $lockSecond, true, $dnsName);
            } catch (\Exception $e) {
                //�����һ��ʧ�ܣ��ٳ���һ��
                $freeHost = self::getFreeHost($ipArray);
                if ($freeHost != null) {
                    $requestUrl = $protocol.$freeHost.$requestPath;
                    curl_setopt($ch, CURLOPT_URL, $requestUrl);
                    $data = self::_exec($ch, $timeoutSecond, $lockSecond, true, $dnsName);
                }
                $data = null;
               
                
            }
            return $data;
        }
        
        
        
        
        //����ִ�У�����Ϊhost��ģʽ
        return self::exec($ch, $timeoutSecond, $lockSecond, true);
    }
    
    

}




?>
