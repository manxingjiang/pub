<?php
/**
 *  Cookie������
 *
 *  @author zsg <xxx@qq.com>
 *
 */
/**
 *  Cookie������
 *
 *  @author zsg <xxx@qq.com>
 */
namespace Tools;
use Tools;
class Cookie
{    
/**
     * cookie���ü�����
     *
     * @param string $var      cookie����
     * @param string $value    ccookieֵ
     * @param string $life     ��Ч��
     * @param bool   $httponly httponly
     *
     * @return unknow
     */
    public static function dsetcookie($var, $value = '', $life = 0, $httponly = false)
    {
        $timenow = time();
        $cookiedomain = '.findlaw.cn';
        $cookiepath = '/';
        if ($value == '' || $life < 0) {
            $value = '';
            $life = -1;
        }
        $life = $life > 0 ? ($timenow + $life) : ( $timenow - 31536000 );
        $path = $httponly && PHP_VERSION < '5.2.0' ? "$cookiepath; HttpOnly" : $cookiepath;
        $secure = $_SERVER['SERVER_PORT'] == 443 ? 1 : 0;
        if (PHP_VERSION < '5.2.0') {
            $ret = setcookie($var, $value, $life, $path, $cookiedomain, $secure);
        } else {
            $ret = setcookie($var, $value, $life, $path, $cookiedomain, $secure, $httponly);
        }
        return $ret ;
    }
    
    /**
     * ��ʼ���ϴ�cookie�� ���flash�ϴ�cookie��ʧ����
     * 
     * @return null
     */
    public static function init_upload_cookies()
    {
        $uploadify_cookies = $_REQUEST['uploadify_cookies'];
        $tmp = explode(';', $uploadify_cookies);
        foreach ($tmp as $str) {
            $pos = strpos($str, '=', 0);
            if ($pos) {
                $k = trim(substr($str, 0, $pos));
                $v = substr($str, $pos+1, strlen($str));
                $v = urldecode($v);
                $_COOKIE[$k] = $v;
            }
        }
    }
    
}
