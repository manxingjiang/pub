<?php
/**
 *  �ִʹ�����
 *
 *  @author zsg <xxx@qq.com>
 *
 */
 
/**
 *  �ִʹ�����
 *
 *  @author zsg <xxx@qq.com>
 */
namespace Tools;
use Tools;
class Split
{
    /**
     * �ִʷ���������
     *
     * @return type
     */
    public static function getSplitHttpServer()
    {
        return C('dicthttpSever');
    }
    
    /**
     * �ִ�
     *
     * @param type $content content
     * @param type $ciku    ciku
     *
     * @return type
     * @author author
     */
    public static function splitWord($content, $ciku)
    {
        static $splitobj = array();
    
        if (!isset($splitobj[$ciku])) {
            $dicthttpSever = self::getSplitHttpServer();
            /*    
            //���йؼ�����7780�˿�
            if (in_array($ciku, array('keyword_filter', 'lanjie_keyword'))) {
                $dicthttpSever = preg_replace('/:\d+$/ims', ':7780', $dicthttpSever); //ԭ7780
            }
            */
            //�Ƿ�ִʵ���ģʽ
            $is_debug_split = isset($_REQUEST['debug']) && $_REQUEST['debug'] == 'debug_split';
            if ($is_debug_split) {
                echo '<hr>�ִʷ�����:' . $dicthttpSever . '<hr>';
            }
    
            $splitobj[$ciku] = scwsObject::get_instance($ciku, $dicthttpSever, 'split');
        }
    
        return $splitobj[$ciku]->spilt($content);
    }
    
    /**
     * �ִ�--�Է��ؽ������ȥ�ش����󷵻�, ������ö��ŷָ�, �޽������false
     *
     * @param type $content content
     * @param type $ciku    ciku
     *
     * @return type
     * @author author
     */
    public static function splitWordA($content, $ciku)
    {
        $content = self::splitWord($content, $ciku);
        $keyarr = explode(' ', trim($content));
        $rekeys = array();
        foreach ($keyarr as $key) {
            $key = trim($key);
            if ($key=='') {
                continue;
            }
            $rekeys[] = $key;
        }
        if (count($rekeys)==0) {
            return false;
        }
        $rekeys = array_unique($rekeys);
        return implode(',', $rekeys);
    }
    
    /**
     * ���йؼ��ʷִʺ���
     *
     * @param type $content content
     *
     * @return type
     * @author zhangshengguang
     */
    public static function mgSplitWord($content)
    {
        return self::splitWord($content, 'keyword_filter');
    }
    
    /**
     * �ж��Ƿ�������йؼ���, �ɹ����طִʽ����ʧ�ܷ���false
     *
     * @param type $content content
     *
     * @return type
     * @author zhangshengguang
     */
    public static function existsMgWord($content)
    {
        $content = str_replace(' ', '', $content);
        $content = self::mgSplitWord($content);
        $keyarr = explode(' ', trim($content));
        $mgkeys = array();
        foreach ($keyarr as $key) {
            $key = trim($key);
            if ($key=='') {
                continue;
            }
            $mgkeys[] = $key;
        }
        if (count($mgkeys)==0) {
            return false;
        }
        $mgkeys = array_unique($mgkeys);
        return implode(',', $mgkeys);
    }
    
    /**
     * ����ִ�
     *
     * @param int    $channel_id channel_id
     * @param int    $detail_id  detail_id
     * @param string $reply      reply
     *
     * @return int
     */
    public function filterInfoDone($channel_id, $detail_id, $reply)
    {
        $mgkeysarr = explode(', ', $reply);
        $mgkeysarr = array_unique($mgkeysarr);
        if (empty($mgkeysarr)) {
            die('�����д���');
        }
        $inset_ids = array();
        foreach ($mgkeysarr as $keys) {
            $arr = array (
                    'channelId'    => $channel_id, 
                    'detailId'    => $detail_id, 
                    'keys'        => $keys, 
                    'split'        => $keys, 
                    'ifaudit'    => 5, 
                    'phrase'    => 1, 
                    'keyscat'    => 1, 
                    'backnum'    => 0, 
                    'pubdate'    => time()
            );
            $inset_ids[] = \Rpc::getData("Recheck.Admin.insertflFilterInfoDone", $arr);
        }
        return $inset_ids;
    }
    /**
     * ������ѯ�ظ���˴ʿ�����ж�
     *
     * @param type $content content
     *
     * @return type
     * @author author
     */
    public static function checkRefWord($content)
    {
        $db=new \Models\PeriodModel();
        $sql='select keyname from findlaw_db.keyword_filter where type = 7';
        $list=$db->query($sql);
        foreach ($list as $v) {
            $re=mb_strpos($content, $v['keyname'], 0, 'gbk');
            if (isset($re) && $re !== false) {
                return true;
            }
        }
        return false;
    }
}




/**
 * Description: scws�ʿ����ӿ�
 *
 * FunctionList:
 * 1. Property(ԭ��)
 * 2. ԭ�Ͳ�������
 * 3. �ʿ����
 *
 *
 *
 * @version 1.0
 * @author it_vitas
 * @package dict
 * @copyright 2012, ���ݺ�� Co. Ltd. All RIGHTS RESERVED
 */

/*
 * ����һ��ԭ��
*/
abstract class dictProperty
{
    protected $dictName;
    protected $httpSever;
    protected $model;

    public function __construct($dictName,$httpSever,$model){
        $this->dictName 	  = $dictName;
        $this->httpSever      = $httpSever;
        $this->model     	  = $model;
    }


    //�д�
    abstract public function spilt($content);
}

/*
 *�ʿ����ò�������
*/
class dictPropertyInfo
{
    const DICT_KEY       = ''; 						         //Ĭ�ϴʿ����� d=
    const HTTPSERVER_KEY = 'http://192.168.1.149:7779'; 	//Ĭ���д�http�����ַ
    const MODEL_KEY      = 'split'; 						//Ĭ���дʷ�ʽ  m= split-�д�   link-Ƶ�����Ĵ�

    public $dictName;
    public $httpSever;
    public $model;

    public function __construct($dictName='',$httpSever='',$model='') {
        $this->dictName  = $this->propValue($dictName, 'dictName', self::DICT_KEY);
        $this->httpSever = $this->propValue($httpSever, 'httpSever', self::HTTPSERVER_KEY);
        $this->model = $this->propValue($model, 'model', self::MODEL_KEY);
    }

    /**
     * �趨����ֵ
     * @param    $props �����ʼ��ֵ
     * @param    $prop  ��ֵ����
     * @param    $key   Ĭ���趨����ֵ
     */
    protected function propValue($props, $prop, $key) {
        if(!is_array($props)){
            return $this->$prop = $props?$props:$key;
        }else{
            /* ���������ݲ�����
             if (array_key_exists($key, $props)) {
            return $this->$prop = $props[$key];

            }*/
            return '';
            	
        }

    }
}


/*
 * �ʿ����
*/
class scwsObject extends dictProperty
{
    static $instance = false;

    //�д�
    public function spilt($content)
    {
        //���url����
        $ws='';
        $request='';

        $url     = $this->httpSever.'?m='.$this->model.'&d='.$this->dictName;
        $URL_Info= parse_url($url);
        $content = strip_tags($content);
        $requestcontent = $content;
        $content = urlencode($content);

        $request.="POST ".$url." HTTP/1.1\r\n";
        $request.="Content-type: application/x-www-form-urlencoded\r\n";
        $tmp_user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT']:'';
        $request.="User-Agent: {$tmp_user_agent}\r\n";
        $request.="Host: ".$URL_Info["host"]."\r\n";
        $request.="Content-length: ".strlen($content)."\r\n";
        $request.="Connection: Close\r\n";
        $request.="Cache-Control: no-cache\r\n";
        $request.="\r\n".$content;

        $fp = @fsockopen($URL_Info["host"], $URL_Info["port"], $errno, $errstr, 15);
        if(!$fp)
        {
            return false;
        } else {
            stream_set_timeout($fp,15);
            if (fwrite($fp, $request))
            {
                $header = "not yet";

                while (!feof($fp)) {
                    $line=fgets($fp,128);
                    if ($line=="\r\n" && $header=="not yet") $header = "passed";
                    if ($header=="passed") $ws.=$line;
                }
            }
            fclose($fp);
        }

        $is_debug_split = isset($_GET['debug']) && $_GET['debug'] == 'debug_split';	//�Ƿ����
        if($is_debug_split){
            echo '<hr>requestContent=>'.$requestcontent.'<br>request=>' . $request . '<br> return=>' . $ws . '<hr>';
        }

        return $ws;


    }

    /**
     * �����ʿ����
     * @param    $dictName  �ʿ�����
     * @param    $httpSever ��������ַ
     * @param    $model     �д�ģʽ(split-�д�   link-Ƶ�����Ĵ�)
     */
    public static function get_instance($dictName='',$httpSever='',$model=''){
        $object   = null;
        $dictInfoObject = new  dictPropertyInfo($dictName,$httpSever,$model);
        if(is_object($dictInfoObject)){
            $object = new scwsObject($dictInfoObject->dictName,$dictInfoObject->httpSever,$dictInfoObject->model);
        }

        return $object;

    }
}
