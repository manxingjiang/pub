<?php
/**
 *  按字母排列地区
 *
 * @author     wusl <525083980@qq.com>
 */

//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);

/**
 * 公开咨询公用类
 *
 * @author     wusl <525083980@qq.com>
 */
$zimuAreas = array (
  'A' => 
  array (
    'anhui' => 
    array (
      'id' => '100100',
      'province' => '安徽',
      'city' => '',
      'country' => '',
      'pinyin' => 'anhui',
      'grade' => '0',
      'grade_salse' => '2',
    ),
    'anqing' => 
    array (
      'id' => '100900',
      'province' => '安徽',
      'city' => '安庆',
      'country' => '',
      'pinyin' => 'anqing',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'anshun' => 
    array (
      'id' => '190700',
      'province' => '贵州',
      'city' => '安顺',
      'country' => '',
      'pinyin' => 'anshun',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'anyang' => 
    array (
      'id' => '230900',
      'province' => '河南',
      'city' => '安阳',
      'country' => '',
      'pinyin' => 'anyang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'anshan' => 
    array (
      'id' => '290400',
      'province' => '辽宁',
      'city' => '鞍山',
      'country' => '',
      'pinyin' => 'anshan',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'ankang' => 
    array (
      'id' => '351000',
      'province' => '陕西',
      'city' => '安康',
      'country' => '',
      'pinyin' => 'ankang',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'akesu' => 
    array (
      'id' => '380600',
      'province' => '新疆',
      'city' => '阿克苏',
      'country' => '',
      'pinyin' => 'akesu',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'ale' => 
    array (
      'id' => '381500',
      'province' => '新疆',
      'city' => '阿拉尔',
      'country' => '',
      'pinyin' => 'ale',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'aomen' => 
    array (
      'id' => '450101',
      'province' => '澳门',
      'city' => '澳门',
      'country' => '',
      'pinyin' => 'aomen',
      'grade' => '0',
      'grade_salse' => '3',
    ),
    'alsm' => 
    array (
      'id' => '301400',
      'province' => '内蒙古',
      'city' => '阿拉善盟',
      'country' => '',
      'pinyin' => 'alsm',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'aba' => 
    array (
      'id' => '362000',
      'province' => '四川',
      'city' => '阿坝',
      'country' => '',
      'pinyin' => 'aba',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'ali' => 
    array (
      'id' => '370800',
      'province' => '西藏',
      'city' => '阿里',
      'country' => '',
      'pinyin' => 'ali',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'aletai' => 
    array (
      'id' => '382000',
      'province' => '新疆',
      'city' => '阿勒泰',
      'country' => '',
      'pinyin' => 'aletai',
      'grade' => '1',
      'grade_salse' => '4',
    ),
  ),
  'B' => 
  array (
    'bangfu' => 
    array (
      'id' => '100700',
      'province' => '安徽',
      'city' => '蚌埠',
      'country' => '',
      'pinyin' => 'bangfu',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'beijing' => 
    array (
      'id' => '110101',
      'province' => '北京',
      'city' => '北京',
      'country' => '',
      'pinyin' => 'beijing',
      'grade' => '0',
      'grade_salse' => '1',
    ),
    'baiyin' => 
    array (
      'id' => '160400',
      'province' => '甘肃',
      'city' => '白银',
      'country' => '',
      'pinyin' => 'baiyin',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'beihai' => 
    array (
      'id' => '180600',
      'province' => '广西',
      'city' => '北海',
      'country' => '',
      'pinyin' => 'beihai',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'baise' => 
    array (
      'id' => '181200',
      'province' => '广西',
      'city' => '百色',
      'country' => '',
      'pinyin' => 'baise',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'bijie' => 
    array (
      'id' => '190600',
      'province' => '贵州',
      'city' => '毕节',
      'country' => '',
      'pinyin' => 'bijie',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'baisha' => 
    array (
      'id' => '200500',
      'province' => '海南',
      'city' => '白沙',
      'country' => '',
      'pinyin' => 'baisha',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'baoting' => 
    array (
      'id' => '200600',
      'province' => '海南',
      'city' => '保亭',
      'country' => '',
      'pinyin' => 'baoting',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'baoding' => 
    array (
      'id' => '210500',
      'province' => '河北',
      'city' => '保定',
      'country' => '',
      'pinyin' => 'baoding',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'baishan' => 
    array (
      'id' => '280700',
      'province' => '吉林省',
      'city' => '白山',
      'country' => '',
      'pinyin' => 'baishan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'baicheng' => 
    array (
      'id' => '280900',
      'province' => '吉林省',
      'city' => '白城',
      'country' => '',
      'pinyin' => 'baicheng',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'benxi' => 
    array (
      'id' => '290600',
      'province' => '辽宁',
      'city' => '本溪',
      'country' => '',
      'pinyin' => 'benxi',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'baotou' => 
    array (
      'id' => '300300',
      'province' => '内蒙古',
      'city' => '包头',
      'country' => '',
      'pinyin' => 'baotou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'binzhou' => 
    array (
      'id' => '331700',
      'province' => '山东',
      'city' => '滨州',
      'country' => '',
      'pinyin' => 'binzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'baoji' => 
    array (
      'id' => '350400',
      'province' => '陕西',
      'city' => '宝鸡',
      'country' => '',
      'pinyin' => 'baoji',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'bazhong' => 
    array (
      'id' => '361600',
      'province' => '四川',
      'city' => '巴中',
      'country' => '',
      'pinyin' => 'bazhong',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'baoshan' => 
    array (
      'id' => '390800',
      'province' => '云南',
      'city' => '保山',
      'country' => '',
      'pinyin' => 'baoshan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'bynem' => 
    array (
      'id' => '301100',
      'province' => '内蒙古',
      'city' => '巴彦淖尔盟',
      'country' => '',
      'pinyin' => 'bynem',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'bygl' => 
    array (
      'id' => '381200',
      'province' => '新疆',
      'city' => '巴音郭楞',
      'country' => '',
      'pinyin' => 'bygl',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'boertala' => 
    array (
      'id' => '381300',
      'province' => '新疆',
      'city' => '博尔塔拉',
      'country' => '',
      'pinyin' => 'boertala',
      'grade' => '1',
      'grade_salse' => '3',
    ),
  ),
  'C' => 
  array (
    'chizhou' => 
    array (
      'id' => '101700',
      'province' => '安徽',
      'city' => '池州',
      'country' => '',
      'pinyin' => 'chizhou',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'chuzhou' => 
    array (
      'id' => '101800',
      'province' => '安徽',
      'city' => '滁州',
      'country' => '',
      'pinyin' => 'chuzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'chongqing' => 
    array (
      'id' => '120101',
      'province' => '重庆',
      'city' => '重庆',
      'country' => '',
      'pinyin' => 'chongqing',
      'grade' => '0',
      'grade_salse' => '1',
    ),
    'chaozhou' => 
    array (
      'id' => '172100',
      'province' => '广东',
      'city' => '潮州',
      'country' => '',
      'pinyin' => 'chaozhou',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'chongzuo' => 
    array (
      'id' => '181400',
      'province' => '广西',
      'city' => '崇左',
      'country' => '',
      'pinyin' => 'chongzuo',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'changjiang' => 
    array (
      'id' => '200700',
      'province' => '海南',
      'city' => '昌江',
      'country' => '',
      'pinyin' => 'changjiang',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'chengmai' => 
    array (
      'id' => '200800',
      'province' => '海南',
      'city' => '澄迈县',
      'country' => '',
      'pinyin' => 'chengmai',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'chengde' => 
    array (
      'id' => '211200',
      'province' => '河北',
      'city' => '承德',
      'country' => '',
      'pinyin' => 'chengde',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'cangzhou' => 
    array (
      'id' => '210900',
      'province' => '河北',
      'city' => '沧州',
      'country' => '',
      'pinyin' => 'cangzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'changsha' => 
    array (
      'id' => '250200',
      'province' => '湖南',
      'city' => '长沙',
      'country' => '',
      'pinyin' => 'changsha',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'changde' => 
    array (
      'id' => '250800',
      'province' => '湖南',
      'city' => '常德',
      'country' => '',
      'pinyin' => 'changde',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'chenzhou' => 
    array (
      'id' => '251000',
      'province' => '湖南',
      'city' => '郴州',
      'country' => '',
      'pinyin' => 'chenzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'changzhou' => 
    array (
      'id' => '261000',
      'province' => '江苏',
      'city' => '常州',
      'country' => '',
      'pinyin' => 'changzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'changchun' => 
    array (
      'id' => '280200',
      'province' => '吉林省',
      'city' => '长春',
      'country' => '',
      'pinyin' => 'changchun',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'chifengshi' => 
    array (
      'id' => '300500',
      'province' => '内蒙古',
      'city' => '赤峰',
      'country' => '',
      'pinyin' => 'chifengshi',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'changzhi' => 
    array (
      'id' => '340500',
      'province' => '山西',
      'city' => '长治',
      'country' => '',
      'pinyin' => 'changzhi',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'chengdu' => 
    array (
      'id' => '360200',
      'province' => '四川',
      'city' => '成都',
      'country' => '',
      'pinyin' => 'chengdu',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'changdu' => 
    array (
      'id' => '370400',
      'province' => '西藏',
      'city' => '昌都',
      'country' => '',
      'pinyin' => 'changdu',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'changji' => 
    array (
      'id' => '380900',
      'province' => '新疆',
      'city' => '昌吉',
      'country' => '',
      'pinyin' => 'changji',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'chuxiong' => 
    array (
      'id' => '391400',
      'province' => '云南',
      'city' => '楚雄',
      'country' => '',
      'pinyin' => 'chuxiong',
      'grade' => '1',
      'grade_salse' => '3',
    ),
  ),
  'D' => 
  array (
    'dingxi' => 
    array (
      'id' => '160700',
      'province' => '甘肃',
      'city' => '定西',
      'country' => '',
      'pinyin' => 'dingxi',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'dongguan' => 
    array (
      'id' => '171100',
      'province' => '广东',
      'city' => '东莞',
      'country' => '',
      'pinyin' => 'dongguan',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'dingan' => 
    array (
      'id' => '200900',
      'province' => '海南',
      'city' => '定安县',
      'country' => '',
      'pinyin' => 'dingan',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'dongfang' => 
    array (
      'id' => '201000',
      'province' => '海南',
      'city' => '东方市',
      'country' => '',
      'pinyin' => 'dongfang',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'dzs' => 
    array (
      'id' => '202000',
      'province' => '海南',
      'city' => '儋州',
      'country' => '',
      'pinyin' => 'dzs',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'daqing' => 
    array (
      'id' => '220700',
      'province' => '黑龙江',
      'city' => '大庆',
      'country' => '',
      'pinyin' => 'daqing',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'dxal' => 
    array (
      'id' => '221200',
      'province' => '黑龙江',
      'city' => '大兴安岭',
      'country' => '',
      'pinyin' => 'dxal',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'dalian' => 
    array (
      'id' => '290300',
      'province' => '辽宁',
      'city' => '大连',
      'country' => '',
      'pinyin' => 'dalian',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'dandong' => 
    array (
      'id' => '290700',
      'province' => '辽宁',
      'city' => '丹东',
      'country' => '',
      'pinyin' => 'dandong',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'dongying' => 
    array (
      'id' => '330600',
      'province' => '山东',
      'city' => '东营',
      'country' => '',
      'pinyin' => 'dongying',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'dezhou' => 
    array (
      'id' => '331400',
      'province' => '山东',
      'city' => '德州',
      'country' => '',
      'pinyin' => 'dezhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'datong' => 
    array (
      'id' => '340300',
      'province' => '山西',
      'city' => '大同',
      'country' => '',
      'pinyin' => 'datong',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'deyang' => 
    array (
      'id' => '360600',
      'province' => '四川',
      'city' => '德阳',
      'country' => '',
      'pinyin' => 'deyang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'dachuan' => 
    array (
      'id' => '361500',
      'province' => '四川',
      'city' => '达州',
      'country' => '',
      'pinyin' => 'dachuan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'dehong' => 
    array (
      'id' => '391500',
      'province' => '云南',
      'city' => '德宏',
      'country' => '',
      'pinyin' => 'dehong',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'dali' => 
    array (
      'id' => '391000',
      'province' => '云南',
      'city' => '大理',
      'country' => '',
      'pinyin' => 'dali',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'diqing' => 
    array (
      'id' => '391600',
      'province' => '云南',
      'city' => '迪庆',
      'country' => '',
      'pinyin' => 'diqing',
      'grade' => '1',
      'grade_salse' => '3',
    ),
  ),
  'E' => 
  array (
    'ezhou' => 
    array (
      'id' => '240900',
      'province' => '湖北',
      'city' => '鄂州',
      'country' => '',
      'pinyin' => 'ezhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'enshi' => 
    array (
      'id' => '241400',
      'province' => '湖北',
      'city' => '恩施州',
      'country' => '',
      'pinyin' => 'enshi',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'eeds' => 
    array (
      'id' => '301000',
      'province' => '内蒙古',
      'city' => '鄂尔多斯',
      'country' => '',
      'pinyin' => 'eeds',
      'grade' => '1',
      'grade_salse' => '2',
    ),
  ),
  'F' => 
  array (
    'fuyang' => 
    array (
      'id' => '101100',
      'province' => '安徽',
      'city' => '阜阳',
      'country' => '',
      'pinyin' => 'fuyang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'fujian' => 
    array (
      'id' => '150100',
      'province' => '福建',
      'city' => '',
      'country' => '',
      'pinyin' => 'fujian',
      'grade' => '0',
      'grade_salse' => '2',
    ),
    'fuzhou' => 
    array (
      'id' => '150200',
      'province' => '福建',
      'city' => '福州',
      'country' => '',
      'pinyin' => 'fuzhou',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'foshan' => 
    array (
      'id' => '171400',
      'province' => '广东',
      'city' => '佛山',
      'country' => '',
      'pinyin' => 'foshan',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'fcg' => 
    array (
      'id' => '180700',
      'province' => '广西',
      'city' => '防城港',
      'country' => '',
      'pinyin' => 'fcg',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'fuzhoushi' => 
    array (
      'id' => '271200',
      'province' => '江西',
      'city' => '抚州',
      'country' => '',
      'pinyin' => 'fuzhoushi',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'fushunshi' => 
    array (
      'id' => '290500',
      'province' => '辽宁',
      'city' => '抚顺',
      'country' => '',
      'pinyin' => 'fushunshi',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'fuxin' => 
    array (
      'id' => '291200',
      'province' => '辽宁',
      'city' => '阜新',
      'country' => '',
      'pinyin' => 'fuxin',
      'grade' => '1',
      'grade_salse' => '2',
    ),
  ),
  'G' => 
  array (
    'gansu' => 
    array (
      'id' => '160100',
      'province' => '甘肃',
      'city' => '',
      'country' => '',
      'pinyin' => 'gansu',
      'grade' => '0',
      'grade_salse' => '2',
    ),
    'guangdong' => 
    array (
      'id' => '170100',
      'province' => '广东',
      'city' => '',
      'country' => '',
      'pinyin' => 'guangdong',
      'grade' => '0',
      'grade_salse' => '1',
    ),
    'guangzhou' => 
    array (
      'id' => '170200',
      'province' => '广东',
      'city' => '广州',
      'country' => '',
      'pinyin' => 'guangzhou',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'guangxi' => 
    array (
      'id' => '180100',
      'province' => '广西',
      'city' => '',
      'country' => '',
      'pinyin' => 'guangxi',
      'grade' => '0',
      'grade_salse' => '1',
    ),
    'guilin' => 
    array (
      'id' => '180400',
      'province' => '广西',
      'city' => '桂林',
      'country' => '',
      'pinyin' => 'guilin',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'guigang' => 
    array (
      'id' => '180900',
      'province' => '广西',
      'city' => '贵港',
      'country' => '',
      'pinyin' => 'guigang',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'guizhou' => 
    array (
      'id' => '190100',
      'province' => '贵州',
      'city' => '',
      'country' => '',
      'pinyin' => 'guizhou',
      'grade' => '0',
      'grade_salse' => '1',
    ),
    'guiyang' => 
    array (
      'id' => '190200',
      'province' => '贵州',
      'city' => '贵阳',
      'country' => '',
      'pinyin' => 'guiyang',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'ganzhou' => 
    array (
      'id' => '270800',
      'province' => '江西',
      'city' => '赣州',
      'country' => '',
      'pinyin' => 'ganzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'guyuan' => 
    array (
      'id' => '310500',
      'province' => '宁夏',
      'city' => '固原',
      'country' => '',
      'pinyin' => 'guyuan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'guangyuan' => 
    array (
      'id' => '360800',
      'province' => '四川',
      'city' => '广元',
      'country' => '',
      'pinyin' => 'guangyuan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'guangan' => 
    array (
      'id' => '361400',
      'province' => '四川',
      'city' => '广安',
      'country' => '',
      'pinyin' => 'guangan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'ganzi' => 
    array (
      'id' => '362100',
      'province' => '四川',
      'city' => '甘孜',
      'country' => '',
      'pinyin' => 'ganzi',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'gannan' => 
    array (
      'id' => '161300',
      'province' => '甘肃',
      'city' => '甘南',
      'country' => '',
      'pinyin' => 'gannan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'guoluo' => 
    array (
      'id' => '320300',
      'province' => '青海',
      'city' => '果洛',
      'country' => '',
      'pinyin' => 'guoluo',
      'grade' => '1',
      'grade_salse' => '3',
    ),
  ),
  'H' => 
  array (
    'hefei' => 
    array (
      'id' => '100200',
      'province' => '安徽',
      'city' => '合肥',
      'country' => '',
      'pinyin' => 'hefei',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'huainan' => 
    array (
      'id' => '100300',
      'province' => '安徽',
      'city' => '淮南',
      'country' => '',
      'pinyin' => 'huainan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'huaibei' => 
    array (
      'id' => '100400',
      'province' => '安徽',
      'city' => '淮北',
      'country' => '',
      'pinyin' => 'huaibei',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'huangshan' => 
    array (
      'id' => '101000',
      'province' => '安徽',
      'city' => '黄山',
      'country' => '',
      'pinyin' => 'huangshan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'haozhou' => 
    array (
      'id' => '101300',
      'province' => '安徽',
      'city' => '亳州',
      'country' => '',
      'pinyin' => 'haozhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'heyuan' => 
    array (
      'id' => '170700',
      'province' => '广东',
      'city' => '河源',
      'country' => '',
      'pinyin' => 'heyuan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'huizhou' => 
    array (
      'id' => '170900',
      'province' => '广东',
      'city' => '惠州',
      'country' => '',
      'pinyin' => 'huizhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'hezhou' => 
    array (
      'id' => '181100',
      'province' => '广西',
      'city' => '贺州',
      'country' => '',
      'pinyin' => 'hezhou',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'hechi' => 
    array (
      'id' => '181300',
      'province' => '广西',
      'city' => '河池',
      'country' => '',
      'pinyin' => 'hechi',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'hainan' => 
    array (
      'id' => '200100',
      'province' => '海南',
      'city' => '',
      'country' => '',
      'pinyin' => 'hainan',
      'grade' => '0',
      'grade_salse' => '2',
    ),
    'haikou' => 
    array (
      'id' => '200200',
      'province' => '海南',
      'city' => '海口',
      'country' => '',
      'pinyin' => 'haikou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'hebei' => 
    array (
      'id' => '210100',
      'province' => '河北',
      'city' => '',
      'country' => '',
      'pinyin' => 'hebei',
      'grade' => '0',
      'grade_salse' => '2',
    ),
    'handan' => 
    array (
      'id' => '210300',
      'province' => '河北',
      'city' => '邯郸',
      'country' => '',
      'pinyin' => 'handan',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'hengshui' => 
    array (
      'id' => '211100',
      'province' => '河北',
      'city' => '衡水',
      'country' => '',
      'pinyin' => 'hengshui',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'heilongjiang' => 
    array (
      'id' => '220100',
      'province' => '黑龙江',
      'city' => '',
      'country' => '',
      'pinyin' => 'heilongjiang',
      'grade' => '0',
      'grade_salse' => '2',
    ),
    'haerbin' => 
    array (
      'id' => '220200',
      'province' => '黑龙江',
      'city' => '哈尔滨',
      'country' => '',
      'pinyin' => 'haerbin',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'hegang' => 
    array (
      'id' => '220400',
      'province' => '黑龙江',
      'city' => '鹤岗',
      'country' => '',
      'pinyin' => 'hegang',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'heihe' => 
    array (
      'id' => '221000',
      'province' => '黑龙江',
      'city' => '黑河',
      'country' => '',
      'pinyin' => 'heihe',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'henan' => 
    array (
      'id' => '230100',
      'province' => '河南',
      'city' => '',
      'country' => '',
      'pinyin' => 'henan',
      'grade' => '0',
      'grade_salse' => '1',
    ),
    'hebi' => 
    array (
      'id' => '230700',
      'province' => '河南',
      'city' => '鹤壁',
      'country' => '',
      'pinyin' => 'hebi',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'hubei' => 
    array (
      'id' => '240100',
      'province' => '湖北',
      'city' => '',
      'country' => '',
      'pinyin' => 'hubei',
      'grade' => '0',
      'grade_salse' => '1',
    ),
    'huangshi' => 
    array (
      'id' => '240300',
      'province' => '湖北',
      'city' => '黄石',
      'country' => '',
      'pinyin' => 'huangshi',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'huanggang' => 
    array (
      'id' => '241100',
      'province' => '湖北',
      'city' => '黄冈',
      'country' => '',
      'pinyin' => 'huanggang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'hunan' => 
    array (
      'id' => '250100',
      'province' => '湖南',
      'city' => '',
      'country' => '',
      'pinyin' => 'hunan',
      'grade' => '0',
      'grade_salse' => '1',
    ),
    'hengyang' => 
    array (
      'id' => '250500',
      'province' => '湖南',
      'city' => '衡阳',
      'country' => '',
      'pinyin' => 'hengyang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'huaihua' => 
    array (
      'id' => '251300',
      'province' => '湖南',
      'city' => '怀化',
      'country' => '',
      'pinyin' => 'huaihua',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'huaian' => 
    array (
      'id' => '261400',
      'province' => '江苏',
      'city' => '淮安',
      'country' => '',
      'pinyin' => 'huaian',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'huludao' => 
    array (
      'id' => '290900',
      'province' => '辽宁',
      'city' => '葫芦岛',
      'country' => '',
      'pinyin' => 'huludao',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'huhehaote' => 
    array (
      'id' => '300200',
      'province' => '内蒙古',
      'city' => '呼和浩特',
      'country' => '',
      'pinyin' => 'huhehaote',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'hlbe' => 
    array (
      'id' => '300900',
      'province' => '内蒙古',
      'city' => '呼伦贝尔',
      'country' => '',
      'pinyin' => 'hlbe',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'heze' => 
    array (
      'id' => '331800',
      'province' => '山东',
      'city' => '菏泽',
      'country' => '',
      'pinyin' => 'heze',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'hanzhong' => 
    array (
      'id' => '350800',
      'province' => '陕西',
      'city' => '汉中',
      'country' => '',
      'pinyin' => 'hanzhong',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'hami' => 
    array (
      'id' => '380400',
      'province' => '新疆',
      'city' => '哈密',
      'country' => '',
      'pinyin' => 'hami',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'hetian' => 
    array (
      'id' => '380500',
      'province' => '新疆',
      'city' => '和田',
      'country' => '',
      'pinyin' => 'hetian',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'hangzhou' => 
    array (
      'id' => '400200',
      'province' => '浙江',
      'city' => '杭州',
      'country' => '',
      'pinyin' => 'hangzhou',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'huzhou' => 
    array (
      'id' => '400600',
      'province' => '浙江',
      'city' => '湖州',
      'country' => '',
      'pinyin' => 'huzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'haibei' => 
    array (
      'id' => '320400',
      'province' => '青海',
      'city' => '海北',
      'country' => '',
      'pinyin' => 'haibei',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'haidong' => 
    array (
      'id' => '320500',
      'province' => '青海',
      'city' => '海东',
      'country' => '',
      'pinyin' => 'haidong',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'hain' => 
    array (
      'id' => '320600',
      'province' => '青海',
      'city' => '海南',
      'country' => '',
      'pinyin' => 'hain',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'haixi' => 
    array (
      'id' => '320700',
      'province' => '青海',
      'city' => '海西',
      'country' => '',
      'pinyin' => 'haixi',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'huangnan' => 
    array (
      'id' => '320900',
      'province' => '青海',
      'city' => '黄南',
      'country' => '',
      'pinyin' => 'huangnan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'honghe' => 
    array (
      'id' => '391200',
      'province' => '云南',
      'city' => '红河',
      'country' => '',
      'pinyin' => 'honghe',
      'grade' => '1',
      'grade_salse' => '2',
    ),
  ),
  'J' => 
  array (
    'jinchang' => 
    array (
      'id' => '160300',
      'province' => '甘肃',
      'city' => '金昌',
      'country' => '',
      'pinyin' => 'jinchang',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'jiayuguan' => 
    array (
      'id' => '160600',
      'province' => '甘肃',
      'city' => '嘉峪关',
      'country' => '',
      'pinyin' => 'jiayuguan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'jiuquan' => 
    array (
      'id' => '161200',
      'province' => '甘肃',
      'city' => '酒泉',
      'country' => '',
      'pinyin' => 'jiuquan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'jiangmen' => 
    array (
      'id' => '171300',
      'province' => '广东',
      'city' => '江门',
      'country' => '',
      'pinyin' => 'jiangmen',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'jieyang' => 
    array (
      'id' => '172200',
      'province' => '广东',
      'city' => '揭阳',
      'country' => '',
      'pinyin' => 'jieyang',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'jixi' => 
    array (
      'id' => '220600',
      'province' => '黑龙江',
      'city' => '鸡西',
      'country' => '',
      'pinyin' => 'jixi',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'jiamusi' => 
    array (
      'id' => '220900',
      'province' => '黑龙江',
      'city' => '佳木斯',
      'country' => '',
      'pinyin' => 'jiamusi',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'jiaozuo' => 
    array (
      'id' => '230600',
      'province' => '河南',
      'city' => '焦作',
      'country' => '',
      'pinyin' => 'jiaozuo',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'jiyuan' => 
    array (
      'id' => '231700',
      'province' => '河南',
      'city' => '济源',
      'country' => '',
      'pinyin' => 'jiyuan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'jingzhou' => 
    array (
      'id' => '240600',
      'province' => '湖北',
      'city' => '荆州',
      'country' => '',
      'pinyin' => 'jingzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'jingmen' => 
    array (
      'id' => '240800',
      'province' => '湖北',
      'city' => '荆门',
      'country' => '',
      'pinyin' => 'jingmen',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'jiangsu' => 
    array (
      'id' => '260100',
      'province' => '江苏',
      'city' => '',
      'country' => '',
      'pinyin' => 'jiangsu',
      'grade' => '0',
      'grade_salse' => '1',
    ),
    'jiangxi' => 
    array (
      'id' => '270100',
      'province' => '江西',
      'city' => '',
      'country' => '',
      'pinyin' => 'jiangxi',
      'grade' => '0',
      'grade_salse' => '2',
    ),
    'jingdezhen' => 
    array (
      'id' => '270300',
      'province' => '江西',
      'city' => '景德镇',
      'country' => '',
      'pinyin' => 'jingdezhen',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'jiujiang' => 
    array (
      'id' => '270600',
      'province' => '江西',
      'city' => '九江',
      'country' => '',
      'pinyin' => 'jiujiang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'jian' => 
    array (
      'id' => '271100',
      'province' => '江西',
      'city' => '吉安',
      'country' => '',
      'pinyin' => 'jian',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'jl' => 
    array (
      'id' => '280100',
      'province' => '吉林省',
      'city' => '',
      'country' => '',
      'pinyin' => 'jl',
      'grade' => '0',
      'grade_salse' => '1',
    ),
    'jilin' => 
    array (
      'id' => '280300',
      'province' => '吉林省',
      'city' => '吉林',
      'country' => '',
      'pinyin' => 'jilin',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'jinzhou' => 
    array (
      'id' => '290800',
      'province' => '辽宁',
      'city' => '锦州',
      'country' => '',
      'pinyin' => 'jinzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'jinan' => 
    array (
      'id' => '330200',
      'province' => '山东',
      'city' => '济南',
      'country' => '',
      'pinyin' => 'jinan',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'jining' => 
    array (
      'id' => '331000',
      'province' => '山东',
      'city' => '济宁',
      'country' => '',
      'pinyin' => 'jining',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'jincheng' => 
    array (
      'id' => '340600',
      'province' => '山西',
      'city' => '晋城',
      'country' => '',
      'pinyin' => 'jincheng',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'jinzhong' => 
    array (
      'id' => '341100',
      'province' => '山西',
      'city' => '晋中',
      'country' => '',
      'pinyin' => 'jinzhong',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'jiaxing' => 
    array (
      'id' => '400500',
      'province' => '浙江',
      'city' => '嘉兴',
      'country' => '',
      'pinyin' => 'jiaxing',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'jinhua' => 
    array (
      'id' => '400800',
      'province' => '浙江',
      'city' => '金华',
      'country' => '',
      'pinyin' => 'jinhua',
      'grade' => '1',
      'grade_salse' => '2',
    ),
  ),
  'K' => 
  array (
    'kaifeng' => 
    array (
      'id' => '230300',
      'province' => '河南',
      'city' => '开封',
      'country' => '',
      'pinyin' => 'kaifeng',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'kelamayi' => 
    array (
      'id' => '380700',
      'province' => '新疆',
      'city' => '克拉玛依',
      'country' => '',
      'pinyin' => 'kelamayi',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'kashi' => 
    array (
      'id' => '380800',
      'province' => '新疆',
      'city' => '喀什',
      'country' => '',
      'pinyin' => 'kashi',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'kunming' => 
    array (
      'id' => '390200',
      'province' => '云南',
      'city' => '昆明',
      'country' => '',
      'pinyin' => 'kunming',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'kzlsk' => 
    array (
      'id' => '381800',
      'province' => '新疆',
      'city' => '克孜勒苏柯尔',
      'country' => '',
      'pinyin' => 'kzlsk',
      'grade' => '1',
      'grade_salse' => '3',
    ),
  ),
  'L' => 
  array (
    'liuan' => 
    array (
      'id' => '101500',
      'province' => '安徽',
      'city' => '六安',
      'country' => '',
      'pinyin' => 'liuan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'longyan' => 
    array (
      'id' => '150900',
      'province' => '福建',
      'city' => '龙岩',
      'country' => '',
      'pinyin' => 'longyan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'lanzhou' => 
    array (
      'id' => '160200',
      'province' => '甘肃',
      'city' => '兰州',
      'country' => '',
      'pinyin' => 'lanzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'linxia' => 
    array (
      'id' => '161100',
      'province' => '甘肃',
      'city' => '临夏',
      'country' => '',
      'pinyin' => 'linxia',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'longnan' => 
    array (
      'id' => '161400',
      'province' => '甘肃',
      'city' => '陇南',
      'country' => '',
      'pinyin' => 'longnan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'liuzhou' => 
    array (
      'id' => '180300',
      'province' => '广西',
      'city' => '柳州',
      'country' => '',
      'pinyin' => 'liuzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'laibin' => 
    array (
      'id' => '181500',
      'province' => '广西',
      'city' => '来宾',
      'country' => '',
      'pinyin' => 'laibin',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'liupanshui' => 
    array (
      'id' => '190300',
      'province' => '贵州',
      'city' => '六盘水',
      'country' => '',
      'pinyin' => 'liupanshui',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'ledong' => 
    array (
      'id' => '201100',
      'province' => '海南',
      'city' => '乐东',
      'country' => '',
      'pinyin' => 'ledong',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'lingao' => 
    array (
      'id' => '201200',
      'province' => '海南',
      'city' => '临高县',
      'country' => '',
      'pinyin' => 'lingao',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'lslz' => 
    array (
      'id' => '201300',
      'province' => '海南',
      'city' => '陵水',
      'country' => '',
      'pinyin' => 'lslz',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'langfang' => 
    array (
      'id' => '211000',
      'province' => '河北',
      'city' => '廊坊',
      'country' => '',
      'pinyin' => 'langfang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'luoyang' => 
    array (
      'id' => '230400',
      'province' => '河南',
      'city' => '洛阳',
      'country' => '',
      'pinyin' => 'luoyang',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'luohe' => 
    array (
      'id' => '231200',
      'province' => '河南',
      'city' => '漯河',
      'country' => '',
      'pinyin' => 'luohe',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'loudi' => 
    array (
      'id' => '251400',
      'province' => '湖南',
      'city' => '娄底',
      'country' => '',
      'pinyin' => 'loudi',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'lianyungang' => 
    array (
      'id' => '260300',
      'province' => '江苏',
      'city' => '连云港',
      'country' => '',
      'pinyin' => 'lianyungang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'liaoyuan' => 
    array (
      'id' => '280500',
      'province' => '吉林省',
      'city' => '辽源',
      'country' => '',
      'pinyin' => 'liaoyuan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'liaoning' => 
    array (
      'id' => '290100',
      'province' => '辽宁',
      'city' => '',
      'country' => '',
      'pinyin' => 'liaoning',
      'grade' => '0',
      'grade_salse' => '1',
    ),
    'liaoyang' => 
    array (
      'id' => '291300',
      'province' => '辽宁',
      'city' => '辽阳',
      'country' => '',
      'pinyin' => 'liaoyang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'laiwu' => 
    array (
      'id' => '331300',
      'province' => '山东',
      'city' => '莱芜',
      'country' => '',
      'pinyin' => 'laiwu',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'linxi' => 
    array (
      'id' => '331500',
      'province' => '山东',
      'city' => '临沂',
      'country' => '',
      'pinyin' => 'linxi',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'liaocheng' => 
    array (
      'id' => '331600',
      'province' => '山东',
      'city' => '聊城',
      'country' => '',
      'pinyin' => 'liaocheng',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'linfen' => 
    array (
      'id' => '340900',
      'province' => '山西',
      'city' => '临汾',
      'country' => '',
      'pinyin' => 'linfen',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'lvliang' => 
    array (
      'id' => '341200',
      'province' => '山西',
      'city' => '吕梁',
      'country' => '',
      'pinyin' => 'lvliang',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'luzhou' => 
    array (
      'id' => '360500',
      'province' => '四川',
      'city' => '泸州',
      'country' => '',
      'pinyin' => 'luzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'leshang' => 
    array (
      'id' => '361100',
      'province' => '四川',
      'city' => '乐山',
      'country' => '',
      'pinyin' => 'leshang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'liangshanzhou' => 
    array (
      'id' => '362200',
      'province' => '四川',
      'city' => '凉山',
      'country' => '',
      'pinyin' => 'liangshanzhou',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'lasha' => 
    array (
      'id' => '370200',
      'province' => '西藏',
      'city' => '拉萨',
      'country' => '',
      'pinyin' => 'lasha',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'linzhi' => 
    array (
      'id' => '370600',
      'province' => '西藏',
      'city' => '林芝',
      'country' => '',
      'pinyin' => 'linzhi',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'lincang' => 
    array (
      'id' => '390700',
      'province' => '云南',
      'city' => '临沧',
      'country' => '',
      'pinyin' => 'lincang',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'lijiang' => 
    array (
      'id' => '391100',
      'province' => '云南',
      'city' => '丽江',
      'country' => '',
      'pinyin' => 'lijiang',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'lishui' => 
    array (
      'id' => '401200',
      'province' => '浙江',
      'city' => '丽水',
      'country' => '',
      'pinyin' => 'lishui',
      'grade' => '1',
      'grade_salse' => '2',
    ),
  ),
  'M' => 
  array (
    'maanshan' => 
    array (
      'id' => '100800',
      'province' => '安徽',
      'city' => '马鞍山',
      'country' => '',
      'pinyin' => 'maanshan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'meizhou' => 
    array (
      'id' => '170800',
      'province' => '广东',
      'city' => '梅州',
      'country' => '',
      'pinyin' => 'meizhou',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'maoming' => 
    array (
      'id' => '171700',
      'province' => '广东',
      'city' => '茂名',
      'country' => '',
      'pinyin' => 'maoming',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'mudanjian' => 
    array (
      'id' => '220800',
      'province' => '黑龙江',
      'city' => '牡丹江',
      'country' => '',
      'pinyin' => 'mudanjian',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'mianyang' => 
    array (
      'id' => '360700',
      'province' => '四川',
      'city' => '绵阳',
      'country' => '',
      'pinyin' => 'mianyang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'meishan' => 
    array (
      'id' => '361800',
      'province' => '四川',
      'city' => '眉山',
      'country' => '',
      'pinyin' => 'meishan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
  ),
  'N' => 
  array (
    'nanping' => 
    array (
      'id' => '150800',
      'province' => '福建',
      'city' => '南平',
      'country' => '',
      'pinyin' => 'nanping',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'ningde' => 
    array (
      'id' => '151000',
      'province' => '福建',
      'city' => '宁德',
      'country' => '',
      'pinyin' => 'ningde',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'nanning' => 
    array (
      'id' => '180200',
      'province' => '广西',
      'city' => '南宁',
      'country' => '',
      'pinyin' => 'nanning',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'nanyang' => 
    array (
      'id' => '231400',
      'province' => '河南',
      'city' => '南阳',
      'country' => '',
      'pinyin' => 'nanyang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'nanjing' => 
    array (
      'id' => '260200',
      'province' => '江苏',
      'city' => '南京',
      'country' => '',
      'pinyin' => 'nanjing',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'nantong' => 
    array (
      'id' => '260800',
      'province' => '江苏',
      'city' => '南通',
      'country' => '',
      'pinyin' => 'nantong',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'nanchang' => 
    array (
      'id' => '270200',
      'province' => '江西',
      'city' => '南昌',
      'country' => '',
      'pinyin' => 'nanchang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'neimenggu' => 
    array (
      'id' => '300100',
      'province' => '内蒙古',
      'city' => '',
      'country' => '',
      'pinyin' => 'neimenggu',
      'grade' => '0',
      'grade_salse' => '2',
    ),
    'ningxia' => 
    array (
      'id' => '310000',
      'province' => '宁夏',
      'city' => '',
      'country' => '',
      'pinyin' => 'ningxia',
      'grade' => '0',
      'grade_salse' => '2',
    ),
    'neijiang' => 
    array (
      'id' => '361000',
      'province' => '四川',
      'city' => '内江',
      'country' => '',
      'pinyin' => 'neijiang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'nanchong' => 
    array (
      'id' => '361200',
      'province' => '四川',
      'city' => '南充',
      'country' => '',
      'pinyin' => 'nanchong',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'naqu' => 
    array (
      'id' => '370300',
      'province' => '西藏',
      'city' => '那曲',
      'country' => '',
      'pinyin' => 'naqu',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'ningbo' => 
    array (
      'id' => '400300',
      'province' => '浙江',
      'city' => '宁波',
      'country' => '',
      'pinyin' => 'ningbo',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'nujiang' => 
    array (
      'id' => '391700',
      'province' => '云南',
      'city' => '怒江',
      'country' => '',
      'pinyin' => 'nujiang',
      'grade' => '1',
      'grade_salse' => '3',
    ),
  ),
  'P' => 
  array (
    'putian' => 
    array (
      'id' => '150500',
      'province' => '福建',
      'city' => '莆田',
      'country' => '',
      'pinyin' => 'putian',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'pingliang' => 
    array (
      'id' => '160800',
      'province' => '甘肃',
      'city' => '平凉',
      'country' => '',
      'pinyin' => 'pingliang',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'pingdingshan' => 
    array (
      'id' => '230500',
      'province' => '河南',
      'city' => '平顶山',
      'country' => '',
      'pinyin' => 'pingdingshan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'puyang' => 
    array (
      'id' => '231000',
      'province' => '河南',
      'city' => '濮阳',
      'country' => '',
      'pinyin' => 'puyang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'pingxiang' => 
    array (
      'id' => '270400',
      'province' => '江西',
      'city' => '萍乡',
      'country' => '',
      'pinyin' => 'pingxiang',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'panjing' => 
    array (
      'id' => '291100',
      'province' => '辽宁',
      'city' => '盘锦',
      'country' => '',
      'pinyin' => 'panjing',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'panzhihua' => 
    array (
      'id' => '360400',
      'province' => '四川',
      'city' => '攀枝花',
      'country' => '',
      'pinyin' => 'panzhihua',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'puer' => 
    array (
      'id' => '390600',
      'province' => '云南',
      'city' => '普洱',
      'country' => '',
      'pinyin' => 'puer',
      'grade' => '1',
      'grade_salse' => '2',
    ),
  ),
  'Q' => 
  array (
    'quanzhou' => 
    array (
      'id' => '150600',
      'province' => '福建',
      'city' => '泉州',
      'country' => '',
      'pinyin' => 'quanzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'qingyang' => 
    array (
      'id' => '161500',
      'province' => '甘肃',
      'city' => '庆阳',
      'country' => '',
      'pinyin' => 'qingyang',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'qingyuan' => 
    array (
      'id' => '172000',
      'province' => '广东',
      'city' => '清远',
      'country' => '',
      'pinyin' => 'qingyuan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'qinzhou' => 
    array (
      'id' => '180800',
      'province' => '广西',
      'city' => '钦州',
      'country' => '',
      'pinyin' => 'qinzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'qianxinan' => 
    array (
      'id' => '190800',
      'province' => '贵州',
      'city' => '黔西南',
      'country' => '',
      'pinyin' => 'qianxinan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'qiandongnan' => 
    array (
      'id' => '190900',
      'province' => '贵州',
      'city' => '黔东南',
      'country' => '',
      'pinyin' => 'qiandongnan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'qionghai' => 
    array (
      'id' => '200400',
      'province' => '海南',
      'city' => '琼海',
      'country' => '',
      'pinyin' => 'qionghai',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'qiongzhong' => 
    array (
      'id' => '201500',
      'province' => '海南',
      'city' => '琼中',
      'country' => '',
      'pinyin' => 'qiongzhong',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'qinghuangdao' => 
    array (
      'id' => '210800',
      'province' => '河北',
      'city' => '秦皇岛',
      'country' => '',
      'pinyin' => 'qinghuangdao',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'qiqihaer' => 
    array (
      'id' => '220300',
      'province' => '黑龙江',
      'city' => '齐齐哈尔',
      'country' => '',
      'pinyin' => 'qiqihaer',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'qitaihe' => 
    array (
      'id' => '221300',
      'province' => '黑龙江',
      'city' => '七台河',
      'country' => '',
      'pinyin' => 'qitaihe',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'qianjiang' => 
    array (
      'id' => '241500',
      'province' => '湖北',
      'city' => '潜江',
      'country' => '',
      'pinyin' => 'qianjiang',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'qinghai' => 
    array (
      'id' => '320000',
      'province' => '青海',
      'city' => '',
      'country' => '',
      'pinyin' => 'qinghai',
      'grade' => '0',
      'grade_salse' => '2',
    ),
    'qingdao' => 
    array (
      'id' => '330300',
      'province' => '山东',
      'city' => '青岛',
      'country' => '',
      'pinyin' => 'qingdao',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'qujing' => 
    array (
      'id' => '390300',
      'province' => '云南',
      'city' => '曲靖',
      'country' => '',
      'pinyin' => 'qujing',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'quzhou' => 
    array (
      'id' => '400900',
      'province' => '浙江',
      'city' => '衢州',
      'country' => '',
      'pinyin' => 'quzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'qiannan' => 
    array (
      'id' => '191000',
      'province' => '贵州',
      'city' => '黔南',
      'country' => '',
      'pinyin' => 'qiannan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
  ),
  'R' => 
  array (
    'rizhao' => 
    array (
      'id' => '331200',
      'province' => '山东',
      'city' => '日照',
      'country' => '',
      'pinyin' => 'rizhao',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'rkz' => 
    array (
      'id' => '370500',
      'province' => '西藏',
      'city' => '日喀则',
      'country' => '',
      'pinyin' => 'rkz',
      'grade' => '1',
      'grade_salse' => '4',
    ),
  ),
  'S' => 
  array (
    'suzhoushi' => 
    array (
      'id' => '101200',
      'province' => '安徽',
      'city' => '宿州',
      'country' => '',
      'pinyin' => 'suzhoushi',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'shanghai' => 
    array (
      'id' => '140101',
      'province' => '上海',
      'city' => '上海',
      'country' => '',
      'pinyin' => 'shanghai',
      'grade' => '0',
      'grade_salse' => '1',
    ),
    'sanming' => 
    array (
      'id' => '150400',
      'province' => '福建',
      'city' => '三明',
      'country' => '',
      'pinyin' => 'sanming',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'shenzhen' => 
    array (
      'id' => '170300',
      'province' => '广东',
      'city' => '深圳',
      'country' => '',
      'pinyin' => 'shenzhen',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'shantou' => 
    array (
      'id' => '170500',
      'province' => '广东',
      'city' => '汕头',
      'country' => '',
      'pinyin' => 'shantou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'shaoguan' => 
    array (
      'id' => '170600',
      'province' => '广东',
      'city' => '韶关',
      'country' => '',
      'pinyin' => 'shaoguan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'shanwei' => 
    array (
      'id' => '171000',
      'province' => '广东',
      'city' => '汕尾',
      'country' => '',
      'pinyin' => 'shanwei',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'sanya' => 
    array (
      'id' => '200300',
      'province' => '海南',
      'city' => '三亚',
      'country' => '',
      'pinyin' => 'sanya',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'sansha' => 
    array (
      'id' => '202100',
      'province' => '海南',
      'city' => '三沙市',
      'country' => '',
      'pinyin' => 'sansha',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'shijiazhuang' => 
    array (
      'id' => '210200',
      'province' => '河北',
      'city' => '石家庄',
      'country' => '',
      'pinyin' => 'shijiazhuang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'shuanyashan' => 
    array (
      'id' => '220500',
      'province' => '黑龙江',
      'city' => '双鸭山',
      'country' => '',
      'pinyin' => 'shuanyashan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'suihua' => 
    array (
      'id' => '221100',
      'province' => '黑龙江',
      'city' => '绥化',
      'country' => '',
      'pinyin' => 'suihua',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'sanmenxia' => 
    array (
      'id' => '231300',
      'province' => '河南',
      'city' => '三门峡',
      'country' => '',
      'pinyin' => 'sanmenxia',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'shangqiu' => 
    array (
      'id' => '231500',
      'province' => '河南',
      'city' => '商丘',
      'country' => '',
      'pinyin' => 'shangqiu',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'shiyan' => 
    array (
      'id' => '240500',
      'province' => '湖北',
      'city' => '十堰',
      'country' => '',
      'pinyin' => 'shiyan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'suizhou' => 
    array (
      'id' => '241300',
      'province' => '湖北',
      'city' => '随州',
      'country' => '',
      'pinyin' => 'suizhou',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'shennongjia' => 
    array (
      'id' => '241800',
      'province' => '湖北',
      'city' => '神农架',
      'country' => '',
      'pinyin' => 'shennongjia',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'shaoyang' => 
    array (
      'id' => '250600',
      'province' => '湖南',
      'city' => '邵阳',
      'country' => '',
      'pinyin' => 'shaoyang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'suqian' => 
    array (
      'id' => '260400',
      'province' => '江苏',
      'city' => '宿迁',
      'country' => '',
      'pinyin' => 'suqian',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'suzhou' => 
    array (
      'id' => '261200',
      'province' => '江苏',
      'city' => '苏州',
      'country' => '',
      'pinyin' => 'suzhou',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'shangrao' => 
    array (
      'id' => '270900',
      'province' => '江西',
      'city' => '上饶',
      'country' => '',
      'pinyin' => 'shangrao',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'siping' => 
    array (
      'id' => '280400',
      'province' => '吉林省',
      'city' => '四平',
      'country' => '',
      'pinyin' => 'siping',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'songyuan' => 
    array (
      'id' => '280800',
      'province' => '吉林省',
      'city' => '松原',
      'country' => '',
      'pinyin' => 'songyuan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'shenyang' => 
    array (
      'id' => '290200',
      'province' => '辽宁',
      'city' => '沈阳',
      'country' => '',
      'pinyin' => 'shenyang',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'shizuishan' => 
    array (
      'id' => '310300',
      'province' => '宁夏',
      'city' => '石嘴山',
      'country' => '',
      'pinyin' => 'shizuishan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'shandong' => 
    array (
      'id' => '330100',
      'province' => '山东',
      'city' => '',
      'country' => '',
      'pinyin' => 'shandong',
      'grade' => '0',
      'grade_salse' => '1',
    ),
    'shanxi' => 
    array (
      'id' => '340100',
      'province' => '山西',
      'city' => '',
      'country' => '',
      'pinyin' => 'shanxi',
      'grade' => '0',
      'grade_salse' => '1',
    ),
    'shuozhou' => 
    array (
      'id' => '340700',
      'province' => '山西',
      'city' => '朔州',
      'country' => '',
      'pinyin' => 'shuozhou',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'shanxi2' => 
    array (
      'id' => '350100',
      'province' => '陕西',
      'city' => '',
      'country' => '',
      'pinyin' => 'shanxi2',
      'grade' => '0',
      'grade_salse' => '1',
    ),
    'shangluo' => 
    array (
      'id' => '351100',
      'province' => '陕西',
      'city' => '商洛',
      'country' => '',
      'pinyin' => 'shangluo',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'sichuan' => 
    array (
      'id' => '360100',
      'province' => '四川',
      'city' => '',
      'country' => '',
      'pinyin' => 'sichuan',
      'grade' => '0',
      'grade_salse' => '1',
    ),
    'shuining' => 
    array (
      'id' => '360900',
      'province' => '四川',
      'city' => '遂宁',
      'country' => '',
      'pinyin' => 'shuining',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'shihezi' => 
    array (
      'id' => '381000',
      'province' => '新疆',
      'city' => '石河子',
      'country' => '',
      'pinyin' => 'shihezi',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'shaoxing' => 
    array (
      'id' => '400700',
      'province' => '浙江',
      'city' => '绍兴',
      'country' => '',
      'pinyin' => 'shaoxing',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'shannan' => 
    array (
      'id' => '370700',
      'province' => '西藏',
      'city' => '山南',
      'country' => '',
      'pinyin' => 'shannan',
      'grade' => '1',
      'grade_salse' => '4',
    ),
  ),
  'T' => 
  array (
    'tongling' => 
    array (
      'id' => '100600',
      'province' => '安徽',
      'city' => '铜陵',
      'country' => '',
      'pinyin' => 'tongling',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'tianjin' => 
    array (
      'id' => '130101',
      'province' => '天津',
      'city' => '天津',
      'country' => '',
      'pinyin' => 'tianjin',
      'grade' => '0',
      'grade_salse' => '1',
    ),
    'tianshui' => 
    array (
      'id' => '160500',
      'province' => '甘肃',
      'city' => '天水',
      'country' => '',
      'pinyin' => 'tianshui',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'tongrenshi' => 
    array (
      'id' => '190500',
      'province' => '贵州',
      'city' => '铜仁',
      'country' => '',
      'pinyin' => 'tongrenshi',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'tunchang' => 
    array (
      'id' => '201600',
      'province' => '海南',
      'city' => '屯昌县',
      'country' => '',
      'pinyin' => 'tunchang',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'tangshan' => 
    array (
      'id' => '210700',
      'province' => '河北',
      'city' => '唐山',
      'country' => '',
      'pinyin' => 'tangshan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'tianmen' => 
    array (
      'id' => '241600',
      'province' => '湖北',
      'city' => '天门',
      'country' => '',
      'pinyin' => 'tianmen',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'taizhoushi' => 
    array (
      'id' => '260700',
      'province' => '江苏',
      'city' => '泰州',
      'country' => '',
      'pinyin' => 'taizhoushi',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'tonghua' => 
    array (
      'id' => '280600',
      'province' => '吉林省',
      'city' => '通化',
      'country' => '',
      'pinyin' => 'tonghua',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'tieling' => 
    array (
      'id' => '291400',
      'province' => '辽宁',
      'city' => '铁岭',
      'country' => '',
      'pinyin' => 'tieling',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'tongliao' => 
    array (
      'id' => '300700',
      'province' => '内蒙古',
      'city' => '通辽',
      'country' => '',
      'pinyin' => 'tongliao',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'taian' => 
    array (
      'id' => '331100',
      'province' => '山东',
      'city' => '泰安',
      'country' => '',
      'pinyin' => 'taian',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'taiyuan' => 
    array (
      'id' => '340200',
      'province' => '山西',
      'city' => '太原',
      'country' => '',
      'pinyin' => 'taiyuan',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'tongchuan' => 
    array (
      'id' => '350300',
      'province' => '陕西',
      'city' => '铜川',
      'country' => '',
      'pinyin' => 'tongchuan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'tulufan' => 
    array (
      'id' => '380380',
      'province' => '新疆',
      'city' => '吐鲁番',
      'country' => '',
      'pinyin' => 'tulufan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'tmsk' => 
    array (
      'id' => '381600',
      'province' => '新疆',
      'city' => '图木舒克',
      'country' => '',
      'pinyin' => 'tmsk',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'taizhou' => 
    array (
      'id' => '401100',
      'province' => '浙江',
      'city' => '台州',
      'country' => '',
      'pinyin' => 'taizhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'taiwan' => 
    array (
      'id' => '430101',
      'province' => '台湾',
      'city' => '台湾',
      'country' => '',
      'pinyin' => 'taiwan',
      'grade' => '0',
      'grade_salse' => '3',
    ),
    'tacheng' => 
    array (
      'id' => '381900',
      'province' => '新疆',
      'city' => '塔城',
      'country' => '',
      'pinyin' => 'tacheng',
      'grade' => '1',
      'grade_salse' => '4',
    ),
  ),
  'W' => 
  array (
    'wuhu' => 
    array (
      'id' => '100500',
      'province' => '安徽',
      'city' => '芜湖',
      'country' => '',
      'pinyin' => 'wuhu',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'wuwei' => 
    array (
      'id' => '160900',
      'province' => '甘肃',
      'city' => '武威',
      'country' => '',
      'pinyin' => 'wuwei',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'wuzhou' => 
    array (
      'id' => '180500',
      'province' => '广西',
      'city' => '梧州',
      'country' => '',
      'pinyin' => 'wuzhou',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'wanning' => 
    array (
      'id' => '201700',
      'province' => '海南',
      'city' => '万宁',
      'country' => '',
      'pinyin' => 'wanning',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'wenchang' => 
    array (
      'id' => '201800',
      'province' => '海南',
      'city' => '文昌',
      'country' => '',
      'pinyin' => 'wenchang',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'wzs' => 
    array (
      'id' => '201900',
      'province' => '海南',
      'city' => '五指山',
      'country' => '',
      'pinyin' => 'wzs',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'wuhan' => 
    array (
      'id' => '240200',
      'province' => '湖北',
      'city' => '武汉',
      'country' => '',
      'pinyin' => 'wuhan',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'wuxi' => 
    array (
      'id' => '261100',
      'province' => '江苏',
      'city' => '无锡',
      'country' => '',
      'pinyin' => 'wuxi',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'wuhai' => 
    array (
      'id' => '300400',
      'province' => '内蒙古',
      'city' => '乌海',
      'country' => '',
      'pinyin' => 'wuhai',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'wlcb' => 
    array (
      'id' => '300800',
      'province' => '内蒙古',
      'city' => '乌兰察布',
      'country' => '',
      'pinyin' => 'wlcb',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'wuzhong' => 
    array (
      'id' => '310400',
      'province' => '宁夏',
      'city' => '吴忠',
      'country' => '',
      'pinyin' => 'wuzhong',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'weifang' => 
    array (
      'id' => '330700',
      'province' => '山东',
      'city' => '潍坊',
      'country' => '',
      'pinyin' => 'weifang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'weihai' => 
    array (
      'id' => '330900',
      'province' => '山东',
      'city' => '威海',
      'country' => '',
      'pinyin' => 'weihai',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'weinan' => 
    array (
      'id' => '350600',
      'province' => '陕西',
      'city' => '渭南',
      'country' => '',
      'pinyin' => 'weinan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'wulumuqi' => 
    array (
      'id' => '380200',
      'province' => '新疆',
      'city' => '乌鲁木齐',
      'country' => '',
      'pinyin' => 'wulumuqi',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'wjq' => 
    array (
      'id' => '381700',
      'province' => '新疆',
      'city' => '五家渠',
      'country' => '',
      'pinyin' => 'wjq',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'wenzhou' => 
    array (
      'id' => '400400',
      'province' => '浙江',
      'city' => '温州',
      'country' => '',
      'pinyin' => 'wenzhou',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'wenshan' => 
    array (
      'id' => '390900',
      'province' => '云南',
      'city' => '文山',
      'country' => '',
      'pinyin' => 'wenshan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
  ),
  'X' => 
  array (
    'xuancheng' => 
    array (
      'id' => '101600',
      'province' => '安徽',
      'city' => '宣城',
      'country' => '',
      'pinyin' => 'xuancheng',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'xiamen' => 
    array (
      'id' => '150300',
      'province' => '福建',
      'city' => '厦门',
      'country' => '',
      'pinyin' => 'xiamen',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'xingtai' => 
    array (
      'id' => '210400',
      'province' => '河北',
      'city' => '邢台',
      'country' => '',
      'pinyin' => 'xingtai',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'xinxiang' => 
    array (
      'id' => '230800',
      'province' => '河南',
      'city' => '新乡',
      'country' => '',
      'pinyin' => 'xinxiang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'xuchang' => 
    array (
      'id' => '231100',
      'province' => '河南',
      'city' => '许昌',
      'country' => '',
      'pinyin' => 'xuchang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'xinyang' => 
    array (
      'id' => '231600',
      'province' => '河南',
      'city' => '信阳',
      'country' => '',
      'pinyin' => 'xinyang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'xiangfan' => 
    array (
      'id' => '240400',
      'province' => '湖北',
      'city' => '襄阳',
      'country' => '',
      'pinyin' => 'xiangfan',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'xiaogan' => 
    array (
      'id' => '241000',
      'province' => '湖北',
      'city' => '孝感',
      'country' => '',
      'pinyin' => 'xiaogan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'xianning' => 
    array (
      'id' => '241200',
      'province' => '湖北',
      'city' => '咸宁',
      'country' => '',
      'pinyin' => 'xianning',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'xiantao' => 
    array (
      'id' => '241700',
      'province' => '湖北',
      'city' => '仙桃',
      'country' => '',
      'pinyin' => 'xiantao',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'xiangtan' => 
    array (
      'id' => '250400',
      'province' => '湖南',
      'city' => '湘潭',
      'country' => '',
      'pinyin' => 'xiangtan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'xiangxi' => 
    array (
      'id' => '251500',
      'province' => '湖南',
      'city' => '湘西',
      'country' => '',
      'pinyin' => 'xiangxi',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'xuzhou' => 
    array (
      'id' => '261300',
      'province' => '江苏',
      'city' => '徐州',
      'country' => '',
      'pinyin' => 'xuzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'xinyu' => 
    array (
      'id' => '270500',
      'province' => '江西',
      'city' => '新余',
      'country' => '',
      'pinyin' => 'xinyu',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'xining' => 
    array (
      'id' => '320200',
      'province' => '青海',
      'city' => '西宁',
      'country' => '',
      'pinyin' => 'xining',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'xizhou' => 
    array (
      'id' => '340800',
      'province' => '山西',
      'city' => '忻州',
      'country' => '',
      'pinyin' => 'xizhou',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'xian' => 
    array (
      'id' => '350200',
      'province' => '陕西',
      'city' => '西安',
      'country' => '',
      'pinyin' => 'xian',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'xianyang' => 
    array (
      'id' => '350500',
      'province' => '陕西',
      'city' => '咸阳',
      'country' => '',
      'pinyin' => 'xianyang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'xizang' => 
    array (
      'id' => '370100',
      'province' => '西藏',
      'city' => '',
      'country' => '',
      'pinyin' => 'xizang',
      'grade' => '0',
      'grade_salse' => '3',
    ),
    'xinjiang' => 
    array (
      'id' => '380100',
      'province' => '新疆',
      'city' => '',
      'country' => '',
      'pinyin' => 'xinjiang',
      'grade' => '0',
      'grade_salse' => '2',
    ),
    'xianggang' => 
    array (
      'id' => '440101',
      'province' => '香港',
      'city' => '香港',
      'country' => '',
      'pinyin' => 'xianggang',
      'grade' => '0',
      'grade_salse' => '3',
    ),
    'xlglms' => 
    array (
      'id' => '301300',
      'province' => '内蒙古',
      'city' => '锡林郭勒盟',
      'country' => '',
      'pinyin' => 'xlglms',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'xishuangbanna' => 
    array (
      'id' => '391300',
      'province' => '云南',
      'city' => '西双版纳',
      'country' => '',
      'pinyin' => 'xishuangbanna',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'xam' => 
    array (
      'id' => '301200',
      'province' => '内蒙古',
      'city' => '兴安盟',
      'country' => '',
      'pinyin' => 'xam',
      'grade' => '1',
      'grade_salse' => '4',
    ),
  ),
  'Y' => 
  array (
    'yangjiang' => 
    array (
      'id' => '171500',
      'province' => '广东',
      'city' => '阳江',
      'country' => '',
      'pinyin' => 'yangjiang',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'yunfu' => 
    array (
      'id' => '171900',
      'province' => '广东',
      'city' => '云浮',
      'country' => '',
      'pinyin' => 'yunfu',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'yulinshi' => 
    array (
      'id' => '181000',
      'province' => '广西',
      'city' => '玉林',
      'country' => '',
      'pinyin' => 'yulinshi',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'yichunshi' => 
    array (
      'id' => '221400',
      'province' => '黑龙江',
      'city' => '伊春',
      'country' => '',
      'pinyin' => 'yichunshi',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'yichang' => 
    array (
      'id' => '240700',
      'province' => '湖北',
      'city' => '宜昌',
      'country' => '',
      'pinyin' => 'yichang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'yueyang' => 
    array (
      'id' => '250700',
      'province' => '湖南',
      'city' => '岳阳',
      'country' => '',
      'pinyin' => 'yueyang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'yiyang' => 
    array (
      'id' => '251100',
      'province' => '湖南',
      'city' => '益阳',
      'country' => '',
      'pinyin' => 'yiyang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'yongzhou' => 
    array (
      'id' => '251200',
      'province' => '湖南',
      'city' => '永州',
      'country' => '',
      'pinyin' => 'yongzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'yancheng' => 
    array (
      'id' => '260500',
      'province' => '江苏',
      'city' => '盐城',
      'country' => '',
      'pinyin' => 'yancheng',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'yangzhou' => 
    array (
      'id' => '260600',
      'province' => '江苏',
      'city' => '扬州',
      'country' => '',
      'pinyin' => 'yangzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'yingtan' => 
    array (
      'id' => '270700',
      'province' => '江西',
      'city' => '鹰潭',
      'country' => '',
      'pinyin' => 'yingtan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'yichun' => 
    array (
      'id' => '271000',
      'province' => '江西',
      'city' => '宜春',
      'country' => '',
      'pinyin' => 'yichun',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'yingkou' => 
    array (
      'id' => '291000',
      'province' => '辽宁',
      'city' => '营口',
      'country' => '',
      'pinyin' => 'yingkou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'yinchuan' => 
    array (
      'id' => '310200',
      'province' => '宁夏',
      'city' => '银川',
      'country' => '',
      'pinyin' => 'yinchuan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'yantai' => 
    array (
      'id' => '330800',
      'province' => '山东',
      'city' => '烟台',
      'country' => '',
      'pinyin' => 'yantai',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'yangquan' => 
    array (
      'id' => '340400',
      'province' => '山西',
      'city' => '阳泉',
      'country' => '',
      'pinyin' => 'yangquan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'yuncheng' => 
    array (
      'id' => '341000',
      'province' => '山西',
      'city' => '运城',
      'country' => '',
      'pinyin' => 'yuncheng',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'yanan' => 
    array (
      'id' => '350700',
      'province' => '陕西',
      'city' => '延安',
      'country' => '',
      'pinyin' => 'yanan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'yulin' => 
    array (
      'id' => '350900',
      'province' => '陕西',
      'city' => '榆林',
      'country' => '',
      'pinyin' => 'yulin',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'yibin' => 
    array (
      'id' => '361300',
      'province' => '四川',
      'city' => '宜宾',
      'country' => '',
      'pinyin' => 'yibin',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'yaan' => 
    array (
      'id' => '361700',
      'province' => '四川',
      'city' => '雅安',
      'country' => '',
      'pinyin' => 'yaan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'yunnan' => 
    array (
      'id' => '390100',
      'province' => '云南',
      'city' => '',
      'country' => '',
      'pinyin' => 'yunnan',
      'grade' => '0',
      'grade_salse' => '1',
    ),
    'yuxi' => 
    array (
      'id' => '390400',
      'province' => '云南',
      'city' => '玉溪',
      'country' => '',
      'pinyin' => 'yuxi',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'yanbianshi' => 
    array (
      'id' => '281000',
      'province' => '吉林省',
      'city' => '延边州',
      'country' => '',
      'pinyin' => 'yanbianshi',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'yushu' => 
    array (
      'id' => '320800',
      'province' => '青海',
      'city' => '玉树',
      'country' => '',
      'pinyin' => 'yushu',
      'grade' => '1',
      'grade_salse' => '4',
    ),
    'yili' => 
    array (
      'id' => '381400',
      'province' => '新疆',
      'city' => '伊犁',
      'country' => '',
      'pinyin' => 'yili',
      'grade' => '1',
      'grade_salse' => '3',
    ),
  ),
  'Z' => 
  array (
    'zhangzhou' => 
    array (
      'id' => '150700',
      'province' => '福建',
      'city' => '漳州',
      'country' => '',
      'pinyin' => 'zhangzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'zhangyi' => 
    array (
      'id' => '161000',
      'province' => '甘肃',
      'city' => '张掖',
      'country' => '',
      'pinyin' => 'zhangyi',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'zhuhai' => 
    array (
      'id' => '170400',
      'province' => '广东',
      'city' => '珠海',
      'country' => '',
      'pinyin' => 'zhuhai',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'zhongshan' => 
    array (
      'id' => '171200',
      'province' => '广东',
      'city' => '中山',
      'country' => '',
      'pinyin' => 'zhongshan',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'zhanjiang' => 
    array (
      'id' => '171600',
      'province' => '广东',
      'city' => '湛江',
      'country' => '',
      'pinyin' => 'zhanjiang',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'zhaoqing' => 
    array (
      'id' => '171800',
      'province' => '广东',
      'city' => '肇庆',
      'country' => '',
      'pinyin' => 'zhaoqing',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'zunyi' => 
    array (
      'id' => '190400',
      'province' => '贵州',
      'city' => '遵义',
      'country' => '',
      'pinyin' => 'zunyi',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'zhangjiakou' => 
    array (
      'id' => '210600',
      'province' => '河北',
      'city' => '张家口',
      'country' => '',
      'pinyin' => 'zhangjiakou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'zhengzhou' => 
    array (
      'id' => '230200',
      'province' => '河南',
      'city' => '郑州',
      'country' => '',
      'pinyin' => 'zhengzhou',
      'grade' => '1',
      'grade_salse' => '1',
    ),
    'zhoukou' => 
    array (
      'id' => '231800',
      'province' => '河南',
      'city' => '周口',
      'country' => '',
      'pinyin' => 'zhoukou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'zhumadian' => 
    array (
      'id' => '231900',
      'province' => '河南',
      'city' => '驻马店',
      'country' => '',
      'pinyin' => 'zhumadian',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'zhuzhou' => 
    array (
      'id' => '250300',
      'province' => '湖南',
      'city' => '株洲',
      'country' => '',
      'pinyin' => 'zhuzhou',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'zhangjiajie' => 
    array (
      'id' => '250900',
      'province' => '湖南',
      'city' => '张家界',
      'country' => '',
      'pinyin' => 'zhangjiajie',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'zhenjiang' => 
    array (
      'id' => '260900',
      'province' => '江苏',
      'city' => '镇江',
      'country' => '',
      'pinyin' => 'zhenjiang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'zhaoyangshi' => 
    array (
      'id' => '291500',
      'province' => '辽宁',
      'city' => '朝阳',
      'country' => '',
      'pinyin' => 'zhaoyangshi',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'zhongwei' => 
    array (
      'id' => '310600',
      'province' => '宁夏',
      'city' => '中卫',
      'country' => '',
      'pinyin' => 'zhongwei',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'zibo' => 
    array (
      'id' => '330400',
      'province' => '山东',
      'city' => '淄博',
      'country' => '',
      'pinyin' => 'zibo',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'zhaozhuang' => 
    array (
      'id' => '330500',
      'province' => '山东',
      'city' => '枣庄',
      'country' => '',
      'pinyin' => 'zhaozhuang',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'zigong' => 
    array (
      'id' => '360300',
      'province' => '四川',
      'city' => '自贡',
      'country' => '',
      'pinyin' => 'zigong',
      'grade' => '1',
      'grade_salse' => '2',
    ),
    'ziyang' => 
    array (
      'id' => '361900',
      'province' => '四川',
      'city' => '资阳',
      'country' => '',
      'pinyin' => 'ziyang',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'zhaotong' => 
    array (
      'id' => '390500',
      'province' => '云南',
      'city' => '昭通',
      'country' => '',
      'pinyin' => 'zhaotong',
      'grade' => '1',
      'grade_salse' => '3',
    ),
    'zhejiang' => 
    array (
      'id' => '400100',
      'province' => '浙江',
      'city' => '',
      'country' => '',
      'pinyin' => 'zhejiang',
      'grade' => '0',
      'grade_salse' => '1',
    ),
    'zhoushan' => 
    array (
      'id' => '401000',
      'province' => '浙江',
      'city' => '舟山',
      'country' => '',
      'pinyin' => 'zhoushan',
      'grade' => '1',
      'grade_salse' => '3',
    ),
  ),
);
return $zimuAreas;
?>