<?php
/**
 *  �ַ�������������
 *
 *  @author zsg <xxx@qq.com>
 *
 */

namespace Tools;
use Tools;

/**
 *  �ַ�������������
 *
 *  @author zsg <xxx@qq.com>
 */
class Strings
{
    /**
     *  UTF8��GBK ���뻥ת  ԭMiscFunc::utf8Gbk
     *
     *  @param mixed  $var ��ת�����������֧���ַ���������
     *  @param string $to  ��ת��Ŀ�����
     *
     *  @return mixed
     */
    public static function utf8Gbk($var, $to = 'GBK')
    {
        $to = strtoupper($to);
        if (is_array($var)) {
            foreach ($var as $key => $val) {
                $_key = self::utf8Gbk($key, $to);
                $var[$_key] = self::utf8Gbk($var[$key], $to);
                if ($_key != $key) {
                    unset($var[$key]);
                }
            }
            return $var;
        } elseif (is_string($var)) {
            if ($to == 'GBK') {
                $encode = mb_detect_encoding($var, array('ASCII', 'UTF-8', 'GB2312', 'GBK', 'BIG5'));
                if ($encode == 'UTF-8') {
                    $convstr = iconv('UTF-8', 'GB18030//TRANSLIT//IGNORE', $var);  
                }
                // ����ַ���ʱ�򣬿��ܴ������⡣����3��gbk����ĺ��֣�6���ֽڣ���ô�п���Ҳ��utf-8�����е�2�����֡�
                //$convstr = mb_check_encoding($var, 'UTF-8') ? iconv('UTF-8', 'GBK//IGNORE', $var) : $var;
            } else {
                $convstr = iconv('GB18030', 'UTF-8//TRANSLIT//IGNORE', $var);
                // ����ַ���ʱ�򣬿��ܴ������⡣����3��gbk����ĺ��֣�6���ֽڣ���ô�п���Ҳ��utf-8�����е�2�����֡�
                //$convstr = mb_check_encoding($var, 'GBK') ? iconv('GBK', 'UTF-8', $var) : $var;
            }
            return ($convstr === false) || ($convstr == '') ? $var : $convstr;
        }
        return $var;
    }

    /**
     * ��������ֻ���֤��
     * 
     * @param mixed $length length
     * 
     * @return string
     */
    public static function randMobileValidCode($length = 5)
    {
        $code = \Org\Util\Strings::randString($length, 1);  // 5λ������
        $codeLen = strlen($code);
        if ($codeLen < 5) {
            $code = str_repeat('0', $length - $codeLen) . $code;
        }
        return $code;
    }

    /**
     * ��������ַ���
     * 
     * @param int    $length Ҫ���ɵ�����ַ�������
     * @param string $type   ��������ͣ�0������+��Сд��ĸ��1�����֣�2��Сд��ĸ��3����д��ĸ��4�������ַ���-1������+��Сд��ĸ+�����ַ�
     * 
     * @return string
     */
    public static function randCode($length = 5, $type = 0)
    {
        $arr = array(1 => "0123456789", 2 => "abcdefghijklmnopqrstuvwxyz", 3 => "ABCDEFGHIJKLMNOPQRSTUVWXYZ", 4 => "~@#$%^&*(){}[]|");
        if ($type == 0) {
            array_pop($arr);
            $string = implode("", $arr);
        } elseif ($type == "-1") {
            $string = implode("", $arr);
        } else {
            $string = $arr[$type];
        }
        $count = strlen($string) - 1;
        $code = '';
        for ($i = 0; $i < $length; $i++) {
            $code .= $string[rand(0, $count)];
        }
        return $code;
    }

    /**
     * php ���ˣ���SQLע��
     * 
     * @param int $str ˵��
     * 
     * @return array ˵��
     */
    public static function filterStr($str)
    {
        if (empty($str)) {
            return "";
        }
        $str = trim($str);
        $str = str_replace("'", "''", $str);
        $str = str_replace("select", "sel&#101;ct", $str);
        $str = str_replace("join", "jo&#105;n", $str);
        $str = str_replace("union", "un&#105;on", $str);
        $str = str_replace("where", "wh&#101;re", $str);
        $str = str_replace("insert", "ins&#101;rt", $str);
        $str = str_replace("delete", "del&#101;te", $str);
        $str = str_replace("update", "up&#100;ate", $str);
        $str = str_replace("like", "lik&#101;", $str);
        $str = str_replace("drop", "dro&#112;", $str);
        $str = str_replace("create", "cr&#101;ate", $str);
        $str = str_replace("modify", "mod&#105;fy", $str);
        $str = str_replace("rename", "ren&#097;me", $str);
        $str = str_replace("alter", "alt&#101;r", $str);
        $str = str_replace("cast", "ca&#115;", $str);
        return $str;
    }

    /**
     * �ַ������GBKת����GBK
     *
     * @param string $string_line    �ַ���
     * @param string $get_conde_type �ַ�����
     *     
     * @return string
     */
    public static function strCodingTransform($string_line, $get_conde_type = '')
    {
        $string_line = urldecode($string_line);
        $encoding = mb_detect_encoding($string_line, array('ASCII', 'GB2312', 'GBK', 'CP936', 'UTF-8'));
        $list_allowed_code = array('GB2312', 'GBK', 'EUC-CN');
        if (!(in_array($encoding, $list_allowed_code))) {
            $string_line = iconv('UTF-8', 'GB18030//TRANSLIT//IGNORE', $string_line);
        }

        if ($get_conde_type) {
            return array($string_line, $encoding);
        } else {
            return $string_line;
        }
    }

    /**
     * ��ȡһ�����ȵ��ַ���
     * 
     * @param string $string string
     * @param int    $length number
     * @param string $dot    �ָ��
     * 
     * @return unknown|string
     */
    function cut_str($string, $length, $dot = '')
    {
        global $charset;
        if (strlen($string) <= $length) {
            return $string;
        }
        $strcut = '';
        if (strtolower($charset) == 'utf-8') {
            $n = $tn = $noc = 0;
            while ($n < strlen($string)) {
                $t = ord($string[$n]);
                if ($t == 9 || $t == 10 || (32 <= $t && $t <= 126)) {
                    $tn = 1;
                    $n++;
                    $noc++;
                } elseif (194 <= $t && $t <= 223) {
                    $tn = 2;
                    $n += 2;
                    $noc += 2;
                } elseif (224 <= $t && $t < 239) {
                    $tn = 3;
                    $n += 3;
                    $noc += 2;
                } elseif (240 <= $t && $t <= 247) {
                    $tn = 4;
                    $n += 4;
                    $noc += 2;
                } elseif (248 <= $t && $t <= 251) {
                    $tn = 5;
                    $n += 5;
                    $noc += 2;
                } elseif ($t == 252 || $t == 253) {
                    $tn = 6;
                    $n += 6;
                    $noc += 2;
                } else {
                    $n++;
                }

                if ($noc >= $length) {
                    break;
                }
            }
            if ($noc > $length) {
                $n -= $tn;
            }
            $strcut = substr($string, 0, $n);
        } else {
            for ($i = 0; $i < $length - 3; $i++) {
                $strcut .= ord($string[$i]) > 127 ? $string[$i] . $string[++$i] : $string[$i];
            }
        }
        return $strcut . $dot;
    }

    /**
     * �����ֽ��б���
     * 
     * @param int $id ID
     * 
     * @return type
     */
    public static function smtyidencode($id)
    {
        if (!is_array($id)) {
            $id = array($id);
        }
        extract($id);

        $key1 = 323982;
        $key2 = 329076;

        $str1 = $id[0] + $key1;
        $str2 = $id[0] + $key2;

        return $str1 . '' . $str2;
    }
    /**
     * �����ֽ��н���
     * 
     * @param int $id ID
     * 
     * @return type
     */
    public static function id_decode($id)
    {
        $key1 = 323982;
        $key2 = 329076;
    
        $len = strlen($id) / 2;
        $str1 = substr($id, 0, $len);
        $str2 = substr($id, $len);
    
        $str1 = $str1 - $key1;
        $str2 = $str2 - $key2;
    
        if ($str1!=$str2) {
            return '-1';
        } else {
            return $str1;
        }
    }

    /**
     * ��������ַ�����������
     * 
     * @param string $str1   �ַ���1
     * @param string $str2   �ַ���2
     * @param int    $length ��ȡ�ؼ�����
     * 
     * @return float
     */
    public static function checksamerate($str1, $str2, $length = 10)
    {
        if (!$str1 || !$str2) {
            return 0;
        }
        $searchstr = array(' ', ',', '/', "\n", "\r", '.', '��', '��', '?', '��');
        $str1 = str_replace($searchstr, "", $str1);
        $str2 = str_replace($searchstr, "", $str2);

        require_once 'include/thrift_rpc/Rpc/Client.class.php';
        rpc_load_module('Keyword');
        $rpc = new \KeywordModule();
        $response1 = $rpc->getKeywords($str1, $length);
        $keywords1 = array();
        if ($response1->isSuccess()) {
            $data = $response1->getData();
            if ($data['data']) {
                $keywords1 = $data['data'];
            }
        }
        $response2 = $rpc->getKeywords($str2, $length);
        $keywords2 = array();
        if ($response2->isSuccess()) {
            $data = $response2->getData();
            if ($data['data']) {
                $keywords2 = $data['data'];
            }
        }
        if ($keywords1 && $keywords2) {
            $allkeywords = array_unique(array_merge($keywords1, $keywords2));
            $alllength = count($allkeywords);
            $samekeywords = array_intersect($keywords2, $keywords1);
            $samelength = count($samekeywords);
        } else {
            return 0;
        }
        // echo '�ַ�1�ִʣ�<br>';
        // echo implode(',', $keywords1).'<br>';
        // echo '�ַ�2�ִʣ�<br>';
        // echo implode(',', $keywords2).'<br>';       
        // echo '�ִ�������<br>';
        // echo $alllength.'��|';
        // echo implode(',', $allkeywords).'<br>';
        // echo '��ͬ�ִ�����<br>';
        // echo $samelength.'��|';
        // echo implode(',', $samekeywords).'<br>';
        return round($samelength / $alllength, 2);
    }

    /**
     * �ȣԣͣ������ı���ȡ�ַ�
     * 
     * @param string $str     HTML����
     * @param int    $start   ��ʼλ��
     * @param int    $len     ��ȡ����
     * @param string $charset ����
     * 
     * @return string
     */
    public static function cutHTMLStr($str, $start = 0, $len = 30, $charset = "GBK")
    {
        $str = htmlspecialchars_decode($str);
        $str = strip_tags($str);
        $space = array(' ', '��', '\t', '\n', '\r', '&nbsp;', '&nbsp');
        $null  = array('');
        $str   = str_replace($space, $null, $str); 
        $str = preg_replace('/\s\s+/', '', $str);
        $str = trim($str);
        $str = mb_substr($str, $start, $len, $charset);
        return $str;
    }
    
    /**
     * ��ȡ�ַ�
     * 
     * @param type $str      �ַ���
     * @param type $start    ��ʼ
     * @param type $length   ����
     * @param type $encoding ����
     * 
     * @return type
     */
    public static function UIsubstr($str, $start = 0, $length = 10000, $encoding = 'gbk')
    {
        $str = str_replace(array('&lt;', '&gt;', '&amp;', '&nbsp;'), array('<', '>', '&', ' '), $str);
        
        return mb_substr(strip_tags($str), $start, $length, $encoding);
    }
    
    /**
     * json���ݴ���
     * 
     * @param array $data ����
     * 
     * @return array
     */
    public static function mb_unserialize($data)
    {
        //�������޸�
        $test = unserialize(preg_replace('!s:(\d+):"(.*?)";!se', '"s:".strlen("$2").":\"$2\";"', $data));
        if (empty($test)) {
            $test = unserialize(preg_replace_callback('|s\:(\d+)\:"(.*?)"|', function ($matches){ return "s:".strlen($matches[2]).":\"$matches[2]\""; }, $data));
        } 
        if (!$test) {
            $test = unserialize($data);
        }
        return $test;
        
    }
}
