<?php
/**
 *  ���󱨾���
 *
 *  @author YateSun <sunyate@wanglv.com>
 *
 */
namespace Tools;
use Tools;
/**
 *  ���󱨾���
 *
 *  @author YateSun <sunyate@wanglv.com>
 */
class Error
{
    /**
     * �������ʱ��
     * 
     * @return boolean
     */
    public static function time()
    {
        list($usec, $sec) = explode(" ", microtime());
        return ceil(($sec + $usec)*1000);
    }

    /**
     * ����ʱ����
     * 
     * @param int $name       ��������
     * @param int $start_time ��ʼʱ��
     * 
     * @return boolean
     */
    public static function end($name, $start_time = 0)
    {
        $time = self::time() - $start_time;
        if ($time >= 1000) {
            //��¼����
            self::postError($name, $time);
        }
    }
    /**
     * Post����
     * 
     * @param string $name      ��������
     * @param int    $runtime   ִ��ʱ��
     * @param string $data_name ��������
     * @param int    $typeid    �������ͣ��Ƿ�ɹ�
     * 
     * @return boolean
     */
    public static function postError($name, $runtime, $data_name = 'findlaw_log_net',$typeid = 0)
    {
        $ips = explode('.', $_SERVER['SERVER_ADDR']);
        $hostname = end(explode('-', gethostname()));
        $ip = $ips[0].'.'.$ips[1].'.'.$ips[2].'.'.$hostname;
        $error_url = explode('findlaw.cn', $_SERVER['SCRIPT_FILENAME'], 2);
        $error_url = $error_url[1].'?'.$_SERVER['QUERY_STRING'];
        $data = array(
            'ip' => $ip,
            'data_name' => $data_name,
            'name' => $name,
            'runtime' => $runtime,
            'addtime' => self::time(),
            'errorUrl' => $error_url
        );
        if ($data_name == 'findlaw_log_rpc') {
            $data['typeid'] = $typeid;
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "http://172.16.3.153:8086/api/v1/custom_report");
        curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT_MS, 200);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('org:1002'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        //curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        //curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_exec($ch);
        curl_close($ch);
    }

    /**
     * ���ִ��curl_exec
     * 
     * @param resource $ch ��Դ
     * 
     * @return boolean
     */
    public static function curl_exec($ch)
    {
        $url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        $start = self::time();
        $data = curl_exec($ch);
        $time = curl_getinfo($ch, CURLINFO_TOTAL_TIME);
        $end = self::time() - $start;
        $microtime = ceil($time*1000);
        curl_close($ch);
        //��������ϲ�����������ʱ��ȷ���Ƿ���Ҫ��¼
        if ($microtime >= 1000) {
            //��¼����
            self::postError($url, $microtime);
        }
        if ($_GET['debug'] == 'rpcExecTime') {
            echo 'Curl:'.$url.'|��Ӧʱ��'.$time.'|��ʱ��'.$end.'ms<br />';
        }
        return $data;
    }

    /**
     * Get����
     * 
     * @param string $url �����ַ
     * 
     * @return boolean
     */
    public static function url_get($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        //curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $result = curl_exec($ch);
        $time = curl_getinfo($ch, CURLINFO_TOTAL_TIME);
        $microtime = ceil($time*1000);
        curl_close($ch);
        //��������ϲ�����������ʱ��ȷ���Ƿ���Ҫ��¼
        if ($microtime >= 1000) {
            //��¼����
            self::postError($url, $microtime);
        }
        if ($_GET['debug'] == 'rpcExecTime') {
            echo 'Get:'.$url.'|��Ӧʱ��'.$time.'<br />';
        }
        curl_close($ch);
        return $result;
    }

    /**
     * php redis ������(�����ר�ô���澯)
     *
     * @param string $string ��Ƭ����
     *
     * @return type
     */
    public static function redis($string = '')
    {
        $hostname = explode('-', gethostname())[0];
        if ($hostname == 'gz') {
            $server = ['192.168.1.114', 6522];
        } else {
            $server = ['172.16.1.114', 6522];
        }
        $redis = new \Redis();
        $time = time();
        if ($redis->connect($server[0], $server[1], 3) && (time()-$time < 3)) {
            return $redis;
        } else {
            return false;
        }
    }

    /**
     * ���ز���¼�б�
     *
     * @param string $key     �б�����
     * @param string $value   ��¼ֵ
     *
     * @return type
     */
    public static function sAdd($key, $value)
    {
        $redis = self::redis();
        $check = $redis->sAdd($key.':set', $value);
        if ($check) {
            $redis->rPush($key, $value);
        }
    }
}
?>
