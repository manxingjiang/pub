<?php
/**
 * ����ͳ�� -- �ͻ��˽ӿ� -- �������������
 *
 * @author ¬�ٲ� <2673861839@qq.com>
 */
namespace Tools\Thrift;

/**
 * �������������
 *
 * @author ¬�ٲ� <2673861839@qq.com>
 *
 * @date 2013-7-15
 *
 */
class RpcRequestParam
{
    /**
     * �����������
     *
     * @param type $header ����ͷ
     * @param type $params ����
     * @param type $config ����
     *
     * @return type
     *
     * @throws RpcException
     */
    public static function doBuild($header, $params = array(), $config = array())
    {
        if (empty($config['TOKEN']) || empty($config['CLIENTID'])) {
            throw new RpcException('RPC: token ���� clientid ����Ϊ�գ�');
        }

        $return = array();

        if (!isset($header[RpcConstant::CMD]) || empty($header[RpcConstant::CMD])) {
            throw new RpcException('RPC: ����cmd����Ϊ�գ�');
        }

        $header[RpcConstant::TIME] = isset($header[RpcConstant::TIME]) ? $header[RpcConstant::TIME] : time();
        $header[RpcConstant::VERSION] = isset($header[RpcConstant::VERSION]) ? $header[RpcConstant::VERSION] : '';
        $header[RpcConstant::CHARSET] = isset($header[RpcConstant::CHARSET]) ? strtolower($header[RpcConstant::CHARSET]) : 'gbk';
        $header[RpcConstant::DEBUG] = isset($header[RpcConstant::DEBUG]) ? $header[RpcConstant::DEBUG] : 0;
        $header[RpcConstant::NONCE] = self::_genNonce();
        $header[RpcConstant::CLIENTID] = intval($config['CLIENTID']);
        $header[RpcConstant::SIGNATURE] = self::_genSignature($header, $config['TOKEN']);

        $return[RpcConstant::HEADER] = $header;
        $return[RpcConstant::PARAMS] = $params;
        return RpcUtils::json_convert_encoding($return, $header[RpcConstant::CHARSET]);
    }

    /**
     * ���ɻ�����
     *
     * @return Integer
     */
    protected static function _genNonce()
    {
        return mt_rand(10000, 99999);
    }

    /**
     * ����ǩ��
     *
     * @param type $header ����ͷ����
     * @param type $token  ����
     *
     * @return String
     */
    protected static function _genSignature($header, $token)
    {
        return sha1($token. $header[RpcConstant::TIME]. $header[RpcConstant::NONCE]);
    }

}

?>
