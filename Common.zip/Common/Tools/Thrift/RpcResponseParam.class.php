<?php
/**
 * ����ͳ�� -- �ͻ��˽ӿ� -- ��Ӧ����������
 *
 * @author ¬�ٲ� <2673861839@qq.com>
 */
namespace Tools\Thrift;

/**
 * ��Ӧ����������
 *
 * PHP version "5++"
 *
 * @author ¬�ٲ� <2673861839@qq.com>
 *
 * @date 2013-7-15
 *
 */
class RpcResponseParam
{
    protected $_response = null;    //ԭʼ����
    protected $_uResponse = null;   //�����������

    /**
     * ��ʼ��
     *
     * @param type $response ��Ӧ��
     *
     * @return void;
     */
    public function __construct($response)
    {
        $this->_response = $response;
        $this->unBuild();
    }

    /**
     * ��ȡ��Ӧͷ��Ϣ
     *
     * @return Array;
     */
    public function getHeader()
    {
        return @$this->_uResponse[RpcConstant::S_HEADER];
    }

    /**
     * ��ȡ��Ӧ״̬
     *
     * @return Integer;
     */
    public function getState()
    {
        return @$this->_uResponse[RpcConstant::S_HEADER][RpcConstant::S_STATE];
    }

    /**
     * ��ȡ������Ϣ
     *
     * @return String;
     */
    public function getDebugInfo()
    {
        return @$this->_uResponse[RpcConstant::S_HEADER][RpcConstant::S_DEBUG_INFO];
    }

    /**
     * ��ȡ������Ϣ
     *
     * @return String;
     */
    public function getDesc()
    {
        return @$this->_uResponse[RpcConstant::S_HEADER][RpcConstant::S_DESC];
    }

    /**
     * ��ȡ����
     *
     * @return mix
     */
    public function getData()
    {
        return @$this->_uResponse[RpcConstant::S_DATA];
    }

    /**
     * ��ȡ����
     *
     * @return mix
     */
    public function getTotal()
    {
        return @$this->_uResponse[RpcConstant::S_TOTAL];
    }

    /**
     * �Ƿ�ɹ�
     *
     * @return Boolean
     */
    public function isSuccess()
    {
        $state = $this->_uResponse[RpcConstant::S_HEADER][RpcConstant::S_STATE];
        if ($state == 200  || $state == 204) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * ��ȡԭʼ��Ӧ����
     *
     * @return String
     */
    public function getResponse()
    {
        return $this->_response;
    }

    /**
     * ��ȡ�����������
     *
     * @return Array
     */
    public function getUResponse()
    {
        return $this->_uResponse;
    }

    /**
     *  ��������
     *
     * @return void
     */
    public function unBuild()
    {
        $_response = RpcUtils::json_convert_decoding($this->_response, 'utf-8');

        if (!$_response) {
            throw new RpcException('RPC: ��Ӧ���ݳ��������ݰ�Ϊ: '. $this->_response);
        }

        if ($_response[RpcConstant::S_HEADER][RpcConstant::S_CHARSET] != 'utf-8') {
            $_response = RpcUtils::convert_encoding(
                $_response, 'utf-8', $_response[RpcConstant::S_HEADER][RpcConstant::S_CHARSET]
            );
        }
        $this->_uResponse = $_response;
    }

}

?>
