<?php
/**
 * Thrift�ͻ��˿����ļ�
 *
 * @author Mijon <mijon@findlaw.cn>
 * @date 2015-1-30
 */
namespace Tools\Thrift;

use \Tools\Thrift\RpcException;
use \Tools\Thrift\RpcConstant;
use \Tools\Thrift\RpcRequestParam;
use \Tools\Thrift\RpcResponseParam;
use \Tools\Thrift\RpcUtils;

define('RPC_ROOT', dirname(__FILE__));
if (defined('APP_DEBUG') && APP_DEBUG) { //������Ŀ״̬�����ӿ�����
    define('THRIFT_RPC_DEBUG', 1);
}

// ����Thrift����ļ�
vendor('Thrift.Thrift');
vendor('Thrift.transport.TSocketPool');
vendor('Thrift.transport.TFramedTransport');
vendor('Thrift.protocol.TBinaryProtocol');
vendor('Thrift.gen-php.wydaservice.WyDaService');

/**
 * Rpc�ͻ��˵���
 *
 * @author Mijon <mijon@findlaw.cn>
 *
 * @date 2015-1-30
 *
 */
class RpcClient
{
    protected $_defaultConfig = array(
        'SERVER'          => array('localhost', 0), //����������:�˿�
        'DEBUG'         => 1,           //�Ƿ����
        'DEBUG_HANDLER'  => array('RpcUtils', 'debug_log'),  //���Դ�������
        'READ_RETRIES'   => 3,    //�ض�����
        'NUM_RETRIES'    => 5,    //����������
        'RETRY_INTERVAL' => 120,  //���Լ��ʱ��
        'RANDOMIZE'     => 1,    //�Ƿ����host����
        'RECV_TIMEOUT'   => 5000, //�������ݳ�ʱʱ�䣨��λ�����룩
        'SEND_TIMEOUT'   => 2000, //�������ݳ�ʱʱ�䣨��λ�����룩
        'PERSIST'       => 0,    //�Ƿ���������
        'TOKEN'         => '',   //ǩ��token
        'CLIENTID'      => 0,    //�ͻ���id
    );
    protected $_defaultConfigSet = false;
    protected $_config = array();
    protected $_trans = null;
    protected $_client = null;

    /**
     * ��ʼ������
     *
     * @param string $name ��������
     *
     * @return void
     */
    public function __construct($name = '')
    {
        if ($name != '') {
            $name = '_'.$name;
        }
        $name = 'RPC_THRIFT'.$name;

        $config = C($name);
        $this->setConfig($config);
    }

    /**
     * ��ȡ����
     *
     * @return void
     */
    public function getConfig()
    {
        return $this->_config;
    }

    /**
     * ��������
     *
     * @param Array $config ����
     *
     * @return void
     */
    public function setConfig($config = array())
    {
        if (!$this->_defaultConfigSet) {
            foreach ($this->_defaultConfig as $k => $v) {
                $this->_config[$k] = $v;
            }

            $this->_defaultConfigSet = true;
        }

        foreach ($config as $k => $v) {
            if (empty($k)) {
                continue;
            }
            $k = strtoupper($k);
            if (array_key_exists($k, $this->_defaultConfig)) {
                $this->_config[$k] = $v;
            } else {
                throw new RpcException(sprintf('RPC: [%s]�����ò������ã���ע�⣡', $k));
            }
        }
    }

    /**
     * ��socket
     *
     * @return void
     */
    public function open()
    {
        $host = array($this->_config['SERVER'][0][0]);
        $port = array($this->_config['SERVER'][0][1]);
        $this->_trans = new \TSocketPool($host, $port, $this->_config['PERSIST'], $this->_config['DEBUG_HANDLER']);

        $this->_trans->setDebug($this->_config['DEBUG']);
        $this->_trans->setNumRetries($this->_config['NUM_RETRIES']);
        $this->_trans->setRetryInterval($this->_config['RETRY_INTERVAL']);
        $this->_trans->setRandomize($this->_config['RANDOMIZE']);
        $this->_trans->setRecvTimeout($this->_config['RECV_TIMEOUT']);
        $this->_trans->setSendTimeout($this->_config['SEND_TIMEOUT']);

        $this->_trans->open();
        $protocol = new \TBinaryProtocol(new \TFramedTransport($this->_trans));
        $this->_client= new \WyDaServiceClient($protocol);
    }

    /**
     * ��ȡ����
     *
     * @param Array $header ����ͷ����
     * @param Array $params ����
     *
     * @return void
     */
    public function getRequest($header, $params = array())
    {
        return RpcRequestParam::doBuild($header, $params, $this->_config);
    }

    /**
     * ��ȡ��Ӧ
     *
     * @param Array $header ����ͷ����
     * @param Array $params ����
     *
     * @return RpcResponseParam
     */
    public function getResponse($header, $params = array())
    {
        $requestParam = $this->getRequest($header, $params);
        //echo $requestParam;exit();
        for ($i = 0; $i < $this->_config['READ_RETRIES']; $i ++) {
            try {
                $response = $this->_client->getdata($requestParam);
                break;
            } catch (TTransportException $e) {
                $this->close();
                $this->open();
                //�����һ���ض���ʧ��ʱ��ֱ���׳��쳣
                if ($i == $this->_config['READ_RETRIES'] - 1) {
                    throw new TTransportException($e->getMessage());
                }
            }
        }

        return new RpcResponseParam($response);
    }

    /**
     * �ر�
     *
     * @return void
     */
    public function close()
    {
        $this->_trans->close();
    }

    /**
     * ����ʱ�ر�socket
     *
     * @return void
     */
    public function __destruct()
    {
        //$this->close();
    }

}

?>
