<?php
/**
 *  SQL������
 *
 *  @author zsg <xxx@qq.com>
 *
 */
/**
 *  SQL������
 *
 *  @author zsg <xxx@qq.com>
 */
namespace Tools;
use Tools;
class Sql 
{    

    /**
     * ����sql
     * 
     * @param unknown $arr arr
     * @return string
     */
    public static function update_sql($arr)
    {
        $tmparr = array();
        foreach ($arr as $k=>$v) {
            $tmparr[] = "$k='$v'";
        }
        return implode(',', $tmparr);
    }
    
    /**
     * ����sql
     * 
     * @param unknown $arr arr
     * @return string
     */
    public static function insert_sql($arr)
    {
        $keys = array();
        $vals = array();
        foreach ($arr as $k=>$v) {
            $keys[] = $k;
            $vals[] = $v;
        }
        return ' ( '. implode(',', $keys) .') values (\'' . implode('\',\'', $vals) . '\' ) ';
    }
    
    /**
     * �������Sql��ע����䡣
     *
     * @param str $Sql_Str    sql
     * $param int $returntype ��������
     * 
     * @return boolean
     */
    public static function sql_check($Sql_Str)
    {
        
        $check=preg_match('/select|insert|update|delete|\'|\\*|\*|\.\.\/|\.\/|union|into|load_file|outfile/i', $Sql_Str);

        if ($check) {
            echo '<script language="JavaScript">alert("ϵͳ���棺\n\n�벻Ҫ�����ڲ����а����Ƿ��ַ���");</script>';
            exit();
        } else {
            return $Sql_Str;
        }
    }
    
    /**
     * php ���ˣ���SQLע��
     * 
     * @param int $str ˵��
     * 
     * @return array ˵��
     */
    public function filterStr($str)
    {
        if(empty($str)) return "";
        $str=trim($str);
        $str=str_replace("'","''",$str);
        $str=str_replace("select","sel&#101;ct",$str);
        $str=str_replace("join","jo&#105;n",$str);
        $str=str_replace("union","un&#105;on",$str);
        $str=str_replace("where","wh&#101;re",$str);
        $str=str_replace("insert","ins&#101;rt",$str);
        $str=str_replace("delete","del&#101;te",$str);
        $str=str_replace("update","up&#100;ate",$str);
        $str=str_replace("like","lik&#101;",$str);
        $str=str_replace("drop","dro&#112;",$str);
        $str=str_replace("create","cr&#101;ate",$str);
        $str=str_replace("modify","mod&#105;fy",$str);
        $str=str_replace("rename","ren&#097;me",$str);
        $str=str_replace("alter","alt&#101;r",$str);
        $str=str_replace("cast","ca&#115;",$str);
        return $str;
    }
}
