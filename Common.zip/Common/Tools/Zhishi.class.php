<?php
/**
 *  ֪ʶ��
 *
 *  @author luohaitao <luohaitao@findlaw.cn>
 *
 */
/**
 *  ֪ʶ��
 *
 *  @author luohaitao <luohaitao@findlaw.cn>
 */
namespace Tools;

class Zhishi
{
    /**
     * ֪ʶ���� pcվ �� mվ��Ӧ�Ĺ���Ϊ 
     * http://china.findlaw.cn/requset_uri -> http://m.findlaw.cn/info/requset_uri
     * �� requset_uri ��������Ŀ¼��ͷ������
     * http://china.findlaw.cn/info/requset_uri -> http://m.findlaw.cn/info/requset_uri
     *
     * @return array
     */
    public static function getInfoDirList($postObj, $contentStr)
    {
        return array(
            'topic','news','falvchangshi','hshs','wstz','chanquan','fangdichan',
            'gongsifalv','jiaotongshigu','hetongfa','yiliao','laodongfa',
            'jingjifa','quanwen','shpc','zhixing','xfwq','zhengju'
        );
    }
}