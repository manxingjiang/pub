<?php
/**
 *	java�м�����÷�װ
 */
namespace Tools;
use Tools;

require_once(COMMON_PATH . 'JavaRpc/RpcCallFactory.php');

class Rpc
{
    /**
     * ��������
     *
     * @param unknown $args args
     *
     * @return multitype:multitype: Ambigous <NULL, unknown> unknown
     */
    public static function parseargs($args)
    {
        $cmd_arg = $args[0];
        $data = array_slice($args, 1);
        $header = null;
        if (is_array($cmd_arg)) {
            $cmd = $cmd_arg[0];
            $header = isset($cmd_arg[1]) ? $cmd_arg[1] : null;
        } else {
            $cmd = $cmd_arg;
        }
        $data = array_slice($args, 1);
        return array($cmd, $header, $data);
    }

    /**
     * ʹ��Ĭ������ִ��rpc����
     *
     * @return Ambigous <NULL, mixed, unknown, string>
     */
    public static function getData()
    {
        list($cmd, $header, $data) = self::parseargs(func_get_args());
        return \RpcCallFactory::getData($cmd, $header, $data);
    }
    /**
     * ʹ��Ĭ������ִ��rpc����
     *
     * @return Ambigous <NULL, mixed, unknown, string>
     */
    public static function getResponse()
    {
        list($cmd, $header, $data) = self::parseargs(func_get_args());
        return \RpcCallFactory::getResponse($cmd, $header, $data);
    }

    /**
     * ʹ��uc����ִ��rpc����
     *
     * @return Ambigous <NULL, mixed, unknown, string>
     */
    public static function getUCData()
    {
        list($cmd, $header, $data) = self::parseargs(func_get_args());
        return \RpcCallFactory::getData($cmd, $header, $data, true, 'GBK', 'uc_config_rpc');
    }
    /**
     * ʹ��uc����ִ��rpc����
     *
     * @return Ambigous <NULL, mixed, unknown, string>
     */
    public static function getUCResponse()
    {
        list($cmd, $header, $data) = self::parseargs(func_get_args());
        return \RpcCallFactory::getResponse($cmd, $header, $data, 'GBK', 'uc_config_rpc');
    }

    /**
     * ʹ��click����ִ��rpc����
     *
     * @return Ambigous <NULL, mixed, unknown, string>
     */
    public static function getClickData()
    {
        list($cmd, $header, $data) = self::parseargs(func_get_args());
        return \RpcCallFactory::getData($cmd, $header, $data, true, 'GBK', 'click_config_rpc');
    }
    /**
     * ʹ��click����ִ��rpc����
     *
     * @return Ambigous <NULL, mixed, unknown, string>
     */
    public static function getClickResponse()
    {
        list($cmd, $header, $data) = self::parseargs(func_get_args());
        return \RpcCallFactory::getResponse($cmd, $header, $data, 'GBK', 'click_config_rpc');
    }

    /**
     * ʹ��shortlink����ִ��rpc����
     *
     * @return Ambigous <NULL, mixed, unknown, string>
     */
    public static function getShortlinkData()
    {
        list($cmd, $header, $data) = self::parseargs(func_get_args());
        return \RpcCallFactory::getData($cmd, $header, $data, true, 'GBK', 'shortlink_config_rpc');
    }
    /**
     * ʹ��shortlink����ִ��rpc����
     *
     * @return Ambigous <NULL, mixed, unknown, string>
     */
    public static function getShortlinkResponse()
    {
        list($cmd, $header, $data) = self::parseargs(func_get_args());
        return \RpcCallFactory::getResponse($cmd, $header, $data, 'GBK', 'shortlink_config_rpc');
    }

}
